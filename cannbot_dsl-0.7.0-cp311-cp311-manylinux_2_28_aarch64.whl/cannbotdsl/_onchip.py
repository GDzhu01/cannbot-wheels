# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Shared on-chip trace state and shape/capacity validation."""

from __future__ import annotations

from contextvars import ContextVar

import cannbotdsl._mlir.ir as ir
from cannbotdsl.core.utils.type_checks import is_exact_instance


class _OnChipTraceState:
    """Per-function storage modes; hardware IDs are allocated by MLIR."""

    def __init__(self):
        self.space_roots = {}
        self.automatic_spaces = set()
        self.has_rewind = False

    def use_automatic_space(self, mem_loc, owner):
        if mem_loc in self.space_roots:
            raise ValueError(
                f"ordinary {mem_loc.name} {owner} cannot mix with manual "
                f"{mem_loc.name}.view() storage in the same kernel"
            )
        self.automatic_spaces.add(mem_loc)


_CURRENT_ONCHIP_TRACE: ContextVar[_OnChipTraceState | None] = ContextVar(
    "cannbotdsl_current_onchip_trace", default=None
)


def _set_current_onchip_trace(state):
    return _CURRENT_ONCHIP_TRACE.set(state)


def _reset_current_onchip_trace(token):
    _CURRENT_ONCHIP_TRACE.reset(token)


def _current_onchip_trace():
    state = _CURRENT_ONCHIP_TRACE.get()
    if state is None:
        raise RuntimeError("Buffer and Channel require an active CANNBotDSL lowering context")
    return state


def _normalize_shape_capacity(shape, capacity, *, owner):
    """Validate a flat logical shape and its static allocation capacity."""
    if not isinstance(shape, tuple):
        raise TypeError(f"{owner} shape must be a flat tuple of positive ints or i64 SSA values")
    if not shape:
        raise ValueError(f"{owner} shape must not be empty")

    has_dynamic = False
    for index, dim in enumerate(shape):
        if is_exact_instance(dim, int):
            if dim <= 0:
                raise ValueError(f"{owner} shape[{index}] must be positive, got {dim}")
            continue
        if isinstance(dim, ir.Value):
            dim_type = dim.type
            if not (isinstance(dim_type, ir.IntegerType) and dim_type.width == 64 and dim_type.is_signless):
                raise TypeError(
                    f"{owner} shape[{index}] SSA value must have canonical signless i64 type, got {dim_type}"
                )
            has_dynamic = True
            continue
        raise TypeError(
            f"{owner} shape[{index}] must be a positive Python int or i64 SSA value, got {type(dim).__name__}"
        )

    if capacity is None:
        if has_dynamic:
            raise TypeError(f"{owner} dynamic shape requires a static capacity tuple")
        capacity = shape
    if not isinstance(capacity, tuple):
        raise TypeError(f"{owner} capacity must be a flat tuple of positive ints")
    if len(capacity) != len(shape):
        raise ValueError(f"{owner} capacity rank {len(capacity)} does not match shape rank {len(shape)}")
    for index, (dim, bound) in enumerate(zip(shape, capacity)):
        if not is_exact_instance(bound, int):
            raise TypeError(f"{owner} capacity[{index}] must be a positive Python int, got {type(bound).__name__}")
        if bound <= 0:
            raise ValueError(f"{owner} capacity[{index}] must be positive, got {bound}")
        if is_exact_instance(dim, int) and dim > bound:
            raise ValueError(f"{owner} shape[{index}] ({dim}) exceeds capacity[{index}] ({bound})")
    return shape, capacity, has_dynamic
