# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Scalar SIMT APIs for use inside ``with vf(mode="simt")``.

Use ordinary Python arithmetic and control flow on the returned scalars.
"""

import builtins

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir
from cannbotdsl.core.contracts.elements import (
    normalize_scalar_for_storage,
    wrap_produced_simt_scalar,
)
from cannbotdsl.core.ir_transport import unwrap_operand
from cannbotdsl.core.utils.type_checks import is_exact_instance, is_exact_instance_of
from cannbotdsl.lang.vf import _CURRENT_VF, _current_vf_mode
from cannbotdsl.types._short_vector import ShortVector, vector_info
from cannbotdsl.types.defs import RoundingMode

__all__ = [
    "RoundingMode",
    "thread_idx",
    "thread_dim",
    "block_idx",
    "grid_dim",
    "warp_size",
    "cast",
    "bitcast",
    "sqrt",
    "rsqrt",
    "exp",
    "log",
    "abs",
    "vsin",
    "vcos",
    "vtan",
    "vtanh",
    "vsqrt",
    "vrsqrt",
    "vexp",
    "vlog",
    "vabs",
    "vfloor",
    "vceil",
    "vtrunc",
    "vexp2",
    "vexp10",
    "vlog2",
    "vlog10",
    "vrcp",
    "vrint",
    "vneg",
    "vadd",
    "vsub",
    "vmul",
    "vdiv",
    "vfmin",
    "vmax",
    "veq",
    "vne",
    "vle",
    "vge",
    "vlt",
    "vgt",
    "vequ",
    "vneu",
    "vleu",
    "vgeu",
    "vltu",
    "vgtu",
    "vbeq",
    "vbne",
    "vble",
    "vbge",
    "vblt",
    "vbgt",
    "veq_mask",
    "vne_mask",
    "vle_mask",
    "vge_mask",
    "vlt_mask",
    "vgt_mask",
    "vequ_mask",
    "vneu_mask",
    "vleu_mask",
    "vgeu_mask",
    "vltu_mask",
    "vgtu_mask",
    "vbeq_mask",
    "vbne_mask",
    "vble_mask",
    "vbge_mask",
    "vblt_mask",
    "vbgt_mask",
    "visnan",
    "vmax_nan",
    "vmin_nan",
    "vfma",
    "vfma_relu",
    "fma_relu",
    "vcmadd",
    "vpack_high",
    "vpack_low",
    "vcast",
    "vbitcast",
    "make_short_vector",
    "syncthreads",
    "threadfence",
    "threadfence_block",
    "dcci_single",
    "dcci_entire_out",
    "l2cache_load",
    "l2cache_store",
    "l2cache_vload",
    "l2cache_vstore",
    "nop",
    "lane_idx",
    "lanemask_eq",
    "lanemask_le",
    "lanemask_lt",
    "lanemask_ge",
    "lanemask_gt",
    "all",
    "any",
    "ballot",
    "activemask",
    "shfl",
    "shfl_up",
    "shfl_down",
    "shfl_xor",
    "reduce_add",
    "reduce_max",
    "reduce_min",
    "sin",
    "cos",
    "tan",
    "tanh",
    "floor",
    "ceil",
    "trunc",
    "exp2",
    "exp10",
    "log2",
    "log10",
    "pow",
    "atan2",
    "fmin",
    "fmax",
    "fmod",
    "add",
    "hadd",
    "hradd",
    "sub",
    "mul",
    "mul_cast",
    "div",
    "neg",
    "max",
    "min",
    "eq",
    "ne",
    "le",
    "ge",
    "lt",
    "gt",
    "rcp",
    "fma",
    "mulhi",
    "brev",
    "clz",
    "ffs",
    "popc",
    "byte_perm",
    "fdivide",
    "sad",
    "mul24",
    "modf",
    "remquo",
    "frexp",
    "ldexp",
    "nan",
    "sincos",
    "sincospi",
    "norm3",
    "rnorm3",
    "norm4",
    "rnorm4",
    "norm",
    "rnorm",
    "logb",
    "ilogb",
    "cyl_bessel_i0",
    "cyl_bessel_i1",
    "normcdf",
    "j0",
    "j1",
    "jn",
    "y0",
    "y1",
    "yn",
    "lround",
    "llround",
    "lrint",
    "llrint",
    "round",
    "rint",
    "normcdfinv",
    "isfinite",
    "isnan",
    "isinf",
    "fdim",
    "remainder",
    "copysign",
    "nearbyint",
    "nextafter",
    "scalbn",
    "scalbln",
    "tanpi",
    "atan",
    "atanh",
    "cosh",
    "cospi",
    "asin",
    "acos",
    "acosh",
    "sinh",
    "sinpi",
    "asinh",
    "expm1",
    "hypot",
    "rhypot",
    "log1p",
    "cbrt",
    "rcbrt",
    "erf",
    "erfc",
    "erfinv",
    "erfcinv",
    "erfcx",
    "tgamma",
    "lgamma",
    "atomic_add",
    "atomic_sub",
    "atomic_exch",
    "atomic_max",
    "atomic_min",
    "atomic_and",
    "atomic_or",
    "atomic_xor",
    "atomic_inc",
    "atomic_dec",
    "atomic_cas",
    "vatomic_add",
    "vatomic_sub",
    "vatomic_exch",
    "vatomic_max",
    "vatomic_min",
    "vatomic_and",
    "vatomic_or",
    "vatomic_xor",
    "vatomic_inc",
    "vatomic_dec",
    "vatomic_cas",
]


def _wrap_simt_scalar(value, *, storage_type=None):
    return wrap_produced_simt_scalar(value, storage_type=value.type if storage_type is None else storage_type)


def _require_simt(api):
    if _current_vf_mode() != "simt":
        raise RuntimeError(f"simt.{api} requires with vf(mode='simt')")


def _rounding_attr(rounding):
    """Build the registered AscEnum attribute for an AscSIMT op."""
    return ir.AttrBuilder.get("AscRoundingModeEnum")(rounding, context=ir.Context.current)


def _create_simt_cast(target, value, rounding, saturate_value):
    return ir.Operation.create(
        "ascsimt.cast",
        operands=[value],
        results=[target],
        attributes={"rounding": _rounding_attr(rounding), "saturate": ir.BoolAttr.get(saturate_value)},
    ).results[0]


def _create_simt_bitcast(target, value):
    return ir.Operation.create("ascsimt.bitcast", operands=[value], results=[target]).results[0]


def _coerce_simt_storage(value, storage_type, *, path="value"):
    """Validate a scalar and bridge to SIMT storage with a bitcast."""
    value, scalar_type = normalize_scalar_for_storage(value, storage_type, path=path)
    if scalar_type != storage_type:
        value = _create_simt_bitcast(storage_type, value)
    return value


def thread_idx():
    """Return (threadIdx.x, threadIdx.y, threadIdx.z)."""
    return tuple(_query("thread_idx", axis) for axis in ("x", "y", "z"))


def thread_dim():
    """Return (blockDim.x, blockDim.y, blockDim.z)."""
    return tuple(_query("thread_dim", axis, kernel_ok=_current_vf_mode() != "simt") for axis in ("x", "y", "z"))


def _query(name, axis="x", *, kernel_ok=False):
    if not kernel_ok:
        _require_simt(name)
    else:
        from cannbotdsl.core.frontend.call_context import in_device_domain

        if not in_device_domain():
            raise RuntimeError(f"simt.{name} requires a kernel")
    dtype = ir.IntegerType.get_signless(32)
    attrs = {"axis": ir.StringAttr.get(axis)}
    ctx = _CURRENT_VF.get()
    if ctx is not None:
        # Keep lexical launches distinct for CSE without reintroducing a
        # CANNIR execution-domain attribute.
        attrs["ascsimt.scope"] = ir.IntegerAttr.get(ir.IntegerType.get_signless(64), ctx.group_id)
    value = ir.Operation.create("ascsimt." + name, results=[dtype], attributes=attrs).results[0]
    return _wrap_simt_scalar(value, storage_type=dtype)


def block_idx():
    """Return (blockIdx.x, blockIdx.y, blockIdx.z)."""
    return tuple(_query("block_idx", axis) for axis in ("x", "y", "z"))


def grid_dim():
    """Return (gridDim.x, gridDim.y, gridDim.z)."""
    return tuple(_query("block_dim", axis) for axis in ("x", "y", "z"))


def warp_size():
    _require_simt("warp_size")
    dtype = ir.IntegerType.get_signless(32)
    result = ir.Operation.create("ascsimt.warp_size", results=[dtype]).results[0]
    return _wrap_simt_scalar(result, storage_type=dtype)


def _math_type(value):
    """Resolve math dtype from a typed scalar; literals default to f32."""
    if is_exact_instance_of(value, (int, float)):
        return ir.F32Type.get()
    if isinstance(value, ir.Value):
        if isinstance(value, ShortVector):
            return value.type
        dtype = value.type
        if isinstance(dtype, (ir.F16Type, ir.F32Type, ir.BF16Type)):
            return dtype
    raise TypeError("SIMT math requires a float16, bfloat16, or float32 scalar")


def _vector_binary(function, lhs, rhs):
    _require_simt(function)
    if not isinstance(lhs, ShortVector) or not isinstance(rhs, ShortVector):
        raise TypeError(f"simt.{function} requires two short vectors")
    if lhs.dtype is not rhs.dtype:
        raise TypeError(f"simt.{function} requires matching short-vector dtypes")
    result = ir.Operation.create(
        "ascsimt.math_binary",
        operands=[lhs, rhs],
        results=[lhs.type],
        attributes={"function": ir.StringAttr.get(function)},
    ).results[0]
    return ShortVector(result, lhs.dtype)


def _require_vector(value, name):
    if not isinstance(value, ShortVector):
        raise TypeError(f"simt.v{name} requires a ShortVector operand")


def _vector_unary(function, value):
    _require_simt("v" + function)
    _require_vector(value, function)
    result = ir.Operation.create(
        "ascsimt.math_unary",
        operands=[value],
        results=[value.type],
        attributes={"function": ir.StringAttr.get(function)},
    ).results[0]
    return ShortVector(result, value.dtype)


def _vector_binary_api(function, lhs, rhs):
    _require_simt("v" + function)
    _require_vector(lhs, function)
    _require_vector(rhs, function)
    return _vector_binary(function, lhs, rhs)


def _vector_bool_compare(function, lhs, rhs):
    _require_simt("v" + function)
    _require_vector(lhs, function)
    _require_vector(rhs, function)
    if lhs.dtype is not rhs.dtype:
        raise TypeError(f"simt.v{function} requires matching short-vector dtypes")
    result_type = ir.IntegerType.get_signless(1)
    result = ir.Operation.create(
        "ascsimt.math_binary",
        operands=[lhs, rhs],
        results=[result_type],
        attributes={"function": ir.StringAttr.get(function)},
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=result_type)


def vsqrt(x):
    return _vector_unary("sqrt", x)


def vrsqrt(x):
    return _vector_unary("rsqrt", x)


def vexp(x):
    return _vector_unary("exp", x)


def vlog(x):
    return _vector_unary("log", x)


def vabs(x):
    return _vector_unary("abs", x)


def vsin(x):
    return _vector_unary("sin", x)


def vcos(x):
    return _vector_unary("cos", x)


def vtan(x):
    return _vector_unary("tan", x)


def vtanh(x):
    return _vector_unary("tanh", x)


def vfloor(x):
    return _vector_unary("floor", x)


def vceil(x):
    return _vector_unary("ceil", x)


def vtrunc(x):
    return _vector_unary("trunc", x)


def vexp2(x):
    return _vector_unary("exp2", x)


def vexp10(x):
    return _vector_unary("exp10", x)


def vlog2(x):
    return _vector_unary("log2", x)


def vlog10(x):
    return _vector_unary("log10", x)


def vadd(x, y):
    return _vector_binary_api("add", x, y)


def vsub(x, y):
    return _vector_binary_api("sub", x, y)


def vmul(x, y):
    return _vector_binary_api("mul", x, y)


def vdiv(x, y):
    return _vector_binary_api("div", x, y)


def vfmin(x, y):
    return _vector_binary_api("fmin", x, y)


def vmax(x, y):
    return _vector_binary_api("fmax", x, y)


def vneg(x):
    return _vector_unary("neg", x)


def veq(x, y):
    return _vector_binary_api("eq", x, y)


def vne(x, y):
    return _vector_binary_api("ne", x, y)


def vle(x, y):
    return _vector_binary_api("le", x, y)


def vge(x, y):
    return _vector_binary_api("ge", x, y)


def vlt(x, y):
    return _vector_binary_api("lt", x, y)


def vgt(x, y):
    return _vector_binary_api("gt", x, y)


def vequ(x, y):
    return _vector_binary_api("equ", x, y)


def vneu(x, y):
    return _vector_binary_api("neu", x, y)


def vleu(x, y):
    return _vector_binary_api("leu", x, y)


def vgeu(x, y):
    return _vector_binary_api("geu", x, y)


def vltu(x, y):
    return _vector_binary_api("ltu", x, y)


def vgtu(x, y):
    return _vector_binary_api("gtu", x, y)


def vrcp(x):
    return _vector_unary("rcp", x)


def vrint(x):
    return _vector_unary("rint", x)


def visnan(x):
    return _vector_unary("isnanx2", x)


def vmax_nan(x, y):
    return _vector_binary_api("max_nan", x, y)


def vmin_nan(x, y):
    return _vector_binary_api("min_nan", x, y)


def vfma(x, y, z):
    return _vector_ternary("fma2", x, y, z)


def vfma_relu(x, y, z):
    return _vector_ternary("fma2_relu", x, y, z)


def vcmadd(x, y, z):
    return _vector_ternary("cmadd", x, y, z)


def _vector_ternary(function, x, y, z):
    _require_simt("v" + function)
    for value in (x, y, z):
        _require_vector(value, function)
    if not (x.dtype is y.dtype is z.dtype):
        raise TypeError(f"simt.v{function} requires matching short-vector dtypes")
    result = ir.Operation.create(
        "ascsimt.math_ternary",
        operands=[x, y, z],
        results=[x.type],
        attributes={"function": ir.StringAttr.get(function)},
    ).results[0]
    return ShortVector(result, x.dtype)


def _vector_mask(function, lhs, rhs):
    _require_simt("v" + function)
    _require_vector(lhs, function)
    _require_vector(rhs, function)
    if lhs.dtype is not rhs.dtype:
        raise TypeError(f"simt.v{function} requires matching short-vector dtypes")
    result_type = ir.IntegerType.get_signless(32)
    result = ir.Operation.create(
        "ascsimt.math_binary",
        operands=[lhs, rhs],
        results=[result_type],
        attributes={"function": ir.StringAttr.get(function + "_mask")},
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=result_type)


def veq_mask(x, y):
    return _vector_mask("eq", x, y)


def vne_mask(x, y):
    return _vector_mask("ne", x, y)


def vle_mask(x, y):
    return _vector_mask("le", x, y)


def vge_mask(x, y):
    return _vector_mask("ge", x, y)


def vlt_mask(x, y):
    return _vector_mask("lt", x, y)


def vgt_mask(x, y):
    return _vector_mask("gt", x, y)


def vequ_mask(x, y):
    return _vector_mask("equ", x, y)


def vneu_mask(x, y):
    return _vector_mask("neu", x, y)


def vleu_mask(x, y):
    return _vector_mask("leu", x, y)


def vgeu_mask(x, y):
    return _vector_mask("geu", x, y)


def vltu_mask(x, y):
    return _vector_mask("ltu", x, y)


def vgtu_mask(x, y):
    return _vector_mask("gtu", x, y)


def vbeq(x, y):
    return _vector_bool_compare("beq", x, y)


def vbne(x, y):
    return _vector_bool_compare("bne", x, y)


def vble(x, y):
    return _vector_bool_compare("ble", x, y)


def vbge(x, y):
    return _vector_bool_compare("bge", x, y)


def vblt(x, y):
    return _vector_bool_compare("blt", x, y)


def vbgt(x, y):
    return _vector_bool_compare("bgt", x, y)


# Compatibility aliases.  The device API returns one bool for the whole pair;
# there is no distinct ``__hb*x2_mask`` family in asc_fp16/asc_bf16.
def vbeq_mask(x, y):
    return vbeq(x, y)


def vbne_mask(x, y):
    return vbne(x, y)


def vble_mask(x, y):
    return vble(x, y)


def vbge_mask(x, y):
    return vbge(x, y)


def vblt_mask(x, y):
    return vblt(x, y)


def vbgt_mask(x, y):
    return vbgt(x, y)


def _vector_lane_op(function, value, *others, result_dtype=None):
    _require_simt("v" + function)
    _require_vector(value, function)
    for other in others:
        _require_vector(other, function)
    operands = [value, *others]
    op_name = "ascsimt.math_unary" if not others else "ascsimt.math_binary"
    result_type = value.type if result_dtype is None else result_dtype
    result = ir.Operation.create(
        op_name,
        operands=operands,
        results=[result_type],
        attributes={"function": ir.StringAttr.get(function)},
    ).results[0]
    if result_dtype is None:
        return ShortVector(result, value.dtype)
    return _wrap_simt_scalar(result, storage_type=result_dtype)


def vhigh(x, y=None):
    """Extract/pack high lanes; one or two vector arguments select the C API."""
    _require_simt("vhigh")
    return _vector_lane_op("high" if y is None else "highs", x, *(() if y is None else (y,)))


def vlow(x, y=None):
    """Extract/pack low lanes; one or two vector arguments select the C API."""
    _require_simt("vlow")
    return _vector_lane_op("low" if y is None else "lows", x, *(() if y is None else (y,)))


def vpack_high(x, y=None, *, dtype=None):
    """Select high lanes or pack high lanes, based on argument count."""
    if dtype is not None:
        from cannbotdsl.core.contracts.elements import scalar_mlir_type_for_dtype

        dtype = scalar_mlir_type_for_dtype(dtype) if hasattr(dtype, "kind") else dtype
    return _vector_lane_op(
        "high_float" if dtype is not None else ("high" if y is None else "highs"),
        x,
        *(() if y is None else (y,)),
        result_dtype=dtype,
    )


def vpack_low(x, y=None):
    """Select low lanes or pack low lanes, based on argument count."""
    return _vector_lane_op("low" if y is None else "lows", x, *(() if y is None else (y,)))


# ``saturate`` is an established public keyword of the cast APIs.
# pylint: disable-next=redefined-outer-name
def vcast(value, *, dtype, rounding=RoundingMode.RN, saturate=False):
    """Cast a short vector using the unified vector conversion spelling."""
    _require_simt("vcast")
    _require_vector(value, "cast")
    if not isinstance(dtype, type(value.dtype)) or not dtype.is_short_vector:
        raise TypeError("simt.vcast dtype must be a short-vector dtype descriptor")
    if value.dtype == dtype:
        raise ValueError("simt.vcast source and destination dtypes must differ")
    # Vector cast lowering is represented by the same conversion operation;
    # the destination vector type is carried by the descriptor.
    target = ir.Type.parse(f'!cannir.simt_vector<"{vector_info(dtype)[2]}">')
    if isinstance(rounding, str):
        rounding = {
            "rn": RoundingMode.RN,
            "rna": RoundingMode.RNA,
            "rd": RoundingMode.RD,
            "ru": RoundingMode.RU,
            "rz": RoundingMode.RZ,
            "ro": RoundingMode.RO,
            "rh": RoundingMode.RH,
        }[rounding.lower()]
    if not isinstance(rounding, RoundingMode):
        raise TypeError("simt.vcast rounding must be a RoundingMode value")
    if not isinstance(saturate, bool):
        raise TypeError("simt.vcast saturate must be a bool")
    result = _create_simt_cast(target, value, rounding, saturate)
    return ShortVector(result, dtype)


def vbitcast(value, *, dtype):
    """Reinterpret a short-vector bit pattern without numeric conversion."""
    _require_simt("vbitcast")
    _require_vector(value, "bitcast")
    if not isinstance(dtype, type(value.dtype)) or not dtype.is_short_vector:
        raise TypeError("simt.vbitcast dtype must be a short-vector dtype descriptor")
    target = ir.Type.parse(f'!cannir.simt_vector<"{vector_info(dtype)[2]}">')
    result = _create_simt_bitcast(target, value)
    return ShortVector(result, dtype)


def _integer_type(value, name):
    if is_exact_instance(value, int):
        return ir.IntegerType.get_signless(32)
    if isinstance(value, ir.Value) and isinstance(value.type, ir.IntegerType):
        return value.type
    raise TypeError(f"simt.{name} requires an integer scalar")


def _integer_unary(function, x):
    _require_simt(function)
    dtype = _integer_type(x, function)
    value = _coerce_simt_storage(x, dtype, path=f"simt.{function} input")
    result = ir.Operation.create(
        "ascsimt.math_unary", operands=[value], results=[dtype], attributes={"function": ir.StringAttr.get(function)}
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=dtype)


def _integer_binary(function, lhs, rhs, *, result_type=None):
    _require_simt(function)
    dtype = _integer_type(lhs, function)
    a = _coerce_simt_storage(lhs, dtype, path=f"simt.{function} lhs")
    b = _coerce_simt_storage(rhs, dtype, path=f"simt.{function} rhs")
    result_type = dtype if result_type is None else result_type
    result = ir.Operation.create(
        "ascsimt.math_binary",
        operands=[a, b],
        results=[result_type],
        attributes={"function": ir.StringAttr.get(function)},
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=result_type)


# ``saturate`` is an established public keyword of the cast APIs.
# pylint: disable-next=redefined-outer-name
def cast(value, *, dtype, rounding=RoundingMode.RN, saturate=False):
    """Convert a scalar to ``dtype`` using one unified cast spelling.

    Conversion suffixes such as ``_rn`` and ``_rz`` are deliberately not
    exposed as separate Python functions.  The destination dtype is explicit;
    the rounding value is carried as an API parameter for backend lowering.
    """
    _require_simt("cast")
    if isinstance(rounding, str):
        try:
            rounding = {
                "rn": RoundingMode.RN,
                "rna": RoundingMode.RNA,
                "rd": RoundingMode.RD,
                "ru": RoundingMode.RU,
                "rz": RoundingMode.RZ,
                "ro": RoundingMode.RO,
                "rh": RoundingMode.RH,
            }[rounding.lower()]
        except KeyError as exc:
            raise ValueError("simt.cast rounding must be rn, rna, rd, ru, rz, ro, or rh") from exc
    if not isinstance(rounding, RoundingMode):
        raise TypeError("simt.cast rounding must be a RoundingMode value")
    if not isinstance(saturate, bool):
        raise TypeError("simt.cast saturate must be a bool")
    # Public dtype descriptors are resolved to their scalar carrier; the
    # destination is represented by the result type of one canonical IR op.
    if hasattr(dtype, "kind") and callable(dtype):
        from cannbotdsl.core.contracts.elements import storage_mlir_type_for_dtype

        target = storage_mlir_type_for_dtype(dtype)
    else:
        target = dtype.scalar_mlir_type() if hasattr(dtype, "scalar_mlir_type") else dtype
    source = target
    if isinstance(value, ir.Value):
        source_dtype = getattr(value, "dtype", None)
        if source_dtype is not None:
            from cannbotdsl.core.contracts.elements import storage_mlir_type_for_dtype

            source = storage_mlir_type_for_dtype(source_dtype)
        else:
            source = value.type
    value = _coerce_simt_storage(value, source, path="simt.cast input")
    if source == target:
        raise ValueError("simt.cast source and destination dtypes must differ")
    result = _create_simt_cast(target, value, rounding, saturate)
    return _wrap_simt_scalar(result, storage_type=target)


def bitcast(value, *, dtype):
    """Reinterpret a scalar bit pattern without numeric conversion."""
    _require_simt("bitcast")
    if hasattr(dtype, "kind") and callable(dtype):
        from cannbotdsl.core.contracts.elements import storage_mlir_type_for_dtype

        target = storage_mlir_type_for_dtype(dtype)
    else:
        target = dtype.scalar_mlir_type() if hasattr(dtype, "scalar_mlir_type") else dtype
    if not isinstance(value, ir.Value):
        raise TypeError("simt.bitcast requires a typed scalar SSA value")
    source_dtype = getattr(value, "dtype", None)
    if source_dtype is not None:
        from cannbotdsl.core.contracts.elements import storage_mlir_type_for_dtype

        value = _coerce_simt_storage(value, storage_mlir_type_for_dtype(source_dtype), path="simt.bitcast input")
    result = _create_simt_bitcast(target, value)
    return _wrap_simt_scalar(result, storage_type=target)


def sqrt(x):
    return _unary("sqrt", x)


def make_short_vector(*values):
    """Construct one short vector; lane count and element dtype are inferred."""
    _require_simt("make")
    if not 2 <= len(values) <= 4:
        raise TypeError("simt.make_short_vector expects two, three, or four lane values")
    from cannbotdsl.types import dtypes
    from cannbotdsl.types._short_vector import _construct

    element = getattr(values[0], "dtype", None)
    if element is None:
        element = dtypes.float32 if builtins.any(is_exact_instance(v, float) for v in values) else dtypes.int32
    if builtins.any(getattr(v, "dtype", element) is not element for v in values):
        raise TypeError("simt.make_short_vector requires matching lane element dtypes")
    vector = next(
        (
            v
            for v in dtypes._DTYPES
            if v.is_short_vector and vector_info(v)[1] is element and vector_info(v)[0] == len(values)
        ),
        None,
    )
    if vector is None:
        raise TypeError(f"no SIMT short-vector dtype for {element.name}x{len(values)}")
    return _construct(vector, values)


def _unary(name, x):
    _require_simt(name)
    if isinstance(x, ShortVector):
        raise TypeError(f"simt.{name} is scalar-only; use simt.v{name}")
    dtype = _math_type(x)
    if isinstance(x, ShortVector):
        result = ir.Operation.create(
            "ascsimt.math_unary",
            operands=[x],
            results=[x.type],
            attributes={"function": ir.StringAttr.get(name)},
        ).results[0]
        return ShortVector(result, x.dtype)
    value = _coerce_simt_storage(x, dtype, path=f"simt.{name} input")
    result = ir.Operation.create(f"ascsimt.{name}", operands=[value], results=[dtype]).results[0]
    return _wrap_simt_scalar(result, storage_type=dtype)


def rsqrt(x):
    return _unary("rsqrt", x)


def exp(x):
    return _unary("exp", x)


def log(x):
    return _unary("log", x)


def abs(x):
    return _unary("abs", x)


def _sync(name):
    _require_simt(name)
    ir.Operation.create(f"ascsimt.{name}")


def syncthreads():
    return _sync("syncthreads")


def threadfence():
    return _sync("threadfence")


def threadfence_block():
    return _sync("threadfence_block")


def dcci_single(point):
    _require_simt("dcci_single")
    from cannbotdsl.ops.scalar import ScalarPtr
    from cannbotdsl.tensor import MemLoc

    if not isinstance(point, ScalarPtr):
        raise TypeError("simt.dcci_single requires a typed GM pointer")
    if MemLoc(cannir.PointerType(point._value.type).memloc) != MemLoc.GM:
        raise TypeError("simt.dcci_single requires a GM pointer")
    ir.Operation.create("ascsimt.dcci_single", operands=[point._value])
    return None


def dcci_entire_out():
    _require_simt("dcci_entire_out")
    from cannbotdsl.ops.sync import dcci_entire_out as _dcci_entire_out

    return _dcci_entire_out()


def _cache_ptr(ptr, mode, api):
    _require_simt(api)
    from cannbotdsl.ops.scalar import ScalarPtr

    if not isinstance(ptr, ScalarPtr):
        raise TypeError(f"simt.{api}: ptr must come from tensor.ptr(coord)")
    from cannbotdsl.tensor import MemLoc

    if MemLoc(cannir.PointerType(ptr._value.type).memloc) != MemLoc.GM:
        raise TypeError(f"simt.{api}: cache operations require a GM pointer")
    result = ir.Operation.create(
        "ascsimt.cache_load",
        operands=[ptr._value],
        results=[ptr._storage_type],
        attributes={"mode": ir.StringAttr.get(mode)},
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=ptr._storage_type)


def l2cache_load(ptr):
    return _cache_ptr(ptr, "l2cache_load", "l2cache_load")


def l2cache_vload(ptr, *, dtype):
    """Load one packed SIMT short vector through the L2 cache.

    ``dtype`` is a short-vector ``DType`` descriptor (for example
    ``dtypes.float16x2`` or ``dtypes.fp8x2_e4m3fn``).  The pointer's
    The pointer must be a GM pointer; UB and generic pointers are rejected.
    """
    _require_simt("l2cache_vload")
    from cannbotdsl.ops.scalar import ScalarPtr

    if not isinstance(ptr, ScalarPtr) or not getattr(dtype, "is_short_vector", False):
        raise TypeError("simt.l2cache_vload requires a typed pointer and vector dtype")
    from cannbotdsl.tensor import MemLoc

    if MemLoc(cannir.PointerType(ptr._value.type).memloc) != MemLoc.GM:
        raise TypeError("simt.l2cache_vload: cache operations require a GM pointer")
    c_name = vector_info(dtype)[2]
    target = ir.Type.parse(f'!cannir.simt_vector<"{c_name}">')
    result = ir.Operation.create(
        "ascsimt.cache_load",
        operands=[ptr._value],
        results=[target],
        attributes={"mode": ir.StringAttr.get("l2cache_load"), "vector_type": ir.StringAttr.get(c_name)},
    ).results[0]
    return ShortVector(result, dtype)


def _cache_store(ptr, value, mode, api):
    _require_simt(api)
    from cannbotdsl.ops.scalar import ScalarPtr

    if not isinstance(ptr, ScalarPtr):
        raise TypeError(f"simt.{api}: ptr must come from tensor.ptr(coord)")
    from cannbotdsl.tensor import MemLoc

    if MemLoc(cannir.PointerType(ptr._value.type).memloc) != MemLoc.GM:
        raise TypeError(f"simt.{api}: cache operations require a GM pointer")
    value = _coerce_simt_storage(value, ptr._storage_type, path=f"simt.{api} value")
    ir.Operation.create(
        "ascsimt.cache_store", operands=[ptr._value, value], attributes={"mode": ir.StringAttr.get(mode)}
    )


def l2cache_store(ptr, value):
    return _cache_store(ptr, value, "l2cache_store", "l2cache_store")


def l2cache_vstore(ptr, value):
    _require_simt("l2cache_vstore")
    from cannbotdsl.ops.scalar import ScalarPtr

    if not isinstance(ptr, ScalarPtr) or not isinstance(value, ShortVector):
        raise TypeError("simt.l2cache_vstore requires a typed pointer and ShortVector")
    from cannbotdsl.tensor import MemLoc

    if MemLoc(cannir.PointerType(ptr._value.type).memloc) != MemLoc.GM:
        raise TypeError("simt.l2cache_vstore: cache operations require a GM pointer")
    ir.Operation.create(
        "ascsimt.cache_store", operands=[ptr._value, value], attributes={"mode": ir.StringAttr.get("l2cache_vstore")}
    )


def nop():
    _require_simt("nop")
    ir.Operation.create("ascsimt.nop")


def _lane_query(name):
    _require_simt(name)
    dtype = ir.IntegerType.get_signless(32)
    value = ir.Operation.create(f"ascsimt.{name}", results=[dtype]).results[0]
    return _wrap_simt_scalar(value, storage_type=dtype)


def lane_idx():
    return _lane_query("lane_id")


def lanemask_eq():
    return _lane_query("lanemask_eq")


def lanemask_le():
    return _lane_query("lanemask_le")


def lanemask_lt():
    return _lane_query("lanemask_lt")


def lanemask_ge():
    return _lane_query("lanemask_ge")


def lanemask_gt():
    return _lane_query("lanemask_gt")


def _warp_unary(name, x):
    _require_simt(name)
    dtype = ir.IntegerType.get_signless(32)
    raw = getattr(x, "_value", x)
    if isinstance(raw, ir.Value) and isinstance(raw.type, ir.IntegerType) and raw.type.width == 1:
        x = ir.Operation.create("arith.extui", operands=[raw], results=[dtype]).results[0]
        raw = x
    value = (
        raw
        if isinstance(raw, ir.Value) and raw.type == dtype
        else _coerce_simt_storage(x, dtype, path=f"simt.{name} input")
    )
    result = ir.Operation.create(f"ascsimt.{name}", operands=[value], results=[dtype]).results[0]
    return _wrap_simt_scalar(result, storage_type=dtype)


def all(x):
    return _warp_unary("all", x)


def any(x):
    return _warp_unary("any", x)


def ballot(x):
    return _warp_unary("ballot", x)


def activemask():
    _require_simt("activemask")
    dtype = ir.IntegerType.get_signless(32)
    result = ir.Operation.create("ascsimt.activemask", results=[dtype]).results[0]
    return _wrap_simt_scalar(result, storage_type=dtype)


def _shuffle(name, value, index, width=32):
    _require_simt(name)
    vector = value if isinstance(value, ShortVector) else None
    dtype = value.type if vector is not None else _collective_type(name, value, allow_i64=True, allow_bf16=True)
    if not is_exact_instance(width, int) or width not in (1, 2, 4, 8, 16, 32):
        raise ValueError("shuffle width must be a power of two in [1, 32]")
    v = value if vector is not None else _coerce_simt_storage(value, dtype, path=f"simt.{name} value")
    index_dtype = ir.IntegerType.get_signless(32)
    i = _coerce_simt_storage(index, index_dtype, path=f"simt.{name} index")
    w = _coerce_simt_storage(width, index_dtype, path=f"simt.{name} width")
    result = ir.Operation.create(f"ascsimt.{name}", operands=[v, i, w], results=[dtype]).results[0]
    if vector is not None:
        return ShortVector(result, vector.dtype)
    return _wrap_simt_scalar(result, storage_type=dtype)


def shfl(value, src_lane, width=32):
    return _shuffle("shfl", value, src_lane, width)


def shfl_up(value, delta, width=32):
    return _shuffle("shfl_up", value, delta, width)


def shfl_down(value, delta, width=32):
    return _shuffle("shfl_down", value, delta, width)


def shfl_xor(value, lane_mask, width=32):
    return _shuffle("shfl_xor", value, lane_mask, width)


def _reduce(name, value):
    _require_simt(name)
    dtype = _collective_type(name, value)
    v = _coerce_simt_storage(value, dtype, path=f"simt.{name} input")
    result = ir.Operation.create(f"ascsimt.{name}", operands=[v], results=[dtype]).results[0]
    return _wrap_simt_scalar(result, storage_type=dtype)


def reduce_add(value):
    return _reduce("reduce_add", value)


def reduce_max(value):
    return _reduce("reduce_max", value)


def reduce_min(value):
    return _reduce("reduce_min", value)


def sin(x):
    return _unary("sin", x)


def cos(x):
    return _unary("cos", x)


def tan(x):
    return _unary("tan", x)


def tanh(x):
    return _unary("tanh", x)


def floor(x):
    return _unary("floor", x)


def ceil(x):
    return _unary("ceil", x)


def trunc(x):
    return _unary("trunc", x)


def exp2(x):
    return _unary("exp2", x)


def exp10(x):
    return _unary("exp10", x)


def log2(x):
    return _unary("log2", x)


def log10(x):
    return _unary("log10", x)


def _math_extra_unary(function, x, *, result_type=None):
    _require_simt(function)
    if isinstance(x, ShortVector):
        raise TypeError(f"simt.{function} is scalar-only; use a simt.v* API")
    dtype = _math_type(x)
    if isinstance(x, ShortVector):
        if result_type is not None:
            raise TypeError(f"simt.{function} cannot change short-vector result type")
        result = ir.Operation.create(
            "ascsimt.math_unary",
            operands=[x],
            results=[x.type],
            attributes={"function": ir.StringAttr.get(function)},
        ).results[0]
        return ShortVector(result, x.dtype)
    value = _coerce_simt_storage(x, dtype, path=f"simt.{function} input")
    result_type = dtype if result_type is None else result_type
    result = ir.Operation.create(
        "ascsimt.math_unary",
        operands=[value],
        results=[result_type],
        attributes={"function": ir.StringAttr.get(function)},
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=result_type)


def _math_extra_binary(function, lhs, rhs):
    _require_simt(function)
    if isinstance(lhs, ShortVector) or isinstance(rhs, ShortVector):
        raise TypeError(f"simt.{function} is scalar-only; use simt.v{function}")
    dtype = _math_type(lhs)
    if isinstance(lhs, ShortVector):
        return _vector_binary(function, lhs, rhs)
    a = _coerce_simt_storage(lhs, dtype, path=f"simt.{function} lhs")
    b = _coerce_simt_storage(rhs, dtype, path=f"simt.{function} rhs")
    result = ir.Operation.create(
        "ascsimt.math_binary",
        operands=[a, b],
        results=[dtype],
        attributes={"function": ir.StringAttr.get(function)},
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=dtype)


def _math_extra_binary_predicate(function, lhs, rhs):
    _require_simt(function)
    if isinstance(lhs, ShortVector) or isinstance(rhs, ShortVector):
        raise TypeError(f"simt.{function} is scalar-only; use simt.v{function}")
    raw_lhs = getattr(lhs, "_value", lhs)
    if isinstance(raw_lhs, ir.Value) and isinstance(raw_lhs.type, ir.IntegerType):
        dtype = raw_lhs.type
    else:
        dtype = _math_type(lhs)
    if isinstance(lhs, ShortVector):
        return _vector_binary(function, lhs, rhs)
    a = _coerce_simt_storage(lhs, dtype, path=f"simt.{function} lhs")
    b = _coerce_simt_storage(rhs, dtype, path=f"simt.{function} rhs")
    result_type = ir.IntegerType.get_signless(1)
    result = ir.Operation.create(
        "ascsimt.math_binary",
        operands=[a, b],
        results=[result_type],
        attributes={"function": ir.StringAttr.get(function)},
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=result_type)


def _math_multi(function, inputs, result_types):
    _require_simt(function)
    input_types = []
    for value in inputs:
        input_types.append(value.type if isinstance(value, ir.Value) else ir.F32Type.get())
    values = []
    for i, (value, dtype) in enumerate(zip(inputs, input_types)):
        values.append(_coerce_simt_storage(value, dtype, path=f"simt.{function} input {i}"))
    results = ir.Operation.create(
        "ascsimt.math_multi",
        operands=values,
        results=result_types,
        attributes={"function": ir.StringAttr.get(function)},
    ).results
    return tuple(_wrap_simt_scalar(v, storage_type=t) for v, t in zip(results, result_types))


def modf(x):
    dtype = _math_type(x)
    return _math_multi("modf", [x], [dtype, dtype])


def remquo(x, y):
    dtype = _math_type(x)
    return _math_multi("remquo", [x, y], [dtype, ir.IntegerType.get_signless(32)])


def frexp(x):
    dtype = _math_type(x)
    return _math_multi("frexp", [x], [dtype, ir.IntegerType.get_signless(32)])


# ``exp`` is an established public keyword matching the mathematical operation.
# pylint: disable-next=redefined-outer-name
def ldexp(x, exp):
    dtype = _math_type(x)
    return _math_multi("ldexp", [x, exp], [dtype, ir.IntegerType.get_signless(32)])


def nan(tag):
    """Return NaN using a compile-time string payload passed to nanf."""
    _require_simt("nan")
    if not isinstance(tag, str):
        raise TypeError("simt.nan tag must be a string")
    result = ir.Operation.create(
        "ascsimt.nan", results=[ir.F32Type.get()], attributes={"tag": ir.StringAttr.get(tag)}
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=ir.F32Type.get())


def sincos(x):
    dtype = _math_type(x)
    return _math_multi("sincosf", [x], [dtype, dtype])


def sincospi(x):
    dtype = _math_type(x)
    return _math_multi("sincospif", [x], [dtype, dtype])


def norm3(a, b, c):
    return _math_extra_ternary("norm3df", a, b, c)


def rnorm3(a, b, c):
    return _math_extra_ternary("rnorm3df", a, b, c)


def norm4(a, b, c, d):
    return _math_extra_quaternary("norm4df", a, b, c, d)


def rnorm4(a, b, c, d):
    return _math_extra_quaternary("rnorm4df", a, b, c, d)


def _norm_array(function, n, ptr=None):
    # CANN's SIMT API follows normf(int n, float* a), rather than a scalar
    # unary overload.  Keep the pointer form explicit in the DSL as well.
    if ptr is None:
        return _math_extra_unary(function, n)
    _require_simt(function)
    count = _coerce_simt_storage(n, ir.IntegerType.get_signless(32), path=f"simt.{function} count")
    pointer = getattr(ptr, "_value", None)
    if pointer is None:
        pointer = unwrap_operand(ptr)
    result_type = ir.F32Type.get()
    result = ir.Operation.create(
        "ascsimt.math_binary",
        operands=[count, pointer],
        results=[result_type],
        attributes={"function": ir.StringAttr.get(function)},
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=result_type)


def norm(n, ptr=None):
    return _norm_array("normf", n, ptr)


def rnorm(n, ptr=None):
    return _norm_array("rnormf", n, ptr)


def logb(x):
    return _math_extra_unary("logbf", x)


def ilogb(x):
    return _math_extra_unary("ilogbf", x, result_type=ir.IntegerType.get_signless(32))


def cyl_bessel_i0(x):
    return _math_extra_unary("cyl_bessel_i0f", x)


def cyl_bessel_i1(x):
    return _math_extra_unary("cyl_bessel_i1f", x)


def normcdf(x):
    return _math_extra_unary("normcdff", x)


def j0(x):
    return _math_extra_unary("j0f", x)


def j1(x):
    return _math_extra_unary("j1f", x)


def jn(n, x):
    return _math_extra_binary("jnf", n, x)


def y0(x):
    return _math_extra_unary("y0f", x)


def y1(x):
    return _math_extra_unary("y1f", x)


def yn(n, x):
    return _math_extra_binary("ynf", n, x)


def fma(x, y, z):
    _require_simt("fma")
    dtype = _math_type(x)
    a = _coerce_simt_storage(x, dtype, path="simt.fma x")
    b = _coerce_simt_storage(y, dtype, path="simt.fma y")
    c = _coerce_simt_storage(z, dtype, path="simt.fma z")
    result = ir.Operation.create(
        "ascsimt.math_ternary",
        operands=[a, b, c],
        results=[dtype],
        attributes={"function": ir.StringAttr.get("fmaf")},
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=dtype)


def fma_relu(x, y, z):
    if builtins.any(isinstance(v, ShortVector) for v in (x, y, z)):
        return _vector_ternary("fma_relu", x, y, z)
    return _math_extra_ternary("fma_relu", x, y, z)


def _math_extra_ternary(function, x, y, z):
    _require_simt(function)
    dtype = _math_type(x)
    a = _coerce_simt_storage(x, dtype, path=f"simt.{function} x")
    b = _coerce_simt_storage(y, dtype, path=f"simt.{function} y")
    c = _coerce_simt_storage(z, dtype, path=f"simt.{function} z")
    result = ir.Operation.create(
        "ascsimt.math_ternary",
        operands=[a, b, c],
        results=[dtype],
        attributes={"function": ir.StringAttr.get(function)},
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=dtype)


def _math_extra_quaternary(function, a0, a1, a2, a3):
    _require_simt(function)
    dtype = _math_type(a0)
    values = [_coerce_simt_storage(v, dtype, path=f"simt.{function} input") for v in (a0, a1, a2, a3)]
    result = ir.Operation.create(
        "ascsimt.math_quaternary",
        operands=values,
        results=[dtype],
        attributes={"function": ir.StringAttr.get(function)},
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=dtype)


def _math_integer_unary(function, x):
    _require_simt(function)
    dtype = _math_type(x)
    value = _coerce_simt_storage(x, dtype, path=f"simt.{function} input")
    result_type = ir.IntegerType.get_signless(64)
    result = ir.Operation.create(
        "ascsimt.math_unary",
        operands=[value],
        results=[result_type],
        attributes={"function": ir.StringAttr.get(function)},
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=result_type)


def lround(x):
    return _math_integer_unary("lroundf", x)


def llround(x):
    return _math_integer_unary("llroundf", x)


def lrint(x):
    return _math_integer_unary("lrintf", x)


def llrint(x):
    return _math_integer_unary("llrintf", x)


def round(x):
    return _math_extra_unary("roundf", x)


def rint(x):
    return _math_extra_unary("rintf", x)


def normcdfinv(x):
    return _math_extra_unary("normcdfinvf", x)


def isfinite(x):
    return _math_extra_unary("isfinite", x, result_type=ir.IntegerType.get_signless(1))


def isnan(x):
    return _math_extra_unary("isnan", x, result_type=ir.IntegerType.get_signless(1))


def isinf(x):
    return _math_extra_unary("isinf", x, result_type=ir.IntegerType.get_signless(1))


def fdim(lhs, rhs):
    return _math_extra_binary("fdimf", lhs, rhs)


def remainder(lhs, rhs):
    return _math_extra_binary("remainderf", lhs, rhs)


def copysign(lhs, rhs):
    return _math_extra_binary("copysignf", lhs, rhs)


def nearbyint(x):
    return _math_extra_unary("nearbyintf", x)


def nextafter(lhs, rhs):
    return _math_extra_binary("nextafterf", lhs, rhs)


def scalbn(lhs, rhs):
    return _math_extra_binary("scalbnf", lhs, rhs)


def scalbln(lhs, rhs):
    return _math_extra_binary("scalblnf", lhs, rhs)


def tanpi(x):
    return _math_extra_unary("tanpif", x)


def atan(x):
    return _math_extra_unary("atanf", x)


def atanh(x):
    return _math_extra_unary("atanhf", x)


def cosh(x):
    return _math_extra_unary("coshf", x)


def cospi(x):
    return _math_extra_unary("cospif", x)


def asin(x):
    return _math_extra_unary("asinf", x)


def acos(x):
    return _math_extra_unary("acosf", x)


def acosh(x):
    return _math_extra_unary("acoshf", x)


def sinh(x):
    return _math_extra_unary("sinhf", x)


def sinpi(x):
    return _math_extra_unary("sinpif", x)


def asinh(x):
    return _math_extra_unary("asinhf", x)


def expm1(x):
    return _math_extra_unary("expm1f", x)


def hypot(lhs, rhs):
    return _math_extra_binary("hypotf", lhs, rhs)


def rhypot(lhs, rhs):
    return _math_extra_binary("rhypotf", lhs, rhs)


def log1p(x):
    return _math_extra_unary("log1pf", x)


def cbrt(x):
    return _math_extra_unary("cbrtf", x)


def rcbrt(x):
    return _math_extra_unary("rcbrtf", x)


def erf(x):
    return _math_extra_unary("erff", x)


def erfc(x):
    return _math_extra_unary("erfcf", x)


def erfinv(x):
    return _math_extra_unary("erfinvf", x)


def erfcinv(x):
    return _math_extra_unary("erfcinvf", x)


def erfcx(x):
    return _math_extra_unary("erfcxf", x)


def tgamma(x):
    return _math_extra_unary("tgammaf", x)


def lgamma(x):
    return _math_extra_unary("lgammaf", x)


def _collective_type(name, value, *, allow_i64=False, allow_bf16=False):
    if is_exact_instance(value, int):
        return ir.IntegerType.get_signless(32)
    if is_exact_instance(value, float):
        return ir.F32Type.get()
    # Check semantic dtype: unsigned wrappers also have a signless carrier.
    allowed = ("int32", "float32", "float16")
    if allow_i64:
        allowed += ("int64",)
    if allow_bf16:
        allowed += ("bfloat16",)
    if not isinstance(value, ir.Value) or getattr(getattr(value, "dtype", None), "name", None) not in allowed:
        raise TypeError(f"simt.{name} supports {allowed}")
    return value.type


def _binary_math(name, lhs, rhs):
    _require_simt(name)
    if isinstance(lhs, ShortVector) or isinstance(rhs, ShortVector):
        raise TypeError(f"simt.{name} is scalar-only; use simt.v{name}")
    dtype = _math_type(lhs)
    if isinstance(lhs, ShortVector):
        return _vector_binary(name, lhs, rhs)
    a = _coerce_simt_storage(lhs, dtype, path=f"simt.{name} lhs")
    b = _coerce_simt_storage(rhs, dtype, path=f"simt.{name} rhs")
    result = ir.Operation.create(f"ascsimt.{name}", operands=[a, b], results=[dtype]).results[0]
    return _wrap_simt_scalar(result, storage_type=dtype)


def pow(lhs, rhs):
    return _binary_math("pow", lhs, rhs)


def atan2(lhs, rhs):
    return _binary_math("atan2", lhs, rhs)


def fmin(lhs, rhs):
    return _binary_math("fmin", lhs, rhs)


def fmax(lhs, rhs):
    return _binary_math("fmax", lhs, rhs)


def fmod(lhs, rhs):
    return _binary_math("fmod", lhs, rhs)


def add(lhs, rhs, rounding=RoundingMode.RN):
    if isinstance(rounding, str):
        rounding = {
            "rn": RoundingMode.RN,
            "rna": RoundingMode.RNA,
            "rd": RoundingMode.RD,
            "ru": RoundingMode.RU,
            "rz": RoundingMode.RZ,
            "ro": RoundingMode.RO,
            "rint": RoundingMode.RN,
        }[rounding.lower()]
    if not isinstance(rounding, RoundingMode):
        raise TypeError("simt.add rounding must be a RoundingMode value")
    return _math_extra_binary("add__" + rounding.name.lower(), lhs, rhs)


def hadd(lhs, rhs):
    return _integer_binary("hadd", lhs, rhs)


def hradd(lhs, rhs):
    return _integer_binary("hradd", lhs, rhs)


def sub(lhs, rhs):
    return _math_extra_binary("sub", lhs, rhs)


def mul(lhs, rhs):
    return _math_extra_binary("mul", lhs, rhs)


def mul_cast(lhs, rhs, *, dtype):
    """Multiply two int32 values and cast the result to the requested dtype."""
    if hasattr(dtype, "kind") and callable(dtype):
        from cannbotdsl.core.contracts.elements import scalar_mlir_type_for_dtype

        target = scalar_mlir_type_for_dtype(dtype)
    else:
        target = dtype.scalar_mlir_type() if hasattr(dtype, "scalar_mlir_type") else dtype
    return _integer_binary("mul_cast", lhs, rhs, result_type=target)


def div(lhs, rhs):
    return _math_extra_binary("div", lhs, rhs)


def max(lhs, rhs):
    return _math_extra_binary("fmaxf", lhs, rhs)


def min(lhs, rhs):
    return _math_extra_binary("fminf", lhs, rhs)


def neg(x):
    return _math_extra_unary("neg", x)


def eq(lhs, rhs):
    return _math_extra_binary_predicate("eq", lhs, rhs)


def ne(lhs, rhs):
    return _math_extra_binary_predicate("ne", lhs, rhs)


def le(lhs, rhs):
    return _math_extra_binary_predicate("le", lhs, rhs)


def ge(lhs, rhs):
    return _math_extra_binary_predicate("ge", lhs, rhs)


def lt(lhs, rhs):
    return _math_extra_binary_predicate("lt", lhs, rhs)


def gt(lhs, rhs):
    return _math_extra_binary_predicate("gt", lhs, rhs)


def rcp(x):
    return _math_extra_unary("hrcp", x)


def mulhi(lhs, rhs):
    return _integer_binary("mulhi", lhs, rhs)


def brev(x):
    return _integer_unary("brev", x)


def clz(x):
    return _integer_unary("clz", x)


def ffs(x):
    return _integer_unary("ffs", x)


def popc(x):
    return _integer_unary("popc", x)


def byte_perm(x, y, selector):
    _require_simt("byte_perm")
    dtype = _integer_type(x, "byte_perm")
    a = _coerce_simt_storage(x, dtype, path="simt.byte_perm x")
    b = _coerce_simt_storage(y, dtype, path="simt.byte_perm y")
    c = _coerce_simt_storage(selector, dtype, path="simt.byte_perm selector")
    result = ir.Operation.create(
        "ascsimt.math_ternary",
        operands=[a, b, c],
        results=[dtype],
        attributes={"function": ir.StringAttr.get("byte_perm")},
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=dtype)


def fdivide(lhs, rhs):
    return _math_extra_binary("fdivide", lhs, rhs)


def sad(x, y, z):
    _require_simt("sad")
    dtype = _integer_type(x, "sad")
    a = _coerce_simt_storage(x, dtype, path="simt.sad x")
    b = _coerce_simt_storage(y, dtype, path="simt.sad y")
    c = _coerce_simt_storage(z, dtype, path="simt.sad z")
    result = ir.Operation.create(
        "ascsimt.math_ternary", operands=[a, b, c], results=[dtype], attributes={"function": ir.StringAttr.get("sad")}
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=dtype)


def mul24(lhs, rhs):
    return _integer_binary("mul24", lhs, rhs)


def _atomic_api(name, *args):
    _require_simt(name)
    from cannbotdsl.ops.scalar import ScalarPtr

    if not isinstance(args[0], ScalarPtr):
        raise TypeError(f"simt.{name} requires a typed pointer")
    from cannbotdsl.tensor import MemLoc

    pointer_memloc = MemLoc(cannir.PointerType(args[0]._value.type).memloc)
    if pointer_memloc not in (MemLoc.GM, MemLoc.UB):
        raise TypeError(f"simt.{name} requires a GM or UB pointer")
    pointer = args[0]._value
    dtype = args[0]._storage_type
    values = [pointer]
    for value in args[1:]:
        values.append(_coerce_simt_storage(value, dtype, path=f"simt.{name} value"))
    result_type = values[1].type
    result = ir.Operation.create(
        "ascsimt.atomic",
        operands=values,
        results=[result_type],
        attributes={"function": ir.StringAttr.get(name)},
    ).results[0]
    return _wrap_simt_scalar(result, storage_type=result_type)


def atomic_add(ptr, value):
    return _atomic_api("atomic_add", ptr, value)


def atomic_sub(ptr, value):
    return _atomic_api("atomic_sub", ptr, value)


def atomic_exch(ptr, value):
    return _atomic_api("atomic_exch", ptr, value)


def atomic_max(ptr, value):
    return _atomic_api("atomic_max", ptr, value)


def atomic_min(ptr, value):
    return _atomic_api("atomic_min", ptr, value)


def atomic_and(ptr, value):
    return _atomic_api("atomic_and", ptr, value)


def atomic_or(ptr, value):
    return _atomic_api("atomic_or", ptr, value)


def atomic_xor(ptr, value):
    return _atomic_api("atomic_xor", ptr, value)


def atomic_inc(ptr, value):
    return _atomic_api("atomic_inc", ptr, value)


def atomic_dec(ptr, value):
    return _atomic_api("atomic_dec", ptr, value)


def atomic_cas(ptr, compare, value):
    return _atomic_api("atomic_cas", ptr, compare, value)


def _vatomic_api(name, ptr, value, compare=None):
    _require_simt("vatomic_" + name)
    from cannbotdsl.ops.scalar import ScalarPtr

    if not isinstance(ptr, ScalarPtr) or not isinstance(value, ShortVector):
        raise TypeError(f"simt.vatomic_{name} requires a typed pointer and ShortVector value")
    from cannbotdsl.tensor import MemLoc

    pointer_memloc = MemLoc(cannir.PointerType(ptr._value.type).memloc)
    if pointer_memloc not in (MemLoc.GM, MemLoc.UB):
        raise TypeError(f"simt.vatomic_{name} requires a GM or UB pointer")
    # The Ascend C SIMT headers only provide packed atomic overloads for
    # half2/bfloat16x2_t, and only for these six operations.  Do not emit a
    # plausible-looking asc_atomic_* call for vector dtypes/operations for
    # which the device header has no overload.
    if value.dtype.name not in {"float16x2", "bfloat16x2"}:
        raise TypeError(
            f"simt.vatomic_{name} supports only dtypes.float16x2 and dtypes.bfloat16x2; got {value.dtype.name}"
        )
    if name not in {"add", "sub", "exch", "max", "min", "cas"}:
        raise NotImplementedError(f"Ascend C has no short-vector asc_atomic_{name} overload")
    operands = [ptr._value]
    if compare is not None:
        if not isinstance(compare, ShortVector) or compare.dtype is not value.dtype:
            raise TypeError(f"simt.vatomic_{name} compare must match value dtype")
        operands.append(compare)
    operands.append(value)
    result = ir.Operation.create(
        "ascsimt.atomic",
        operands=operands,
        results=[value.type],
        attributes={"function": ir.StringAttr.get("atomic_" + name)},
    ).results[0]
    return ShortVector(result, value.dtype)


def vatomic_add(ptr, value):
    return _vatomic_api("add", ptr, value)


def vatomic_sub(ptr, value):
    return _vatomic_api("sub", ptr, value)


def vatomic_exch(ptr, value):
    return _vatomic_api("exch", ptr, value)


def vatomic_max(ptr, value):
    return _vatomic_api("max", ptr, value)


def vatomic_min(ptr, value):
    return _vatomic_api("min", ptr, value)


def vatomic_and(ptr, value):
    return _vatomic_api("and", ptr, value)


def vatomic_or(ptr, value):
    return _vatomic_api("or", ptr, value)


def vatomic_xor(ptr, value):
    return _vatomic_api("xor", ptr, value)


def vatomic_inc(ptr, value):
    return _vatomic_api("inc", ptr, value)


def vatomic_dec(ptr, value):
    return _vatomic_api("dec", ptr, value)


def vatomic_cas(ptr, compare, value):
    return _vatomic_api("cas", ptr, value, compare)
