# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

from enum import IntEnum as _IntEnum

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import asccube, ascvec, cannir
from cannbotdsl.core.ir_transport import unwrap_operand
from cannbotdsl.core.scalar_conversion import coerce_scalar_value
from cannbotdsl.core.utils.type_checks import is_exact_instance


class PIPE(_IntEnum):
    P_NULL = 0
    S = 1
    V = 2
    M = 3
    MTE1 = 4
    MTE2 = 5
    MTE3 = 6
    MTE4 = 7
    MTE5 = 8
    V2 = 9
    ALL = 10
    FIXPIPE = 11
    VLD = 12
    VST = 13
    LD = 14
    ST = 15
    LD_ST = 16
    VEXE = 17
    AIV_MTE2 = 18
    AIC_MTE3 = 19
    AIC_MTE1 = 20


class CmpOp(_IntEnum):
    EQ = 0
    NE = 1
    GE = 2
    GT = 3
    LE = 4
    LT = 5


class _CoreRole(_IntEnum):
    AIC = 0
    AIV = 1


# Codegen packs flag_id into a 4-bit FFTS config field (`flagId & 0xf` in
# lib/CANNIR/Translate/TranslateToAscendC.cpp), so ids above 15 wrap silently.
MAX_SYNC_BLOCK_FLAG_ID = 15

# Flags per barrier: one for the AIV->AIC funnel, one for the cross-block
# handshake, one for the AIC->AIV release.  The ids need not be adjacent or
# related -- the hardware just shifts each into a 4-bit field -- only distinct,
# because the wait path discards mode.
#
# The cross-block flag is issued twice, once by each core type, and that is not
# a collision: mode 0 means "all cores of the issuing type"
# (pto/npu/a2a3/TPush.hpp gives CUBE_ALL_CORE_SYNC and VEC_ALL_CORE_SYNC the
# same value 0), so the issuing core type partitions the flag.
_GLOBAL_SYNC_ALL_FLAG_IDS = (0, 1, 2)
_GLOBAL_SYNC_ALL_PHASES = len(_GLOBAL_SYNC_ALL_FLAG_IDS)


def _check_flag_id(flag_id, *, api_name):
    """Range-check a constant sync_block flag id.

    Out-of-range ids are truncated silently by codegen and the sync_block ops
    declare no verifier, so this is the only guard.  Dynamic i64 SSA ids cannot
    be checked at trace time and pass through.
    """
    if isinstance(flag_id, int) and not 0 <= flag_id <= MAX_SYNC_BLOCK_FLAG_ID:
        raise ValueError(
            f"{api_name} flag_id must be in [0, {MAX_SYNC_BLOCK_FLAG_ID}] (codegen truncates with & 0xf), got {flag_id}"
        )


def _ensure_i32_attr(val: int) -> ir.IntegerAttr:
    """Helper to convert standard Python ints to MLIR I32 attributes."""
    if isinstance(val, ir.IntegerAttr):
        return val
    return ir.IntegerAttr.get(ir.IntegerType.get_signless(32), int(val))


def _ensure_i32_value(val) -> ir.Value:
    """Convert Python int / MLIR Value to an MLIR i32 Value."""
    return coerce_scalar_value(val, ir.IntegerType.get_signless(32))


def _ensure_index_value(val) -> ir.Value:
    """Convert Python int / MLIR Value to an MLIR index Value."""
    return coerce_scalar_value(val, ir.IndexType.get())


def _ensure_i64_value(val) -> ir.Value:
    """Convert a Python integer or explicit i64 SSA value to MLIR i64."""
    try:
        return coerce_scalar_value(val, ir.IntegerType.get_signless(64))
    except TypeError as exc:
        raise TypeError(
            "sync/buffer ID must be an int or i64 MLIR Value "
            f"(or a convertible integer SSA value), got {type(val).__name__}"
        ) from exc


def _unwrap_tensor(value):
    """Raw memory operations consume an explicitly selected Tensor."""
    from cannbotdsl.ops._operands import _tensor_operand

    return unwrap_operand(_tensor_operand(value))


def _wait_point_operands(point, *, api_name):
    if not isinstance(point, ir.Value):
        raise TypeError(f"{api_name} point must be a direct Tensor[...] result, got {type(point).__name__}")

    # Tensor point indexing produces a scalar load SSA value.  Recover its
    # address operands so the wait APIs observe the location rather than the
    # already-loaded scalar.  Unsigned tensor loads add one storage cast.
    value = point
    owner = getattr(value, "owner", None)
    operation = getattr(owner, "operation", owner)
    while getattr(operation, "name", None) == "cannir.scalar_storage_cast":
        value = unwrap_operand(operation.operands[0])
        owner = getattr(value, "owner", None)
        operation = getattr(owner, "operation", owner)

    if getattr(operation, "name", None) != "cannir.memref_load":
        producer = getattr(operation, "name", type(point).__name__)
        raise TypeError(f"{api_name} point must be a direct Tensor[...] result; got value produced by {producer}")

    memref = unwrap_operand(operation.operands[0])
    coord = unwrap_operand(operation.operands[1])
    from cannbotdsl.core.contracts.elements import dtype_for_storage_mlir_type
    from cannbotdsl.tensor import MemLoc

    memref_type = cannir.TensorType(memref.type)
    pointer_type = cannir.PointerType(memref_type.pointer)
    if MemLoc(pointer_type.memloc) != MemLoc.GM:
        raise NotImplementedError(f"{api_name} supports only GM tensor points")

    storage_type = pointer_type.dtype
    dtype = dtype_for_storage_mlir_type(storage_type)
    if dtype.name not in ("int32", "uint32"):
        raise TypeError(f"{api_name} requires an int32 or uint32 GM tensor point, got dtypes.{dtype.name}")
    return memref, coord, storage_type


def _busy_wait(point, expected, cmp, pause_nops, *, api_name, op):
    """Shared body of :func:`cube_busy_wait` and :func:`vec_busy_wait`.

    Two calling conventions:
    1. ``*_busy_wait(check_fn)`` — ``check_fn`` is a callable (e.g. ``@jit``
       method) returning ``Boolean``.  Builds an ``scf.while`` loop that
       repeatedly calls ``check_fn`` until it returns ``True``.  The caller
       manages all UB buffer allocation, event IDs, DMA, and pipeline sync
       inside ``check_fn``.  The loop itself is core-agnostic scaffolding.
    2. ``*_busy_wait(tensor_point, expected, cmp=CmpOp.NE, pause_nops=50)`` —
       dev-bypass GM load polling.  Loops while ``*ptr <cmp> expected`` is
       true, where <cmp> names the not-ready (keep-waiting) condition, and
       executes ``pause_nops`` NOP instructions between two polls.
    """
    if callable(point):
        from cannbotdsl.core.frontend.api import SourceSpan
        from cannbotdsl.core.frontend.runtime.control_flow import while_region
        from cannbotdsl.core.frontend.runtime.hooks import RegionInfo

        def _cond():
            return ~point()

        def _body():
            return ()

        while_region(
            (),
            _cond,
            _body,
            RegionInfo(
                id=0,
                kind="while",
                span=SourceSpan(f"<{api_name}>", 0, 0, 0, 1),
                source=f"<{api_name}>",
                source_first_line=0,
            ),
        )
        return

    from cannbotdsl.core.contracts.elements import coerce_scalar_to_storage

    memref, coord, storage_type = _wait_point_operands(point, api_name=api_name)
    expected_value = coerce_scalar_to_storage(expected, storage_type, path=f"{api_name} expected")
    if not is_exact_instance(pause_nops, int) or pause_nops < 0:
        raise TypeError(f"{api_name} pause_nops must be a non-negative int, got {pause_nops!r}")
    cmp_val = int(cmp) if isinstance(cmp, CmpOp) else int(CmpOp.NE)
    op(memref, coord, expected_value, cmp=cmp_val, pause_nops=pause_nops)


def cube_busy_wait(point, expected=None, *, cmp=CmpOp.NE, pause_nops=50):
    """Busy-wait on a GM scalar on the cube (AIC) core.

    See :func:`_busy_wait` for the two calling conventions.  On a MIX
    kernel the wait executes only in the AIC clone.
    """
    _busy_wait(point, expected, cmp, pause_nops, api_name="cube_busy_wait", op=cannir.cube_busy_wait)


def vec_busy_wait(point, expected=None, *, cmp=CmpOp.NE, pause_nops=50):
    """Busy-wait on a GM scalar on the vector (AIV) core.

    See :func:`_busy_wait` for the two calling conventions.  On a MIX
    kernel the wait executes only in the AIV clone.
    """
    _busy_wait(point, expected, cmp, pause_nops, api_name="vec_busy_wait", op=cannir.vec_busy_wait)


def try_wait(point, expected=None, *, cmp=CmpOp.NE):
    """Read one GM scalar once and return whether it satisfies ``cmp``.

    Two calling conventions:
    1. ``try_wait(check_fn)`` — ``check_fn`` is a callable returning
       ``Boolean``.  Calls ``check_fn`` once and returns its result.
    2. ``try_wait(tensor_point, expected, cmp=CmpOp.NE)`` — volatile GM load.
       Returns ``Boolean`` indicating whether ``*ptr <cmp> expected`` is true.
    """
    if callable(point):
        return point()

    from cannbotdsl.core.contracts.elements import coerce_scalar_to_storage, wrap_produced_scalar

    memref, coord, storage_type = _wait_point_operands(point, api_name="try_wait")
    expected_value = coerce_scalar_to_storage(expected, storage_type, path="try_wait expected")
    cmp_val = int(cmp) if isinstance(cmp, CmpOp) else int(CmpOp.NE)
    result = cannir.try_wait(memref, coord, expected_value, cmp=cmp_val)
    from cannbotdsl._mlir.ir import IntegerType

    return wrap_produced_scalar(result, storage_type=IntegerType.get_signless(1))


# ==============================================================================
# Vector Core Synchronization Operations
# ==============================================================================


def dcci_single(point):
    """Invalidate the data-cache line of one GM scalar location.

    Flushes the cache line containing the location addressed by ``point`` so
    the next scalar-unit read observes Global Memory directly (manual
    cache-coherency barrier for cross-core communication).  Use before
    polling a flag written by another core, or after publishing a
    scalar-unit store that must become visible immediately.

    ``point`` must be a direct ``Tensor[...]`` indexing expression result
    (same calling convention as ``cube_busy_wait``/``vec_busy_wait``/``try_wait``).
    """
    memref, coord, _ = _wait_point_operands(point, api_name="dcci_single")
    cannir.dcci_single(memref, coord)


def dcci_entire_out():
    """Flush all write-out data-cache lines to Global Memory.

    Batch publish barrier after scalar-unit GM stores spanning many cache
    lines.  Complements dcci_single (one precise line) with a whole-region
    flush; stronger than needed for a single flag, cheaper per line for
    large scattered stores.
    """
    cannir.dcci_entire_out()


def dcci_entire_atomic():
    """Flush all atomic-path data-cache lines to Global Memory.

    Publish barrier after atomic read-modify-write ops on GM (counters,
    locks) so other cores observe the effects.  Companion of
    dcci_entire_out for the atomic access path.
    """
    cannir.dcci_entire_atomic()


def dci():
    """Invalidate the entire data cache, discarding dirty lines.

    Stronger than dcci_entire_*: unpublished local modifications are dropped,
    not flushed.  A full data barrier (DSB_ALL) is emitted automatically
    before the invalidation as the hardware contract requires.  Use when
    re-reading GM wholesale after other cores rewrote it and local cached
    writes are known to be disposable.
    """
    cannir.dci()


def vec_get_buf(pipe: PIPE, buf_id, mode: int = 0):
    """
    Apply for a logical buffer within the NPU Vector Core.
    """
    ascvec.get_buf(pipe, _ensure_i64_value(buf_id), _ensure_i32_attr(mode))


def vec_release_buf(pipe: PIPE, buf_id, mode: int = 0):
    """
    Release a logical buffer within the NPU Vector Core.
    """
    ascvec.release_buf(pipe, _ensure_i64_value(buf_id), _ensure_i32_attr(mode))


def vec_sync_intra_arrive(pipe: PIPE, sync_id):
    """
    Issue an intra-block arrive signal within the NPU Vector Core.
    """
    ascvec.sync_intra_arrive(pipe, _ensure_i64_value(sync_id))


def vec_sync_intra_wait(pipe: PIPE, sync_id):
    """
    Wait for an intra-block arrive signal within the NPU Vector Core.
    """
    ascvec.sync_intra_wait(pipe, _ensure_i64_value(sync_id))


def _fill_l1_value(value, value_dtype):
    from cannbotdsl import dtypes

    supported = (dtypes.uint32, dtypes.float16, dtypes.bfloat16)
    if value_dtype is None:
        value_dtype = getattr(value, "dtype", None)
        if value_dtype is None:
            if is_exact_instance(value, int):
                value_dtype = dtypes.uint32
            elif is_exact_instance(value, float):
                value_dtype = dtypes.float16
    if value_dtype not in supported:
        names = ", ".join(f"dtypes.{dtype.name}" for dtype in supported)
        raise TypeError(f"asc_fill_l1 value_dtype must be one of: {names}")
    return unwrap_operand(value_dtype(value)), value_dtype


def _validate_fill_l1_config(*, offset_elems, repeat, blk_num, dst_gap):
    if is_exact_instance(offset_elems, int) and offset_elems < 0:
        raise ValueError("asc_fill_l1 offset_elems must be non-negative")
    for name, value in (("repeat", repeat), ("blk_num", blk_num)):
        if is_exact_instance(value, int) and not 1 <= value <= 32767:
            raise ValueError(f"asc_fill_l1 {name} must be in [1, 32767]")
    if is_exact_instance(dst_gap, int) and not 0 <= dst_gap <= 32767:
        raise ValueError("asc_fill_l1 dst_gap must be in [0, 32767]")


def cube_fill_l1(
    l1_buf, value, *, value_dtype=None, offset_elems: int = 0, repeat: int = 1, blk_num: int = 1, dst_gap: int = 0
):
    """Fill L1 DataBlocks with a uint32 bit pattern, half, or bfloat16 value.

    Python integers default to the ``uint32_t`` bit-pattern overload and Python
    floats default to ``half``. Pass ``value_dtype`` explicitly when a literal
    must use another supported overload. A ``bfloat16_t`` fill value is valid
    only for a bfloat16 L1 destination, matching the Ascend C API.
    """
    from cannbotdsl import dtypes

    _validate_fill_l1_config(
        offset_elems=offset_elems,
        repeat=repeat,
        blk_num=blk_num,
        dst_gap=dst_gap,
    )
    fill_value, resolved_dtype = _fill_l1_value(value, value_dtype)
    dst_dtype = getattr(l1_buf, "dtype", None)
    normal_destinations = {
        dtypes.int16,
        dtypes.uint16,
        dtypes.float16,
        dtypes.int32,
        dtypes.uint32,
        dtypes.float32,
    }
    if dst_dtype == dtypes.bfloat16:
        pass
    elif dst_dtype in normal_destinations:
        if resolved_dtype == dtypes.bfloat16:
            raise TypeError("a bfloat16 asc_fill_l1 value requires a bfloat16 destination")
    else:
        raise TypeError("cube_fill_l1 destination dtype is not supported by asc_fill_l1")
    cannir.raw_fill_l1(
        _unwrap_tensor(l1_buf),
        _ensure_index_value(offset_elems),
        fill_value,
        _ensure_i32_value(repeat),
        _ensure_i32_value(blk_num),
        _ensure_i32_value(dst_gap),
    )


def cube_fill_l1_zero(l1_buf, *, offset_elems: int = 0, repeat: int = 1, blk_num: int = 1, dst_gap: int = 0):
    """Compatibility zero-fill, including internal aliased fp8 L1 buffers."""
    _validate_fill_l1_config(
        offset_elems=offset_elems,
        repeat=repeat,
        blk_num=blk_num,
        dst_gap=dst_gap,
    )
    cannir.raw_fill_l1(
        _unwrap_tensor(l1_buf),
        _ensure_index_value(offset_elems),
        _ensure_i32_value(0),
        _ensure_i32_value(repeat),
        _ensure_i32_value(blk_num),
        _ensure_i32_value(dst_gap),
    )


def vec_sync_block_arrive(pipe: PIPE, flag_id, mode: int = 2):
    """Issue an all-core arrive signal from the NPU Vector Core."""
    _check_flag_id(flag_id, api_name="vec_sync_block_arrive")
    kwargs = {} if mode == 2 else {"mode": _ensure_i32_attr(mode)}
    ascvec.sync_block_arrive(pipe, _ensure_i64_value(flag_id), **kwargs)


def vec_sync_block_wait(pipe: PIPE, flag_id, mode: int = 2):
    """Wait for an all-core sync signal from the NPU Vector Core.

    ``mode`` does not reach the device: codegen emits ``asc_sync_block_wait``
    without it, so the matching arrive alone selects the participant set.

    It is not inert, though.  ``split-mix-kernel`` reads it to tell an
    all-cores handshake (mode 0, survives on a pure-core kernel) from an
    intra-block one (mode 2, pruned there because its partner core is gone).
    Pass the same mode as the matching arrive, or a mode 0 wait will be
    dropped on a pure-core kernel and the barrier will not hold.
    """
    _check_flag_id(flag_id, api_name="vec_sync_block_wait")
    kwargs = {} if mode == 2 else {"mode": _ensure_i32_attr(mode)}
    ascvec.sync_block_wait(pipe, _ensure_i64_value(flag_id), **kwargs)


def vec_sync_all():
    """Wait for all pending Vector Core pipeline operations."""
    ascvec.sync_all()


def vec_sync_pipe(pipe: PIPE):
    """Order operations on one Vector pipeline, including overlapping writes."""
    ascvec.sync_pipe(pipe)


def vec_sync_notify(src_pipe: PIPE, dst_pipe: PIPE, event_id: int):
    """
    Cross-pipe notify within the NPU Vector Core (asc_sync_notify).

    Issued by the producer pipe to inform the consumer pipe that a hardware
    event_id slot is now armed.
    """
    ascvec.sync_notify(
        _ensure_i32_attr(int(src_pipe)),
        _ensure_i32_attr(int(dst_pipe)),
        _ensure_i32_attr(int(event_id)),
    )


def vec_sync_wait(src_pipe: PIPE, dst_pipe: PIPE, event_id: int):
    """
    Cross-pipe wait within the NPU Vector Core (asc_sync_wait).

    AscendC convention: BOTH notify and wait carry (src_pipe=producer,
    dst_pipe=consumer). The wait blocks the consumer pipe until the
    producer signals — pass the SAME (src, dst) ordering as the matching
    vec_sync_notify; do not flip the args.
    """
    ascvec.sync_wait(
        _ensure_i32_attr(int(src_pipe)),
        _ensure_i32_attr(int(dst_pipe)),
        _ensure_i32_attr(int(event_id)),
    )


# ==============================================================================
# Cube Core Synchronization Operations
# ==============================================================================


def cube_get_buf(pipe: PIPE, buf_id, mode: int = 0):
    """
    Apply for a logical buffer within the NPU Cube Core.
    """
    asccube.get_buf(pipe, _ensure_i64_value(buf_id), _ensure_i32_attr(mode))


def cube_release_buf(pipe: PIPE, buf_id, mode: int = 0):
    """
    Release a logical buffer within the NPU Cube Core.
    """
    asccube.release_buf(pipe, _ensure_i64_value(buf_id), _ensure_i32_attr(mode))


def cube_sync_intra_arrive(pipe: PIPE, sync_id):
    """
    Issue an intra-block arrive signal within the NPU Cube Core.
    """
    asccube.sync_intra_arrive(pipe, _ensure_i64_value(sync_id))


def cube_sync_intra_wait(pipe: PIPE, sync_id):
    """
    Wait for an intra-block arrive signal within the NPU Cube Core.
    """
    asccube.sync_intra_wait(pipe, _ensure_i64_value(sync_id))


def cube_sync_block_arrive(pipe: PIPE, flag_id, mode: int = 2):
    """Issue an all-core arrive signal from the NPU Cube Core."""
    _check_flag_id(flag_id, api_name="cube_sync_block_arrive")
    kwargs = {} if mode == 2 else {"mode": _ensure_i32_attr(mode)}
    asccube.sync_block_arrive(pipe, _ensure_i64_value(flag_id), **kwargs)


def cube_sync_block_wait(pipe: PIPE, flag_id, mode: int = 2):
    """Wait for an all-core sync signal from the NPU Cube Core.

    ``mode`` does not reach the device: codegen emits ``asc_sync_block_wait``
    without it, so the matching arrive alone selects the participant set.

    It is not inert, though.  ``split-mix-kernel`` reads it to tell an
    all-cores handshake (mode 0, survives on a pure-core kernel) from an
    intra-block one (mode 2, pruned there because its partner core is gone).
    Pass the same mode as the matching arrive, or a mode 0 wait will be
    dropped on a pure-core kernel and the barrier will not hold.
    """
    _check_flag_id(flag_id, api_name="cube_sync_block_wait")
    kwargs = {} if mode == 2 else {"mode": _ensure_i32_attr(mode)}
    asccube.sync_block_wait(pipe, _ensure_i64_value(flag_id), **kwargs)


def cube_sync_all():
    """Wait for all pending Cube Core pipeline operations."""
    asccube.sync_all()


def cube_sync_pipe(pipe: PIPE):
    """Wait for all pending operations issued on one Cube pipeline."""
    asccube.sync_pipe(pipe)


def cube_sync_notify(src_pipe: PIPE, dst_pipe: PIPE, event_id: int):
    """
    Cross-pipe notify within the NPU Cube Core (asc_sync_notify).

    The canonical use is to serialize a producer pipe's GM/L1 write against
    a consumer pipe's GM/L1 read on the same memory region — e.g., after a
    FIXPIPE drains L0C → GM, notify MTE2 before re-reading the same GM tile
    via copy_gm2l1. AscendC does NOT auto-serialize across pipes.
    """
    asccube.sync_notify(
        _ensure_i32_attr(int(src_pipe)),
        _ensure_i32_attr(int(dst_pipe)),
        _ensure_i32_attr(int(event_id)),
    )


def cube_sync_wait(src_pipe: PIPE, dst_pipe: PIPE, event_id: int):
    """
    Cross-pipe wait within the NPU Cube Core (asc_sync_wait).

    AscendC convention: BOTH notify and wait carry (src_pipe=producer,
    dst_pipe=consumer). The wait says 'block on the consumer pipe until
    the producer pipe has signalled this event_id'. So callers should pass
    the SAME (src, dst) ordering they used for cube_sync_notify — do not
    flip the args.

    event_id should cycle over a small pool (typically 0-3 for the cube
    core) — reusing the same id sequentially is safe because each
    notify/wait pair drains before the id is reused.
    """
    asccube.sync_wait(
        _ensure_i32_attr(int(src_pipe)),
        _ensure_i32_attr(int(dst_pipe)),
        _ensure_i32_attr(int(event_id)),
    )


# ==============================================================================
# Grid-wide Synchronization
# ==============================================================================


def global_sync_all(*, flag_ids=None):
    """Barrier across every core of the launch.

    Emits the full four-phase sequence.  What survives depends on how the
    kernel classifies, which ``split-mix-kernel`` decides late in the pass
    pipeline from the ops the whole function ended up emitting:

    ======  ==============================  ============================
    phase   handshake                       kept on
    ======  ==============================  ============================
    1       AIV -> AIC, within block (m=2)  mix
    2       all AIC, across blocks   (m=0)  mix, pure-AIC
    3       all AIV, across blocks   (m=0)  mix, pure-AIV
    4       AIC -> AIV, within block (m=2)  mix
    ======  ==============================  ============================

    On a mix kernel all four run.  Phase 2 is the grid barrier; phases 1 and 4
    funnel the vector cores through the AIC of their own block, which is the
    only cross-block path they have.  Phase 3 is a redundant AIV-to-AIV meeting
    point inside that funnel -- every AIV reaches it anyway, so it reorders
    nothing.

    On a pure-core kernel ``split-mix-kernel`` prunes the other core's ops and
    the mode 2 handshakes, whose partner no longer runs, leaving a single
    mode 0 barrier: phase 2 on pure AIC, phase 3 on pure AIV.  That is why this
    function does not take a "which core am I" argument -- at trace time the
    kernel body after this call does not exist yet, so any answer here would be
    a guess about ops not yet emitted.  Emitting the superset and letting the
    pass prune moves the decision to where the answer is known.

    Phases 2 and 3 share a flag id.  mode 0 means "all cores of the issuing
    type" -- ``pto/npu/a2a3/TPush.hpp`` gives ``CUBE_ALL_CORE_SYNC`` and
    ``VEC_ALL_CORE_SYNC`` the same value 0 -- so the issuing core type
    partitions the flag and the two handshakes cannot alias.  The three ids
    that *are* distinct must stay so: codegen drops ``mode`` on the wait path,
    leaving the id as the only thing telling one phase from the next.

    The leading sync_all calls are load-bearing: an FFTS arrive drains only the
    pipe it is issued on, so without them a peer can observe the flag before an
    in-flight write on another pipe.

    Args:
        flag_ids: three distinct ids in [0, 15] -- funnel-in, cross-block,
            funnel-out. Defaults to the fixed triple (0, 1, 2), reused by
            successive completed barriers, including statically unrolled loops.
            Keep these IDs separate from overlapping manual FFTS protocols,
            or supply a different explicit triple for the barrier.

    The Channel resource pass can reuse hardware IDs across this complete
    barrier once the old protocols are closed. ``channel_rewind()`` is needed
    only when explicitly reusing on-chip addresses; it is not an ID allocator
    and cannot replace this synchronization boundary.

    Deadlocks if the launch does not fit one resident wave: a mode 0 phase
    makes resident blocks wait for blocks the scheduler cannot start.
    ``block_dim`` must not exceed the device core count for the issuing core
    type.  That cannot be checked here -- this function has no visibility into
    block_dim.
    """
    if flag_ids is None:
        flag_ids = _GLOBAL_SYNC_ALL_FLAG_IDS
    else:
        flag_ids = list(flag_ids)
        if len(flag_ids) != _GLOBAL_SYNC_ALL_PHASES:
            raise ValueError(
                f"global_sync_all needs {_GLOBAL_SYNC_ALL_PHASES} flag ids (one per phase), got {len(flag_ids)}"
            )
        if len(set(flag_ids)) != len(flag_ids):
            raise ValueError(
                "global_sync_all flag_ids must be distinct -- the wait path "
                f"ignores mode, so a shared id merges two phases: {flag_ids}"
            )
        for flag_id in flag_ids:
            _check_flag_id(flag_id, api_name="global_sync_all")

    aiv_ready_flag_id, cross_block_flag_id, aic_aiv_ready_flag_id = flag_ids

    # Drain both cores' pipelines before anything is announced externally.
    cube_sync_all()
    vec_sync_all()

    # 1. AIV -> AIC, within block.
    vec_sync_block_arrive(PIPE.MTE3, aiv_ready_flag_id, mode=2)
    cube_sync_block_wait(PIPE.S, aiv_ready_flag_id)

    # 2. All AIC, across blocks -- the grid barrier.
    cube_sync_block_arrive(PIPE.FIXPIPE, cross_block_flag_id, mode=0)
    cube_sync_block_wait(PIPE.S, cross_block_flag_id, mode=0)

    # 3. All AIV, across blocks.  Redundant on a mix kernel -- every AIV is
    # already held by phases 1 and 4 -- and the whole barrier on a pure-AIV
    # kernel, once the pass has pruned the cube side.  Shares phase 2's flag:
    # mode 0 is partitioned by issuing core type.
    vec_sync_block_arrive(PIPE.MTE3, cross_block_flag_id, mode=0)
    vec_sync_block_wait(PIPE.S, cross_block_flag_id, mode=0)

    # 4. AIC -> AIV, within block.
    cube_sync_block_arrive(PIPE.MTE3, aic_aiv_ready_flag_id, mode=2)
    vec_sync_block_wait(PIPE.S, aic_aiv_ready_flag_id)


def channel_rewind(reset_sync_id=True):
    """Declare an explicit address/Buffer-ID allocation boundary.

    With reset_sync_id=True, also permit a new counter allocation phase.
    False keeps counters in the same phase at this boundary only. A boundary
    does not insert a hardware barrier or release live resources: counter reuse
    still needs proven completion, and address reuse requires dead storage.
    Hardware IDs are assigned by MLIR using next-fit; its cursor is not reset.
    """
    from cannbotdsl._onchip import _current_onchip_trace

    if not is_exact_instance(reset_sync_id, bool):
        raise TypeError("reset_sync_id must be a static bool")
    state = _current_onchip_trace()
    if state.space_roots:
        raise ValueError("channel_rewind is not supported in kernels with manual storage roots")
    state.has_rewind = True
    cannir.OnChipRewindOp(reset_sync_id=reset_sync_id)


# ==============================================================================
# UDMA Communication (Hcomm)
# ==============================================================================


def hcomm_init(ubuf, ubuf_len: int = 512, *, core: _CoreRole):
    """Initialize an Hcomm UDMA instance on its communication core."""
    from cannbotdsl.buffer import Buffer
    from cannbotdsl.tensor import Tensor

    if isinstance(ubuf, (Tensor,)):
        ubuf_val = unwrap_operand(ubuf)
    elif isinstance(ubuf, Buffer):
        ubuf_val = ubuf.memref
    elif isinstance(ubuf, ir.Value):
        ubuf_val = ubuf
    else:
        raise TypeError(f"hcomm_init ubuf must be a Buffer or Tensor, got {type(ubuf).__name__}")
    return cannir.hcomm_init(
        ubuf_val,
        _ensure_i32_value(ubuf_len),
        core=core,
    )


def write_nbi(handle, channel, dst, src, length, *, core: _CoreRole):
    """Non-blocking PUT write from local GM to a remote rank's comm buffer."""
    from cannbotdsl.tensor import Tensor

    if isinstance(src, Tensor):
        src_val = unwrap_operand(src)
    elif isinstance(src, ir.Value):
        src_val = src
    else:
        src_val = _ensure_i64_value(src)
    cannir.write_nbi(
        _ensure_i64_value(handle),
        _ensure_i64_value(channel),
        _ensure_i64_value(dst),
        src_val,
        _ensure_i64_value(length),
        core=core,
    )


def read_nbi(handle, channel, dst, src, length, *, core: _CoreRole):
    """Non-blocking GET read from remote GM into local GM."""

    cannir.read_nbi(
        _ensure_i64_value(handle),
        _ensure_i64_value(channel),
        _ensure_i64_value(dst),
        _ensure_i64_value(src),
        _ensure_i64_value(length),
        core=core,
    )


def _tensor_to_gm_addr(tensor):
    """Extract the raw GM byte address from a DSL Tensor or ir.Value."""
    from cannbotdsl._mlir.dialects import cannir as cannir_dialect
    from cannbotdsl.tensor import Tensor

    if isinstance(tensor, Tensor):
        value = unwrap_operand(tensor)
    else:
        value = tensor

    for _ in range(20):
        if isinstance(value, Tensor):
            value = unwrap_operand(value)
            continue
        if isinstance(value, ir.Value):
            break
        raise TypeError(f"write_nbi src does not contain an ir.Value, got {type(value).__name__}")

    VIEW_OPS = frozenset(
        (
            "cannir.tile_slice",
            "cannir.local_slice",
            "cannir.partition_view",
            "cannir.rebase_view",
            "cannir.permute_view",
            "cannir.tensor_select",
        )
    )

    for _ in range(10):
        if isinstance(value, Tensor):
            value = unwrap_operand(value)
            continue
        owner = value.owner
        if owner is None:
            break
        op = owner if hasattr(owner, "name") else getattr(owner, "operation", None)
        if op is None:
            break
        op_name = getattr(op, "name", None)
        if op_name in VIEW_OPS:
            value = op.operands[0]
            continue
        break

    memref_value = value

    if not cannir_dialect.TensorType.isinstance(memref_value.type):
        raise TypeError(f"write_nbi src must be a GM tensor, got type {memref_value.type}")

    ptr = cannir_dialect.extract_pointer(memref_value)

    ptr_owner = ptr.owner
    if ptr_owner is not None:
        ptr_op = ptr_owner if hasattr(ptr_owner, "name") else getattr(ptr_owner, "operation", None)
        if ptr_op is not None and getattr(ptr_op, "name", None) == "cannir.make_pointer":
            return ptr_op.operands[0]

    addr = cannir_dialect.extract_address(ptr)
    return addr


def hcomm_drain(handle, channel, *, core: _CoreRole):
    """Block until all submitted transfers on a channel complete."""
    cannir.hcomm_drain(
        _ensure_i64_value(handle),
        _ensure_i64_value(channel),
        core=core,
    )
