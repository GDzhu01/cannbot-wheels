# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Distributed data-plane lowering primitives for MC2 kernels.

A rank's registered communication buffer is addressed through
``ctx.commBufferAddrs[pe]``.  Callers describe explicitly reserved symmetric
regions with ``SymBuffer``; this module does not reserve hidden heap offsets.

Public transfers are issued through
``distributed.create_transfer_context(..., role=TransferRole.*)``.  Its
``put`` method writes local data to a peer, while ``get`` reads peer data
into a local destination.  Both accept contiguous Identity/ND GM tensors or
``tile_slice`` views.  The byte addresses are derived from the view chains
and the byte count from the source view's tail-aware actual extent.  Its
``flush`` method drains that context's Hcomm stream on one peer channel.
The private ``_put``, ``_get``, and ``_flush`` helpers emit the role-bearing
CANNIR operations used by that facade.

``BarrierContext.barrier_all(epoch)`` provides the cross-rank barrier over
caller-owned symmetric flag rows (DMA flag write, then busy-wait poll; two
phases: write ALL, then poll ALL).  Its private ``_barrier_all`` lowering is
kept here beside the data-plane primitives.
"""

import cannbotdsl._mlir.ir as ir
from cannbotdsl import Buffer, MemLoc, get_block_idx, mem_copy
from cannbotdsl import dtypes as d
from cannbotdsl._mlir.dialects import arith, cannir
from cannbotdsl.core.contracts.elements import dtype_for_storage_mlir_type
from cannbotdsl.core.ir_transport import unwrap_operand
from cannbotdsl.core.scalar_conversion import coerce_scalar_value, materialize_literal
from cannbotdsl.core.utils.type_checks import is_exact_instance
from cannbotdsl.lang.jit import jit
from cannbotdsl.lang.vf import vf
from cannbotdsl.ops.sync import (
    PIPE,
    hcomm_drain,
    read_nbi,
    vec_busy_wait,
    vec_sync_notify,
    vec_sync_wait,
    write_nbi,
)
from cannbotdsl.tensor import (
    LayoutMapKind,
    tile_slice,
)
from cannbotdsl.types._numeric import Int64 as _Int64

_BARRIER_EVENT_ID = 1


# View ops whose origin shift this module can derive.  tile_slice covers the
# zero-copy alias style; other view kinds raise a clear error.
_SUPPORTED_VIEW_OPS = frozenset({"cannir.tile_slice"})


def _i64_type():
    """Signless i64 MLIR type (created lazily — needs an MLIR context)."""

    return ir.IntegerType.get_signless(64)


def _flatten_tree(tree):
    """DFS-flatten a nested int tuple into its leaves."""

    leaves = []

    def visit(node):
        if isinstance(node, (list, tuple)):
            for child in node:
                visit(child)
            return
        leaves.append(node)

    visit(tree)
    return leaves


def _to_i64_ssa(term):
    """Materialize an int / integer-SSA term as a signless i64 SSA value."""

    if isinstance(term, int):
        return materialize_literal(term, _i64_type(), semantic_unsigned=False)
    return coerce_scalar_value(term, _i64_type())


def _defining_op(value):
    """The defining op of an OpResult as its registered OpView; else None."""

    if isinstance(value, ir.OpResult):
        owner = value.owner
        return owner.opview if hasattr(owner, "opview") else owner
    return None


def _view_origin_elements(value):
    """Peel a tile_slice chain, returning ``(root_ssa, origin_terms, extents)``.

    *origin_terms*: one element-count contribution (int or integer SSA
    value) per nonzero (coord x tile x parent-stride) leaf product.
    *extents*: per-leaf actual extent (int or i64 SSA) of the outermost
    view — tail tiles are clipped to the remaining parent range
    (``min(parent_dim - coord x tile, tile)``), matching the tile_slice
    runtime semantics.
    """

    terms = []
    extents = None
    while True:
        defining = _defining_op(value)
        op_name = getattr(defining, "name", None) if defining is not None else None
        if op_name not in _SUPPORTED_VIEW_OPS:
            return value, terms, extents
        if op_name != "cannir.tile_slice":
            raise NotImplementedError(f"distributed transfer: unsupported view op {op_name}")
        parent = unwrap_operand(defining.input)

        tile_type = defining.tile.type
        coord_type = defining.coord.type
        tile_leaves = _flatten_tree(tile_type.as_tuple)
        if any(leaf == tile_type.DYNAMIC for leaf in tile_leaves):
            raise NotImplementedError(
                "distributed transfer: dynamic tile leaves (make_bounded_tiler) have no derivable byte origin"
            )
        coord_leaves = _flatten_tree(coord_type.as_tuple)
        if any(leaf == coord_type.KEEP for leaf in coord_leaves):
            raise NotImplementedError("distributed transfer: coord KEEP leaves are not supported")
        dynamic_values = list(defining.coord.owner.opview.dynamic_values)
        dyn_iter = iter(dynamic_values)
        coord_vals = []
        for leaf in coord_leaves:
            coord_vals.append(next(dyn_iter) if leaf == coord_type.DYNAMIC else leaf)

        parent_dims = _flatten_tree(parent.type.layout.shape)
        parent_strides = _flatten_tree(parent.type.layout.stride)
        if any(not isinstance(leaf, int) for leaf in parent_strides):
            raise NotImplementedError("distributed transfer: dynamic parent strides have no derivable byte origin")
        if any(not isinstance(leaf, int) for leaf in parent_dims):
            raise NotImplementedError("distributed transfer: dynamic parent dims have no derivable byte origin")
        num_parent = len(parent_strides)
        num_leaves = len(tile_leaves)
        if len(coord_vals) != num_leaves or num_leaves > num_parent:
            raise ValueError(
                f"distributed transfer: tile/coord/stride leaf mismatch ({num_leaves} leaves on {num_parent} dims)"
            )

        shape_leaves = _flatten_tree(value.type.layout.shape)
        first_peel = extents is None
        if first_peel:
            extents = []
        dim_base = num_parent - num_leaves

        for i in range(num_leaves):
            coord = coord_vals[i]
            tile = tile_leaves[i]
            stride = parent_strides[dim_base + i]
            if first_peel:
                shape_leaf = shape_leaves[i]
                if isinstance(shape_leaf, int) and shape_leaf >= 0:
                    extents.append(shape_leaf)
                elif isinstance(coord, int):
                    extents.append(max(min(parent_dims[dim_base + i] - coord * tile, tile), 0))
                else:
                    remaining = arith.subi(
                        _to_i64_ssa(parent_dims[dim_base + i]), arith.muli(_to_i64_ssa(coord), _to_i64_ssa(tile))
                    )
                    extents.append(arith.minsi(remaining, _to_i64_ssa(tile)))
            if tile == 0 or stride == 0:
                continue
            if isinstance(coord, int):
                if coord == 0:
                    continue
                terms.append(coord * tile * stride)
            else:
                terms.append(arith.muli(_to_i64_ssa(coord), _to_i64_ssa(tile * stride)))
        value = parent


def _elem_size_bytes(tensor_type):
    tensor_type = cannir.TensorType(tensor_type)
    storage = cannir.PointerType(tensor_type.pointer).dtype
    bits = dtype_for_storage_mlir_type(storage).bits
    if bits < 8 or bits % 8:
        raise NotImplementedError("distributed transfer: sub-byte tensor dtypes are not supported")
    return bits // 8


def _view_extents(value, extents):
    """Return actual view extents, or the declared root Tensor shape."""

    if extents is not None:
        return extents
    tensor_type = cannir.TensorType(value.type)
    return _flatten_tree(tensor_type.layout.shape)


def _require_contiguous_gm(value, root, extents, *, operand):
    """Validate the statically provable byte-span contract of a transfer."""

    tensor_type = cannir.TensorType(value.type)
    root_type = cannir.TensorType(root.type)
    root_pointer = cannir.PointerType(root_type.pointer)
    if MemLoc(root_pointer.memloc) != MemLoc.GM:
        raise NotImplementedError(f"distributed transfer: {operand} must be a GM Tensor")

    dtype = dtype_for_storage_mlir_type(root_pointer.dtype)
    if dtype.bits < 8 or dtype.bits % 8:
        raise NotImplementedError(f"distributed transfer: {operand} sub-byte dtype {dtype.name} is not supported")

    layout_map_kind = LayoutMapKind(tensor_type.layout_map_kind)
    if layout_map_kind != LayoutMapKind.Identity:
        raise NotImplementedError(
            f"distributed transfer: {operand} must use an Identity/ND layout; got {layout_map_kind.name}"
        )

    strides = _flatten_tree(tensor_type.layout.stride)
    if len(extents) != len(strides):
        raise NotImplementedError(
            f"distributed transfer: {operand} contiguous byte span cannot be "
            "proved because shape and stride ranks differ"
        )

    # A zero-element view has an empty byte span regardless of its strides.
    if any(isinstance(extent, int) and extent == 0 for extent in extents):
        return

    expected_stride = 1
    dynamic_inner_span = False
    for extent, stride in reversed(list(zip(extents, strides))):
        if not isinstance(stride, int) or stride < 0:
            raise NotImplementedError(
                f"distributed transfer: {operand} contiguous byte span requires static non-negative strides"
            )
        if isinstance(extent, int):
            if extent < 0:
                raise NotImplementedError(
                    f"distributed transfer: {operand} contiguous byte span cannot "
                    "be proved from a dynamic declared extent"
                )
            if extent <= 1:
                continue
            if dynamic_inner_span or stride != expected_stride:
                raise NotImplementedError(
                    f"distributed transfer: {operand} must be contiguous; "
                    f"got extents {extents!r} and strides {strides!r}"
                )
            expected_stride *= extent
            continue

        if dynamic_inner_span or stride != expected_stride:
            raise NotImplementedError(
                f"distributed transfer: {operand} must be contiguous; got extents {extents!r} and strides {strides!r}"
            )
        dynamic_inner_span = True


def _root_gm_byte_addr(root):
    """Byte address (i64 SSA) of a view-chain root GM tensor."""

    ptr = cannir.extract_pointer(root)
    owner = ptr.owner
    op = owner if hasattr(owner, "name") else getattr(owner, "operation", None)
    if op is not None and getattr(op, "name", None) == "cannir.make_pointer":
        return op.operands[0]
    return cannir.extract_address(ptr)


def _addr_from_parts(root, terms):
    """Root byte address + view-origin terms -> byte address (i64 SSA)."""

    root_addr = _root_gm_byte_addr(root)
    itemsize = _elem_size_bytes(root.type)

    offset = None
    int_sum = 0
    for term in terms:
        if isinstance(term, int):
            int_sum += term
        elif offset is None:
            offset = term
        else:
            offset = arith.addi(offset, term)
    if int_sum:
        offset = _to_i64_ssa(int_sum) if offset is None else arith.addi(offset, _to_i64_ssa(int_sum))
    if offset is not None:
        return arith.addi(root_addr, arith.muli(offset, _to_i64_ssa(itemsize)))
    return root_addr


def _tensor_gm_addr(src):
    """Byte address (i64 SSA) of a GM tensor, view origin included."""

    if isinstance(src, ir.Value):
        value = src
    else:
        value = unwrap_operand(src)

    root, terms, extents = _view_origin_elements(value)
    extents = _view_extents(value, extents)
    _require_contiguous_gm(value, root, extents, operand="destination")
    return _addr_from_parts(root, terms)


def _tensor_gm_addr_and_bytes(src):
    """Resolve a GM tensor (optionally a tile_slice alias) to
    ``(byte_addr_i64_ssa, nbytes)``.

    The address includes the view origin; the byte count comes from the
    per-leaf actual extents (tail tiles clipped to the remaining parent
    range), so the payload never over-reads the source tensor.
    """

    if isinstance(src, ir.Value):
        value = src
    else:
        value = unwrap_operand(src)

    root, _terms, extents = _view_origin_elements(value)
    extents = _view_extents(value, extents)
    _require_contiguous_gm(value, root, extents, operand="source")
    byte_addr = _addr_from_parts(root, _terms)
    itemsize = _elem_size_bytes(root.type)

    if not extents or any(isinstance(leaf, int) and leaf < 0 for leaf in extents):
        raise NotImplementedError("distributed transfer: view extent has no derivable byte count")
    numel = None
    for leaf in extents:
        if numel is None:
            numel = leaf
        elif isinstance(numel, int) and isinstance(leaf, int):
            numel = numel * leaf
        else:
            numel = arith.muli(_to_i64_ssa(numel), _to_i64_ssa(leaf))
    if isinstance(numel, int):
        nbytes = numel * itemsize
    else:
        nbytes = arith.muli(numel, _to_i64_ssa(itemsize))
    return byte_addr, nbytes


def _as_i64(v):
    """Normalize an int / integer SSA to a 64-bit ``Integer`` wrapper."""

    if is_exact_instance(v, int):
        return d.int64(v)
    if (
        isinstance(v, ir.Value)
        and isinstance(v.type, ir.IntegerType)
        and v.type.width == 64
        and not isinstance(v, _Int64)
    ):
        return d.int64(v)
    if isinstance(v, _Int64):
        return v
    return d.int64(coerce_scalar_value(v, _Int64.scalar_mlir_type()))


def _put(ctx, handle, pe, dst, src, *, core):
    """Nonblocking PUT into a peer's symmetric heap on the selected core.

    Copies a contiguous Identity/ND GM tensor or ``tile_slice`` view ``src``
    into a likewise contiguous ``dst`` at the symmetric position (e.g.
    ``tile_slice(sym_buffer, tiler, coord).peer(pe)``). The byte count derives from
    ``src``'s per-leaf actual extents. Sub-byte dtypes and layouts whose byte span
    cannot be proved contiguous are rejected.  Transport runs on ``pe``'s
    channel; completion requires the matching core-specific flush.
    """

    channel = ctx.channelHandles[_as_i64(pe)]
    dst_addr = _tensor_gm_addr(dst)
    src_addr, nbytes = _tensor_gm_addr_and_bytes(src)
    write_nbi(handle, channel, dst_addr, src_addr, nbytes, core=core)


def _get(ctx, handle, pe, dst, src, *, core):
    """Nonblocking GET from a peer's symmetric heap on the selected core.

    Copies a contiguous Identity/ND GM tensor or ``tile_slice`` view ``src``
    at a peer-accessible address into a likewise contiguous local ``dst``.
    The byte count derives from ``src``'s per-leaf actual extents. Transport
    runs on ``pe``'s channel; completion requires the matching core-specific
    flush.
    """

    channel = ctx.channelHandles[_as_i64(pe)]
    dst_addr = _tensor_gm_addr(dst)
    src_addr, nbytes = _tensor_gm_addr_and_bytes(src)
    read_nbi(handle, channel, dst_addr, src_addr, nbytes, core=core)


def _flush(ctx, handle, pe, *, core):
    """Complete this context's outstanding transfers on one peer channel."""

    channel = ctx.channelHandles[_as_i64(pe)]
    hcomm_drain(handle, channel, core=core)


@jit
def _barrier_all(flags, epoch):
    """Cross-rank barrier over a symmetric flag buffer.

    Job-strided flag rows: block ``j`` of card ``R`` writes row ``j`` locally
    and polls row ``R`` in every peer rank ``i``
    it serves (mirrors apace barrier_ubmem CrossDeviceExecute: write ALL,
    then poll ALL). ``epoch`` is the monotonic round number. The implementation
    derives rank metadata from the buffer's CommContext, uses the executing
    block id for work mapping, and owns its small UB scratch buffer. Each rank
    occupies one 32-byte row in the two-dimensional flag matrix.
    """

    ctx = flags.comm
    rank_size = d.int64(flags.rank_size)
    count = d.int32(epoch)
    job_index = get_block_idx()
    my_rank = d.int32(ctx.rankId)
    my_rank_i64 = d.int64(my_rank)
    sync_buf = Buffer(MemLoc.UB, shape=(1, 8), dtype=d.int32)

    ub_tile = tile_slice(sync_buf, (1, 1), (0, 0))

    for i in range(job_index, rank_size, rank_size):
        gm_tile = tile_slice(flags, (1, 1), (i, 0))

        with vf(mode="simt", thread=1):
            sync_buf[d.int64(0), d.int64(0)] = count
        vec_sync_notify(PIPE.S, PIPE.MTE3, _BARRIER_EVENT_ID)
        vec_sync_wait(PIPE.S, PIPE.MTE3, _BARRIER_EVENT_ID)
        mem_copy(gm_tile, ub_tile)
        vec_sync_notify(PIPE.MTE3, PIPE.S, _BARRIER_EVENT_ID)
        vec_sync_wait(PIPE.MTE3, PIPE.S, _BARRIER_EVENT_ID)

    for i in range(job_index, rank_size, rank_size):
        i_i32 = d.int32(i)
        if i_i32 != my_rank:
            _poll_remote_flag(flags, sync_buf, i, my_rank_i64, count)


def _poll_remote_flag(flags, sync_buf, remote_rank, my_rank_i64, count):
    """Poll this rank's row in one peer until it reaches ``count``."""

    ub_tile = tile_slice(sync_buf, (1, 1), (0, 0))
    remote_tile = tile_slice(flags, (1, 1), (my_rank_i64, 0)).peer(remote_rank)

    def _check():
        vec_sync_notify(PIPE.S, PIPE.MTE2, _BARRIER_EVENT_ID)
        vec_sync_wait(PIPE.S, PIPE.MTE2, _BARRIER_EVENT_ID)
        mem_copy(ub_tile, remote_tile)
        vec_sync_notify(PIPE.MTE2, PIPE.S, _BARRIER_EVENT_ID)
        vec_sync_wait(PIPE.MTE2, PIPE.S, _BARRIER_EVENT_ID)
        return sync_buf[d.int64(0), d.int64(0)] >= count

    vec_busy_wait(_check)
