# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""cannbotdsl.ops.distributed -- HCCL collectives, reached as ``cannbotdsl.distributed.*``."""

from cannbotdsl.ops.distributed.context import (
    auto,
    dtypes,
    CArray,
    datastruct,
    hccl,
    COMM_MAX_RANK_NUM,
    CommEngine,
    Engine,
    BufferSource,
    CommContext,
    get_comm_context,
    get_device_ptr,
)
from cannbotdsl.ops.distributed.sym_buffer import SymBuffer
from cannbotdsl.ops.distributed.barrier_context import (
    BARRIER_FLAG_ELEMS,
    BarrierContext,
    create_barrier_context,
)
from cannbotdsl.ops.distributed.transfer_context import (
    TransferContext,
    TransferRole,
    create_transfer_context,
)

__all__ = [
    "BufferSource",
    "BARRIER_FLAG_ELEMS",
    "BarrierContext",
    "CArray",
    "COMM_MAX_RANK_NUM",
    "CommContext",
    "CommEngine",
    "Engine",
    "SymBuffer",
    "TransferContext",
    "TransferRole",
    "auto",
    "datastruct",
    "dtypes",
    "get_comm_context",
    "get_device_ptr",
    "hccl",
    "create_barrier_context",
    "create_transfer_context",
]
