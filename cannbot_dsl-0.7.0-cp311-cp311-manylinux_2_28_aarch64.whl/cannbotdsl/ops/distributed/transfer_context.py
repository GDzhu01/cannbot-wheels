# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Kernel-side context for role-owned distributed transfers."""

from enum import IntEnum

from cannbotdsl.core.utils.type_checks import is_exact_instance


class TransferRole(IntEnum):
    """Core role that owns a transfer context and all of its side effects."""

    CUBE = 0
    VEC = 1


class TransferContext:
    """One Hcomm transfer stream bound to a communication context and role."""

    __slots__ = ("_comm", "_handle", "_role")

    def __init__(self, *args, **kwargs):
        raise TypeError("TransferContext cannot be constructed directly; use create_transfer_context")

    @classmethod
    def _create(cls, comm, handle, role):
        instance = object.__new__(cls)
        object.__setattr__(instance, "_comm", comm)
        object.__setattr__(instance, "_handle", handle)
        object.__setattr__(instance, "_role", role)
        return instance

    def __setattr__(self, name, value):
        raise AttributeError("TransferContext is immutable")

    @property
    def role(self):
        """The core role selected when this context was created."""

        return self._role

    def _core_role(self):
        from cannbotdsl.ops.sync import _CoreRole

        if self._role is TransferRole.CUBE:
            return _CoreRole.AIC
        return _CoreRole.AIV

    def put(self, pe, dst, src):
        """Issue a nonblocking transfer from ``src`` to peer ``dst``."""

        from cannbotdsl.ops.distributed.distributed import _put

        _put(
            self._comm,
            self._handle,
            pe,
            dst,
            src,
            core=self._core_role(),
        )

    def get(self, pe, dst, src):
        """Issue a nonblocking transfer from peer ``src`` to local ``dst``."""

        from cannbotdsl.ops.distributed.distributed import _get

        _get(
            self._comm,
            self._handle,
            pe,
            dst,
            src,
            core=self._core_role(),
        )

    def flush(self, pe):
        """Complete outstanding transfers on ``pe``'s channel."""

        from cannbotdsl.ops.distributed.distributed import _flush

        _flush(self._comm, self._handle, pe, core=self._core_role())


def create_transfer_context(comm, workspace, *, role):
    """Create a role-owned transfer context using caller-provided UB."""

    if not is_exact_instance(role, TransferRole):
        raise TypeError("role must be TransferRole.CUBE or TransferRole.VEC")

    from cannbotdsl.ops.sync import _CoreRole, hcomm_init

    core = _CoreRole.AIC if role is TransferRole.CUBE else _CoreRole.AIV
    return TransferContext._create(comm, hcomm_init(workspace, 512, core=core), role)
