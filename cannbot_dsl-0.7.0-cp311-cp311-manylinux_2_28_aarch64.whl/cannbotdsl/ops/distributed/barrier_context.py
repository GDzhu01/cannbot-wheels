# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Kernel-side context for a cross-rank barrier."""

from cannbotdsl.core.utils.type_checks import is_exact_instance
from cannbotdsl.ops.distributed.context import COMM_MAX_RANK_NUM
from cannbotdsl.ops.distributed.sym_buffer import SymBuffer
from cannbotdsl.types import dtypes

BARRIER_FLAG_ELEMS = 8
_BARRIER_FLAG_BYTES = BARRIER_FLAG_ELEMS * 4


class BarrierContext:
    """A cross-rank barrier bound to caller-owned symmetric flags."""

    __slots__ = ("_flags",)

    def __init__(self, *args, **kwargs):
        raise TypeError("BarrierContext cannot be constructed directly; use create_barrier_context")

    @classmethod
    def _create(cls, flags):
        instance = object.__new__(cls)
        object.__setattr__(instance, "_flags", flags)
        return instance

    def __setattr__(self, name, value):
        raise AttributeError("BarrierContext is immutable")

    def barrier_all(self, epoch):
        """Wait until every rank in this context reaches ``epoch``."""

        from cannbotdsl.ops.distributed.distributed import _barrier_all

        _barrier_all(self._flags, epoch)


def create_barrier_context(flags):
    """Bind a barrier context to caller-owned symmetric flag storage."""

    if not isinstance(flags, SymBuffer):
        raise TypeError("barrier flags must be a SymBuffer")
    if flags.dtype is not dtypes.int32:
        raise TypeError("barrier flags dtype must be int32")
    if not is_exact_instance(flags.rank_size, int):
        raise TypeError("barrier flags rank_size must be a static int")
    if not 1 <= flags.rank_size <= COMM_MAX_RANK_NUM:
        raise ValueError(f"barrier flags rank_size must be in [1, {COMM_MAX_RANK_NUM}]")
    if len(flags.shape) != 2:
        raise ValueError("barrier flags must be two-dimensional")
    rows, flag_elems = flags.shape
    if rows != flags.rank_size:
        raise ValueError("barrier flags first dimension must equal rank_size")
    if flag_elems != BARRIER_FLAG_ELEMS:
        raise ValueError(f"barrier flags second dimension must equal {BARRIER_FLAG_ELEMS}")
    if not is_exact_instance(flags.heap_base, int) or not is_exact_instance(flags.base_offset, int):
        raise TypeError("barrier flags heap_base and base_offset must be static ints")
    if (flags.heap_base + flags.base_offset) % _BARRIER_FLAG_BYTES:
        raise ValueError("barrier flags storage must be 32-byte aligned")
    return BarrierContext._create(flags)
