# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Tensor-like symmetric communication-buffer addressing."""

from cannbotdsl.core.ir_transport import unwrap_operand
from cannbotdsl.tensor import (
    Tensor,
    _FRAMEWORK_TENSOR_SUBCLASS_TOKEN,
    make_layout,
    make_pointer,
    make_tensor,
    tile_slice,
)
from cannbotdsl.types._numeric import Int64 as _Int64


class SymBuffer(
    Tensor,
    _framework_internal=_FRAMEWORK_TENSOR_SUBCLASS_TOKEN,
):
    """A local GM Tensor whose corresponding peer view is addressable."""

    __slots__ = (
        "_comm",
        "_rank_size",
        "_heap_base",
        "_base_offset",
        "_root_shape",
        "_dtype",
        "_views",
    )

    def __init__(self, comm, *, shape, dtype, rank_size, heap_base=4096, base_offset=0):
        super().__init__(_framework_internal=_FRAMEWORK_TENSOR_SUBCLASS_TOKEN)
        if not hasattr(comm, "rankId") or not hasattr(
            comm,
            "commBufferAddrs",
        ):
            raise TypeError("SymBuffer comm must be a kernel-side CommContext")
        object.__setattr__(self, "_comm", comm)
        object.__setattr__(self, "_rank_size", rank_size)
        object.__setattr__(self, "_heap_base", heap_base)
        object.__setattr__(self, "_base_offset", base_offset)
        object.__setattr__(self, "_root_shape", _freeze_tree(shape))
        object.__setattr__(self, "_dtype", dtype)
        object.__setattr__(self, "_views", ())
        local = self._root_tensor(comm.rankId)
        Tensor._bind_ir(self, unwrap_operand(local))

    def __setattr__(self, name, value):
        del name, value
        raise AttributeError("SymBuffer is immutable")

    @property
    def comm(self):
        return self._comm

    @property
    def rank_size(self):
        return self._rank_size

    @property
    def heap_base(self):
        return self._heap_base

    @property
    def base_offset(self):
        return self._base_offset

    @property
    def shape(self):
        if not self._views:
            return self._root_shape
        return self._local_tensor().shape

    @property
    def dtype(self):
        return self._dtype

    def _root_tensor(self, rank):
        offset = _Int64(self.heap_base) + _Int64(self.base_offset)
        base = self.comm.commBufferAddrs[_Int64(rank)] + offset
        return make_tensor(
            make_pointer(self.dtype, base, _gm_loc()),
            make_layout(self._root_shape),
        )

    def _local_tensor(self):
        try:
            carrier = unwrap_operand(self)
        except AttributeError as exc:
            raise TypeError("SymBuffer can be used as a Tensor only while tracing with a CommContext") from exc
        return Tensor._from_ir(carrier)

    def _tile_slice(self, local_view, tiler, coord):
        result = object.__new__(type(self))
        object.__setattr__(result, "_comm", self.comm)
        object.__setattr__(result, "_rank_size", self.rank_size)
        object.__setattr__(result, "_heap_base", self.heap_base)
        object.__setattr__(result, "_base_offset", self.base_offset)
        object.__setattr__(result, "_root_shape", self._root_shape)
        object.__setattr__(result, "_dtype", self._dtype)
        # Retain the complete tile SSA value, including its dynamic operands
        # and TileType alignment, so local and peer views share one declaration.
        object.__setattr__(
            result,
            "_views",
            self._views + ((tiler, _freeze_tree(coord)),),
        )
        local = _bind_view(local_view)
        Tensor._bind_ir(result, unwrap_operand(local))
        return result

    def peer(self, rank):
        """Return this same Tensor view in ``rank``'s symmetric region."""

        return self._materialize(rank)

    def _materialize(self, rank):
        view = self._root_tensor(rank)
        for tiler, coord in self._views:
            view = tile_slice(view, tiler, coord)
            view = _bind_view(view)
        return view


def _bind_view(view):
    """Bind a contiguous view; preserve other standard Tensor views."""

    from cannbotdsl.ops.distributed.distributed import _tensor_gm_addr

    try:
        address = _tensor_gm_addr(view)
    except NotImplementedError:
        return view

    return make_tensor(
        make_pointer(view.dtype, address, _gm_loc()),
        make_layout(view.shape, stride=view.stride),
    )


def _freeze_tree(value):
    if isinstance(value, (list, tuple)):
        return tuple(_freeze_tree(child) for child in value)
    return value


def _gm_loc():
    from cannbotdsl import MemLoc

    return MemLoc.GM
