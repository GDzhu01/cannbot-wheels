# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode gather ops."""

from cannbotdsl._mlir.dialects import ascvec, cannir

from cannbotdsl.lang.vf import _require_raw_mode

from cannbotdsl.ops.reg._common import _raw_tensor_operand, _raw_vreg_type, _tag_raw_op
from cannbotdsl.ops.reg.mask import Mask
from cannbotdsl.ops.reg.reg_defs import RawVReg


def vgather(tensor, index: RawVReg, *, mask: Mask) -> RawVReg:
    """Gather vector elements from UB tensor by per-lane index.

    For each lane i where mask is true: dst[i] = tensor[index[i]].
    The tensor dtype determines the result element type. For b8 sources, each
    16-bit hardware lane contains the gathered byte in its low 8 bits and zero
    in its high 8 bits; the result remains an i8/ui8 register and the gather
    mask uses b16 lane granularity.
    """
    _require_raw_mode("vgather")
    operand, dtype = _raw_tensor_operand(tensor)
    op = cannir.RawRegGatherOp(
        _raw_vreg_type(dtype),
        operand,
        index.value,
        mask.value,
    )
    _tag_raw_op(op)
    return RawVReg(op.result, dtype)


def vgather_reg(src: RawVReg, index: RawVReg) -> RawVReg:
    """Gather vector elements from another register by per-lane index.

    Lowers to the no-mask register-register ``asc_gather(dst, src, index)``
    CAPI. The index register width must match the source element width.
    """
    _require_raw_mode("vgather_reg")
    op = ascvec.VGatherRegOp(
        _raw_vreg_type(src.dtype),
        src.value,
        index.value,
    )
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vgather_datablock(tensor, index: RawVReg, *, mask: Mask | None = None) -> RawVReg:
    """Gather 32-byte data blocks from UB tensor by u32 per-lane index.

    Omitting ``mask`` selects the unmasked AscendC overload.
    """
    _require_raw_mode("vgather_datablock")
    operand, result_dtype = _raw_tensor_operand(tensor)
    op = cannir.RawRegGatherDatablockOp(
        _raw_vreg_type(result_dtype),
        operand,
        index.value,
        mask=mask.value if mask is not None else None,
    )
    _tag_raw_op(op)
    return RawVReg(op.result, result_dtype)
