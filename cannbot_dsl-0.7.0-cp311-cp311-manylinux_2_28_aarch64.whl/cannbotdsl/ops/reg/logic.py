# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode bitwise, shift and reinterpret ops."""

from cannbotdsl._mlir.dialects import ascvec

from cannbotdsl.lang.vf import _require_raw_mode

from cannbotdsl.ops.reg._common import (
    _check_b64_mask,
    _dtype_bits,
    _dtype_type,
    _raw_vreg_type,
    _tag_raw_op,
)
from cannbotdsl.ops.reg.mask import Mask, _binary, _unary
from cannbotdsl.ops.reg.reg_defs import RawVReg


def vnot(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.VNotOp, "vnot")


# ---------------------------------------------------------------------------
# Bitwise operations
# ---------------------------------------------------------------------------


def vbitwise_xor(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    return _binary(lhs, rhs, mask, ascvec.VXorOp, "vbitwise_xor")


def vbitwise_and(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    return _binary(lhs, rhs, mask, ascvec.VAndOp, "vbitwise_and")


def vbitwise_or(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    return _binary(lhs, rhs, mask, ascvec.VOrOp, "vbitwise_or")


def vshr(src: RawVReg, shift_bits: int, *, mask: Mask) -> RawVReg:
    _require_raw_mode("vshr")
    _check_b64_mask("vshr", src.dtype, mask)
    if _dtype_bits(src.dtype) == 64 and (type(shift_bits) is not int or not 0 <= shift_bits < 64):
        raise ValueError("vshr: b64 shift must be an integer in [0, 64)")
    op = ascvec.VShrOp(
        _raw_vreg_type(src.dtype),
        src.value,
        shift_bits,
        mask.value,
    )
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vshl(src: RawVReg, shift_bits: int, *, mask: Mask) -> RawVReg:
    _require_raw_mode("vshl")
    _check_b64_mask("vshl", src.dtype, mask)
    if _dtype_bits(src.dtype) == 64 and (type(shift_bits) is not int or not 0 <= shift_bits < 64):
        raise ValueError("vshl: b64 shift must be an integer in [0, 64)")
    op = ascvec.VShlOp(
        _raw_vreg_type(src.dtype),
        src.value,
        shift_bits,
        mask.value,
    )
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vreinterpret_lanes(src: RawVReg, dtype) -> RawVReg:
    """Reinterpret a raw register's 256-byte payload as a *different lane width*.

    Unlike :func:`vreinterpret` (same element width, pure type relabel), this
    views the same physical register as a narrower/wider lane type — e.g. a u32
    broadcast register (64 lanes) viewed as u8 (256 lanes). Matches arch35's
    reference-cast ``(MicroAPI::RegTensor<uint8_t>&)idxHigh``: the bytes are
    untouched, only the lane interpretation changes. Lowers to the same
    ``(vector_T&)src`` reference-cast as :func:`vreinterpret`.
    """
    _require_raw_mode("vreinterpret_lanes")
    dtype = _dtype_type(dtype)
    op = ascvec.VReinterpretOp(_raw_vreg_type(dtype), src.value)
    _tag_raw_op(op)
    return RawVReg(op.result, dtype)


def vreinterpret(src: RawVReg, dtype) -> RawVReg:
    """Reinterpret the bit-pattern of src as a different type of the same width.

    Zero-cost: no instruction emitted, pure compile-time type change.
    """
    _require_raw_mode("vreinterpret")
    dtype = _dtype_type(dtype)
    src_bits = _dtype_bits(src.dtype)
    dst_bits = _dtype_bits(dtype)
    if src_bits != dst_bits:
        raise ValueError(f"vreinterpret: bit-width must match, got src={src_bits} dst={dst_bits}")
    op = ascvec.VReinterpretOp(_raw_vreg_type(dtype), src.value)
    _tag_raw_op(op)
    return RawVReg(op.result, dtype)
