# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Single capability table for supported private storage encodings."""

from __future__ import annotations


# Keys are both public ``DType.name`` values and canonical contract element
# tags.  The two spellings differ only for the integer types.  The MX fp8
# formats (C0 = 32) and the packed fp4 format (C0 = 64 elements = 32 bytes)
# round out the table: every supported element keeps a 32-byte DataBlock.
# ``mx`` marks elements that carry an OCP MX block scale: the hardware MX
# group spans 64 elements, so when C0 < 64 the FRACTAL_NZ allocation may
# cover an odd number of C0 fractals and the GM->L1 raw-copy lowering
# zero-fills the missing K stripe in L1.
#
# Whether an element is byte-carried is deliberately *not* a column here:
# that is a property of the dtype, not of FRACTAL_NZ, and it already has one
# answer in ``DType.is_packed_sub_byte``.
_FRACTAL_NZ_ELEMENTS = {
    "int8": (32, False),
    "uint8": (32, False),
    "float16": (16, False),
    "bfloat16": (16, False),
    "float32": (8, False),
    "float8_e4m3fn": (32, True),
    "float8_e5m2": (32, True),
    "fp4x2_e2m1": (64, True),
    "i8": (32, False),
    "u8": (32, False),
    "f16": (16, False),
    "bf16": (16, False),
    "f32": (8, False),
    "f8e4m3": (32, True),
    "f8e5m2": (32, True),
    "fp4x2e2m1": (64, True),
}

FRACTAL_NZ_DTYPE_NAMES = frozenset(
    {
        "int8",
        "uint8",
        "float16",
        "bfloat16",
        "float32",
        "float8_e4m3fn",
        "float8_e5m2",
        "fp4x2_e2m1",
    }
)
FRACTAL_NZ_ELEMENT_TAGS = frozenset(
    {"i8", "u8", "f16", "bf16", "f32", "f8e4m3", "f8e5m2", "fp4x2e2m1"}
)

# Elements that carry an OCP MX block scale.  Their GM->L1 raw copy may
# leave a K-direction gap between the FRACTAL_NZ allocation (padded to C0)
# and the hardware MX group extent (64 elements); the lowering zero-fills
# that gap in L1, mirroring the ND-input engine path.
FRACTAL_NZ_MX_ELEMENT_TAGS = frozenset(
    {"f8e4m3", "f8e5m2", "fp4x2e2m1"}
)


def _fractal_nz_entry(dtype_name_or_tag: str) -> tuple[int, bool]:
    try:
        return _FRACTAL_NZ_ELEMENTS[dtype_name_or_tag]
    except KeyError as error:
        raise TypeError(f"FRACTAL_NZ does not support element {dtype_name_or_tag!r}") from error


def fractal_nz_c0(dtype_name_or_tag: str) -> int:
    """Return the hardware C0 extent for one supported element spelling."""

    return _fractal_nz_entry(dtype_name_or_tag)[0]


__all__ = [
    "FRACTAL_NZ_DTYPE_NAMES",
    "FRACTAL_NZ_ELEMENT_TAGS",
    "FRACTAL_NZ_MX_ELEMENT_TAGS",
    "fractal_nz_c0",
]
