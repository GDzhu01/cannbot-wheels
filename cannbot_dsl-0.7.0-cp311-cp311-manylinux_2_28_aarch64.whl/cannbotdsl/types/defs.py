# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Predefined scalar enum values shared by DSL frontends."""

from enum import IntEnum


class RoundingMode(IntEnum):
    """Common CANN scalar/SIMT conversion and arithmetic rounding modes."""

    RN = 0
    RNA = 1
    RD = 2
    RU = 3
    RZ = 4
    RO = 5
    NA = 6
    RH = 7


__all__ = ["RoundingMode"]
