# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""SIMT short-vector ABI metadata.

The public dtype descriptors remain in :mod:`dtypes`; this module only owns
the device ABI spelling and lane/element lookup used by SIMT lowering.
"""

import cannbotdsl._mlir.ir as ir
from cannbotdsl.core.utils.type_checks import is_exact_instance
from cannbotdsl.types.dtypes import DType, DTypeKind


def _integer_vector_info(prefix, abi_types):
    result = {}
    for bits, abi in abi_types:
        for lanes in (2, 3, 4):
            result[f"{prefix}{bits}x{lanes}"] = (lanes, f"{prefix}{bits}", f"{abi}{lanes}")
    return result


_VECTOR_INFO = {
    **_integer_vector_info("int", ((8, "char"), (16, "short"), (32, "int"), (64, "longlong"))),
    **_integer_vector_info("uint", ((8, "uchar"), (16, "ushort"), (32, "uint"), (64, "ulonglong"))),
    "float32x2": (2, "float32", "float2"),
    "float32x3": (3, "float32", "float3"),
    "float32x4": (4, "float32", "float4"),
    "float16x2": (2, "float16", "half2"),
    "bfloat16x2": (2, "bfloat16", "bfloat16x2_t"),
    "fp8x2_e4m3fn": (2, "float8_e4m3fn", "float8_e4m3x2_t"),
    "fp8x2_e5m2": (2, "float8_e5m2", "float8_e5m2x2_t"),
    "hifloat8x2": (2, "hifloat8", "hifloat8x2_t"),
}


def vector_info(dtype: DType):
    try:
        lanes, element_name, c_name = _VECTOR_INFO[dtype.name]
    except KeyError as exc:
        raise TypeError(f"unknown SIMT short-vector dtype {dtype.name}") from exc
    from cannbotdsl.types import dtypes

    element = getattr(dtypes, element_name, None)
    return lanes, element, c_name


class ShortVector(ir.Value):
    """Typed SSA value carrying one SIMT short-vector dtype descriptor."""

    _dtype: DType

    def __init__(self, value: ir.Value, dtype: DType):
        if not isinstance(value, ir.Value):
            raise TypeError(f"ShortVector requires an MLIR SSA value, got {type(value).__name__}")
        if not isinstance(dtype, DType) or not dtype.is_short_vector:
            raise TypeError("ShortVector requires a short-vector DType descriptor")
        # The carrier is represented by the AscSimt vector type in the IR.
        super().__init__(value)
        self._dtype = dtype

    @classmethod
    def _from_ir(cls, value: ir.Value, dtype: DType) -> "ShortVector":
        return cls(value, dtype)

    @property
    def dtype(self) -> DType:
        return self._dtype

    @property
    def element_type(self):
        return vector_info(self._dtype)[1]

    @property
    def lanes(self) -> int:
        return vector_info(self._dtype)[0]

    @property
    def is_integer(self) -> bool:
        return self.element_type.kind is DTypeKind.INTEGER

    def lane(self, index: int):
        if not is_exact_instance(index, int) or not 0 <= index < self.lanes:
            raise IndexError(f"short-vector lane must be in [0, {self.lanes})")
        from cannbotdsl.core.contracts.elements import scalar_mlir_type_for_dtype, wrap_produced_scalar

        ty = scalar_mlir_type_for_dtype(self.element_type)
        value = ir.Operation.create(
            "ascsimt.vector_extract",
            operands=[self],
            results=[ty],
            attributes={"lane": ir.IntegerAttr.get(ir.IntegerType.get_signless(64), index)},
        ).results[0]
        return wrap_produced_scalar(value, storage_type=ty)

    @property
    def x(self):
        return self.lane(0)

    @property
    def y(self):
        return self.lane(1)

    @property
    def z(self):
        return self.lane(2)

    @property
    def w(self):
        return self.lane(3)

    def __len__(self) -> int:
        return self.lanes

    def __bool__(self):
        raise TypeError("a dynamic SIMT short vector has no scalar truth value")

    def __repr__(self) -> str:
        return f"ShortVector(dtype={self.dtype!r}, lanes={self.lanes})"

    def _binary(self, other, function):
        from cannbotdsl.ops import simt

        return getattr(simt, "v" + function)(self, other)

    def __add__(self, other):
        return self._binary(other, "add")

    def __sub__(self, other):
        return self._binary(other, "sub")

    def __mul__(self, other):
        return self._binary(other, "mul")

    def __truediv__(self, other):
        return self._binary(other, "div")


def _vector_ir_type(dtype: DType):
    return ir.Type.parse(f'!cannir.simt_vector<"{vector_info(dtype)[2]}">')


def _construct(dtype: DType, values):
    from cannbotdsl.core.contracts.elements import scalar_mlir_type_for_dtype
    from cannbotdsl.ops.simt import _coerce_simt_storage, _require_simt

    _require_simt("short-vector construction")
    if len(values) == 1 and isinstance(values[0], ShortVector):
        if values[0].dtype is dtype:
            return values[0]
        raise TypeError("short-vector conversion requires simt.cast")
    if len(values) == 1 and isinstance(values[0], (tuple, list)):
        values = tuple(values[0])
    lanes, element_dtype, c_name = vector_info(dtype)
    if len(values) != lanes:
        raise TypeError(f"dtypes.{dtype.name} expects {lanes} lane values")
    element_type = scalar_mlir_type_for_dtype(element_dtype)
    operands = [_coerce_simt_storage(v, element_type, path=f"{dtype.name}[{i}]") for i, v in enumerate(values)]
    result = ir.Operation.create(
        "ascsimt.vector_pack",
        operands=operands,
        results=[_vector_ir_type(dtype)],
        attributes={"dtype": ir.StringAttr.get(c_name)},
    ).results[0]
    return ShortVector(result, dtype)
