# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Canonical, backend-independent dtype descriptors.

Use these objects for tensor, buffer, aggregate, and scalar annotations.  A
descriptor is also the sole public scalar construction/conversion spelling:
``dtypes.int32(value)``.  Concrete SSA wrapper classes remain implementation
details in :mod:`cannbotdsl.types._numeric`.
"""

from __future__ import annotations

import builtins as _builtins
from dataclasses import dataclass
from enum import Enum
from types import MappingProxyType

from cannbotdsl.core.utils.type_checks import is_exact_instance
from cannbotdsl.types import scalar as _scalar


class DTypeKind(str, Enum):
    """Closed descriptor kind set; internal to the dtype implementation."""

    BOOLEAN = "bool"
    INTEGER = "integer"
    FLOAT = "float"


# Carriers that pack an exact number of logical elements into one addressable
# byte.  Mirrors ``cannir::isPackedSubByteStorageType``.  Named rather than
# derived from ``bits``: that field is the *logical* element width, so any
# arithmetic test ("narrower than a byte", "divides a byte") also admits
# ``bool``, which is a predicate type with no packed byte container behind it.
_PACKED_SUB_BYTE_NAMES = frozenset(("fp4x2_e2m1", "fp4x2_e1m2", "int4x2"))


@dataclass(frozen=True, slots=True)
class DType:
    """Immutable intrinsic description of one CANNBotDSL scalar dtype.

    Calling a descriptor constructs a contextually typed scalar literal or
    explicitly converts a dynamic DSL scalar.  Descriptor data is independent
    of backend mappings, and the conversion implementation is imported lazily
    at the call site.  Importing the package still initializes the MLIR backend
    and value casters.
    """

    name: str
    kind: DTypeKind
    bits: int
    signed: _builtins.bool | None
    format: str
    is_short_vector: _builtins.bool = False

    def __post_init__(self) -> None:
        if not is_exact_instance(self.name, str) or not self.name:
            raise ValueError("dtype names must be non-empty strings")
        if not isinstance(self.kind, DTypeKind):
            raise ValueError(f"dtype {self.name!r} has unsupported kind {self.kind!r}")
        if not is_exact_instance(self.bits, int) or self.bits <= 0:
            raise ValueError(f"dtype {self.name!r} must have a positive bit width")
        if not is_exact_instance(self.format, str) or not self.format:
            raise ValueError(f"dtype {self.name!r} must have a non-empty format")
        if self.kind is DTypeKind.BOOLEAN:
            if self.bits != 1 or self.signed is not None:
                raise ValueError(f"boolean dtype {self.name!r} must be one unsigned-neutral bit")
        elif self.kind is DTypeKind.INTEGER:
            if not is_exact_instance(self.signed, _builtins.bool):
                raise ValueError(f"integer dtype {self.name!r} must declare signedness")
        elif self.signed is not None:
            raise ValueError(f"floating dtype {self.name!r} cannot declare integer signedness")
        if not is_exact_instance(self.is_short_vector, _builtins.bool):
            raise ValueError(f"dtype {self.name!r} has an invalid short-vector marker")

    @property
    def width(self) -> int:
        return self.bits

    @property
    def is_packed_sub_byte(self) -> _builtins.bool:
        """True when several logical elements share one addressable byte.

        The single Python-side answer to "is this element byte-carried", and
        the mirror of ``cannir::isPackedSubByteStorageType``.  Ask this rather
        than testing ``bits``; see ``_PACKED_SUB_BYTE_NAMES``.
        """

        return self.name in _PACKED_SUB_BYTE_NAMES

    @property
    def c0_elems(self) -> int:
        """Logical elements per 32-byte hardware DataBlock (the fractal C0).

        Derived from the bit width rather than ``32 // bytes`` so that packed
        sub-byte formats are exact: fp4x2_e2m1 is 64, not 32.  Mirrors
        ``cannir::getC0Elems`` on the C++ side.
        """

        return 256 // self.bits

    def bytes_for(self, elems: int) -> int:
        """Byte size of ``elems`` logical elements.

        Scales down for packed sub-byte formats instead of truncating the
        per-element byte width to zero.
        """

        return elems * self.bits // 8

    @property
    def minimum(self) -> int | None:
        if self.kind is DTypeKind.BOOLEAN:
            return 0
        if self.kind is not DTypeKind.INTEGER:
            return None
        if self.signed:
            return -(1 << (self.bits - 1))
        return 0

    @property
    def maximum(self) -> int | None:
        if self.kind is DTypeKind.BOOLEAN:
            return 1
        if self.kind is not DTypeKind.INTEGER:
            return None
        if self.signed:
            return (1 << (self.bits - 1)) - 1
        return (1 << self.bits) - 1

    def __call__(self, value: object, /) -> _scalar.ScalarValue:
        """Construct or explicitly convert one traced scalar to this dtype."""

        if self.is_short_vector:
            raise TypeError(f"{self.name} is a short-vector dtype; use simt.make_short_vector")
        from cannbotdsl.core.scalar_conversion import _scalar_cast

        return _scalar_cast(value, self)

    def __repr__(self) -> str:
        return f"dtypes.{self.name}"


_DTYPES = (
    DType("float16", DTypeKind.FLOAT, 16, None, "ieee-f16"),
    DType("float32", DTypeKind.FLOAT, 32, None, "ieee-f32"),
    DType("float64", DTypeKind.FLOAT, 64, None, "ieee-f64"),
    DType("bfloat16", DTypeKind.FLOAT, 16, None, "bfloat16"),
    DType("float8_e4m3fn", DTypeKind.FLOAT, 8, None, "float8-e4m3fn"),
    DType("float8_e5m2", DTypeKind.FLOAT, 8, None, "float8-e5m2"),
    DType("float8_e8m0", DTypeKind.FLOAT, 8, None, "float8-e8m0"),
    # Huawei HiFloat8: eight bits wide, tapered exponent/mantissa.  Unlike the
    # OCP fp8 pair it carries no block scale, so it reaches the cube through the
    # plain mmad path rather than mmad_mx.
    DType("hifloat8", DTypeKind.FLOAT, 8, None, "hifloat8"),
    # OCP MX FP4 E2M1.  ``bits`` is the *logical* element width: two elements
    # share one addressable byte, matching the AscendC ``fp4x2_e2m1_t`` carrier
    # whose ``sizeof()`` is 1 but whose ``SizeOfBits`` is 4.
    DType("fp4x2_e2m1", DTypeKind.FLOAT, 4, None, "fp4x2-e2m1"),
    # Alternate packed FP4 encoding used by the register conversion APIs.
    DType("fp4x2_e1m2", DTypeKind.FLOAT, 4, None, "fp4x2-e1m2"),
    # Signed int4 register storage, packed two logical values per byte.
    DType("int4x2", DTypeKind.INTEGER, 4, True, "int4x2"),
    # SIMT short-vector descriptors.  They follow the same direct table style
    # as the packed dtypes above; ABI details are resolved by the SIMT layer.
    DType("int8x2", DTypeKind.INTEGER, 16, True, "twos-complement-x2", True),
    DType("int8x3", DTypeKind.INTEGER, 24, True, "twos-complement-x3", True),
    DType("int8x4", DTypeKind.INTEGER, 32, True, "twos-complement-x4", True),
    DType("uint8x2", DTypeKind.INTEGER, 16, False, "unsigned-x2", True),
    DType("uint8x3", DTypeKind.INTEGER, 24, False, "unsigned-x3", True),
    DType("uint8x4", DTypeKind.INTEGER, 32, False, "unsigned-x4", True),
    DType("int16x2", DTypeKind.INTEGER, 32, True, "twos-complement-x2", True),
    DType("int16x3", DTypeKind.INTEGER, 48, True, "twos-complement-x3", True),
    DType("int16x4", DTypeKind.INTEGER, 64, True, "twos-complement-x4", True),
    DType("uint16x2", DTypeKind.INTEGER, 32, False, "unsigned-x2", True),
    DType("uint16x3", DTypeKind.INTEGER, 48, False, "unsigned-x3", True),
    DType("uint16x4", DTypeKind.INTEGER, 64, False, "unsigned-x4", True),
    DType("int32x2", DTypeKind.INTEGER, 64, True, "twos-complement-x2", True),
    DType("int32x3", DTypeKind.INTEGER, 96, True, "twos-complement-x3", True),
    DType("int32x4", DTypeKind.INTEGER, 128, True, "twos-complement-x4", True),
    DType("uint32x2", DTypeKind.INTEGER, 64, False, "unsigned-x2", True),
    DType("uint32x3", DTypeKind.INTEGER, 96, False, "unsigned-x3", True),
    DType("uint32x4", DTypeKind.INTEGER, 128, False, "unsigned-x4", True),
    DType("int64x2", DTypeKind.INTEGER, 128, True, "twos-complement-x2", True),
    DType("int64x3", DTypeKind.INTEGER, 192, True, "twos-complement-x3", True),
    DType("int64x4", DTypeKind.INTEGER, 256, True, "twos-complement-x4", True),
    DType("uint64x2", DTypeKind.INTEGER, 128, False, "unsigned-x2", True),
    DType("uint64x3", DTypeKind.INTEGER, 192, False, "unsigned-x3", True),
    DType("uint64x4", DTypeKind.INTEGER, 256, False, "unsigned-x4", True),
    DType("float32x2", DTypeKind.FLOAT, 64, None, "ieee-f32x2", True),
    DType("float32x3", DTypeKind.FLOAT, 96, None, "ieee-f32x3", True),
    DType("float32x4", DTypeKind.FLOAT, 128, None, "ieee-f32x4", True),
    DType("float16x2", DTypeKind.FLOAT, 32, None, "ieee-f16x2", True),
    DType("bfloat16x2", DTypeKind.FLOAT, 32, None, "bfloat16x2", True),
    DType("fp8x2_e4m3fn", DTypeKind.FLOAT, 16, None, "float8-e4m3fnx2", True),
    DType("fp8x2_e5m2", DTypeKind.FLOAT, 16, None, "float8-e5m2x2", True),
    DType("hifloat8x2", DTypeKind.FLOAT, 16, None, "hifloat8x2", True),
    DType("int8", DTypeKind.INTEGER, 8, True, "twos-complement"),
    DType("int16", DTypeKind.INTEGER, 16, True, "twos-complement"),
    DType("int32", DTypeKind.INTEGER, 32, True, "twos-complement"),
    DType("int64", DTypeKind.INTEGER, 64, True, "twos-complement"),
    DType("uint8", DTypeKind.INTEGER, 8, False, "unsigned"),
    DType("uint16", DTypeKind.INTEGER, 16, False, "unsigned"),
    DType("uint32", DTypeKind.INTEGER, 32, False, "unsigned"),
    DType("uint64", DTypeKind.INTEGER, 64, False, "unsigned"),
    DType("bool", DTypeKind.BOOLEAN, 1, None, "boolean"),
)

_BY_NAME = MappingProxyType({item.name: item for item in _DTYPES})
if len(_BY_NAME) != len(_DTYPES):  # pragma: no cover - module invariant
    raise ValueError("canonical dtype descriptors contain duplicate names")

_PYTHON_DEFAULTS = {
    _builtins.bool: "bool",
    _builtins.int: "int64",
    _builtins.float: "float32",
}


def _resolve_dtype(value: object, *, allow_python: _builtins.bool = False) -> DType:
    """Canonicalize a descriptor or an explicitly allowed Python scalar type."""

    if is_exact_instance(value, DType):
        canonical = _BY_NAME.get(value.name)
        if canonical == value:
            return canonical
    if allow_python:
        for python_type, name in _PYTHON_DEFAULTS.items():
            if value is python_type:
                return _BY_NAME[name]
    supported = ", ".join(item.name for item in _DTYPES)
    if isinstance(value, type):
        rendered = type.__getattribute__(value, "__name__")
    else:
        rendered = type.__getattribute__(type(value), "__name__")
    raise TypeError(f"unsupported CANNBotDSL dtype {rendered}; supported: {supported}")


float16 = _BY_NAME["float16"]
float32 = _BY_NAME["float32"]
float64 = _BY_NAME["float64"]
bfloat16 = _BY_NAME["bfloat16"]
float8_e4m3fn = _BY_NAME["float8_e4m3fn"]
float8_e5m2 = _BY_NAME["float8_e5m2"]
float8_e8m0 = _BY_NAME["float8_e8m0"]
hifloat8 = _BY_NAME["hifloat8"]
fp4x2_e2m1 = _BY_NAME["fp4x2_e2m1"]
fp4x2_e1m2 = _BY_NAME["fp4x2_e1m2"]
int4x2 = _BY_NAME["int4x2"]
int8x2 = _BY_NAME["int8x2"]
int8x3 = _BY_NAME["int8x3"]
int8x4 = _BY_NAME["int8x4"]
int16x2 = _BY_NAME["int16x2"]
int16x3 = _BY_NAME["int16x3"]
int16x4 = _BY_NAME["int16x4"]
int32x2 = _BY_NAME["int32x2"]
int32x3 = _BY_NAME["int32x3"]
int32x4 = _BY_NAME["int32x4"]
int64x2 = _BY_NAME["int64x2"]
int64x3 = _BY_NAME["int64x3"]
int64x4 = _BY_NAME["int64x4"]
uint8x2 = _BY_NAME["uint8x2"]
uint8x3 = _BY_NAME["uint8x3"]
uint8x4 = _BY_NAME["uint8x4"]
uint16x2 = _BY_NAME["uint16x2"]
uint16x3 = _BY_NAME["uint16x3"]
uint16x4 = _BY_NAME["uint16x4"]
uint32x2 = _BY_NAME["uint32x2"]
uint32x3 = _BY_NAME["uint32x3"]
uint32x4 = _BY_NAME["uint32x4"]
uint64x2 = _BY_NAME["uint64x2"]
uint64x3 = _BY_NAME["uint64x3"]
uint64x4 = _BY_NAME["uint64x4"]
float32x2 = _BY_NAME["float32x2"]
float32x3 = _BY_NAME["float32x3"]
float32x4 = _BY_NAME["float32x4"]
float16x2 = _BY_NAME["float16x2"]
bfloat16x2 = _BY_NAME["bfloat16x2"]
fp8x2_e4m3fn = _BY_NAME["fp8x2_e4m3fn"]
fp8x2_e5m2 = _BY_NAME["fp8x2_e5m2"]
hifloat8x2 = _BY_NAME["hifloat8x2"]
int8 = _BY_NAME["int8"]
int16 = _BY_NAME["int16"]
int32 = _BY_NAME["int32"]
int64 = _BY_NAME["int64"]
uint8 = _BY_NAME["uint8"]
uint16 = _BY_NAME["uint16"]
uint32 = _BY_NAME["uint32"]
uint64 = _BY_NAME["uint64"]
bool_ = _BY_NAME["bool"]

# ``bool`` is the natural dtype spelling; ``bool_`` avoids shadowing when
# callers need the Python builtin in the same scope.
bool = bool_


__all__ = [
    "DType",
    "bfloat16",
    "bool",
    "bool_",
    "float16",
    "float32",
    "float64",
    "float8_e4m3fn",
    "float8_e5m2",
    "float8_e8m0",
    "fp4x2_e2m1",
    "fp4x2_e1m2",
    "hifloat8",
    "int8",
    "int16",
    "int32",
    "int64",
    "int4x2",
    "uint8",
    "uint16",
    "uint32",
    "uint64",
    "int8x2",
    "int8x3",
    "int8x4",
    "uint8x2",
    "uint8x3",
    "uint8x4",
    "int16x2",
    "int16x3",
    "int16x4",
    "uint16x2",
    "uint16x3",
    "uint16x4",
    "int32x2",
    "int32x3",
    "int32x4",
    "uint32x2",
    "uint32x3",
    "uint32x4",
    "int64x2",
    "int64x3",
    "int64x4",
    "uint64x2",
    "uint64x3",
    "uint64x4",
    "float32x2",
    "float32x3",
    "float32x4",
    "float16x2",
    "bfloat16x2",
    "fp8x2_e4m3fn",
    "fp8x2_e5m2",
    "hifloat8x2",
]
