# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""On-chip Tensor allocation, static storage and Buffer resource binding."""

from __future__ import annotations

from functools import reduce
from operator import mul

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir
from cannbotdsl._onchip import (
    _current_onchip_trace,
    _normalize_shape_capacity,
)
from cannbotdsl.core.ir_transport import unwrap_operand
from cannbotdsl.core.utils.type_checks import is_exact_instance
from cannbotdsl.tensor import (
    _FRAMEWORK_TENSOR_SUBCLASS_TOKEN,
    Layout,
    MemLoc,
    Tensor,
    _infer_contiguous_stride,
    _physical_layout_spec,
    _tensor_type_from_layouts,
    make_layout,
)
from cannbotdsl.types import dtypes

_BUFFER_MEM_LOCS = frozenset(
    (MemLoc.UB, MemLoc.L1, MemLoc.L0A, MemLoc.L0B, MemLoc.L0C,
     MemLoc.BIAS, MemLoc.SSBUF, MemLoc.FBUF)
)
_BUFFER_FORMATS = frozenset(("nd", "nz", "zn"))
# Carriers that pack an exact number of logical elements into one addressable
# byte.  Derived from the dtype table's own marker rather than re-listed here:
# DType.is_packed_sub_byte is the single Python-side mirror of
# cannir::isPackedSubByteStorageType, and it is the place that records why bool
# is excluded (a predicate type, not tensor storage).
_PACKED_SUB_BYTE_DTYPES = frozenset(
    dtype.name for dtype in dtypes._DTYPES if dtype.is_packed_sub_byte
)


def _normalize_mem_loc(mem_loc):
    if not isinstance(mem_loc, MemLoc):
        raise TypeError(f"Buffer mem_loc must be a MemLoc value, got {type(mem_loc).__name__}")
    if mem_loc not in _BUFFER_MEM_LOCS:
        supported = ", ".join(item.name for item in _BUFFER_MEM_LOCS)
        raise ValueError(f"Buffer does not support MemLoc.{mem_loc.name}; supported: {supported}")
    return mem_loc


def _normalize_stride(stride, shape):
    if stride is None:
        return _infer_contiguous_stride(shape), False
    if not isinstance(stride, tuple):
        raise TypeError("Buffer stride must be a flat tuple of non-negative ints")
    if len(stride) != len(shape):
        raise ValueError(f"Buffer stride rank {len(stride)} does not match shape rank {len(shape)}")
    has_dynamic_stride = False
    for index, value in enumerate(stride):
        if is_exact_instance(value, int):
            if value < -(1 << 63) or value >= (1 << 63):
                raise OverflowError(
                    f"Buffer stride[{index}] exceeds signed int64: {value}"
                )
            if value < 0:
                raise ValueError(f"Buffer stride[{index}] must be non-negative, got {value}")
            continue
        if isinstance(value, ir.Value):
            value_type = value.type
            if not (
                isinstance(value_type, ir.IntegerType)
                and value_type.width == 64
                and value_type.is_signless
            ):
                raise TypeError(
                    f"Buffer stride[{index}] SSA value must have canonical "
                    f"signless i64 type, got {value_type}"
                )
            has_dynamic_stride = True
            continue
        raise TypeError(
            f"Buffer stride[{index}] must be a non-negative Python int, got {type(value).__name__}"
        )
    return stride, has_dynamic_stride


def _normalize_dtype(dtype):
    from cannbotdsl.core.contracts.elements import normalize_storage_dtype

    dtype = normalize_storage_dtype(dtype)
    if dtype.is_packed_sub_byte:
        return dtype
    width = getattr(dtype, "width", None)
    if not is_exact_instance(width, int) or width <= 0 or width % 8:
        raise ValueError(
            f"Buffer dtype must have a whole-byte storage width, or be one of the "
            f"packed sub-byte carriers {sorted(_PACKED_SUB_BYTE_DTYPES)}, "
            f"got {dtype!r} ({width!r} bits)"
        )
    return dtype


def _normalize_format(mem_loc, shape, data_format, n1_pad):
    if data_format is None:
        data_format = "nd" if mem_loc in (MemLoc.UB, MemLoc.BIAS, MemLoc.SSBUF, MemLoc.FBUF) else "nz"
    if not is_exact_instance(data_format, str):
        raise TypeError(f"Buffer data_format must be one of 'nd', 'nz', or 'zn', got {type(data_format).__name__}")
    if data_format not in _BUFFER_FORMATS:
        raise ValueError(f"Buffer data_format must be one of 'nd', 'nz', or 'zn', got {data_format!r}")
    if mem_loc in (MemLoc.BIAS, MemLoc.SSBUF, MemLoc.FBUF) and data_format != "nd":
        raise ValueError(f"{mem_loc.name} Buffer requires data_format='nd'")
    if data_format in ("nz", "zn") and len(shape) not in (2, 3):
        raise ValueError(f"Buffer data_format={data_format!r} requires rank 2 or 3, got rank {len(shape)}")
    if not is_exact_instance(n1_pad, int):
        raise TypeError(f"Buffer n1_pad must be a non-negative Python int, got {type(n1_pad).__name__}")
    if n1_pad < 0:
        raise ValueError(f"Buffer n1_pad must be non-negative, got {n1_pad}")
    if n1_pad and data_format != "nz":
        raise ValueError("Buffer n1_pad is only supported for data_format='nz'")
    return data_format, n1_pad


def _make_onchip_allocation(
    dtype,
    mem_loc: MemLoc,
    logical_layout: Layout,
    physical_layout: Layout,
    *,
    data_format: str,
    fixed_addr: int | None = None,
    storage_type=None,
) -> Tensor:
    """Emit a pass-planned on-chip allocation declaration for one Tensor."""
    logical_layout_value = unwrap_operand(logical_layout)
    tensor_type = _tensor_type_from_layouts(
        dtype,
        mem_loc,
        logical_layout,
        physical_layout,
        data_format=data_format,
    )
    attributes = {}
    if fixed_addr is not None:
        i64 = ir.IntegerType.get_signless(64)
        attributes["fixed_addr"] = ir.IntegerAttr.get(i64, fixed_addr)
    if storage_type is not None:
        attributes["storage_type"] = ir.TypeAttr.get(storage_type)
    operation = cannir.OnChipAllocOp.build_generic(
        results=[tensor_type],
        operands=[logical_layout_value],
        attributes=attributes,
    )
    return Tensor._from_ir(operation.results[0])


def _build_buffer_tensor(
    mem_loc,
    shape,
    dtype,
    fixed_addr,
    stride,
    data_format,
    n1_pad,
):
    physical_shape, physical_stride = _physical_layout_spec(dtype, shape, data_format, n1_pad, mem_loc=mem_loc)
    if data_format == "nd":
        physical_stride = stride
    logical_layout = make_layout(shape, stride=stride)
    physical_layout = (
        make_layout(physical_shape) if physical_stride is None else make_layout(physical_shape, stride=physical_stride)
    )
    tensor = _make_onchip_allocation(
        dtype,
        mem_loc,
        logical_layout,
        physical_layout,
        data_format=data_format,
        fixed_addr=fixed_addr,
    )
    unwrap_operand(tensor).owner.attributes["cannir.infer_physical_layout"] = ir.UnitAttr.get()
    return tensor


class Buffer(Tensor, _framework_internal=_FRAMEWORK_TENSOR_SUBCLASS_TOKEN):
    """Construct one ordinary on-chip Tensor.

    ``Buffer`` has no runtime value kind of its own. Calling the class emits
    an on-chip allocation declaration and returns a plain :class:`Tensor`;
    the memory-planning pass assigns its byte address and materializes the
    pointer/Tensor root. There is no ``Buffer`` instance at runtime:
    ``type(Buffer(...)) is Tensor``.
    """

    __slots__ = ()

    def __new__(
        cls,
        mem_loc,
        shape=None,
        dtype=None,
        *,
        capacity=None,
        layout=None,
        physical_layout=None,
        stride=None,
        data_format=None,
        n1_pad=0,
    ) -> Tensor:
        del cls
        mem_loc = _normalize_mem_loc(mem_loc)
        try:
            trace_state = _current_onchip_trace()
        except RuntimeError:
            trace_state = None
        if trace_state is not None:
            trace_state.use_automatic_space(mem_loc, "Buffer")
        if dtype is None:
            raise TypeError("Buffer requires dtype and a declared layout")
        if layout is not None:
            if shape is not None or stride is not None:
                raise TypeError("Buffer layout form does not accept shape or stride")
            if not isinstance(layout, Layout):
                raise TypeError(
                    f"Buffer layout must be a Layout, got {type(layout).__name__}"
                )
            if not isinstance(physical_layout, Layout):
                raise TypeError("Buffer layout form requires physical_layout as a Layout")
            if capacity is None:
                raise TypeError("Buffer layout form requires a static capacity tuple")
            shape = layout.shape
        elif shape is None:
            raise TypeError("Buffer requires shape/dtype or layout/dtype")
        elif physical_layout is not None:
            raise TypeError("Buffer physical_layout is accepted only with layout")

        shape, capacity, has_dynamic_shape = _normalize_shape_capacity(
            shape, capacity, owner="Buffer"
        )
        dtype = _normalize_dtype(dtype)
        capacity_stride, has_dynamic_stride = _normalize_stride(stride, capacity)
        if (has_dynamic_shape or shape != capacity) and has_dynamic_stride:
            raise TypeError(
                "Buffer dynamic shape requires a static backing stride"
            )
        data_format, n1_pad = _normalize_format(
            mem_loc, capacity, data_format, n1_pad
        )
        if layout is not None:
            capacity_physical_shape, capacity_physical_stride = (
                _physical_layout_spec(
                    dtype,
                    capacity,
                    data_format,
                    n1_pad,
                    mem_loc=mem_loc,
                )
            )
            if data_format == "nd":
                capacity_physical_stride = capacity_stride
            capacity_layout = make_layout(capacity, stride=capacity_stride)
            capacity_physical_layout = (
                make_layout(capacity_physical_shape)
                if capacity_physical_stride is None
                else make_layout(
                    capacity_physical_shape,
                    stride=capacity_physical_stride,
                )
            )
            storage_type = _tensor_type_from_layouts(
                dtype,
                mem_loc,
                capacity_layout,
                capacity_physical_layout,
                data_format=data_format,
            )
            declared_layout = make_layout(layout.shape, stride=layout.stride)
            return _make_onchip_allocation(
                dtype,
                mem_loc,
                declared_layout,
                physical_layout,
                data_format=data_format,
                fixed_addr=None,
                storage_type=storage_type,
            )

        root = _build_buffer_tensor(
            mem_loc,
            capacity,
            dtype,
            None,
            capacity_stride,
            data_format,
            n1_pad,
        )
        if not has_dynamic_shape and shape == capacity:
            return root

        from cannbotdsl.tensor import make_tiler, reinterpret

        dynamic_tiler = make_tiler(shape)
        return reinterpret(root, shape=dynamic_tiler, stride=capacity_stride)


# arch_3510 capacities, matching PlanOnChipMemory. SSBUF describes the full
# MIX address space; scalar access verification enforces per-core windows.
_SPACE_CAPACITY_BYTES = {
    MemLoc.UB: 256 * 1024, MemLoc.L1: 512 * 1024,
    MemLoc.L0A: 64 * 1024, MemLoc.L0B: 64 * 1024,
    MemLoc.L0C: 256 * 1024, MemLoc.BIAS: 4 * 1024,
    MemLoc.SSBUF: 3 * 1024, MemLoc.FBUF: 4 * 1024,
}
_STATIC_VIEW_OPS = frozenset(
    {
        "cannir.reshape_view",
        "cannir.memref_slice",
        "cannir.local_slice",
        "cannir.tile_slice",
        "cannir.reinterpret_view",
        "cannir.storage_cast",
        "cannir.dtype_view",
        "cannir.permute_view",
        "cannir.make_buf",
    }
)


def _static_product(shape) -> int:
    values = []
    for dim in shape:
        if not is_exact_instance(dim, int) or dim <= 0:
            raise TypeError(
                "on-chip space views require a non-empty static shape of positive ints"
            )
        values.append(dim)
    if not values:
        raise ValueError("on-chip space view shape must not be empty")
    return reduce(mul, values, 1)


def _ensure_static_view(view: Tensor) -> None:
    shape = view.shape
    stride = view.stride
    _static_product(shape)
    for name, values in (("stride", stride),):
        for index, value in enumerate(values):
            if not is_exact_instance(value, int) or value <= 0:
                raise TypeError(
                    f"on-chip space view {name}[{index}] must be a positive static int"
                )


def _find_space_root(value):
    """Find the explicit on-chip root through the supported static view chain."""

    current = unwrap_operand(value)
    visited = set()
    while current is not None and current not in visited:
        visited.add(current)
        owner = getattr(current, "owner", None)
        name = str(getattr(owner, "name", ""))
        if name == "cannir.onchip_alloc":
            if "cannir.onchip_space_root" in owner.attributes:
                return current
            return None
        if name not in _STATIC_VIEW_OPS:
            return None
        current = unwrap_operand(owner.operands[0])
    return None


def _has_bound_resource(value) -> bool:
    """Return whether a view chain already contains a make_buf boundary."""

    current = unwrap_operand(value)
    visited = set()
    while current is not None and current not in visited:
        visited.add(current)
        owner = getattr(current, "owner", None)
        name = str(getattr(owner, "name", ""))
        if name == "cannir.make_buf":
            return True
        if name not in _STATIC_VIEW_OPS:
            return False
        current = unwrap_operand(owner.operands[0])
    return False


class _OnChipSpace:
    """Function-local, full-capacity byte storage for manual placement."""

    __slots__ = ("mem_loc",)

    def __init__(self, mem_loc):
        self.mem_loc = mem_loc

    def view(self, *shape, dtype=None):
        """Return a static uint8 view of this space's complete capacity.

        Repeated calls in one kernel reuse the same root. For contiguous ND,
        take a byte slice and use Tensor.view for dtype and shape; use
        reinterpret for explicit physical layouts or SSBUF. Bind the typed
        view with make_buffer or make_channel before use.
        """
        if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
            shape = tuple(shape[0])
        else:
            shape = tuple(shape)
        name = self.mem_loc.name
        capacity = _SPACE_CAPACITY_BYTES[self.mem_loc]
        if dtype is not None and dtype != dtypes.uint8:
            raise ValueError(f"dsl.{name}.view is byte-addressed; dtype must be dtypes.uint8")
        if _static_product(shape) != capacity:
            raise ValueError(
                f"dsl.{name}.view must cover the complete {capacity // 1024} KiB "
                f"{name} space ({capacity} uint8 elements), got shape={shape!r}"
            )
        trace_state = _current_onchip_trace()
        if self.mem_loc in trace_state.automatic_spaces:
            raise ValueError(
                f"dsl.{name}.view cannot mix with ordinary {name} Buffer/Channel "
                "allocations in the same kernel"
            )
        if trace_state.has_rewind:
            raise ValueError("channel_rewind is not supported in kernels with manual storage roots")
        root = trace_state.space_roots.get(self.mem_loc)
        if root is None:
            layout = make_layout((capacity,))
            root = _make_onchip_allocation(
                dtypes.uint8, self.mem_loc, layout, layout,
                data_format="nd", fixed_addr=0,
            )
            unwrap_operand(root).owner.attributes["cannir.onchip_space_root"] = ir.UnitAttr.get()
            trace_state.space_roots[self.mem_loc] = root
        return root.view(shape)


UB, L1, L0A, L0B, L0C, BIAS, SSBUF, FBUF = (
    _OnChipSpace(mem_loc) for mem_loc in _SPACE_CAPACITY_BYTES
)


def make_buffer(view: Tensor, *, dtype=None) -> Tensor:
    """Bind a static on-chip view to a hardware Buffer identity.

    The operation reuses the view's storage root and address.  It emits no
    ``onchip_alloc``; only a ``make_buf`` marker and a buf-id are added.
    """

    if not isinstance(view, Tensor):
        raise TypeError(
            f"make_buffer expects a Tensor view, got {type(view).__name__}"
        )
    if view.memloc not in _BUFFER_MEM_LOCS:
        raise ValueError("make_buffer supports only on-chip views")
    _ensure_static_view(view)

    root = _find_space_root(view)
    if root is None:
        raise ValueError(
            f"make_buffer requires a static view derived from dsl.{view.memloc.name}.view()"
        )

    # A view of an already-bound Buffer keeps that resource.  A dtype view is
    # formed before this check by the caller (or by the implementation below),
    # so no second buf-id can be introduced accidentally.
    if dtype is not None:
        from cannbotdsl.core.contracts.elements import normalize_storage_dtype

        dtype = normalize_storage_dtype(dtype)
        if dtype != view.dtype:
            view = view.view(dtype=dtype)
            _ensure_static_view(view)
    if _has_bound_resource(view):
        return view

    _current_onchip_trace()
    identity = cannir.BufferResourceOp.build_generic(
        results=[ir.IntegerType.get_signless(64)], operands=[unwrap_operand(view)]
    ).results[0]
    marker = cannir.make_buf(unwrap_operand(view), identity)
    marker_value = unwrap_operand(marker)
    marker_value.owner.attributes["cannir.buffer.explicit_binding"] = ir.UnitAttr.get()
    marker_value.owner.attributes["cannir.buffer.logical"] = ir.UnitAttr.get()
    return Tensor._from_ir(marker_value)


__all__ = ["Buffer", "UB", "L1", "L0A", "L0B", "L0C", "BIAS", "SSBUF", "FBUF", "make_buffer"]
