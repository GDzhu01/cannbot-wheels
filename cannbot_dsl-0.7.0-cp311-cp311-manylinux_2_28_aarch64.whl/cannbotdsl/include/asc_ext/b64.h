// Copyright (c) 2026 Huawei Technologies Co., Ltd.
// Licensed under CANN Open Software License Agreement Version 2.0.
#ifndef ASC_EXT_B64_H
#define ASC_EXT_B64_H
#include "c_api/asc_simd.h"
#include <type_traits>

// 3510 integer b64 extensions. One register contains 32 elements. A predicate
// uses the b32 encoding with identical bits for both words of each element.
// Arithmetic wraps modulo 2^64; division truncates toward zero. Division by
// zero returns all-one bits; INT64_MIN / -1 returns INT64_MIN.
namespace asc_ext {
__simd_callee__ inline vector_bool asc_update_mask_b64(uint32_t& remaining) {
    uint32_t words = (remaining < 32 ? remaining : 32) * 2;
    remaining = remaining > 32 ? remaining - 32 : 0;
    return ::asc_update_mask_b32(words);
}
__simd_callee__ inline vector_bool asc_create_mask_b64(uint32_t count) {
    return asc_ext::asc_update_mask_b64(count);
}
namespace detail {
struct words { vector_uint32_t lo, hi; };
template<class V> __simd_callee__ inline void check_b64() {
    static_assert(std::is_same<V, vector_int64_t>::value || std::is_same<V, vector_uint64_t>::value,
                  "asc_ext b64 APIs require vector_int64_t or vector_uint64_t");
}
__simd_callee__ inline vector_bool all() { return asc_create_mask_b32(PAT_ALL); }
__simd_callee__ inline vector_uint32_t dup(uint32_t x) {
    vector_uint32_t r; ::asc_duplicate_scalar(r, x); return r;
}
template<class V> __simd_callee__ inline words split(V x) {
    check_b64<V>();
    vector_uint32_t lo, hi, unused;
    ::asc_deintlv(lo, hi, (vector_uint32_t&)x, (vector_uint32_t&)x);
    words r;
    ::asc_intlv(r.lo, unused, lo, lo);
    ::asc_intlv(r.hi, unused, hi, hi);
    return r;
}
template<class V> __simd_callee__ inline void join(V& dst, words x) {
    check_b64<V>();
    vector_uint32_t lo, hi, unused, packed;
    ::asc_deintlv(lo, unused, x.lo, x.lo);
    ::asc_deintlv(hi, unused, x.hi, x.hi);
    ::asc_intlv(packed, unused, lo, hi);
    dst = (V&)packed;
}
__simd_callee__ inline words add(words a, words b, vector_bool m) {
    words r; vector_bool carry, unused;
    ::asc_add(carry, r.lo, a.lo, b.lo, m);
    ::asc_addc(unused, r.hi, a.hi, b.hi, carry, m);
    return r;
}
__simd_callee__ inline words sub(words a, words b, vector_bool m) {
    words r; vector_bool carry, unused;
    ::asc_subc(carry, r.lo, a.lo, b.lo, all(), m);
    ::asc_subc(unused, r.hi, a.hi, b.hi, carry, m);
    return r;
}
__simd_callee__ inline words neg(words a, vector_bool m) {
    words zero{dup(0), dup(0)}; return sub(zero, a, m);
}
__simd_callee__ inline words select(words a, words b, vector_bool p) {
    words r; ::asc_select(r.lo, a.lo, b.lo, p); ::asc_select(r.hi, a.hi, b.hi, p); return r;
}
__simd_callee__ inline vector_bool eq(words a, words b, vector_bool m) {
    vector_bool lo, hi, r;
    ::asc_eq(lo, a.lo, b.lo, m); ::asc_eq(hi, a.hi, b.hi, m);
    ::asc_and(r, lo, hi, m); return r;
}
template<bool Signed> __simd_callee__ inline vector_bool lt(words a, words b, vector_bool m) {
    vector_bool lo, hi, same, tied, r;
    ::asc_lt(lo, a.lo, b.lo, m);
    if constexpr (Signed) ::asc_lt(hi, (vector_int32_t&)a.hi, (vector_int32_t&)b.hi, m);
    else ::asc_lt(hi, a.hi, b.hi, m);
    ::asc_eq(same, a.hi, b.hi, m); ::asc_and(tied, same, lo, m);
    ::asc_or(r, hi, tied, m); return r;
}
__simd_callee__ inline vector_bool sign(words a, vector_bool m) {
    vector_int32_t zero; ::asc_duplicate_scalar(zero, 0);
    vector_bool p; ::asc_lt(p, (vector_int32_t&)a.hi, zero, m); return p;
}
__simd_callee__ inline words shl(words a, uint32_t n, vector_bool m) {
    words r; vector_uint32_t cross, upper;
    if (n == 0) { ::asc_select(r.lo, a.lo, dup(0), m); ::asc_select(r.hi, a.hi, dup(0), m); }
    else if (n < 32) {
        ::asc_shiftleft_scalar(r.lo, a.lo, n, m);
        ::asc_shiftright_scalar(cross, a.lo, 32-n, m);
        ::asc_shiftleft_scalar(upper, a.hi, n, m); ::asc_or(r.hi, upper, cross, m);
    } else { r.lo = dup(0); ::asc_shiftleft_scalar(r.hi, a.lo, n-32, m); }
    return r;
}
} // namespace detail

template<class T, class V> __simd_callee__ inline void asc_storealign(__ubuf__ T* dst, V src, vector_bool m) {
    detail::check_b64<V>();
    static_assert(sizeof(T) == 8, "b64 store pointer elements must be 64 bits");
    ::asc_storealign((__ubuf__ uint32_t*)dst, (vector_uint32_t&)src, m);
}
template<class T, class V> __simd_callee__ inline void asc_storealign_postupdate(
    __ubuf__ T*& dst, V src, int32_t stride, vector_bool m) {
    detail::check_b64<V>();
    static_assert(sizeof(T) == 8, "b64 store pointer elements must be 64 bits");
    auto words = (__ubuf__ uint32_t*)dst;
    ::asc_storealign_postupdate(words, (vector_uint32_t&)src, stride * 2, m);
    dst = (__ubuf__ T*)words;
}

template<class V> __simd_callee__ inline void asc_select(V& dst, V a, V b, vector_bool p) {
    detail::check_b64<V>();
    vector_uint32_t r; ::asc_select(r, (vector_uint32_t&)a, (vector_uint32_t&)b, p); dst = (V&)r;
}
template<class V> __simd_callee__ inline void asc_copy(V& dst, V a, vector_bool m) {
    detail::check_b64<V>();
    // Native asc_copy uses MODE_MERGING; a fresh destination would leave
    // inactive words undefined. The extension has explicit zeroing semantics.
    vector_uint32_t r; ::asc_select(r, (vector_uint32_t&)a, detail::dup(0), m); dst = (V&)r;
}
#define ASC_EXT_BINARY_BITS(NAME) \
template<class V> __simd_callee__ inline void NAME(V& dst, V a, V b, vector_bool m) { \
    detail::check_b64<V>(); \
    vector_uint32_t r; ::NAME(r, (vector_uint32_t&)a, (vector_uint32_t&)b, m); dst = (V&)r; }
ASC_EXT_BINARY_BITS(asc_and)
ASC_EXT_BINARY_BITS(asc_or)
ASC_EXT_BINARY_BITS(asc_xor)
#undef ASC_EXT_BINARY_BITS
template<class V> __simd_callee__ inline void asc_not(V& dst, V a, vector_bool m) {
    detail::check_b64<V>();
    vector_uint32_t r; ::asc_not(r, (vector_uint32_t&)a, m); dst = (V&)r;
}
template<class V> __simd_callee__ inline void asc_add(V& dst, V a, V b, vector_bool m) {
    detail::join(dst, detail::add(detail::split(a), detail::split(b), m));
}
template<class V> __simd_callee__ inline void asc_sub(V& dst, V a, V b, vector_bool m) {
    detail::join(dst, detail::sub(detail::split(a), detail::split(b), m));
}
template<class V> __simd_callee__ inline void asc_mul(V& dst, V a, V b, vector_bool m) {
    auto x = detail::split(a); auto y = detail::split(b);
    detail::words r; vector_uint32_t p, q, unused, sum;
    ::asc_mull(r.lo, r.hi, x.lo, y.lo, m);
    ::asc_mull(p, unused, x.lo, y.hi, m); ::asc_mull(q, unused, x.hi, y.lo, m);
    ::asc_add(sum, r.hi, p, m); ::asc_add(r.hi, sum, q, m); detail::join(dst, r);
}
template<class V> __simd_callee__ inline void asc_neg(V& dst, V a, vector_bool m) {
    detail::join(dst, detail::neg(detail::split(a), m));
}
template<class V> __simd_callee__ inline void asc_abs(V& dst, V a, vector_bool m) {
    if constexpr (std::is_same<V, vector_int64_t>::value) {
        auto x = detail::split(a); detail::join(dst, detail::select(detail::neg(x, m), x, detail::sign(x, m)));
        asc_ext::asc_copy(dst, dst, m);
    } else asc_ext::asc_copy(dst, a, m);
}
template<class V> __simd_callee__ inline void asc_eq(vector_bool& dst, V a, V b, vector_bool m) {
    dst = detail::eq(detail::split(a), detail::split(b), m);
}
template<class V> __simd_callee__ inline void asc_ne(vector_bool& dst, V a, V b, vector_bool m) {
    vector_bool p; asc_ext::asc_eq(p, a, b, m); ::asc_not(dst, p, m);
}
template<class V> __simd_callee__ inline void asc_lt(vector_bool& dst, V a, V b, vector_bool m) {
    dst = detail::lt<std::is_same<V, vector_int64_t>::value>(detail::split(a), detail::split(b), m);
}
template<class V> __simd_callee__ inline void asc_gt(vector_bool& dst, V a, V b, vector_bool m) {
    asc_ext::asc_lt(dst, b, a, m);
}
template<class V> __simd_callee__ inline void asc_ge(vector_bool& dst, V a, V b, vector_bool m) {
    vector_bool p; asc_ext::asc_lt(p, a, b, m); ::asc_not(dst, p, m);
}
template<class V> __simd_callee__ inline void asc_le(vector_bool& dst, V a, V b, vector_bool m) {
    asc_ext::asc_ge(dst, b, a, m);
}
template<class V> __simd_callee__ inline void asc_max(V& dst, V a, V b, vector_bool m) {
    vector_bool p; asc_ext::asc_ge(p, a, b, m); asc_ext::asc_select(dst, a, b, p); asc_ext::asc_copy(dst, dst, m);
}
template<class V> __simd_callee__ inline void asc_min(V& dst, V a, V b, vector_bool m) {
    vector_bool p; asc_ext::asc_le(p, a, b, m); asc_ext::asc_select(dst, a, b, p); asc_ext::asc_copy(dst, dst, m);
}
template<class V> __simd_callee__ inline void asc_shiftleft_scalar(V& dst, V a, uint32_t n, vector_bool m) {
    detail::join(dst, detail::shl(detail::split(a), n, m));
}
template<class V> __simd_callee__ inline void asc_shiftright_scalar(V& dst, V a, uint32_t n, vector_bool m) {
    auto x = detail::split(a); detail::words r; vector_uint32_t cross, low;
    if (n == 0) { asc_ext::asc_copy(dst, a, m); return; }
    if constexpr (std::is_same<V, vector_int64_t>::value) {
        vector_int32_t hi, shifted;
        ::asc_shiftright_scalar(hi, (vector_int32_t&)x.hi, n < 32 ? n : 31, m); r.hi = (vector_uint32_t&)hi;
        if (n >= 32) { ::asc_shiftright_scalar(shifted, (vector_int32_t&)x.hi, n-32, m); r.lo = (vector_uint32_t&)shifted; }
    } else {
        if (n < 32) ::asc_shiftright_scalar(r.hi, x.hi, n, m);
        else { r.hi = detail::dup(0); ::asc_shiftright_scalar(r.lo, x.hi, n-32, m); }
    }
    if (n < 32) {
        ::asc_shiftleft_scalar(cross, x.hi, 32-n, m); ::asc_shiftright_scalar(low, x.lo, n, m); ::asc_or(r.lo, low, cross, m);
    }
    detail::join(dst, r);
}
template<class V> __simd_callee__ inline void asc_div(V& dst, V a, V b, vector_bool m) {
    auto x = detail::split(a); auto y = detail::split(b);
    vector_bool negative = asc_create_mask_b32(PAT_ALLF);
    if constexpr (std::is_same<V, vector_int64_t>::value) {
        auto sx = detail::sign(x, m); auto sy = detail::sign(y, m); ::asc_xor(negative, sx, sy, m);
        x = detail::select(detail::neg(x, m), x, sx); y = detail::select(detail::neg(y, m), y, sy);
    }
    detail::words zero{detail::dup(0), detail::dup(0)}, q = zero, rem = zero;
    auto one = detail::dup(1);
    for (int bit = 63; bit >= 0; --bit) {
        vector_bool overflow = detail::sign(rem, m), less, take;
        rem = detail::shl(rem, 1, m);
        vector_uint32_t input, digit;
        if (bit >= 32) ::asc_shiftright_scalar(input, x.hi, bit-32, m);
        else ::asc_shiftright_scalar(input, x.lo, bit, m);
        ::asc_and(digit, input, one, m); ::asc_or(rem.lo, rem.lo, digit, m);
        less = detail::lt<false>(rem, y, m); ::asc_not(take, less, m); ::asc_or(take, take, overflow, m);
        rem = detail::select(detail::sub(rem, y, m), rem, take);
        q = detail::shl(q, 1, m); ::asc_select(digit, one, zero.lo, take); ::asc_or(q.lo, q.lo, digit, m);
    }
    if constexpr (std::is_same<V, vector_int64_t>::value) q = detail::select(detail::neg(q, m), q, negative);
    auto divzero = detail::eq(y, zero, m);
    detail::words ones{detail::dup(0xffffffffU), detail::dup(0xffffffffU)};
    q = detail::select(ones, q, divzero); detail::join(dst, q); asc_ext::asc_copy(dst, dst, m);
}
} // namespace asc_ext
#endif
