# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# Licensed under the CANN Open Software License Agreement Version 2.0.
"""Installed Native artifacts, resolved by the independent Native binary key.

No dependency on the publication package: the publisher supplies a scoped observer.
Installed files are snapshotted into process-owned storage before mapping.

Resolution is fail-closed for registered resources: prefer falls back only when
no resources/variant apply or the schema/format/ABI is incompatible. Missing
registered manifests, malformed data, checksum failures and conflicting binaries
raise NativeBinaryError even in prefer mode. Discovery checks all registered
manifests, so a broken root can also block lookups for other operators. Off mode
bypasses resource discovery and loading.
"""
from collections import Counter, deque
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from functools import wraps
import atexit
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tempfile
import threading

COLLECTOR = ContextVar('cannbotdsl_native_collector', default=None)
_OBSERVERS = ContextVar('cannbotdsl_compile_observers', default=())


@contextmanager
def observe_compilations(callback, *, aot_only=False):
    """Observe successful compilation artifacts within this context.

    callback(artifact, source_function) runs after Native collection snapshots
    the artifact. Observers must not take ownership of the artifact. aot_only
    rejects direct run/JIT requests before compiling. Nested scopes all observe.
    """
    token = _OBSERVERS.set((*_OBSERVERS.get(), (callback, aot_only)))
    try:
        yield
    finally:
        _OBSERVERS.reset(token)


SCHEMA = 3
COLLECTION_OWNER = None
_lock = threading.RLock()
_catalog = None
_registered_directories = set()
_private = None
_snapshots = {}
_EVENT_LIMIT = 1024
_events = deque(maxlen=_EVENT_LIMIT)
_event_counts = Counter()
_events_dropped = 0
_DIGEST = re.compile(r'[0-9a-f]{64}\Z')


class NativeBinaryError(RuntimeError):
    """A selected package is invalid, ambiguous, or required but absent."""


def _json(data):
    if len(data) > 16 * 1024 * 1024:
        raise NativeBinaryError('Native package JSON exceeds 16 MiB')

    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise NativeBinaryError(f'duplicate Native JSON key: {key}')
            result[key] = value
        return result

    try:
        return json.loads(data, object_pairs_hook=pairs)
    except (ValueError, RecursionError) as exc:
        raise NativeBinaryError('invalid Native package JSON') from exc


def _relative_path(relative):
    if not isinstance(relative, str):
        raise NativeBinaryError('invalid Native package path')
    path = PurePosixPath(relative)
    if not relative or path.is_absolute() or any(p in ('..', '.', '') for p in relative.split('/')) or '\\' in relative:
        raise NativeBinaryError('invalid Native package path')
    return path


def _read(root, relative, limit=256 * 1024 * 1024):
    path = _relative_path(relative)
    descriptors = []
    flags = os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW
    try:
        root = Path(root).absolute()
        parent = os.open(root.anchor, flags | os.O_DIRECTORY)
        descriptors.append(parent)
        for part in (*root.parts[1:], *path.parts[:-1]):
            parent = os.open(part, flags | os.O_DIRECTORY, dir_fd=parent)
            descriptors.append(parent)
        fd = os.open(path.name, flags | os.O_NONBLOCK, dir_fd=parent)
        descriptors.append(fd)
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
            raise NativeBinaryError('Native package file type/size is unsupported')
        chunks, count = [], 0
        while True:
            data = os.read(fd, min(1024 * 1024, limit - count + 1))
            if not data:
                break
            count += len(data)
            if count > limit:
                raise NativeBinaryError('Native package file exceeds size limit')
            chunks.append(data)
        after = os.fstat(fd)
        before_state = (before.st_size, before.st_mtime_ns, before.st_ctime_ns)
        after_state = (after.st_size, after.st_mtime_ns, after.st_ctime_ns)
        if before_state != after_state:
            raise NativeBinaryError('Native package changed while reading')
        return b''.join(chunks)
    except OSError as exc:
        raise NativeBinaryError(f'cannot read Native package file without symlinks: {relative}') from exc
    finally:
        for fd in reversed(descriptors):
            os.close(fd)


def event(kind, **fields):
    """Atomically refresh complete counts and the most recent bounded details."""
    global _events_dropped
    path = os.environ.get('CANNBOTDSL_NATIVE_BINARY_REPORT')
    if not path:
        return
    with _lock:
        _event_counts[kind] += 1
        if len(_events) == _events.maxlen:
            _events_dropped += 1
        _events.append(dict(event=kind, **fields))
        destination = Path(path).absolute()
        destination.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix='.native-report-', dir=destination.parent)
        try:
            with os.fdopen(fd, 'w') as stream:
                json.dump({'counts': dict(_event_counts), 'events': list(_events),
                           'events_dropped': _events_dropped}, stream, indent=2)
            os.replace(name, destination)
        finally:
            if os.path.exists(name):
                os.unlink(name)


def mode():
    value = os.environ.get('CANNBOTDSL_NATIVE_BINARY_MODE', 'prefer')
    if value not in ('prefer', 'require', 'off'):
        raise NativeBinaryError(f'invalid CANNBOTDSL_NATIVE_BINARY_MODE: {value}')
    return value


def enabled():
    if COLLECTOR.get() is not None or mode() == 'require':
        return True
    if mode() != 'prefer':
        return False
    try:
        return bool(_discover())
    except (KeyError, TypeError, ValueError, OSError, AttributeError) as exc:
        raise NativeBinaryError('invalid installed Native package') from exc


def register_directory(path):
    """Register a Native artifact directory containing manifest.json.

    Accept a string or PathLike, relative to the current working directory or
    absolute. Registration is lazy: no manifest or binary is read here.
    Repeated registration is inert; a new directory invalidates cached misses.
    Resources must be ordinary filesystem files, not ZIP members or symlinks.
    """
    try:
        value = os.fspath(path)
        if not isinstance(value, str) or not value or "\x00" in value:
            raise ValueError("expected a nonempty filesystem path")
        # Do not resolve symlinks: discovery must validate the original path.
        directory = Path(os.path.abspath(value))
    except (TypeError, ValueError, OSError) as exc:
        raise NativeBinaryError('invalid Native directory path') from exc
    global _catalog
    with _lock:
        if directory not in _registered_directories:
            _registered_directories.add(directory)
            _catalog = None


def _discover():
    global _catalog
    with _lock:
        if _catalog is not None:
            return _catalog
        catalog = {}
        for root in sorted(_registered_directories):
            manifest_bytes = _read(root, 'manifest.json', 16 * 1024 * 1024)
            manifest = _json(manifest_bytes)
            from cannbotdsl.core.compiler.binary_key import BINARY_KEY_SCHEMA
            from cannbotdsl.core.compiler.abi import HOST_ABI_VERSION
            if (manifest.get('schema_version') != SCHEMA or
                    manifest.get('binary_key_schema') != BINARY_KEY_SCHEMA or
                    manifest.get('host_abi_version') != HOST_ABI_VERSION):
                event('incompatible', reason='package_version')
                continue
            
            def installed_path(relative):
                _relative_path(relative)
                return relative

            manifest = dict(manifest, files={installed_path(name): digest
                                            for name, digest in manifest['files'].items()},
                            index=installed_path(manifest['index']))
            files = manifest['files']
            index_path = manifest['index']
            index_bytes = _read(root, index_path, 16 * 1024 * 1024)
            if hashlib.sha256(index_bytes).hexdigest() != files[index_path]:
                raise NativeBinaryError('Native index checksum mismatch')
            entries = _json(index_bytes)
            if not isinstance(entries, dict) or len(entries) > 65536:
                raise NativeBinaryError('invalid Native index')
            for key, record in entries.items():
                descriptor_path = installed_path(record['descriptor'])
                descriptor_bytes = _read(root, descriptor_path, 16 * 1024 * 1024)
                if hashlib.sha256(descriptor_bytes).hexdigest() != files[descriptor_path]:
                    raise NativeBinaryError('Native descriptor checksum mismatch')
                record = _json(descriptor_bytes)
                if record['binary_key'] != key or record['binary_key_schema'] != BINARY_KEY_SCHEMA:
                    raise NativeBinaryError('Native descriptor binary key mismatch')
                if record['target'] != manifest['target']:
                    raise NativeBinaryError('Native descriptor target mismatch')
                record = dict(record, **{field: installed_path(record[field]) for field in ('binary', 'sidecar')})
                if not _DIGEST.fullmatch(key):
                    raise NativeBinaryError('invalid Native binary key')
                if record['binary'] not in files or record['sidecar'] not in files:
                    raise NativeBinaryError('unlisted Native artifact')
                catalog.setdefault(key, []).append((root, manifest, record))
        _catalog = catalog
        return catalog


@dataclass(frozen=True)
class NativeHit:
    so_path: str
    symbol_name: str
    host_abi_version: int
    content_key: str
    format_version_tag: str


def _resolve(key, contract, target):
    candidates = [item for item in _discover().get(key, ()) if item[1]['target'] == target]
    if not candidates:
        return None
    from cannbotdsl.core.compiler import metadata
    from cannbotdsl.core.compiler.binary_key import host_platform
    from cannbotdsl.core.contracts.codec import contract_digest
    payload = None
    semantic = None
    chosen = None
    for root, manifest, record in candidates:
        incompatible_platform = record['host_platform'] != host_platform()
        incompatible_python = record['python_abi'] not in (None, sys.implementation.cache_tag)
        if incompatible_platform or incompatible_python:
            event('incompatible', reason='host_abi', key=key)
            continue
        binary = _read(root, record['binary'])
        sidecar = _read(root, record['sidecar'], 16 * 1024 * 1024)
        for name, data in ((record['binary'], binary), (record['sidecar'], sidecar)):
            if hashlib.sha256(data).hexdigest() != manifest['files'][name]:
                raise NativeBinaryError('Native artifact checksum mismatch')
        info = _json(sidecar)
        if info.get('version') != metadata.SIDECAR_VERSION:
            event('incompatible', reason='sidecar_version', key=key)
            continue
        symbol, actual, abi, digest, content_key, fmt = metadata.parse_metadata(info)
        if (content_key != record['build_provenance']['cache_key'] or
                fmt != record['build_provenance']['cache_format_tag'] or
                digest != hashlib.sha256(binary).hexdigest() or
                contract_digest(actual) != contract_digest(contract) or
                record['key_inputs']['call_contract_sha256'] != contract_digest(actual)):
            raise NativeBinaryError('Native artifact does not match compilation request')
        current = (binary, symbol, abi, contract_digest(actual), record['python_abi'])
        if semantic is not None and semantic != current:
            raise NativeBinaryError('conflicting installed Native artifacts for binary key')
        semantic = current
        payload, chosen = (binary, sidecar), (symbol, abi, content_key, fmt)
    if payload is None:
        return None
    global _private
    with _lock:
        identity = (key, hashlib.sha256(payload[0]).hexdigest(),
                    hashlib.sha256(payload[1]).hexdigest())
        path = _snapshots.get(identity)
        if path is None:
            if _private is None:
                _private = tempfile.TemporaryDirectory(prefix='cannbotdsl-native-')
                atexit.register(_private.cleanup)
            directory = Path(_private.name) / key / identity[1] / identity[2]
            directory.mkdir(parents=True, exist_ok=True)
            path = directory / 'provider.so'
            path.write_bytes(payload[0])
            Path(str(path) + '.meta.json').write_bytes(payload[1])
            _snapshots[identity] = str(path)
        return NativeHit(str(path), *chosen)


def lookup(key, contract, target, *, bypass=None):
    active = COLLECTOR.get()
    if active is not None:
        if target != active.target:
            raise NativeBinaryError("collection target differs from effective compiler target")
        if bypass is not None or key is None:
            raise NativeBinaryError(f'cannot collect non-persistent compilation: {bypass or "key_error"}')
        return None
    policy = mode()
    if policy == 'off':
        return None
    if key is None or bypass is not None:
        reason = bypass or 'key_error'
        event('installed_miss', reason=reason)
        if policy == 'require':
            raise NativeBinaryError(f'Native binary required: {reason}')
        return None
    try:
        hit = _resolve(key, contract, target)
    except (KeyError, TypeError, ValueError, OSError, AttributeError) as exc:
        raise NativeBinaryError('invalid installed Native package') from exc
    event('installed_hit' if hit else 'installed_miss', key=key, binary_key_schema=1,
          reason=None if hit else 'key_miss')
    if hit is None and policy == 'require':
        raise NativeBinaryError(
            f'Native binary required but not found: {key}; '
            'verify the target/ABI and re-export older packages'
        )
    return hit


def observe(function):
    @wraps(function)
    def wrapped(fn, call_args, call_kwargs, **kwargs):
        if COLLECTION_OWNER is not None and COLLECTION_OWNER != (os.getpid(), threading.get_ident()):
            raise NativeBinaryError("Native collection does not support concurrent threads or fork")
        collector = COLLECTOR.get()
        if collector is not None and not kwargs.get('aot', False):
            raise NativeBinaryError("Native export requires compile(); direct run/JIT export is unsupported")
        observers = _OBSERVERS.get()
        if any(aot_only for _, aot_only in observers) and not kwargs.get('aot', False):
            raise NativeBinaryError("compilation observer requires explicit compile()")
        artifact = function(fn, call_args, call_kwargs, **kwargs)
        if collector is not None:
            recorded = False
            try:
                collector.record(artifact, fn)
                recorded = True
            finally:
                if not recorded and artifact.owns_so and artifact.so_path:
                    from cannbotdsl.core.compiler.function import _remove_owned_artifact

                    _remove_owned_artifact(artifact.so_path)
        for callback, _ in observers:
            callback(artifact, fn)
        return artifact
    return wrapped
