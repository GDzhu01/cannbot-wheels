# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Ahead-of-time compilation of staged functions and bound methods."""



def compile(func, /, *args, **kwargs):
    """Compile a ``@host`` function or bound method into a ``ProviderCallable``.

    Descriptors and constexpr values in ``args`` and ``kwargs`` bind to the
    source function's signature, including its defaults. A bound receiver is
    available during tracing and is excluded from the runtime signature.
    ``func`` is positional-only so a source parameter named ``func`` can be
    supplied by keyword.
    """
    from cannbotdsl.core.frontend.call_context import current_call_context
    from cannbotdsl.lang.host import HostFunction, _BoundHostMethod
    from cannbotdsl.core.compiler.builder import compile_to_artifact
    from cannbotdsl.core.compiler.function import ProviderCallable
    from cannbotdsl.core.contracts.binding import bind_aot_call

    if isinstance(func, _BoundHostMethod):
        host_function = func._host_function
        surface = func._surface
        call_args = (func._instance, *args)
    elif isinstance(func, HostFunction):
        host_function = func
        surface = func._surface
        call_args = args
    else:
        raise TypeError(
            "cannbotdsl.compile() expects a @host function or bound @host method "
            f"as its first argument, got {type(func).__name__}"
        )

    if current_call_context() is not None:
        raise RuntimeError("cannbotdsl.compile() cannot be called inside @host")
    surface.validate_void_return_annotation(path=host_function.__qualname__)
    bound_call = bind_aot_call(
        host_function.fn,
        call_args,
        kwargs,
        surface_signature=surface,
    )
    artifact = compile_to_artifact(
        host_function.fn,
        call_args,
        kwargs,
        aot=True,
        bound_call=bound_call,
    )
    if not artifact.so_path:
        return ProviderCallable._make_noop(
            artifact.symbol_name,
            artifact.contract,
        )
    return ProviderCallable._create(
        artifact.so_path,
        artifact.symbol_name,
        artifact.contract,
        host_abi_version=artifact.host_abi_version,
        owns_so=artifact.owns_so,
        debug_plans=artifact.debug_plans,
        content_key=artifact.content_key,
        format_version_tag=artifact.format_version_tag,
    )
