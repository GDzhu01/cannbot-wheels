"""Native export declarations, collection and atomic artifact publication."""
import ast
from contextlib import ExitStack, contextmanager
import ctypes
import errno
import hashlib
import importlib
import importlib.util
import inspect
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import threading
import types
from typing import Callable, NamedTuple

from . import runtime as native_binary
from .runtime import NativeBinaryError, register_directory, observe_compilations

__all__ = ["export", "build", "register_directory"]


# Versioned interface shared by independently distributed package builders.
# 3: discover() 的 aclnn_collector 参数替换为通用 marks/exclude_dirs 协议；
# core 不再携带任何具体注解（如 ACLNN）的知识。


class Mark(NamedTuple):
    """包构建器注入的导出标记：AST 识别名、入口属性与收集回调包装。

    ast_names：源码扫描识别的调用/装饰器名（含 import 别名解析）；
    attribute：入口对象上携带导出名（str）的属性；wrap：把入口包装为
    收集期零参回调。core 不预置任何标记，具体约定全部由构建器注入。
    """

    ast_names: frozenset
    attribute: str
    wrap: Callable[[object], Callable[[], object]]


def module_identity(name):
    """Stable module identity, independent of an isolated discovery session."""
    return re.sub(r"^_cannbot_collect_[0-9a-f]+\.", "", name)


def _name(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', value) or value in ('.', '..'):
        raise ValueError(f'invalid Native package/task name: {value!r}')
    return value


def export(name):
    """Mark a no-argument function; importing a collector never invokes it."""
    _name(name)

    def decorate(function):
        if not inspect.isfunction(function) or inspect.iscoroutinefunction(function):
            raise TypeError('Native collector must be a synchronous function')
        if inspect.signature(function).parameters:
            raise TypeError('Native collector takes no arguments')
        if hasattr(function, '__opkit_export__'):
            raise ValueError('Native collector already registered')
        # Keep the historical marker so old and new authoring paths interoperate.
        function.__opkit_export__ = name
        return function

    return decorate


def _declares_registration(source, markers):
    """Find explicit export calls without executing unrelated Python files.

    Registration may be inline in an operator module or in a separate file.
    Recognize direct/qualified calls, import aliases and simple alias assignments;
    actual callable tags are checked after import, never inferred from the AST.
    markers：'export' 加上各注入 Mark 的 ast_names。
    """
    tree = ast.parse(source.read_bytes(), filename=str(source))
    names = set(markers)
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            names.update(alias.asname or alias.name for alias in node.names if alias.name in markers)

    def is_register(node):
        return (isinstance(node, ast.Name) and node.id in names) or (
            isinstance(node, ast.Attribute) and node.attr in markers
        )

    changed = True
    while changed:
        changed = False
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign) and is_register(node.value):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id not in names:
                        names.add(target.id)
                        changed = True
    return any(isinstance(node, ast.Call) and is_register(node.func)
               for node in ast.walk(tree))


@contextmanager
def discover(*, collectors, operators=None, pattern="*.py", marks=(), exclude_dirs=()):
    """Keep source modules alive until all collected requests have been compiled.

    core 只识别 @export 标记的 Native 任务；marks 是构建器注入的导出标记
    （Mark），exclude_dirs 是扫描时跳过的相对路径中间目录名。
    """
    if not isinstance(pattern, str) or not pattern.endswith(".py") or "/" in pattern or "\\" in pattern:
        raise ValueError("pattern must be a Python filename pattern, e.g. collect.py")
    root = Path(collectors).resolve(strict=True)
    if not root.is_dir():
        raise ValueError('collectors must be a directory')
    tasks = {}
    markers = {'export'}
    for mark in marks:
        markers |= set(mark.ast_names)
    namespace = '_cannbot_collect_' + hashlib.sha256(os.urandom(32)).hexdigest()[:16]
    before = set(sys.modules)
    try:
        init = root / '__init__.py'
        if init.exists():
            spec = importlib.util.spec_from_file_location(namespace, init, submodule_search_locations=[str(root)])
            module = importlib.util.module_from_spec(spec)
            sys.modules[namespace] = module
            spec.loader.exec_module(module)
        else:
            module = types.ModuleType(namespace)
            module.__path__ = [str(root)]
            sys.modules[namespace] = module
        modules = [module]
        for source in sorted(root.rglob(pattern)):
            relative = source.relative_to(root)
            if any(part in exclude_dirs for part in relative.parts[:-1]):
                continue
            if any(part.startswith('.') or part == '__pycache__' for part in relative.parts):
                continue
            try:
                declared = _declares_registration(source, markers)
            except SyntaxError as exc:
                # Preserve SyntaxError location fields and the original cause.
                # Skipping could silently omit an operator from the export.
                message = (f'Native collector discovery failed while parsing {source}; '
                           f'scan root: {root}, pattern: {pattern!r}: {exc.msg}')
                raise SyntaxError(message, (exc.filename, exc.lineno, exc.offset,
                                           exc.text, exc.end_lineno, exc.end_offset)) from exc
            if not declared:
                continue
            parts = list(relative.with_suffix('').parts)
            if parts[-1] == '__init__':
                parts.pop()
            if not parts:
                continue
            if not all(part.isidentifier() for part in parts):
                raise ValueError(f'collector path is not a Python module: {relative}')
            modules.append(importlib.import_module(namespace + '.' + '.'.join(parts)))
        origins = {}
        for module in modules:
            for function in vars(module).values():
                marked = False
                for mark in marks:
                    exported_name = getattr(function, mark.attribute, None)
                    if isinstance(exported_name, str):
                        if exported_name in tasks and origins.get(exported_name) is not function:
                            raise ValueError(f"duplicate exported name: {exported_name}")
                        origins[exported_name] = function
                        tasks[exported_name] = mark.wrap(function)
                        marked = True
                        break
                if marked:
                    continue
                if not inspect.isfunction(function) or function.__module__ != module.__name__:
                    continue
                task = getattr(function, '__opkit_export__', None)
                if task is None:
                    continue
                if task in tasks and tasks[task] is not function:
                    raise ValueError(f'duplicate Native task: {task}')
                tasks[task] = function
        selected = sorted(tasks) if operators is None else list(operators)
        if not selected or len(set(selected)) != len(selected) or any(task not in tasks for task in selected):
            raise ValueError('empty, duplicate or unknown Native task selection')
        yield {task: tasks[task] for task in selected}
    finally:
        for module_name in set(sys.modules) - before:
            if module_name == namespace or module_name.startswith(namespace + '.'):
                sys.modules.pop(module_name, None)


_session_lock = threading.Lock()


def _json(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True) + '\n').encode()


def _sha(value):
    return hashlib.sha256(value).hexdigest()


class Collection:
    """Native package collection and package-builder extension lifecycle.

    ``task`` selects the label for subsequent requests. ``tasks`` and
    ``records`` may be inspected for membership/truthiness; their stored
    values are internal. After leaving collect(), build_directory() publishes
    the captured artifacts and close() releases them idempotently.
    """
    def __init__(self, target):
        if target not in ('dav-2201', 'dav-3510'):
            raise ValueError('Native collection requires dav-2201 or dav-3510 target')
        self.target = target
        self.task = 'default'
        self.records, self.tasks = {}, {}
        self._extensions = {}
        self._cleanups = ExitStack()
        self._temp = tempfile.TemporaryDirectory(prefix='cannbotdsl-collect-')
        self._ready = False
        self._closed = False
        self._thread = threading.get_ident()
        self._pid = os.getpid()

    def close(self):
        """Release collected temporary artifacts after publication; safe to call again."""
        self._ready = False
        self._closed = True
        try:
            self._cleanups.close()
        finally:
            self._extensions.clear()
            self._temp.cleanup()

    def record(self, artifact, function):
        if self._closed:
            raise RuntimeError("Native collection is closed")
        if threading.get_ident() != self._thread or os.getpid() != self._pid:
            raise RuntimeError('Native collection supports one thread/process')
        if not artifact.so_path or not artifact.content_key or not artifact.binary_key or artifact.debug_plans:
            raise native_binary.NativeBinaryError('collection requires a persistent, content-addressed Provider')
        from cannbotdsl.core.compiler.metadata import publish_artifact
        key = artifact.binary_key
        source = {'function': function.__qualname__, 'module': function.__module__, 'mode': 'aot'}
        task = self.tasks.setdefault(self.task, {'requests': 0, 'artifacts': [], 'sources': []})
        task['requests'] += 1
        if source not in task['sources']:
            task['sources'].append(source)
        if key not in task['artifacts']:
            task['artifacts'].append(key)
        directory = Path(self._temp.name) / key
        directory.mkdir(exist_ok=True)
        destination = directory / 'provider.so'
        if key not in self.records:
            publish_artifact(artifact.so_path, str(destination), artifact.symbol_name, artifact.contract,
                             host_abi_version=artifact.host_abi_version, content_key=artifact.content_key,
                             format_version_tag=artifact.format_version_tag)
            from cannbotdsl.core.compiler.binary_key import build_provenance, host_platform
            self.records[key] = {'directory': directory, 'owner': self.task,
                'descriptor': {
                    'binary_key_schema': artifact.binary_key_schema, 'binary_key': key,
                    'target': self.target, 'host_platform': host_platform(), 'python_abi': None,
                    'key_inputs': artifact.binary_key_inputs,
                    'build_provenance': dict(build_provenance(), cache_key=artifact.content_key,
                                            cache_format_tag=artifact.format_version_tag)}}
        else:
            # Same key with different bytes is an identity conflict, never an overwrite.
            from cannbotdsl.core.compiler.metadata import parse_metadata
            from cannbotdsl.core.contracts.codec import contract_digest
            symbol, contract, abi, digest, _, _ = parse_metadata(
                json.loads(Path(str(destination) + '.meta.json').read_bytes()))
            if (digest != _sha(Path(artifact.so_path).read_bytes()) or
                    symbol != artifact.symbol_name or abi != artifact.host_abi_version or
                    contract_digest(contract) != contract_digest(artifact.contract)):
                raise native_binary.NativeBinaryError('different binaries produced the same binary key')

    def extension(self, name, create):
        """Return session-local state owned by a package-builder extension."""
        if self._closed:
            raise RuntimeError("Native collection is closed")
        if name not in self._extensions:
            self._extensions[name] = create()
        return self._extensions[name]

    def add_cleanup(self, callback):
        """Run a builder's cleanup when the collection is closed."""
        if self._closed:
            raise RuntimeError("Native collection is closed")
        self._cleanups.callback(callback)

    def add_task_metadata(self, name, value):
        """Append JSON metadata to the current task, preserving core fields.

        Extensions own the meaning of their fields. Freeze values immediately;
        repeated equal entries are stored once, as with artifact references.
        """
        if self._closed:
            raise RuntimeError("Native collection is closed")
        if not isinstance(name, str) or not name or name in {
            'name', 'requests', 'artifacts', 'sources', 'variants'
        }:
            raise ValueError("reserved or invalid Native task metadata field")
        value = json.loads(_json(value))
        values = self.tasks[self.task].setdefault(name, [])
        if value not in values:
            values.append(value)

    def _package_files(self):
        """Create the backend-independent, artifact-root-relative layout."""
        if not self._ready or not self.records:
            raise RuntimeError('Native package requires a completed, nonempty collection')
        from cannbotdsl.core.compiler.binary_key import BINARY_KEY_SCHEMA
        from cannbotdsl.core.compiler.abi import HOST_ABI_VERSION
        files, index = {}, {}
        for key, record in sorted(self.records.items()):
            base = f'operators/{record["owner"]}/variants/{key}'
            binary, sidecar = base + '/provider.so', base + '/provider.so.meta.json'
            files[binary] = (record['directory'] / 'provider.so').read_bytes()
            files[sidecar] = (record['directory'] / 'provider.so.meta.json').read_bytes()
            descriptor = base + '/variant.json'
            files[descriptor] = _json(dict(record['descriptor'], binary=binary, sidecar=sidecar))
            index[key] = {'descriptor': descriptor}
        for name, task in sorted(self.tasks.items()):
            info = dict(task, name=name, variants={key: index[key] for key in sorted(task['artifacts'])})
            files[f'operators/{name}/operator.json'] = _json(info)
        index_path = 'index.json'
        files[index_path] = _json(index)
        manifest_path = 'manifest.json'
        files[manifest_path] = _json(
            {
                'schema_version': native_binary.SCHEMA,
                'target': self.target,
                'binary_key_schema': BINARY_KEY_SCHEMA,
                'host_abi_version': HOST_ABI_VERSION,
                'index': index_path,
                'files': {name: _sha(data) for name, data in sorted(files.items())},
            }
        )
        return files

    def build_directory(self, output):
        """Atomically export to the exact output path; never overwrite it."""
        files = self._package_files()
        output = Path(output).absolute()
        output.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='.native-artifacts-', dir=output.parent) as temp:
            staged = Path(temp) / 'artifacts'
            staged.mkdir()
            for relative, data in sorted(files.items()):
                destination = staged / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)
            publish_path(staged, output)
        return output


@contextmanager
def collect(*, target):
    """Collect explicit compile requests; no changes to user return values."""
    if not _session_lock.acquire(blocking=False):
        raise RuntimeError('nested/concurrent Native collection is unsupported')
    session = None
    token = None
    previous_target = os.environ.get("CANNBOTDSL_NPU_ARCH")
    try:
        session = Collection(target)
        token = native_binary.COLLECTOR.set(session)
        os.environ["CANNBOTDSL_NPU_ARCH"] = target
        native_binary.COLLECTION_OWNER = (os.getpid(), threading.get_ident())
        yield session
        session._ready = not session._closed
    finally:
        native_binary.COLLECTION_OWNER = None
        if previous_target is None:
            os.environ.pop("CANNBOTDSL_NPU_ARCH", None)
        else:
            os.environ["CANNBOTDSL_NPU_ARCH"] = previous_target
        if token is not None:
            native_binary.COLLECTOR.reset(token)
        _session_lock.release()
        if session is not None and not session._ready:
            session.close()


def build(*, collectors, target, output, operators=None, pattern="*.py"):
    """Discover registered tasks, compile Providers and publish one Native package."""
    with discover(collectors=collectors, operators=operators, pattern=pattern,
                  exclude_dirs=frozenset({"tests", "test", "build", "dist"})) as tasks:
        with collect(target=target) as session:
            for task, callback in tasks.items():
                session.task = task
                callback()
                if task not in session.tasks:
                    raise RuntimeError(f'Native task collected no Provider: {task}')
        try:
            return session.build_directory(output)
        finally:
            session.close()


def publish_path(source, destination):
    """Linux renameat2 prevents even an empty destination from being replaced."""
    libc = ctypes.CDLL(None, use_errno=True)
    rename = getattr(libc, "renameat2", None)
    if rename is None:
        raise OSError(errno.ENOSYS, "atomic non-replacing package publication requires renameat2")
    rename.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
    rename.restype = ctypes.c_int
    if rename(-100, os.fsencode(source), -100, os.fsencode(destination), 1):
        code = ctypes.get_errno()
        raise OSError(code, os.strerror(code), os.fspath(destination))


def host_source(value):
    """Return the source function of a Native host callable, or None."""
    from cannbotdsl.lang.host import HostFunction, _BoundHostMethod
    if isinstance(value, _BoundHostMethod):
        value = value._host_function
    return value.fn if isinstance(value, HostFunction) else None
