# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""On-chip slots with independent explicit write and read cursors.

``produce()`` and ``consume()`` select a Tensor and advance their respective
cursor immediately. Data accesses determine synchronization; selecting a slot
does not initialize data, wait, check fullness, or copy the stored data. Both
returned Tensors support reads, writes and in-place updates.

SameCore and CrossCore declarations use the same selection interface.
The compiler derives local and cross-core synchronization from Tensor accesses.

For single-slot VF-internal scratch space (no ring-buffer semantics), use
``cannbotdsl.buffer.Buffer``. Buffer and Channel allocation declarations share
the pass-side address planner. Byte slices and ``Tensor.view`` describe
contiguous ND aliases; ``reinterpret`` describes explicit physical layouts.
Neither view operation requests another allocation.
"""
from __future__ import annotations

from enum import IntEnum as _IntEnum

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir
from cannbotdsl._onchip import _current_onchip_trace, _normalize_shape_capacity
from cannbotdsl.core.ir_transport import unwrap_operand
from cannbotdsl.core.utils.type_checks import is_exact_instance
from cannbotdsl.ops.sync import channel_rewind as channel_rewind
from cannbotdsl.tensor import MemLoc, Tensor

_CUBE_MEM_LOCS = {MemLoc.L1, MemLoc.L0A, MemLoc.L0B, MemLoc.L0C, MemLoc.BIAS}


class ChannelKind(_IntEnum):
    SameCore = 0
    CrossCore = 1


@ir.register_value_caster(cannir.ChannelType.get_static_typeid())
class _ChannelValue(ir.Value):
    """SSA-level Channel value. Auto-cast from ChannelType SSA values."""

    @property
    def dtype(self):
        memref_ty = cannir.TensorType(self.type.element)
        from cannbotdsl.core.contracts.elements import dtype_for_storage_mlir_type

        return dtype_for_storage_mlir_type(
            cannir.PointerType(memref_ty.pointer).dtype
        )

    @property
    def memloc(self):
        memref_ty = cannir.TensorType(self.type.element)
        return cannir.PointerType(memref_ty.pointer).memloc

    @property
    def layout(self):
        return cannir.extract_layout(self)

    @property
    def physical_layout(self):
        return cannir.extract_physical_layout(self)

    @property
    def shape(self):
        return self.layout.shape

    @property
    def stride(self):
        return self.layout.stride

    @property
    def physical_shape(self):
        return self.physical_layout.shape

    @property
    def physical_stride(self):
        return self.physical_layout.stride

    @property
    def depth(self):
        return self.type.depth

    @property
    def element(self):
        return self.type.element

    @property
    def kind(self):
        return self.type.kind

    @property
    def layout_map_kind(self):
        from cannbotdsl.tensor import LayoutMapKind

        memref_ty = cannir.TensorType(self.type.element)
        return LayoutMapKind(memref_ty.layout_map_kind)

    @property
    def logical_format(self):
        # Channel logical views are ND; still validate the carried map kind.
        _ = self.layout_map_kind
        return "nd"

    @property
    def physical_format(self):
        from cannbotdsl.tensor import _physical_format_for_map

        return _physical_format_for_map(self.layout_map_kind)

    @property
    def data_format(self):
        return self.physical_format


class Channel:
    """A depth-N slot pool with independent advancing cursors.

    ``produce()`` selects ``slots[write_cursor]`` and advances write_cursor;
    ``consume()`` does the same for read_cursor. Both start at zero whenever
    the declaration executes. Views apply to the selected Tensor.
    """

    def __init_subclass__(cls, **kwargs):
        del cls, kwargs
        raise TypeError("Channel is a sealed CANNBotDSL resource type")

    def __init__(self, mem_loc, shape=None, dtype=None, *, depth,
                 capacity=None,
                 kind=ChannelKind.SameCore,
                 stride=None, data_format=None, n1_pad=0):
        trace_state = _current_onchip_trace()
        if mem_loc not in _CUBE_MEM_LOCS and mem_loc != MemLoc.UB:
            raise ValueError(f"unsupported mem_loc for channel: {mem_loc!r}")
        if not is_exact_instance(depth, int):
            raise TypeError("Channel depth must be a positive compile-time Python int")
        if depth < 1:
            raise ValueError(f"Channel depth must be >= 1, got {depth}")
        is_cross_core = (kind == ChannelKind.CrossCore)
        if is_cross_core and depth > 8:
            raise ValueError(
                f"cross-core Channel depth must be <= 8, got {depth} "
                "(per-Channel select-chain policy; the allocation epoch has "
                "16 logical sync ids)"
            )
        self._kind = kind
        self._depth = depth
        self._mem_loc = mem_loc
        trace_state.use_automatic_space(mem_loc, "Channel")
        self._resource = cannir.ChannelResourceOp.build_generic(
            results=[ir.NoneType.get()], operands=[]
        ).results[0]
        self._init_planned_slots(shape, dtype, capacity, stride, data_format, n1_pad)

    def _bind_slots(self, bound):
        raw_op = cannir.MakeChannelOp.build_generic(
            operands=bound,
            attributes={"cannir.channel.kind": ir.IntegerAttr.get(
                ir.IntegerType.get_signless(32), int(self._kind))},
        )
        return raw_op.results[0]

    def _init_planned_slots(self, shape, dtype, capacity, stride,
                            data_format, n1_pad):
        """Allocate depth independent Buffers and bind them as channel slots.

        Each slot is one ``Buffer`` allocation over the static capacity; the
        declared (possibly dynamic) shape stays a selection-time view concept,
        so slot bindings keep the capacity-typed storage roots exactly as the
        legacy multi-result path produced them.
        """
        from cannbotdsl.buffer import Buffer
        from cannbotdsl.tensor import make_tiler, reinterpret

        shape, capacity, has_dynamic_shape = _normalize_shape_capacity(
            shape, capacity, owner="Buffer"
        )
        self._buffers = tuple(
            Buffer(
                self._mem_loc,
                capacity,
                dtype,
                stride=stride,
                data_format=data_format,
                n1_pad=n1_pad,
            )
            for _ in range(self._depth)
        )
        self._slot_storage_values = tuple(
            unwrap_operand(buf) for buf in self._buffers
        )

        bound = []
        for index, buf in enumerate(self._buffers):
            value = unwrap_operand(buf)
            slot = cannir.ChannelSlotOp.build_generic(
                results=[value.type], operands=[value, self._resource],
                attributes={"slot": ir.IntegerAttr.get(
                    ir.IntegerType.get_signless(64), index)},
            )
            bound.append(unwrap_operand(slot.results[0]))
        root = self._bind_slots(bound)

        declared = self._buffers[0]
        self._dtype = declared.dtype
        self._shape = shape
        self._capacity = capacity
        self._has_dynamic_shape = has_dynamic_shape
        self._stride = declared.stride
        self._data_format = declared.data_format
        self._n1_pad = n1_pad
        self._root_ir_value = root
        self._layout_ir_value = root
        self._dynamic_tiler = None
        if has_dynamic_shape or shape != capacity:
            self._dynamic_tiler = make_tiler(shape)
            view = reinterpret(
                Tensor._from_ir(self._slot_storage_values[0]),
                shape=self._dynamic_tiler,
                stride=self._stride,
            )
            self._layout_ir_value = unwrap_operand(view)
            self._layout_ir_value.owner.attributes[
                "cannir.channel.declared_layout"
            ] = ir.UnitAttr.get()
        self._ir_value = root

    def _select(self, operation):
        from cannbotdsl.lang.vf import _current_vf_mode
        if _current_vf_mode() is not None:
            raise ValueError("Channel cursors must be advanced outside VF regions; pass a selected Tensor into the VF")
        slot = Tensor._from_ir(operation(self._root_ir_value).res)
        if self._dynamic_tiler is not None:
            from cannbotdsl.tensor import reinterpret

            slot = reinterpret(slot, shape=self._dynamic_tiler, stride=self._stride)
            unwrap_operand(slot).owner.attributes["cannir.declared_slot_layout"] = ir.UnitAttr.get()
        return slot

    def produce(self) -> Tensor:
        """Select the write slot, then advance the independent write cursor.

        The returned Tensor is an ordinary alias, not a snapshot or a lease.
        Selection neither accesses storage nor waits for another operation.
        """
        return self._select(cannir.ChannelProduceOp)

    def consume(self) -> Tensor:
        """Select the read slot, then advance the independent read cursor.

        No pairing or FIFO full/empty checks are performed. Both selected
        Tensors may be read, written, or updated in place.
        """
        return self._select(cannir.ChannelConsumeOp)

    @property
    def dtype(self):
        memref_ty = cannir.TensorType(self._ir_value.type.element)
        from cannbotdsl.core.contracts.elements import dtype_for_storage_mlir_type

        return dtype_for_storage_mlir_type(
            cannir.PointerType(memref_ty.pointer).dtype
        )

    @property
    def layout(self):
        return cannir.extract_layout(self._layout_ir_value)

    @property
    def physical_layout(self):
        return cannir.extract_physical_layout(self._layout_ir_value)

    @property
    def shape(self):
        return self.layout.shape

    @property
    def stride(self):
        return self.layout.stride

    @property
    def physical_shape(self):
        return self.physical_layout.shape

    @property
    def physical_stride(self):
        return self.physical_layout.stride

    @property
    def memloc(self):
        return cannir.PointerType(cannir.TensorType(self._ir_value.type.element).pointer).memloc

    @property
    def layout_map_kind(self):
        from cannbotdsl.tensor import LayoutMapKind

        return LayoutMapKind(cannir.TensorType(self._ir_value.type.element).layout_map_kind)

    @property
    def logical_format(self):
        _ = self.layout_map_kind
        return "nd"

    @property
    def physical_format(self):
        from cannbotdsl.tensor import _physical_format_for_map

        return _physical_format_for_map(self.layout_map_kind)

    @property
    def data_format(self):
        return self.physical_format

    @property
    def depth(self):
        return self._ir_value.type.depth

    @property
    def is_cross_core(self):
        return self._ir_value.type.kind == int(ChannelKind.CrossCore)

    def __repr__(self):
        return (f"Channel({self.memloc}, {self.shape}, {self.dtype}, "
                f"depth={self.depth})")


def make_channel(views, *, dtype=None, kind=None):
    """Create a Channel whose slots are unbound static on-chip space views.

    Slots may have different origins, but must have identical Tensor types.
    Bound resources cannot be transferred into a Channel.
    """
    from cannbotdsl.buffer import (
        _ensure_static_view,
        _find_space_root,
        _has_bound_resource,
    )

    if kind is None:
        kind = ChannelKind.SameCore
    if kind not in (ChannelKind.SameCore, ChannelKind.CrossCore):
        raise ValueError("make_channel kind must be SameCore or CrossCore")
    if not isinstance(views, (list, tuple)) or not views:
        raise ValueError("make_channel requires a non-empty list or tuple of views")
    if kind == ChannelKind.CrossCore and len(views) > 8:
        raise ValueError("cross-core Channel depth must be <= 8")
    slots = []
    for view in views:
        if not isinstance(view, Tensor) or _find_space_root(view) is None:
            raise ValueError("make_channel requires views derived from an on-chip space view()")
        if view.memloc not in _CUBE_MEM_LOCS and view.memloc != MemLoc.UB:
            raise ValueError(f"unsupported mem_loc for channel: {view.memloc!r}")
        if _has_bound_resource(view):
            raise ValueError("make_channel requires unbound views; Buffer ownership transfer is not supported")
        if dtype is not None:
            from cannbotdsl.core.contracts.elements import normalize_storage_dtype

            target = normalize_storage_dtype(dtype)
            if view.dtype != target:
                view = view.view(dtype=target)
        _ensure_static_view(view)
        if slots and unwrap_operand(view).type != unwrap_operand(slots[0]).type:
            raise ValueError("make_channel slots must have identical dtype, shape, stride and layout")
        slots.append(view)

    _current_onchip_trace()
    ch = object.__new__(Channel)
    ch._kind = kind
    ch._depth = len(slots)
    ch._mem_loc = slots[0].memloc
    ch._dtype = slots[0].dtype
    ch._shape = ch._capacity = slots[0].shape
    ch._stride = slots[0].stride
    ch._has_dynamic_shape = False
    ch._data_format = slots[0].data_format
    ch._n1_pad = 0
    ch._resource = cannir.ChannelResourceOp.build_generic(
        results=[ir.NoneType.get()], operands=[]
    ).results[0]
    ch._buffers = tuple(slots)
    ch._slot_storage_values = tuple(unwrap_operand(slot) for slot in slots)
    bound = []
    for index, slot in enumerate(slots):
        marker = cannir.ChannelSlotOp.build_generic(
            results=[unwrap_operand(slot).type], operands=[unwrap_operand(slot), ch._resource],
            attributes={"slot": ir.IntegerAttr.get(ir.IntegerType.get_signless(64), index),
                        "cannir.buffer.explicit_binding": ir.UnitAttr.get()},
        ).results[0]
        bound.append(unwrap_operand(marker))
    op = cannir.MakeChannelOp.build_generic(operands=bound, attributes={
        "cannir.channel.kind": ir.IntegerAttr.get(ir.IntegerType.get_signless(32), int(kind))})
    ch._ir_value = ch._root_ir_value = ch._layout_ir_value = op.results[0]
    ch._dynamic_tiler = None
    return ch
