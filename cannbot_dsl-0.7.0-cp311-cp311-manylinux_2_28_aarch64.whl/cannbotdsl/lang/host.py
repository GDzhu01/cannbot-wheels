# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Host entry points: bind, compile, cache, execute, and release artifacts."""

from typing import Any, Callable, Optional

from cannbotdsl.core.contracts.surface import (
    SurfaceSignature,
    class_local_namespace,
)
from cannbotdsl.core.frontend.call_context import validate_call


class _BoundHostMethod:
    """Per-instance view of a ``@host`` method; avoids mutating a shared descriptor."""

    __slots__ = ("_host_function", "_instance", "_surface")

    def __init__(
        self,
        host_function: "HostFunction",
        instance,
        surface: SurfaceSignature,
    ):
        self._host_function = host_function
        self._instance = instance
        self._surface = surface

    def __call__(self, *args, **kwargs):
        return self._host_function._invoke(self._instance, self._surface, args, kwargs)

    @property
    def __signature__(self):
        return self._surface.public_signature


class HostFunction:
    """Callable descriptor produced by :func:`host` for Python entry points."""

    def __init__(self, fn: Callable[..., Any]):
        self.fn = fn
        self.__name__ = getattr(fn, "__name__", type(self).__name__)
        self.__qualname__ = getattr(fn, "__qualname__", self.__name__)
        self.__doc__ = getattr(fn, "__doc__", None)
        self.__wrapped__ = fn
        self._surface = SurfaceSignature.from_callable(fn)
        self.__signature__ = self._surface.signature

    def __set_name__(self, owner, name):
        del name
        self._surface = self._surface.with_local_namespace(class_local_namespace(owner))

    def __get__(self, instance, owner):
        if instance is None:
            return self
        surface = self._surface.bind_receiver(label=f"bound @host entry {owner.__qualname__}.{self.__name__}")
        return _BoundHostMethod(self, instance, surface)

    def __call__(self, *args, **kwargs):
        return self._invoke(None, self._surface, args, kwargs)

    def _invoke(
        self,
        bound_instance: Optional[Any],
        surface: SurfaceSignature,
        args: tuple,
        kwargs: dict,
    ) -> Any:
        from cannbotdsl.core.compiler.builder import compile_to_artifact
        from cannbotdsl.core.compiler.jit_executor import (
            _build_provider_callable_for_jit,
            _execute_bound_call,
        )
        from cannbotdsl.core.utils.env import env

        call_args = (bound_instance, *args) if bound_instance is not None else args

        validate_call("host", self.fn, self)

        surface.validate_void_return_annotation(path=self.__qualname__)
        from cannbotdsl.core.contracts.binding import bind_jit_call

        bound_call = bind_jit_call(
            self.fn,
            call_args,
            kwargs,
            surface_signature=surface,
        )
        artifact = compile_to_artifact(
            self.fn,
            call_args,
            kwargs,
            bound_call=bound_call,
        )

        # CANNBOTDSL_PIPE_STAGE stops JIT before constructing or invoking a
        # ProviderCallable.  Retire any private compile-stage artifact here,
        # because no ProviderCallable will otherwise receive its ownership.
        stage = env().pipe_stage
        if stage in {"transform", "translate", "compile"}:
            if artifact.owns_so and artifact.so_path:
                from cannbotdsl.core.compiler.function import (
                    _remove_owned_artifact,
                )

                _remove_owned_artifact(artifact.so_path)
            return

        program = _build_provider_callable_for_jit(
            artifact,
            artifact.debug_plans,
        )
        try:
            _execute_bound_call(program, bound_call)
        finally:
            program.close()


def host(fn=None):
    def decorator(fn):
        return HostFunction(fn)

    if fn is None:
        return decorator
    return decorator(fn)
