# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Inline DSL helpers that inherit their caller's host/device domain."""

from typing import Any, Callable, Optional

from cannbotdsl.core.contracts.surface import (
    SurfaceSignature,
    class_local_namespace,
)
from cannbotdsl.core.frontend.compiler import compile_function
from cannbotdsl.core.frontend.call_context import (
    call_scope, current_call_context, validate_call,
)


class _BoundJitMethod:
    """Per-instance view of a ``@jit`` method; avoids mutating a shared descriptor."""

    __slots__ = ("_jit_function", "_instance", "_surface")

    def __init__(
        self,
        jit_function: "JitFunction",
        instance,
        surface: SurfaceSignature,
    ):
        self._jit_function = jit_function
        self._instance = instance
        self._surface = surface

    def __call__(self, *args, **kwargs):
        return self._jit_function._invoke(self._instance, self._surface, args, kwargs)

    @property
    def __signature__(self):
        return self._surface.public_signature


class JitFunction:
    """Callable descriptor produced by :func:`jit` for staged functions."""

    def __init__(self, fn: Callable[..., Any]):
        self.fn = fn
        self.__name__ = getattr(fn, "__name__", type(self).__name__)
        self.__qualname__ = getattr(fn, "__qualname__", self.__name__)
        self.__doc__ = getattr(fn, "__doc__", None)
        self.__wrapped__ = fn
        self._surface = SurfaceSignature.from_callable(fn)
        self.__signature__ = self._surface.signature

    def __set_name__(self, owner, name):
        del name
        self._surface = self._surface.with_local_namespace(class_local_namespace(owner))

    def __get__(self, instance, owner):
        if instance is None:
            return self
        surface = self._surface.bind_receiver(label=f"bound @jit entry {owner.__qualname__}.{self.__name__}")
        return _BoundJitMethod(self, instance, surface)

    def __call__(self, *args, **kwargs):
        return self._invoke(None, self._surface, args, kwargs)

    def _invoke(
        self,
        bound_instance: Optional[Any],
        surface: SurfaceSignature,
        args: tuple,
        kwargs: dict,
    ) -> Any:
        validate_call("jit", self.fn, self)
        context = current_call_context()
        call_args = (bound_instance, *args) if bound_instance is not None else args
        with call_scope("jit", context.domain, self.fn):
            ir_builder = compile_function(self.fn).function
            return ir_builder(*call_args, **kwargs)


def jit(fn=None):
    def decorator(fn):
        return JitFunction(fn)

    if fn is None:
        return decorator
    return decorator(fn)
