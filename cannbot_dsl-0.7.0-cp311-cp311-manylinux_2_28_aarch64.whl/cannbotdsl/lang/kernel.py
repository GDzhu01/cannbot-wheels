# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Device entry points, launched directly from an ``@host`` source body.

Functions, bound methods, and class entries share one launch validator. Kernels
must return None; reusable inline logic belongs in ``@jit`` helpers.

``@kernel`` on a class
----------------------

When ``@kernel`` decorates a class, the resulting object is a launch handle
factory. ``op = C(*ctor_args, **ctor_kwargs)`` does *not* execute ``__init__``
in the host scope -- it only records the ctor arguments. Each call of the form
``op[block_dim].method(*args)`` (or ``op.method(*args)`` with default
``block_dim=1``, or ``op[block_dim](*args)`` ≡ ``op[block_dim].__call__(*args)``)
synthesises a kernel function whose body is

    inst = cls.__new__(cls)
    cls.__init__(inst, *ctor_args, **ctor_kwargs)
    return cls.<method>(inst, *args, **kwargs)

so all class methods and attributes live exclusively inside the kernel body
trace (each method gets its own device function). Implications:

* ``__init__`` may emit IR ops (for example, Channel construction) -- they land in the
  device function entry block, shared across all entry methods.
* Ctor arguments may be ordinary Python objects and containers. Passing an
  ``ir.Value`` (a live SSA value from the enclosing trace) raises ``TypeError``
  because it cannot cross into a separately traced device function; pass
  runtime values via the entry method. The recursive host-side check covers
  standard containers, normal instance dictionaries, real slots, cycles, and
  shared references as an early diagnostic; it does not prove arbitrary opaque
  objects are free of hidden SSA values.
* ``__init__`` is *not* run through frontend lowering: Python ``for`` / ``if``
  there expand under Python semantics during trace, which matches construction
  intent (for example, constructing several Channel members in a loop). Entry
  method bodies are still preprocessed.
* Eligible entries are instance methods (``inspect.isfunction`` + a first
  positional receiver), inherited via MRO, plus ``__call__``. Receiver names
  are immaterial. ``staticmethod`` / ``classmethod`` / other dunder methods
  are excluded.
* Same ``op`` invoking the same method twice reuses the Python wrapper, but
  retraces a candidate device function on every syntax call. Identical
  candidates are committed once by the content registry.
* ``op.<non-entry attr>`` raises ``AttributeError`` (host scope has no live
  ``__init__``); the message lists available entries.
"""

import inspect
from typing import Union

from cannbotdsl.lang.launch import parse_launch_config
from cannbotdsl.core.compiler.kernel_materialize import _emit_kernel_call
from cannbotdsl.core.contracts.surface import SurfaceSignature, class_local_namespace
from cannbotdsl.core.frontend.call_context import validate_call


class _BoundKernelLauncher:
    """Per-instance receiver and launch configuration for a ``@kernel`` method."""

    __slots__ = ("_launcher", "_instance", "_block_dim", "_thread_dim", "_dyn_ub_buf", "_surface")

    def __init__(self, launcher, instance, surface):
        self._launcher = launcher
        self._instance = instance
        self._surface = surface
        self._block_dim = None
        self._thread_dim = None
        self._dyn_ub_buf = 0

    @property
    def __signature__(self):
        return self._surface.public_signature

    def __call__(self, *args, **kwargs):
        return self._launcher._invoke(
            self, self._surface, (self._instance, *args), kwargs,
        )

    def __getitem__(self, launch_config: Union[int, tuple]):
        self._block_dim, self._thread_dim, self._dyn_ub_buf = parse_launch_config(launch_config)
        return self


class KernelLauncher:
    """Trace-time facade for a device entry and its launch configuration."""

    def __init__(self, fn, *, profile=None, _surface_signature: SurfaceSignature | None = None):
        self.fn = fn
        self.profile = profile
        self._block_dim = None
        self._thread_dim = None
        self._dyn_ub_buf = 0
        self._surface = SurfaceSignature.from_callable(fn) if _surface_signature is None else _surface_signature
        self.__signature__ = self._surface.signature
        if profile is not None:
            from cannbotdsl.core.profiling import ProfileSpec

            if not isinstance(profile, ProfileSpec):
                raise TypeError("kernel(profile=...) requires ProfileSpec")
            profile._validate_signature(self._surface.signature)

    def __set_name__(self, owner, name):
        del name
        self._surface = self._surface.with_local_namespace(class_local_namespace(owner))

    def _invoke(self, launch, surface, args, kwargs, *, call_target=None):
        block_dim = launch._block_dim if launch._block_dim is not None else 1
        thread_dim, dyn_ub_buf = launch._thread_dim, launch._dyn_ub_buf
        # Consume launch configuration even when validation or tracing fails.
        launch._block_dim, launch._thread_dim, launch._dyn_ub_buf = None, None, 0
        validate_call("kernel", self.fn, launch if call_target is None else call_target)
        _emit_kernel_call(
            self.fn, args, kwargs, block_dim=block_dim, thread_dim=thread_dim,
            dyn_ub_buf=dyn_ub_buf, surface_signature=surface, profile=self.profile,
        )
        return None

    def __call__(self, *args, **kwargs):
        return self._invoke(self, self._surface, args, kwargs)

    def __get__(self, instance, owner):
        if instance is None:
            return self
        surface = self._surface.bind_receiver(label=f"bound @kernel entry {owner.__qualname__}.{self.fn.__name__}")
        return _BoundKernelLauncher(self, instance, surface)

    def __getitem__(self, launch_config: Union[int, tuple]):
        self._block_dim, self._thread_dim, self._dyn_ub_buf = parse_launch_config(launch_config)
        return self


def kernel(fn=None, *, profile=None):
    def decorator(target):
        if inspect.isclass(target):
            from cannbotdsl.lang.kernel_class import _KernelClassLauncher
            return _KernelClassLauncher(target, profile=profile)
        return KernelLauncher(target, profile=profile)

    if fn is None:
        return decorator
    return decorator(fn)
