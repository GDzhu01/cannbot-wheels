# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Host-side launch helpers: raw stream acquisition and x86 golden buffers."""

from __future__ import annotations

import ctypes


def current_raw_stream(device_id: int = 0) -> int:
    """Current torch_npu raw stream handle (same accessor the debug bridge uses)."""
    import torch_npu

    accessor = getattr(getattr(torch_npu, "_C", None), "_npu_getCurrentRawStream", None)
    if not callable(accessor):
        raise RuntimeError("torch_npu does not expose _npu_getCurrentRawStream")
    return int(accessor(device_id))


def pack_struct_bytes(spec, values: dict) -> bytes:
    """Pack args-struct bytes for the legacy single-pointer launch ABI."""
    raw = bytearray()
    for fname, ann in spec.fields:
        from cannbotdsl.aicpu.types import GmFieldType

        if isinstance(ann, GmFieldType):
            ct = ctypes.c_uint64
        else:
            ct = ann.ctypes_type
        raw.extend(ct(int(values.get(fname, 0))))
    return bytes(raw)


class X86Buffer:
    """Host buffer handed to the x86 cross-check build in place of a GM view."""

    def __init__(self, values, elem):
        import numpy as np

        arr = np.asarray(values, dtype=np.int64)
        self.data = (elem.ctypes_type * arr.size)(*arr.tolist())
        self.np = arr
