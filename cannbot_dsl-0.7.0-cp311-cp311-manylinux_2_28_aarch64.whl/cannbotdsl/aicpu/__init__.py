# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""AICPU kernel frontend (Phase-1, source-to-source trace).

Python tiling function -> portable C++ body -> ``.aicpu`` device kernel +
``.asc`` host shim -> bisheng -> ``.so`` -> ctypes launch via ``<<<>>>``.
The same traced program runs on the host for golden cross-checks.
"""

from cannbotdsl.aicpu.interp import AicpuTraceError
from cannbotdsl.aicpu.kernel import aicpu_kernel
from cannbotdsl.aicpu.types import GmIn, GmOut, I32, I64, U32, U64
from cannbotdsl.aicpu.launcher import X86Buffer, current_raw_stream, pack_struct_bytes

__all__ = [
    "aicpu_kernel",
    "AicpuTraceError",
    "GmIn",
    "GmOut",
    "I32",
    "I64",
    "U32",
    "U64",
    "X86Buffer",
    "current_raw_stream",
    "pack_struct_bytes",
]
