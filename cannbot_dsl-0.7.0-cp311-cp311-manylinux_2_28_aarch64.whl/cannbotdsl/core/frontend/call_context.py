# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""DSL call roles, inherited execution domains, and source call provenance.

An insertion point does not authorize a DSL call. Only the compiler opens a
host/device scope, and only a call emitted from the host source can launch a
kernel. Call sites name the actual callable, so a Python forwarding function
cannot inherit its caller's launch permission.
"""

from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
import inspect
from typing import Callable, Literal


@dataclass(frozen=True)
class CallContext:
    role: Literal["host", "kernel", "jit"]
    domain: Literal["host", "device"]
    function: Callable


@dataclass(frozen=True)
class CallSite:
    function: Callable
    target: object
    filename: str
    line: int
    column: int


_CONTEXT: ContextVar[CallContext | None] = ContextVar("cannbotdsl_call_context", default=None)
_SITE: ContextVar[CallSite | None] = ContextVar("cannbotdsl_call_site", default=None)


def current_call_context() -> CallContext | None:
    return _CONTEXT.get()


def in_device_domain() -> bool:
    context = _CONTEXT.get()
    return context is not None and context.domain == "device"


@contextmanager
def call_scope(role, domain, function):
    token = _CONTEXT.set(CallContext(role, domain, function))
    site_token = _SITE.set(None)
    try:
        yield
    finally:
        _SITE.reset(site_token)
        _CONTEXT.reset(token)


def dispatch_call(source, filename, line, column, target, /, *args, **kwargs):
    token = _SITE.set(CallSite(source, target, filename, line, column))
    try:
        return target(*args, **kwargs)
    finally:
        _SITE.reset(token)


def validate_call(role, function, target):
    """Reject an invalid boundary before binding or materializing any IR."""
    context = _CONTEXT.get()
    site = _SITE.get()
    if role == "host" and context is None:
        return
    if role == "jit" and context is not None:
        return
    is_host_kernel_call = role == "kernel" and context is not None and context.role == "host"
    if is_host_kernel_call:
        is_matching_site = site is not None and site.function is context.function and site.target is target
        if is_matching_site:
            # Claim this source call once. Python hooks invoked while binding or
            # materializing its arguments must not inherit launch authorization,
            # including hooks that happen to call the very same kernel handle.
            _SITE.set(None)
            return

    caller = "Python"
    if context is not None:
        caller = f"@{context.role} {context.function.__qualname__}"
    if site is not None and site.target is target:
        location = f"{site.filename}:{site.line}:{site.column + 1}"
    else:
        # Only diagnostics inspect frames. Ordinary Python bodies are not
        # lowered, so their actual source location must come from the stack.
        frame = inspect.currentframe()
        try:
            while frame is not None:
                module = frame.f_globals.get("__name__", "")
                if not module.startswith("cannbotdsl."):
                    location = f"{frame.f_code.co_filename}:{frame.f_lineno}"
                    caller = f"Python {frame.f_code.co_qualname}" + (
                        f" (within {caller})" if context is not None else ""
                    )
                    break
                frame = frame.f_back
            else:
                location = "<unknown>"
        finally:
            del frame

    callee = f"@{role} {getattr(function, '__qualname__', type(function).__name__)}"
    hints = {
        "host": "Call @host only from ordinary Python outside the DSL; use @jit for shared helper logic.",
        "kernel": "Launch @kernel directly in the @host source body; move launches out of @jit and Python helpers.",
        "jit": (
            "@jit is an inline helper. Migrate the Python entry to @host, or call this helper from @host/@kernel/@jit."
        ),
    }
    raise RuntimeError(f"Illegal DSL call: {caller} -> {callee} at {location}. {hints[role]}")
