# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Lazy access to the DSL's built-in Native binary runtime."""
from functools import wraps


def _runtime():
    from cannbotdsl.aot import runtime
    return runtime


def enabled():
    return _runtime().enabled()


def lookup(*args, **kwargs):
    return _runtime().lookup(*args, **kwargs)


def event(*args, **kwargs):
    return _runtime().event(*args, **kwargs)


def observe(function):
    wrapped = None

    @wraps(function)
    def dispatch(*args, **kwargs):
        nonlocal wrapped
        if wrapped is None:
            wrapped = _runtime().observe(function)
        return wrapped(*args, **kwargs)

    return dispatch
