# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Persist profiling declarations on launch sites, independent of device deduplication."""

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir


def launch_profile(fn, spec, call_plan, argument_access=()):
    entries = {}
    offset = 0
    for entry in call_plan._entries:
        entries[entry.name] = (offset, entry._types)
        offset += len(entry._types)
    indices, roles = [], []
    if spec is None:
        from cannbotdsl.core.profiling import ProfileSpec

        inputs, outputs, inouts = [], [], []
        for name, (start, types) in entries.items():
            combined = 0
            for index, type_ in enumerate(types, start):
                if not cannir.TensorType.isinstance(type_):
                    continue
                mask = argument_access[index]
                combined |= mask
                for role, bit in ((0, 1), (1, 2)):
                    if mask & bit:
                        indices.append(index)
                        roles.append(role)
            if combined == 1:
                inputs.append(name)
            elif combined == 2:
                outputs.append(name)
            elif combined == 3:
                inouts.append(name)
        spec = ProfileSpec(
            name=fn.__name__, op_type=fn.__name__, inputs=tuple(inputs), outputs=tuple(outputs), inouts=tuple(inouts)
        )
    else:
        for names, role in ((spec.inputs + spec.inouts, 0), (spec.outputs + spec.inouts, 1)):
            for name in names:
                start, types = entries[name]
                if not types or not all(cannir.TensorType.isinstance(t) for t in types):
                    raise TypeError(
                        f"ProfileSpec parameter {name!r} must lower to Tensor arguments; "
                        "scalar, StructRef, and dynamic TensorList descriptors cannot be reported as tensors"
                    )
                indices.extend(range(start, start + len(types)))
                roles.extend([role] * len(types))
    return ir.DictAttr.get(
        {
            "name": ir.StringAttr.get(spec.name or fn.__name__),
            "op_type": ir.StringAttr.get((spec.op_type if spec else None) or fn.__name__),
            "indices": ir.DenseI64ArrayAttr.get(indices),
            "roles": ir.DenseI64ArrayAttr.get(roles),
        }
    )
