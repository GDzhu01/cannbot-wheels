# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Cycle-safe validation for values captured by a device-function trace."""

from __future__ import annotations

import inspect
import types

from cannbotdsl.core.diag.diagnostics import (
    ST101_UNSUPPORTED_DYNAMIC_ARGUMENT,
    CANNBotTypeError,
)
from cannbotdsl.core.utils.type_checks import is_exact_instance, is_exact_instance_of


def _dict_path(path: str, key: object) -> str:
    if is_exact_instance(key, str):
        escaped = key.replace("\\", "\\\\").replace('"', '\\"')
        return f'{path}["{escaped}"]'
    return f"{path}[{key!r}]"


def find_active_ssa_path(
    value: object,
    *,
    path: str,
    visited: set[int] | None = None,
) -> str | None:
    """Return the first reachable live SSA path without invoking user code."""

    import cannbotdsl._mlir.ir as ir

    if isinstance(value, ir.Value):
        return path

    # Framework composition objects such as Tensor, Buffer, Layout and Channel
    # retain their carrier outside ``__dict__`` on some implementations.
    try:
        from cannbotdsl.core.ir_transport import unwrap_operand

        carrier = unwrap_operand(value)
    except TypeError:
        carrier = None
    if isinstance(carrier, ir.Value):
        return path

    value_type = type(value)
    if value is None or value_type in {
        bool,
        int,
        float,
        complex,
        str,
        bytes,
    }:
        return None
    if inspect.isclass(value) or inspect.isroutine(value) or inspect.ismodule(value):
        return None

    if visited is None:
        visited = set()
    identity = id(value)
    if identity in visited:
        return None
    visited.add(identity)

    if value_type is dict:
        for key, item in value.items():
            found = find_active_ssa_path(
                key,
                path=f"{_dict_path(path, key)}.<key>",
                visited=visited,
            )
            if found is not None:
                return found
            found = find_active_ssa_path(
                item,
                path=_dict_path(path, key),
                visited=visited,
            )
            if found is not None:
                return found
        return None
    if value_type in {tuple, list}:
        for index, item in enumerate(value):
            found = find_active_ssa_path(
                item,
                path=f"{path}[{index}]",
                visited=visited,
            )
            if found is not None:
                return found
        return None
    if value_type in {set, frozenset}:
        for index, item in enumerate(value):
            found = find_active_ssa_path(
                item,
                path=f"{path}[{index}]",
                visited=visited,
            )
            if found is not None:
                return found
        return None

    attributes = None
    for owner in type.__getattribute__(value_type, "__mro__"):
        descriptor = type.__getattribute__(owner, "__dict__").get("__dict__")
        if descriptor is None:
            continue
        if is_exact_instance_of(descriptor, (types.GetSetDescriptorType, types.MemberDescriptorType)):
            try:
                attributes = descriptor.__get__(value, value_type)
            except AttributeError:
                pass
        break
    if is_exact_instance(attributes, dict):
        for name, item in attributes.items():
            found = find_active_ssa_path(
                item,
                path=f"{path}.{name}",
                visited=visited,
            )
            if found is not None:
                return found

    for owner in type.__getattribute__(value_type, "__mro__"):
        namespace = type.__getattribute__(owner, "__dict__")
        slots = namespace.get("__slots__", ())
        if is_exact_instance(slots, str):
            slots = (slots,)
        elif not is_exact_instance_of(slots, (tuple, list)):
            continue
        for original_name in slots:
            if not is_exact_instance(original_name, str) or original_name in {
                "__dict__",
                "__weakref__",
            }:
                continue
            name = original_name
            if name.startswith("__") and not name.endswith("__"):
                owner_name = type.__getattribute__(owner, "__name__")
                name = f"_{owner_name.lstrip('_')}{name}"
            descriptor = namespace.get(name)
            if not is_exact_instance(descriptor, types.MemberDescriptorType):
                continue
            try:
                item = descriptor.__get__(value, value_type)
            except AttributeError:
                continue
            found = find_active_ssa_path(
                item,
                path=f"{path}.{original_name}",
                visited=visited,
            )
            if found is not None:
                return found
    return None


def validate_no_active_ssa(value: object, *, path: str, subject: str) -> None:
    found = find_active_ssa_path(value, path=path)
    if found is None:
        return
    raise CANNBotTypeError(
        ST101_UNSUPPORTED_DYNAMIC_ARGUMENT,
        f"{subject} contains an active SSA value at {found}; it cannot cross a separate device-function boundary.",
        phase="staging",
        path=found,
        hint="Pass the value through a supported runtime parameter or keep the helper inline.",
    )


__all__: list[str] = []
