# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Exact type predicates for checks that intentionally reject subclasses."""

from __future__ import annotations

from typing import TypeVar

_T = TypeVar("_T")


def is_exact_instance(value: object, expected_type: type[_T]) -> bool:
    """Return whether *value* is an instance of exactly *expected_type*."""
    return isinstance(value, expected_type) and value.__class__ is expected_type


def is_exact_instance_of(value: object, expected_types: tuple[type[object], ...]) -> bool:
    """Return whether *value* has exactly one of *expected_types*."""
    return isinstance(value, expected_types) and value.__class__ in expected_types
