# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""CANNBotDSL implementation of ``indexer_prologue_k``.

The operator executes the following pipeline and updates ``k_cache`` in place::

    latent -- BF16 GEMM --> projected -- RMSNorm --> tail RoPE
           --> block-32 MXFP4 packing --> indexed uint8 k_cache

Projection and fused post-processing/cache scatter use two kernels on the
same NPU stream, so the projected intermediate does not require a host sync.
"""

import torch

from cannbotdsl import MemLoc, Tensor, TensorSpec, const_expr, dtypes
from cannbotdsl.buffer import Buffer
from cannbotdsl.channel import Channel
from cannbotdsl.lang.jit import jit
from cannbotdsl.lang.kernel import kernel
from cannbotdsl.lang.vf import vf
from cannbotdsl.ops import reg as rr
from cannbotdsl.ops import scalar
from cannbotdsl.ops.arch import get_block_idx, get_block_num
from cannbotdsl.ops.matmul import matmul
from cannbotdsl.ops.memcpy import make_copy_engine, mem_copy
from cannbotdsl.ops.sync import vec_sync_all
from cannbotdsl.tensor import tile_view

__all__ = [
    "IndexerPrologueKPostprocess",
    "IndexerPrologueKScatter",
    "indexer_prologue_k",
]


VL = 64
FP4_GROUP_SIZE = 32
FP4_MAX = 6.0
FP32_EXP_SHIFT = 23
FP32_MANTISSA_MASK = 0x7FFFFF
FP32_EXP_MASK = 0xFF
DEFAULT_AIC_NUM = 32
DEFAULT_AIV_NUM = 64
BASE_M = 16
BASE_N = 64
BASE_K = 128


def _ceil_div(value, divisor):
    return (value + divisor - 1) // divisor


class _ProjectionKernel:
    """BF16 ND ``[M,K]`` x NZ ``[N,K].T`` with FP32 accumulation."""

    def __init__(self, m: int, n: int, k: int):
        self.m = int(m)
        self.n = int(n)
        self.k = int(k)
        # Raw FRACTAL_NZ GM->L1 copies must end on physical 16x16 fractal
        # boundaries.  Keep the wide fast path for aligned model shapes and
        # fall back to one fractal along a non-aligned axis.
        self.base_n = BASE_N if self.n % BASE_N == 0 else 16
        self.base_k = BASE_K if self.k % BASE_K == 0 else 16
        self.m_tiles = _ceil_div(self.m, BASE_M)
        self.n_tiles = _ceil_div(self.n, self.base_n)
        self.k_tiles = _ceil_div(self.k, self.base_k)
        self.total_tiles = self.m_tiles * self.n_tiles
        self.block_num = min(DEFAULT_AIC_NUM, self.total_tiles)

    @kernel
    def kernel(self, gm_latent: Tensor, gm_weight: Tensor, gm_projected: Tensor):
        base_n = self.base_n
        base_k = self.base_k
        l1_a = Channel(MemLoc.L1, (BASE_M, base_k), dtypes.bfloat16, depth=2)
        l1_b = Channel(
            MemLoc.L1,
            (base_n, base_k),
            dtypes.bfloat16,
            depth=2,
            data_format="nz",
        )
        l0a = Channel(MemLoc.L0A, (BASE_M, base_k), dtypes.bfloat16, depth=2)
        l0b = Channel(MemLoc.L0B, (base_n, base_k), dtypes.bfloat16, depth=2)
        l0c = Channel(MemLoc.L0C, (BASE_M, base_n), dtypes.float32, depth=1)
        nd2nz = make_copy_engine(
            format_transform="nd2nz", dtype=dtypes.bfloat16, pad_value=0.0
        )

        block_idx = get_block_idx()
        block_num = get_block_num()
        for tile_idx in range(block_idx, self.total_tiles, block_num):
            m_idx = tile_idx // self.n_tiles
            n_idx = tile_idx % self.n_tiles
            for k_idx in range(self.k_tiles):
                mem_copy(
                    l1_a,
                    tile_view(gm_latent, (BASE_M, base_k), (m_idx, k_idx)),
                    engine=nd2nz,
                )
                mem_copy(
                    l1_b,
                    tile_view(gm_weight, (base_n, base_k), (n_idx, k_idx)),
                )
                mem_copy(l0a, l1_a)
                mem_copy(l0b, l1_b)
                matmul(l0c, l0a, l0b, init=(k_idx == 0))

            mem_copy(
                tile_view(gm_projected, (BASE_M, base_n), (m_idx, n_idx)),
                l0c,
            )

    @jit
    def run(self, gm_latent: Tensor, gm_weight: Tensor, gm_projected: Tensor):
        self.kernel[self.block_num](gm_latent, gm_weight, gm_projected)


@kernel
class _FusedPostScatterKernel:
    """Destination-owner RMSNorm + RoPE + MXFP4 direct cache update."""

    def __init__(
        self,
        *,
        total_rows: int,
        index_head_dim: int,
        rope_head_dim: int,
        storage_mode: int,
        combined_block_size: int,
        raw_block_size: int,
        write_scale_cache: bool,
    ):
        self.total_rows = int(total_rows)
        self.index_head_dim = int(index_head_dim)
        self.rope_head_dim = int(rope_head_dim)
        self.storage_mode = int(storage_mode)
        self.combined_block_size = int(combined_block_size)
        self.raw_block_size = int(raw_block_size)
        self.write_scale_cache = bool(write_scale_cache)
        self.padded_dim = _ceil_div(self.index_head_dim, VL) * VL

    @jit
    def _normalize(self, projected, gamma, normalized, epsilon: dtypes.float32):
        dim = self.index_head_dim
        with vf(mode="raw"):
            full = rr.full_mask()
            lane0 = rr.update_mask(1, elem_bits=32)[0]
            square_sum = rr.vdups(0.0, dtypes.float32, mask=lane0)
            for segment in range(_ceil_div(dim, VL)):
                offset = segment * VL
                valid = min(VL, dim - offset)
                segment_mask = rr.update_mask(valid, elem_bits=32)[0]
                packed = rr.vload_unpack(
                    projected, offset, unpack_mode=rr.UnpackMode.B16_TO_B32
                )
                value = rr.vcast(packed, dtypes.float32, mask=segment_mask)
                partial = rr.vreduce_sum(
                    rr.vmul(value, value, mask=segment_mask), mask=segment_mask
                )
                square_sum = rr.vadd(square_sum, partial, mask=lane0)

            mean = rr.vmuls(square_sum, 1.0 / dim, mask=lane0)
            root = rr.vsqrt(rr.vadds(mean, epsilon, mask=lane0), mask=lane0)
            inverse_rms = rr.vdiv(
                rr.vdups(1.0, dtypes.float32, mask=lane0), root, mask=lane0
            )
            inverse_rms = rr.vdup(inverse_rms, mask=full)

            for segment in range(_ceil_div(dim, VL)):
                offset = segment * VL
                valid = min(VL, dim - offset)
                segment_mask = rr.update_mask(valid, elem_bits=32)[0]
                packed = rr.vload_unpack(
                    projected, offset, unpack_mode=rr.UnpackMode.B16_TO_B32
                )
                value = rr.vcast(packed, dtypes.float32, mask=segment_mask)
                gamma_value = rr.vload(gamma, offset)
                value = rr.vmul(value, inverse_rms, mask=segment_mask)
                value = rr.vmul(value, gamma_value, mask=segment_mask)
                value = rr.vcast(value, dtypes.bfloat16, mask=segment_mask)
                rr.vstore_pack(
                    normalized,
                    offset,
                    value,
                    segment_mask,
                    pack_mode=rr.PackMode.B32_TO_B16,
                )
            rr.vmem_bar("vst_vld")

    @jit
    def _load_bf16_rope_work(self, source, work):
        with vf(mode="raw"):
            dim = self.index_head_dim
            first_segment = (dim - self.rope_head_dim) // VL
            for segment in range(first_segment, _ceil_div(dim, VL)):
                offset = segment * VL
                valid = min(VL, dim - offset)
                segment_mask = rr.update_mask(valid, elem_bits=32)[0]
                packed = rr.vload_unpack(
                    source, offset, unpack_mode=rr.UnpackMode.B16_TO_B32
                )
                value = rr.vcast(packed, dtypes.float32, mask=segment_mask)
                rr.vstore(work, offset, value, segment_mask)
            rr.vmem_bar("vst_vld")

    @jit
    def _apply_rope(self, work, rope_sin, rope_cos, rotated):
        """Rotate adjacent pairs in the final ``rope_head_dim`` columns."""
        dim = self.index_head_dim
        rd = self.rope_head_dim
        rope_start = dim - rd

        with vf(mode="raw"):
            full = rr.full_mask()
            for chunk in range(_ceil_div(rd, VL)):
                chunk_offset = chunk * VL
                valid = min(VL, rd - chunk_offset)
                pair_mask = rr.update_mask(valid // 2, elem_bits=32)[0]
                rope_mask = rr.update_mask(valid, elem_bits=32)[0]
                source_offset = rope_start + chunk_offset
                if const_expr(rope_start % 8 == 0):
                    x_even, x_odd = rr.vload_deinterleave(
                        work, source_offset, width="b32"
                    )
                else:
                    rr.vload_unalign_init(work, source_offset)
                    packed_rope = rr.vload_unalign(work, source_offset)
                    x_even, x_odd = rr.vdeinterleave(packed_rope, packed_rope)

                cos_even, cos_odd = rr.vload_deinterleave(
                    rope_cos, chunk_offset, width="b32"
                )
                sin_even, sin_odd = rr.vload_deinterleave(
                    rope_sin, chunk_offset, width="b32"
                )
                out_even = rr.vsub(
                    rr.vmul(x_even, cos_even, mask=pair_mask),
                    rr.vmul(x_odd, sin_even, mask=pair_mask),
                    mask=pair_mask,
                )
                out_odd = rr.vadd(
                    rr.vmul(x_odd, cos_odd, mask=pair_mask),
                    rr.vmul(x_even, sin_odd, mask=pair_mask),
                    mask=pair_mask,
                )
                interleaved, _ = rr.vinterleave(out_even, out_odd)
                rr.vstore(rotated, VL + chunk_offset, interleaved, rope_mask)
            rr.vmem_bar("vst_vld")

            # CANN 9.2 cannot lower the DSL unaligned-store helper.  Rebase
            # the compact rotated tail through an unaligned load, merge it
            # into aligned 64-lane work segments, and only issue aligned
            # stores.  The VL prefix guarantees every rebased load is in-bounds.
            first_segment = rope_start // VL
            for segment in range(first_segment, _ceil_div(dim, VL)):
                segment_start = segment * VL
                local_start = max(0, rope_start - segment_start)
                local_end = min(VL, dim - segment_start)
                end_mask = rr.update_mask(local_end, elem_bits=32)[0]
                prefix_mask = rr.update_mask(local_start, elem_bits=32)[0]
                range_mask = rr.mask_xor(
                    end_mask, prefix_mask, exec_mask=full
                )
                rotated_offset = VL + segment_start - rope_start
                rr.vload_unalign_init(rotated, rotated_offset)
                shifted = rr.vload_unalign(rotated, rotated_offset)
                old = rr.vload(work, segment_start)
                merged = rr.vmerge(range_mask, shifted, old)
                rr.vstore(work, segment_start, merged, end_mask)
            rr.vmem_bar("vst_vld")

    @jit
    def _pack_mxfp4(self, source, packed_output, code_scratch):
        """Pack signed E2M1 pairs and append one UE8M0 scale per 32 values."""
        dim = self.index_head_dim
        num_groups = dim // FP4_GROUP_SIZE
        value_bytes = dim // 2
        with vf(mode="raw"):
            mask = rr.update_mask(FP4_GROUP_SIZE, elem_bits=32)[0]
            packed_mask = rr.update_mask(FP4_GROUP_SIZE // 2, elem_bits=32)[0]
            byte_block_mask = rr.update_mask(FP4_GROUP_SIZE, elem_bits=32)[0]
            lane0 = rr.update_mask(1, elem_bits=32)[0]
            one_u32 = rr.vdups(1, dtypes.uint32, mask=mask)
            zero_u32 = rr.vdups(0, dtypes.uint32, mask=mask)
            sign_u32 = rr.vdups(8, dtypes.uint32, mask=mask)
            zero_f32 = rr.vdups(0.0, dtypes.float32, mask=mask)
            mantissa_mask = rr.vdups(FP32_MANTISSA_MASK, dtypes.uint32, mask=mask)
            exponent_mask = rr.vdups(FP32_EXP_MASK, dtypes.uint32, mask=mask)

            for group in range(num_groups):
                offset = group * FP4_GROUP_SIZE
                unpacked = rr.vload_unpack(
                    source, offset, unpack_mode=rr.UnpackMode.B16_TO_B32
                )
                value = rr.vcast(unpacked, dtypes.float32, mask=mask)
                abs_value = rr.vabs(value, mask=mask)
                amax = rr.vreduce_max(abs_value, mask=mask)
                safe_amax = rr.vmaxs(amax, FP4_MAX * (2.0**-126), mask=mask)
                raw_scale = rr.vmuls(safe_amax, 1.0 / FP4_MAX, mask=mask)

                scale_bits = rr.vreinterpret(raw_scale, dtypes.uint32)
                exponent = rr.vbitwise_and(
                    rr.vshr(scale_bits, FP32_EXP_SHIFT, mask=mask),
                    exponent_mask,
                    mask=mask,
                )
                mantissa = rr.vbitwise_and(scale_bits, mantissa_mask, mask=mask)
                has_mantissa = rr.vne(mantissa, zero_u32, mask=mask)
                increment = rr.vselect(one_u32, zero_u32, cond_mask=has_mantissa)
                exponent = rr.vadd(exponent, increment, mask=mask)
                pow2_bits = rr.vshl(exponent, FP32_EXP_SHIFT, mask=mask)
                scale = rr.vreinterpret(pow2_bits, dtypes.float32)
                scale = rr.vdup(scale, mask=mask)

                scaled_abs = rr.vdiv(abs_value, scale, mask=mask)
                code = rr.vdups(7, dtypes.uint32, mask=mask)
                for threshold, level_code in (
                    (5.0, 6),
                    (3.5, 5),
                    (2.5, 4),
                    (1.75, 3),
                    (1.25, 2),
                    (0.75, 1),
                    (0.25, 0),
                ):
                    lower = rr.vdups(level_code, dtypes.uint32, mask=mask)
                    choose_lower = rr.vles(scaled_abs, threshold, mask=mask)
                    code = rr.vselect(lower, code, cond_mask=choose_lower)

                is_negative = rr.vlt(value, zero_f32, mask=mask)
                sign = rr.vselect(sign_u32, zero_u32, cond_mask=is_negative)
                code = rr.vadd(code, sign, mask=mask)
                even_code, odd_code = rr.vdeinterleave(code, code)
                high_nibble = rr.vshl(odd_code, 4, mask=packed_mask)
                packed_code = rr.vbitwise_or(
                    even_code, high_nibble, mask=packed_mask
                )
                rr.vstore(
                    code_scratch,
                    group * VL,
                    packed_code,
                    packed_mask,
                )

                exponent_u8 = rr.vcast(
                    exponent,
                    dtypes.uint8,
                    mask=lane0,
                    reg_layout=rr.RegLayout.ZERO,
                )
                rr.vstore_first(
                    packed_output,
                    value_bytes + group,
                    exponent_u8,
                )
            rr.vmem_bar("vst_vld")

            # Two 32-value groups produce 16 bytes each.  Join them into one
            # aligned 32-byte store to avoid non-aligned vector writes on 950.
            prefix = rr.update_mask(FP4_GROUP_SIZE // 2, elem_bits=32)[0]
            tail = rr.mask_xor(byte_block_mask, prefix, exec_mask=rr.full_mask())
            for group_pair in range(num_groups // 2):
                first_group = 2 * group_pair
                first = rr.vload(code_scratch, first_group * VL)
                second_shifted = rr.vload(
                    code_scratch, (first_group + 1) * VL - FP4_GROUP_SIZE // 2
                )
                joined = rr.vmerge(tail, second_shifted, first)
                rr.vstore_pack(
                    packed_output,
                    group_pair * FP4_GROUP_SIZE,
                    joined,
                    byte_block_mask,
                    pack_mode=rr.PackMode.B32_TO_B8,
                )
            if const_expr(num_groups % 2 != 0):
                last_group = num_groups - 1
                last = rr.vload(code_scratch, last_group * VL)
                rr.vstore_pack(
                    packed_output,
                    (num_groups // 2) * FP4_GROUP_SIZE,
                    last,
                    packed_mask,
                    pack_mode=rr.PackMode.B32_TO_B8,
                )
            rr.vmem_bar("vst_vld")

    @jit
    def _cast_output(self, work, output):
        with vf(mode="raw"):
            dim = self.index_head_dim
            first_segment = (dim - self.rope_head_dim) // VL
            for segment in range(first_segment, _ceil_div(dim, VL)):
                offset = segment * VL
                valid = min(VL, dim - offset)
                segment_mask = rr.update_mask(valid, elem_bits=32)[0]
                value = rr.vload(work, offset)
                packed = rr.vcast(value, dtypes.bfloat16, mask=segment_mask)
                rr.vstore_pack(
                    output,
                    offset,
                    packed,
                    segment_mask,
                    pack_mode=rr.PackMode.B32_TO_B16,
                )

    @jit
    def _store_packed_row(
        self,
        packed_output,
        packed_data,
        packed_scale,
        gm_cache,
        gm_scale_cache,
        cache_row,
    ):
        value_bytes = self.index_head_dim // 2
        scale_bytes = self.index_head_dim // FP4_GROUP_SIZE
        # Partial-width UB vector copies are unsafe on 950 when D/32 is odd:
        # their 16-byte data tail (and odd-byte scale row) can raise a vector
        # core exception.  Those shapes use the scalar path below directly
        # from packed_output; aligned/even-group shapes retain the DMA path.
        if const_expr(value_bytes % 32 == 0):
            mem_copy(
                packed_data,
                tile_view(packed_output, (1, value_bytes), (0, 0)),
            )
            mem_copy(
                packed_scale,
                tile_view(
                    packed_output,
                    (1, scale_bytes),
                    (0, value_bytes // scale_bytes),
                ),
            )
        if const_expr(self.storage_mode == 0):
            raw_block_size = self.raw_block_size
            block_id = cache_row // raw_block_size
            slot = cache_row % raw_block_size
            if const_expr(value_bytes % 32 == 0):
                mem_copy(
                    tile_view(
                        gm_cache,
                        (1, 1, 1, value_bytes),
                        (block_id, slot, 0, 0),
                    ).view(1, value_bytes),
                    packed_data,
                )
            else:
                for byte_idx in range(value_bytes):
                    scalar.store_bypass(
                        gm_cache.ptr((block_id, slot, 0, byte_idx)),
                        packed_output[0, byte_idx],
                    )
            if const_expr(self.write_scale_cache):
                if const_expr(value_bytes % 32 == 0):
                    mem_copy(
                        tile_view(
                            gm_scale_cache,
                            (1, 1, 1, scale_bytes),
                            (block_id, slot, 0, 0),
                        ).view(1, scale_bytes),
                        packed_scale,
                    )
                else:
                    for byte_idx in range(scale_bytes):
                        scalar.store_bypass(
                            gm_scale_cache.ptr(
                                (block_id, slot, 0, byte_idx)
                            ),
                            packed_output[0, value_bytes + byte_idx],
                        )
        else:
            group_size = self.combined_block_size
            raw_block_size = self.raw_block_size
            block_id = cache_row // raw_block_size
            slot = cache_row % raw_block_size
            cache_group = slot // group_size
            sub_slot = slot % group_size
            data_offset = sub_slot * value_bytes
            scale_offset = group_size * value_bytes + sub_slot * scale_bytes
            combined_width = group_size * (value_bytes + scale_bytes)
            if const_expr(
                value_bytes % 32 == 0 and combined_width % 32 == 0
            ):
                mem_copy(
                    tile_view(
                        gm_cache,
                        (1, 1, 1, value_bytes),
                        (block_id, cache_group, 0, sub_slot),
                    ).view(1, value_bytes),
                    packed_data,
                )
            else:
                for byte_idx in range(value_bytes):
                    scalar.store_bypass(
                        gm_cache.ptr(
                            (
                                block_id,
                                cache_group,
                                0,
                                data_offset + byte_idx,
                            )
                        ),
                        packed_output[0, byte_idx],
                    )
            if const_expr(value_bytes % 32 == 0):
                mem_copy(
                    tile_view(
                        gm_cache,
                        (1, 1, 1, scale_bytes),
                        (
                            block_id,
                            cache_group,
                            0,
                            scale_offset // scale_bytes,
                        ),
                    ).view(1, scale_bytes),
                    packed_scale,
                )
            else:
                for byte_idx in range(scale_bytes):
                    scalar.store_bypass(
                        gm_cache.ptr(
                            (
                                block_id,
                                cache_group,
                                0,
                                scale_offset + byte_idx,
                            )
                        ),
                        packed_output[0, value_bytes + byte_idx],
                    )

    @jit
    def _process_owned_row(
        self,
        gm_projected,
        gm_rope_sin,
        gm_rope_cos,
        gamma,
        gm_cache,
        gm_scale_cache,
        projected,
        output,
        packed_output,
        packed_data,
        packed_scale,
        code_scratch,
        work,
        rope_sin,
        rope_cos,
        rotated,
        row,
        cache_row,
        epsilon,
    ):
        dim = self.index_head_dim
        rd = self.rope_head_dim
        mem_copy(projected, tile_view(gm_projected, (1, dim), (row, 0)))
        mem_copy(rope_sin, tile_view(gm_rope_sin, (1, rd), (row, 0)))
        mem_copy(rope_cos, tile_view(gm_rope_cos, (1, rd), (row, 0)))
        # Preserve both BF16 publication boundaries from the reference path.
        self._normalize(projected, gamma, output, epsilon)
        self._load_bf16_rope_work(output, work)
        self._apply_rope(work, rope_sin, rope_cos, rotated)
        self._cast_output(work, output)
        self._pack_mxfp4(output, packed_output, code_scratch)
        value_bytes = self.index_head_dim // 2
        scale_bytes = self.index_head_dim // FP4_GROUP_SIZE
        combined_width = self.combined_block_size * (
            value_bytes + scale_bytes
        )
        if const_expr(
            value_bytes % 32 != 0
            or (
                self.storage_mode == 1
                and combined_width % 32 != 0
            )
        ):
            # The unaligned cache path consumes vector-produced packed bytes
            # from PIPE_S.  Make the V->S dependency explicit before scalar
            # loads from packed_output (not needed by the aligned MTE path).
            vec_sync_all()
        self._store_packed_row(
            packed_output,
            packed_data,
            packed_scale,
            gm_cache,
            gm_scale_cache,
            cache_row,
        )

    def __call__(
        self,
        gm_projected: Tensor,
        gm_rope_sin: Tensor,
        gm_rope_cos: Tensor,
        gm_gamma: Tensor,
        gm_cache_index: Tensor,
        gm_cache: Tensor,
        gm_scale_cache: Tensor,
        epsilon: dtypes.float32,
    ):
        dim = self.index_head_dim
        rd = self.rope_head_dim
        padded_dim = self.padded_dim
        padded_rd = _ceil_div(rd, VL) * VL
        projected = Channel(
            MemLoc.UB, (1, padded_dim), dtypes.bfloat16, depth=2
        )
        # This storage is reused by several V->V rounding boundaries before
        # the final MTE3 write, so it is a Buffer rather than a FIFO Channel.
        # One extra vector keeps the final masked BF16 unpack in bounds when
        # MXFP4 groups begin at a 32-element (half-vector) offset.
        output = Buffer(MemLoc.UB, (1, padded_dim + VL), dtypes.bfloat16)
        packed_output = Buffer(MemLoc.UB, (1, padded_dim), dtypes.uint8)
        packed_data = Channel(
            MemLoc.UB, (1, dim // 2), dtypes.uint8, depth=1
        )
        packed_scale = Channel(
            MemLoc.UB,
            (1, dim // FP4_GROUP_SIZE),
            dtypes.uint8,
            depth=1,
        )
        code_scratch = Buffer(
            MemLoc.UB, (dim // FP4_GROUP_SIZE, VL), dtypes.uint32
        )
        gamma = Buffer(MemLoc.UB, (padded_dim,), dtypes.float32)
        work = Buffer(MemLoc.UB, (padded_dim + 2 * VL,), dtypes.float32)
        rope_sin = Buffer(MemLoc.UB, (1, padded_rd), dtypes.float32)
        rope_cos = Buffer(MemLoc.UB, (1, padded_rd), dtypes.float32)
        rotated = Buffer(MemLoc.UB, (padded_rd + 2 * VL,), dtypes.float32)

        mem_copy(gamma, gm_gamma)
        block_idx = get_block_idx()
        block_num = get_block_num()
        # Every owner scans source rows in ascending order.  Ownership is
        # decided before RMSNorm/RoPE/packing, so duplicate destinations remain
        # deterministic while unowned rows perform no vector work.
        for row in range(self.total_rows):
            cache_row = gm_cache_index[row]
            if cache_row != -1:
                if const_expr(self.storage_mode == 0):
                    if cache_row % block_num == block_idx:
                        self._process_owned_row(
                            gm_projected, gm_rope_sin, gm_rope_cos, gamma,
                            gm_cache, gm_scale_cache, projected, output,
                            packed_output, packed_data, packed_scale,
                            code_scratch, work, rope_sin, rope_cos, rotated,
                            row, cache_row, epsilon,
                        )
                else:
                    group_size = self.combined_block_size
                    raw_block_size = self.raw_block_size
                    block_id = cache_row // raw_block_size
                    slot = cache_row % raw_block_size
                    cache_group = slot // group_size
                    combined_row = block_id * (raw_block_size // group_size)
                    combined_row = combined_row + cache_group
                    if combined_row % block_num == block_idx:
                        self._process_owned_row(
                            gm_projected, gm_rope_sin, gm_rope_cos, gamma,
                            gm_cache, gm_scale_cache, projected, output,
                            packed_output, packed_data, packed_scale,
                            code_scratch, work, rope_sin, rope_cos, rotated,
                            row, cache_row, epsilon,
                        )


class IndexerPrologueKPostprocess:
    """Host wrapper for the fused destination-owner vector stage."""

    def __init__(self, **kwargs):
        total_rows = int(kwargs["total_rows"])
        storage_mode = int(kwargs["storage_mode"])
        group_size = int(kwargs["combined_block_size"])
        self.block_num = (
            min(DEFAULT_AIV_NUM, total_rows)
            if storage_mode == 0
            else min(DEFAULT_AIV_NUM, _ceil_div(total_rows, group_size))
        )
        self.kernel = _FusedPostScatterKernel(**kwargs)

    @jit
    def run(
        self,
        projected,
        rope_sin,
        rope_cos,
        gamma,
        cache_index,
        cache,
        scale_cache,
        epsilon: dtypes.float32,
    ):
        self.kernel[self.block_num](
            projected,
            rope_sin,
            rope_cos,
            gamma,
            cache_index,
            cache,
            scale_cache,
            epsilon,
        )


class IndexerPrologueKScatter:
    """Compatibility marker; scatter is fused into postprocess on this route."""


class _IndexerPrologueKPipeline:
    """Compile Projection and fused post-scatter into one host program."""

    def __init__(
        self,
        *,
        total_rows: int,
        head_dim: int,
        index_head_dim: int,
        rope_head_dim: int,
        storage_mode: int,
        combined_block_size: int,
        raw_block_size: int,
        write_scale_cache: bool,
    ):
        self.projection = _ProjectionKernel(
            total_rows, index_head_dim, head_dim
        )
        self.postprocess = IndexerPrologueKPostprocess(
            total_rows=total_rows,
            index_head_dim=index_head_dim,
            rope_head_dim=rope_head_dim,
            storage_mode=storage_mode,
            combined_block_size=combined_block_size,
            raw_block_size=raw_block_size,
            write_scale_cache=write_scale_cache,
        )

    @jit
    def run(
        self,
        latent,
        weight,
        gamma,
        rope_sin,
        rope_cos,
        cache_index,
        cache,
        scale_cache,
        projected,
        _unused_packed_rows,
        epsilon: dtypes.float32,
    ):
        # Nested @jit calls are inlined into this outer program.  The resulting
        # ProviderCallable submits both kernels without retracing each
        # stage on every operator invocation.
        self.projection.run(latent, weight, projected)
        self.postprocess.run(
            projected,
            rope_sin,
            rope_cos,
            gamma,
            cache_index,
            cache,
            scale_cache,
            epsilon,
        )


class _FusedIndexerPrologueKPipeline(_IndexerPrologueKPipeline):
    """Active two-kernel ABI with no temporary uint8 GM tensor."""

    @jit
    def run_fused(
        self,
        latent,
        weight,
        gamma,
        rope_sin,
        rope_cos,
        cache_index,
        cache,
        scale_cache,
        projected,
        epsilon: dtypes.float32,
    ):
        self.projection.run(latent, weight, projected)
        self.postprocess.run(
            projected,
            rope_sin,
            rope_cos,
            gamma,
            cache_index,
            cache,
            scale_cache,
            epsilon,
        )


_FUSED_AOT_CALLABLE_CACHE = {}


def _get_fused_pipeline_callable(
    *,
    total_rows,
    head_dim,
    index_head_dim,
    rope_head_dim,
    storage_mode,
    combined_block_size,
    raw_block_size,
    write_scale_cache,
    cache_shape,
    cache_stride,
    scale_cache_shape,
    scale_cache_stride,
):
    """Compile/cache the active two-kernel ABI without packed-row GM."""
    key = (
        total_rows,
        head_dim,
        index_head_dim,
        rope_head_dim,
        storage_mode,
        combined_block_size,
        raw_block_size,
        write_scale_cache,
        tuple(cache_shape),
        tuple(cache_stride),
        tuple(scale_cache_shape),
        tuple(scale_cache_stride),
    )
    compiled = _FUSED_AOT_CALLABLE_CACHE.get(key)
    if compiled is not None:
        return compiled
    pipeline = _FusedIndexerPrologueKPipeline(
        total_rows=total_rows,
        head_dim=head_dim,
        index_head_dim=index_head_dim,
        rope_head_dim=rope_head_dim,
        storage_mode=storage_mode,
        combined_block_size=combined_block_size,
        raw_block_size=raw_block_size,
        write_scale_cache=write_scale_cache,
    )
    specs = (
        TensorSpec((total_rows, head_dim), dtypes.bfloat16),
        TensorSpec(
            (index_head_dim, head_dim),
            dtypes.bfloat16,
            storage_format="nz",
        ),
        TensorSpec((index_head_dim,), dtypes.float32),
        TensorSpec((total_rows, rope_head_dim), dtypes.float32),
        TensorSpec((total_rows, rope_head_dim), dtypes.float32),
        TensorSpec((total_rows,), dtypes.int64),
        TensorSpec(
            tuple(cache_shape), dtypes.uint8, stride=tuple(cache_stride)
        ),
        TensorSpec(
            tuple(scale_cache_shape),
            dtypes.uint8,
            stride=tuple(scale_cache_stride),
        ),
        TensorSpec((total_rows, index_head_dim), dtypes.bfloat16),
        dtypes.float32,
    )
    compiled = pipeline.run_fused.compile(*specs)
    _FUSED_AOT_CALLABLE_CACHE[key] = compiled
    return compiled


_AOT_CALLABLE_CACHE = {}


def _get_pipeline_callable(
    *,
    total_rows,
    head_dim,
    index_head_dim,
    rope_head_dim,
    storage_mode,
    combined_block_size,
    raw_block_size,
    write_scale_cache,
    cache_shape,
    cache_stride,
    scale_cache_shape,
    scale_cache_stride,
    packed_stride,
):
    """Return a cached AOT callable for one fully static operator shape."""
    key = (
        total_rows,
        head_dim,
        index_head_dim,
        rope_head_dim,
        storage_mode,
        combined_block_size,
        raw_block_size,
        write_scale_cache,
        tuple(cache_shape),
        tuple(cache_stride),
        tuple(scale_cache_shape),
        tuple(scale_cache_stride),
        packed_stride,
    )
    compiled = _AOT_CALLABLE_CACHE.get(key)
    if compiled is not None:
        return compiled

    pipeline = _IndexerPrologueKPipeline(
        total_rows=total_rows,
        head_dim=head_dim,
        index_head_dim=index_head_dim,
        rope_head_dim=rope_head_dim,
        storage_mode=storage_mode,
        combined_block_size=combined_block_size,
        raw_block_size=raw_block_size,
        write_scale_cache=write_scale_cache,
    )
    specs = (
        TensorSpec((total_rows, head_dim), dtypes.bfloat16),
        TensorSpec(
            (index_head_dim, head_dim),
            dtypes.bfloat16,
            storage_format="nz",
        ),
        TensorSpec((index_head_dim,), dtypes.float32),
        TensorSpec((total_rows, rope_head_dim), dtypes.float32),
        TensorSpec((total_rows, rope_head_dim), dtypes.float32),
        TensorSpec((total_rows,), dtypes.int64),
        TensorSpec(
            tuple(cache_shape), dtypes.uint8, stride=tuple(cache_stride)
        ),
        TensorSpec(
            tuple(scale_cache_shape),
            dtypes.uint8,
            stride=tuple(scale_cache_stride),
        ),
        TensorSpec((total_rows, index_head_dim), dtypes.bfloat16),
        TensorSpec((total_rows, packed_stride), dtypes.uint8),
        dtypes.float32,
    )
    compiled = pipeline.run.compile(*specs)
    _AOT_CALLABLE_CACHE[key] = compiled
    return compiled


def indexer_prologue_k(
    latent: torch.Tensor,
    wk: torch.Tensor,
    norm_weight: torch.Tensor,
    rope_sin: torch.Tensor,
    rope_cos: torch.Tensor,
    k_cache: torch.Tensor,
    k_scale_cache: torch.Tensor | None = None,
    *,
    cache_index: torch.Tensor,
    storage_mode: int,
    norm_eps: float,
    combined_block_size: int = -1,
) -> torch.Tensor:
    """Project ``latent[T,H]`` and scatter packed MXFP4 rows into cache.

    ``storage_mode=0`` stores E2M1 bytes in ``k_cache`` and optionally stores
    UE8M0 scales in ``k_scale_cache``.  ``storage_mode=1`` combines ``G``
    tokens in each cache row, where ``G=combined_block_size``.  A cache index
    of ``-1`` skips the corresponding token.
    """
    total_rows, head_dim = map(int, latent.shape)
    index_head_dim = int(wk.shape[0])
    rope_head_dim = int(rope_sin.shape[1])
    if total_rows <= 0:
        raise ValueError("T must be positive")
    if head_dim <= 0 or head_dim % 16 != 0:
        raise ValueError("H must be a positive multiple of 16 for FRACTAL_NZ wk")
    if int(k_cache.shape[2]) != 1:
        raise ValueError("k_cache dimension 2 must equal 1")
    if index_head_dim < FP4_GROUP_SIZE or index_head_dim % FP4_GROUP_SIZE != 0:
        raise ValueError(f"D must be a positive multiple of {FP4_GROUP_SIZE}")
    if rope_head_dim <= 0 or rope_head_dim % 2 != 0:
        raise ValueError("Dr must be a positive even number")
    if rope_head_dim > index_head_dim:
        raise ValueError("Dr cannot exceed D")
    if storage_mode not in (0, 1):
        raise ValueError("storage_mode must be 0 or 1")

    value_bytes = index_head_dim // 2
    scale_bytes = index_head_dim // FP4_GROUP_SIZE
    block_num = int(k_cache.shape[0])
    if storage_mode == 0:
        raw_block_size = int(k_cache.shape[1])
        if int(k_cache.shape[3]) != value_bytes:
            raise ValueError(
                f"storage_mode=0 requires k_cache.shape[-1] == {value_bytes}"
            )
        if k_scale_cache is not None:
            expected_scale_shape = (
                block_num,
                raw_block_size,
                1,
                scale_bytes,
            )
            if tuple(k_scale_cache.shape) != expected_scale_shape:
                raise ValueError(
                    f"k_scale_cache must have shape {expected_scale_shape}"
                )
    else:
        if combined_block_size <= 0:
            raise ValueError(
                "storage_mode=1 requires combined_block_size to be positive"
            )
        expected_width = combined_block_size * (value_bytes + scale_bytes)
        if int(k_cache.shape[3]) != expected_width:
            raise ValueError(
                "storage_mode=1 requires k_cache.shape[-1] == "
                f"{expected_width}"
            )
        raw_block_size = int(k_cache.shape[1]) * combined_block_size

    projected = torch.empty(
        (total_rows, index_head_dim), dtype=latent.dtype, device=latent.device
    )
    write_scale_cache = storage_mode == 0 and k_scale_cache is not None
    if write_scale_cache:
        scale_cache_arg = k_scale_cache
    else:
        # Keep the compiled pipeline ABI static without allocating a fake
        # output.  write_scale_cache=False is part of the compile key and
        # removes every gm_scale_cache access at compile time, so this alias
        # is never read or written by mode 0 without a scale cache (nor by
        # mode 1, whose scales are stored in the combined cache).
        scale_cache_arg = k_cache[:1, :1, :1, :1]
    compiled = _get_fused_pipeline_callable(
        total_rows=total_rows,
        head_dim=head_dim,
        index_head_dim=index_head_dim,
        rope_head_dim=rope_head_dim,
        storage_mode=storage_mode,
        combined_block_size=combined_block_size,
        raw_block_size=raw_block_size,
        write_scale_cache=write_scale_cache,
        cache_shape=tuple(k_cache.shape),
        cache_stride=tuple(k_cache.stride()),
        scale_cache_shape=tuple(scale_cache_arg.shape),
        scale_cache_stride=tuple(scale_cache_arg.stride()),
    )
    compiled(
        latent,
        wk,
        norm_weight,
        rope_sin,
        rope_cos,
        cache_index,
        k_cache,
        scale_cache_arg,
        projected,
        float(norm_eps),
    )
    return k_cache
