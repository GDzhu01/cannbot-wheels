"""Native AOT signatures for :mod:`ops.indexer_prologue_k`.

Concrete deployment shapes live here rather than in the generic operator
implementation. Shapes not listed here continue through CANNBotDSL's normal
Native ``prefer`` fallback and are JIT-compiled on first use.
"""

from cannbotdsl.package.native import register

from .indexer_prologue_k import (
    FP4_GROUP_SIZE,
    _AOT_CALLABLE_CACHE,
    _FUSED_AOT_CALLABLE_CACHE,
    _get_fused_pipeline_callable,
)


def _contiguous_stride(shape):
    stride = [1] * len(shape)
    for axis in range(len(shape) - 2, -1, -1):
        stride[axis] = stride[axis + 1] * shape[axis + 1]
    return tuple(stride)


def _close_aot_callables():
    """Release Provider callables retained by the Python JIT caches."""
    for cache in (_FUSED_AOT_CALLABLE_CACHE, _AOT_CALLABLE_CACHE):
        for compiled in cache.values():
            close = getattr(compiled, "close", None)
            if callable(close):
                close()
        cache.clear()


@register("indexer_prologue_k")
def export_indexer_prologue_k():
    """Export the four layouts exercised by the ACLGraph validation suite."""
    total_rows = 72
    head_dim = 512
    index_head_dim = 128
    rope_head_dim = 64
    block_num = 2
    raw_block_size = 64
    value_bytes = index_head_dim // 2
    scale_bytes = index_head_dim // FP4_GROUP_SIZE

    variants = (
        # storage_mode, combined_block_size, write_scale_cache
        (0, -1, True),
        (0, -1, False),
        (1, 4, False),
        (1, 8, False),
    )
    try:
        for storage_mode, group_size, write_scale_cache in variants:
            if storage_mode == 0:
                cache_shape = (
                    block_num,
                    raw_block_size,
                    1,
                    value_bytes,
                )
            else:
                cache_shape = (
                    block_num,
                    raw_block_size // group_size,
                    1,
                    group_size * (value_bytes + scale_bytes),
                )
            cache_stride = _contiguous_stride(cache_shape)
            if write_scale_cache:
                scale_cache_shape = (
                    block_num,
                    raw_block_size,
                    1,
                    scale_bytes,
                )
                scale_cache_stride = _contiguous_stride(scale_cache_shape)
            else:
                # Sentinel view produced by k_cache[:1, :1, :1, :1] when the
                # public function has no separate scale-cache output.
                scale_cache_shape = (1, 1, 1, 1)
                scale_cache_stride = cache_stride

            _get_fused_pipeline_callable(
                total_rows=total_rows,
                head_dim=head_dim,
                index_head_dim=index_head_dim,
                rope_head_dim=rope_head_dim,
                storage_mode=storage_mode,
                combined_block_size=group_size,
                raw_block_size=raw_block_size,
                write_scale_cache=write_scale_cache,
                cache_shape=cache_shape,
                cache_stride=cache_stride,
                scale_cache_shape=scale_cache_shape,
                scale_cache_stride=scale_cache_stride,
            )
    finally:
        _close_aot_callables()
