from pathlib import Path
from cannbotdsl.aot import register_directory

register_directory(Path(__file__).resolve().parent / '_native')
