from pathlib import Path
from cannbot_dsl.aot import register_directory

register_directory(Path(__file__).resolve().parent / '_native')
