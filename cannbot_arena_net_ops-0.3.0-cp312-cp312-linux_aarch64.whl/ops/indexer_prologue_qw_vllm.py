# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""QW entry matching staged BF16 projections, rotary and native MXFP4."""

from cannbot_dsl.aot import export

if __package__:
    from .indexer_prologue_qw import (
        _export_indexer_prologue_qw,
        _indexer_prologue_qw,
    )
else:  # Native collectors import the staged modules by filename.
    from indexer_prologue_qw import (
        _export_indexer_prologue_qw,
        _indexer_prologue_qw,
    )


def indexer_prologue_qw(*tensors, **options):
    return _indexer_prologue_qw(tensors, options, staged_bf16=True)


@export("indexer_prologue_qw_vllm")
def export_indexer_prologue_qw():
    _export_indexer_prologue_qw(staged_bf16=True)
