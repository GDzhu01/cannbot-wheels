# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Staged ``@jit`` function surface and its calling conventions.

Calling conventions matrix (caller -> callee):

    Python      -> @jit         OK   (DSL runtime; full compile + execute)
    Python      -> @kernel      ERR  (raised at _emit_kernel_call)
    @jit        -> @jit         OK   (compile-time inline; nested path below)
    @jit        -> Python       OK   (trace-time inline)
    @jit        -> @kernel      OK   (cannir.kernel_launch op -> NPU runtime)
    @kernel     -> @jit         OK   (compile-time inline via nested path)
    @kernel     -> Python       OK   (trace-time inline)
    @kernel     -> @kernel      ERR  (raised at KernelLauncher.__call__ entry)

Inlining mechanism (rows 3, 6): ``JitFunction._invoke`` checks
``ir.InsertionPoint.current`` -- when an outer @jit or @kernel has already
opened an insertion point, the nested @jit emits IR ops directly instead of
starting a new compilation pipeline. See the ``nested`` branch in ``_invoke``.

Rejection mechanism (row 2): see ``core.compiler.kernel_materialize.
_emit_kernel_call``; it raises when no ``JitLoweringState`` is
active (i.e. caller is plain Python). The kernel-in-kernel rejection
(row 8) lives in ``kernel_launcher.py``.
"""

from typing import Any, Callable, Optional

from cannbotdsl.core.contracts.surface import (
    SurfaceSignature,
    class_local_namespace,
)
from cannbotdsl.core.frontend.compiler import compile_function
from cannbotdsl.core.mlir_context import (
    _has_current_context,
    _has_current_insertion_point,
)


class _BoundJitMethod:
    """Per-instance view of a ``@jit`` method; avoids mutating a shared descriptor."""

    __slots__ = ("_jit_function", "_instance", "_surface")

    def __init__(
        self,
        jit_function: "JitFunction",
        instance,
        surface: SurfaceSignature,
    ):
        self._jit_function = jit_function
        self._instance = instance
        self._surface = surface

    def __call__(self, *args, **kwargs):
        return self._jit_function._invoke(self._instance, self._surface, args, kwargs)

    def compile(self, *args, **kwargs):
        return self._jit_function._compile(self._instance, self._surface, args, kwargs)

    @property
    def __signature__(self):
        return self._surface.public_signature


class JitFunction:
    """Callable descriptor produced by :func:`jit` for staged functions."""

    def __init__(self, fn: Callable[..., Any]):
        self.fn = fn
        self.__name__ = getattr(fn, "__name__", type(self).__name__)
        self.__qualname__ = getattr(fn, "__qualname__", self.__name__)
        self.__doc__ = getattr(fn, "__doc__", None)
        self.__wrapped__ = fn
        self._surface = SurfaceSignature.from_callable(fn)
        self.__signature__ = self._surface.signature

    def __set_name__(self, owner, name):
        del name
        self._surface = self._surface.with_local_namespace(class_local_namespace(owner))

    def __get__(self, instance, owner):
        if instance is None:
            return self
        surface = self._surface.bind_receiver(label=f"bound @jit entry {owner.__qualname__}.{self.__name__}")
        return _BoundJitMethod(self, instance, surface)

    def __call__(self, *args, **kwargs):
        return self._invoke(None, self._surface, args, kwargs)

    def compile(self, *args, **kwargs):
        return self._compile(None, self._surface, args, kwargs)

    def _compile(
        self,
        bound_instance: Optional[Any],
        surface: SurfaceSignature,
        args: tuple,
        kwargs: dict,
    ):
        from cannbotdsl.core.compiler.builder import compile_to_artifact
        from cannbotdsl.core.compiler.function import ProviderCallable
        from cannbotdsl.core.contracts.binding import bind_aot_call

        if _has_current_context():
            raise RuntimeError(".compile() cannot be called inside @jit")
        surface.validate_void_return_annotation(path=self.__qualname__)
        call_args = (bound_instance, *args) if bound_instance is not None else args
        bound_call = bind_aot_call(
            self.fn,
            call_args,
            kwargs,
            surface_signature=surface,
        )
        artifact = compile_to_artifact(
            self.fn,
            call_args,
            kwargs,
            aot=True,
            bound_call=bound_call,
        )
        if not artifact.so_path:
            return ProviderCallable._make_noop(
                artifact.symbol_name,
                artifact.contract,
            )
        return ProviderCallable._create(
            artifact.so_path,
            artifact.symbol_name,
            artifact.contract,
            host_abi_version=artifact.host_abi_version,
            owns_so=artifact.owns_so,
            debug_plans=artifact.debug_plans,
            content_key=artifact.content_key,
            format_version_tag=artifact.format_version_tag,
        )

    def _invoke(
        self,
        bound_instance: Optional[Any],
        surface: SurfaceSignature,
        args: tuple,
        kwargs: dict,
    ) -> Any:
        from cannbotdsl.core.compiler.builder import compile_to_artifact
        from cannbotdsl.core.compiler.jit_executor import (
            _build_provider_callable_for_jit,
            _execute_bound_call,
        )
        from cannbotdsl.core.utils.env import env

        call_args = (bound_instance, *args) if bound_instance is not None else args

        # Trace-time inline: when an outer @jit / @kernel has opened an
        # InsertionPoint, just emit IR ops here and bypass the full compilation
        # pipeline.
        if _has_current_context() and _has_current_insertion_point():
            ir_builder = compile_function(self.fn).function
            return ir_builder(*call_args, **kwargs)

        surface.validate_void_return_annotation(path=self.__qualname__)
        from cannbotdsl.core.contracts.binding import bind_jit_call

        bound_call = bind_jit_call(
            self.fn,
            call_args,
            kwargs,
            surface_signature=surface,
        )
        artifact = compile_to_artifact(
            self.fn,
            call_args,
            kwargs,
            bound_call=bound_call,
        )

        # CANNBOTDSL_PIPE_STAGE stops JIT before constructing or invoking a
        # ProviderCallable.  Retire any private compile-stage artifact here,
        # because no ProviderCallable will otherwise receive its ownership.
        stage = env().pipe_stage
        if stage in {"transform", "translate", "compile"}:
            if artifact.owns_so and artifact.so_path:
                from cannbotdsl.core.compiler.function import (
                    _remove_owned_artifact,
                )

                _remove_owned_artifact(artifact.so_path)
            return

        program = _build_provider_callable_for_jit(
            artifact,
            artifact.debug_plans,
        )
        try:
            _execute_bound_call(program, bound_call)
        finally:
            program.close()


def jit(fn=None):
    def decorator(fn):
        return JitFunction(fn)

    if fn is None:
        return decorator
    return decorator(fn)
