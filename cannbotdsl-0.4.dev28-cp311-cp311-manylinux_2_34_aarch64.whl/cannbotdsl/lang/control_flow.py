# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Structured control-flow markers recognized by the Python frontend."""

from __future__ import annotations

from typing import Any, Optional


def range(
    *args: Any,
    unroll: Optional[int] = None,
    unroll_full: bool = False,
):
    """Describe a DSL ``scf.for`` loop and its AscendC unroll policy.

    This marker is lowered by the frontend inside ``@jit`` and
    ``@kernel`` functions. It deliberately cannot fall back to Python's
    builtin ``range``: doing so would silently discard the optimization
    request outside a frontend boundary.
    """

    del args, unroll, unroll_full
    raise RuntimeError(
        "cannbotdsl.range() is only valid inside a @jit or @kernel AST "
        "frontend boundary; use builtins.range() for ordinary Python loops"
    )
