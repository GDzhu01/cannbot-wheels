# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""User-facing compile-time marker functions.

The frontend recognizes these callables by object identity. The function
bodies also provide their ordinary Python behavior during trace-time
meta-stage execution.
"""

from __future__ import annotations

import builtins
from typing import Any


def _static_bool(value: Any, marker: str) -> bool:
    # Import lazily so importing the public marker module does not initialize
    # MLIR. Accepting trace-value truthiness would silently specialize device
    # data, including first-class DSL wrappers around ir.Value.
    from cannbotdsl.core.frontend.runtime.trace_value import is_trace_value

    if is_trace_value(value):
        raise TypeError(
            f"{marker}() requires a compile-time Python value; "
            "use an if statement inside a @jit/@kernel boundary for a "
            "runtime DSL predicate"
        )
    return builtins.bool(value)


def const_expr(value: Any) -> bool:
    return _static_bool(value, "const_expr")


def target_version(value: Any) -> bool:
    return _static_bool(value, "target_version")


def range_constexpr(*args):
    return range(*args)
