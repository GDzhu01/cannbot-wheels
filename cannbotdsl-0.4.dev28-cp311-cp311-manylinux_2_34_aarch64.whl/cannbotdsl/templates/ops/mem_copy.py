# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Mem_copy templates in raw_reg style.

Parameterized by dtype to support multiple data types.
"""

from cannbotdsl.ops.reg import (
    mask_counter,
    full_mask,
    update_mask,
    vload,
    vstore,
    vstore_strided,
    vload_strided
)
from cannbotdsl.types import Tensor
from cannbotdsl.lang.vf import vf
from ..vf_template import vf_template

_ELEM_BITS = {"f32": 32, "f16": 16, "bf16": 16, "i32": 32, "i16": 16, "f8e4m3": 8, "f8e5m2": 8}


@vf_template(
    signature={
        "op": ["ub_format_convert"],
        "operand_dtypes": [
            ("f32", "f32", "copy_engine:nd2nz"),
            ("f16", "f16", "copy_engine:nd2nz"),
            ("bf16", "bf16", "copy_engine:nd2nz"),
            ("i32", "i32", "copy_engine:nd2nz"),
            ("i16", "i16", "copy_engine:nd2nz"),
            ("f8e4m3", "f8e4m3", "copy_engine:nd2nz"),
            ("f8e5m2", "f8e5m2", "copy_engine:nd2nz"),
        ],
        "attr_values": ["nd2nz"],
    },
    method={"name": "default"},
    info={"vstore_type": "normal", "vload_type": "normal", "can_front_fuse": "True", "can_back_fuse": "false"},
)
def ub_format_convert_nd2nz(ub_dst: Tensor, ub_src: Tensor, *, dtype_str: str = "f32", format_transform: str = "nd2nz"):
    """ND to NZ format conversion.

    ND: row-major layout [M, N]
    NZ: blocked layout with M0xN0 blocks

    Parameterized by dtype_str: "f32", "f16", "i32", "i16"
    """
    elem_bits = _ELEM_BITS[dtype_str]
    vl = 2048 // elem_bits
    elem_bytes = elem_bits // 8
    with vf(mode="raw"):
        nd_layout = ub_src.layout
        rows = nd_layout.shape[0]
        cols = nd_layout.shape[1]
        nz_layout = ub_dst.physical_layout
        nz_shape = nz_layout.shape
        nz_stride = nz_layout.stride

        M0 = 16
        N0 = 32 * 8 // elem_bits
        M1 = (rows + M0 - 1) // M0

        nz_n1_stride = nz_stride[0]
        row_stride = ub_src.physical_layout.stride[0]
        for row in range(rows):
            vmask = mask_counter(cols)
            for col in range(0, cols, vl):
                mask, vmask = update_mask(vmask, elem_bits=elem_bits)
                nd_offset = row * row_stride + col
                block_stride = nz_n1_stride * elem_bytes // 32
                repeat_stride = 0 #
                # `col` is a logical element coordinate. Convert it to the
                # physical N1 block coordinate before applying the N1 stride.
                nz_offset = row * N0 + (col // N0) * nz_n1_stride
                v = vload(ub_src, nd_offset)
                vstore_strided(ub_dst, nz_offset, v, mask, block_stride=block_stride, repeat_stride=repeat_stride)




@vf_template(
    signature={
        "op": ["ub_format_convert"],
        "operand_dtypes": [
            ("f32", "f32", "copy_engine:nz2nd"),
            ("f16", "f16", "copy_engine:nz2nd"),
            ("bf16", "bf16", "copy_engine:nz2nd"),
            ("i32", "i32", "copy_engine:nz2nd"),
            ("i16", "i16", "copy_engine:nz2nd"),
            ("f8e4m3", "f8e4m3", "copy_engine:nz2nd"),
            ("f8e5m2", "f8e5m2", "copy_engine:nz2nd"),
        ],
        "attr_values": ["nz2nd"],
    },
    method={"name": "default"},
    info={"vstore_type": "normal", "vload_type": "normal", "can_front_fuse": "false", "can_back_fuse": "True"},
)
def ub_format_convert_nz2nd(ub_dst: Tensor, ub_src: Tensor, *, dtype_str: str = "f32", format_transform: str = "nz2nd"):
    """NZ to ND format conversion.

    NZ: blocked layout with M0xN0 blocks
    ND: row-major layout [M, N]

    Parameterized by dtype_str: "f32", "f16", "i32", "i16"
    """
    elem_bits = _ELEM_BITS[dtype_str]
    vl = 2048 // elem_bits
    elem_bytes = elem_bits // 8
    with vf(mode="raw"):
        nz_layout = ub_src.physical_layout
        nz_shape = nz_layout.shape    # (N1=8, M1=2, M0=16, N0=16)
        nz_stride = nz_layout.stride  # (528, 256, 16, 1)
        nz_n1_stride = nz_stride[0]   # 528 (含 n1_pad=16)
        
        
        nd_layout = ub_dst.layout
        rows = nd_layout.shape[0]
        cols = nd_layout.shape[1]
        row_stride = ub_dst.physical_layout.stride[0]
        for row in range(rows):
            vmask = mask_counter(cols)
            for col in range(0, cols, vl):
                mask, vmask = update_mask(vmask, elem_bits=elem_bits)
                
                nd_offset = row * row_stride + col
                
                block_stride = nz_n1_stride * elem_bytes // 32
                #repeat_stride = nz_n1_stride * 8 * elem_bytes // 32 # TODO:BUG will use post_update
                #nz_offset = row * (32 // elem_bytes)
                repeat_stride = 0 #
                nz_offset = row * (32 // elem_bytes) + col*nz_n1_stride*8 // elem_bytes

                v = vload_strided(ub_src, nz_offset, mask, block_stride=block_stride, repeat_stride=repeat_stride)
                vstore(ub_dst, nd_offset, v, mask=mask)


@vf_template(
    signature={
        "op": ["ub_copy"],
        "operand_dtypes": [("f32", "f32"), ("f16", "f16"), ("i32", "i32"), ("i16", "i16")],
    },
    method={"name": "default"},
    info={"vstore_type": "normal", "vload_type": "normal", "can_front_fuse": "True", "can_back_fuse": "True"},
)
def ub_copy_default(ub_dst: Tensor, ub_src: Tensor, *, dtype_str: str = "f32"):
    """Simple memory copy between buffers with the same format.

    Copies data from src to dst element by element using flatten (1D loop).

    Parameterized by dtype_str: "f32", "f16", "i32", "i16"
    """
    elem_bits = _ELEM_BITS[dtype_str]
    vl = 2048 // elem_bits

    with vf(mode="raw"):
        physical_layout = ub_src.physical_layout
        rows = physical_layout.shape[0]
        cols = physical_layout.shape[1]

        total_elems = rows * cols
        vmask = mask_counter(total_elems)
        for i in range(0, total_elems, vl):
            mask, vmask = update_mask(vmask, elem_bits=elem_bits)
            v = vload(ub_src, i)
            vstore(ub_dst, i, v, mask=mask)
            
