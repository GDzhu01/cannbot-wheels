# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""VF template decorator and registry.

Templates are registered via @vf_template decorator and discovered automatically
by materialize_templates.py.
"""

from typing import Any, Callable, Dict, List

_VF_TEMPLATE_REGISTRY: List[Dict[str, Any]] = []


def vf_template(signature: dict, method: dict, info: dict) -> Callable:
    """Decorator: register a VF template function."""

    def decorator(fn: Callable) -> Callable:
        entry = {
            "fn": fn,
            "signature": signature,
            "method": method,
            "info": info,
        }
        _VF_TEMPLATE_REGISTRY.append(entry)
        fn._vf_template = entry
        return fn

    return decorator


def get_all_vf_templates() -> List[Dict[str, Any]]:
    """Return all registered vf_template entries."""
    return list(_VF_TEMPLATE_REGISTRY)


def clear_registry():
    """Clear the registry (for testing)."""
    _VF_TEMPLATE_REGISTRY.clear()
