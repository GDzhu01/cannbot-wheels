# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Materialize VF templates to parametric MLIR files.

This script:
1. Auto-discovers all @vf_template decorated functions in templates/*.py
2. Generates parametric MLIR for each (op, dtype_tuple) combination
3. Groups funcs by op_name into flat mlir/<op_name>.mlir files
4. Generates manifest.json for C++ template matching
"""

import argparse
import importlib
import inspect
import json
import logging
from pathlib import Path
import sys
from typing import Callable

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir, func

from cannbotdsl.core.frontend.compiler import compile_function
from cannbotdsl.types import MemLoc

_LOG = logging.getLogger(__name__)

_SPECIAL_DTYPE_MAP = {
    "f8e4m3": lambda: ir.Float8E4M3FNType.get(),
    "f8e5m2": lambda: ir.Float8E5M2Type.get(),
}


def _get_dtype_constructor(dtype_str: str) -> Callable:
    from cannbotdsl.core.contracts.elements import element_for_tag

    try:
        return element_for_tag(dtype_str).mlir_type
    except ValueError:
        try:
            return _SPECIAL_DTYPE_MAP[dtype_str]
        except KeyError as exc:
            raise ValueError(f"Unsupported dtype: {dtype_str}") from exc


def _make_dynamic_memref_type(rank: int, dtype_str: str, memloc: MemLoc = MemLoc.UB) -> ir.Type:
    shape = tuple(cannir.ShapeType.DYNAMIC for _ in range(rank))
    stride = tuple(cannir.StrideType.DYNAMIC for _ in range(rank))
    layout_ty = cannir.LayoutType.get(shape, stride, context=ir.Context.current)
    dtype_ctor = _get_dtype_constructor(dtype_str)
    elem_ty = dtype_ctor() if callable(dtype_ctor) else dtype_ctor
    ptr_ty = cannir.PointerType.get(memloc, elem_ty, context=ir.Context.current)
    return cannir.TensorType.get(ptr_ty, layout_ty, layout_ty, 0)


def _make_copy_engine_type(dtype_str: str, format_transform_str: str) -> ir.Type:
    dtype_ctor = _get_dtype_constructor(dtype_str)
    elem_ty = dtype_ctor() if callable(dtype_ctor) else dtype_ctor
    ft_map = {
        "identity": 0,
        "nd2nz": 1,
        "nz2nd": 2,
        "dn2nz": 3,
        "mx_scale_a": 4,
        "mx_scale_b": 5,
        "transpose": 6,
        "mx_scale_bnd": 7,
        "mx_scale_bdn": 8,
        "mx_scale_and": 9,
        "mx_scale_adn": 10,
    }
    ft_val = ft_map.get(format_transform_str, 0)
    return cannir.CopyEngineType.get(ft_val, elem_ty, context=ir.Context.current)


def auto_discover_templates():
    """Scan templates/ops/ directory, import all .py modules to trigger @vf_template registration."""
    from .vf_template import clear_registry

    clear_registry()

    ops_dir = Path(__file__).parent / "ops"
    ops_package = f"{__package__}.ops"
    exclude = {"__init__"}

    for path in sorted(ops_dir.glob("*.py")):
        module_name = path.stem
        if module_name.startswith("_") or module_name in exclude:
            continue
        qualified_name = f"{ops_package}.{module_name}"
        if qualified_name in sys.modules:
            importlib.reload(sys.modules[qualified_name])
        else:
            importlib.import_module(f".{module_name}", package=ops_package)


def _extract_op_type(op_name: str) -> str:
    """Extract op_type from op_name: 'reduce_sum' -> 'sum', 'reduce_max' -> 'max'."""
    if op_name.startswith("reduce_"):
        return op_name[len("reduce_") :]
    return ""


def _build_kwargs(fn, dtype_tuple, op_name, signature):
    """Build kwargs for template function based on its signature."""
    params = inspect.signature(fn).parameters
    kwargs = {}
    if "dtype_str" in params:
        kwargs["dtype_str"] = next((d for d in dtype_tuple if not d.startswith("copy_engine:")), "f32")
    if "op_type" in params:
        kwargs["op_type"] = _extract_op_type(op_name)
    attr_vals = signature.get("attr_values", [])
    attr_idx = 0
    if "axis" in params and attr_idx < len(attr_vals):
        kwargs["axis"] = attr_vals[attr_idx]
        attr_idx += 1
    if "format_transform" in params and attr_idx < len(attr_vals):
        kwargs["format_transform"] = attr_vals[attr_idx]
        attr_idx += 1
    return kwargs


def _generate_func_name(op_name: str, dtype_tuple: tuple, signature: dict, method: str) -> str:
    """Generate MLIR func name."""
    primary_dtype = next((d for d in dtype_tuple if not d.startswith("copy_engine:")), "unknown")
    parts = [op_name, primary_dtype]

    attr_vals = signature.get("attr_values", [])
    for val in attr_vals:
        parts.append(str(val))
    if method != "default":
        parts.append(method)

    return "_".join(parts)


def _make_wrapper(fn, **kwargs):
    """Create a wrapper function that calls fn with kwargs."""
    import functools

    @functools.wraps(fn)
    def wrapper(*args):
        return fn(*args, **kwargs)

    wrapper._original_fn = fn
    wrapper._kwargs = kwargs
    return wrapper


def _build_func_param_types(dtype_tuple: tuple):
    """Build MLIR function parameter types from dtype_tuple."""
    param_types = []
    for dt in dtype_tuple:
        if dt.startswith("copy_engine:"):
            ft_str = dt.split(":")[1]
            primary_dtype = next((d for d in dtype_tuple if not d.startswith("copy_engine:")), "f32")
            param_types.append(_make_copy_engine_type(primary_dtype, ft_str))
        else:
            param_types.append(_make_dynamic_memref_type(2, dt, MemLoc.UB))
    return param_types


def _build_func_attributes(ctx, entry, op_name, dtype_tuple):
    """Build func.func attributes."""
    sig = entry["signature"]
    method = entry["method"]["name"]
    info = entry["info"]

    sig_attrs = {
        "op": ir.StringAttr.get(op_name),
        "operand_dtypes": ir.ArrayAttr.get([ir.StringAttr.get(d) for d in dtype_tuple]),
    }
    attr_vals = sig.get("attr_values", [])
    if attr_vals:
        val_attrs = []
        for v in attr_vals:
            if isinstance(v, int):
                val_attrs.append(ir.IntegerAttr.get(ir.IntegerType.get_signless(64), v))
            else:
                val_attrs.append(ir.StringAttr.get(str(v)))
        sig_attrs["attr_values"] = ir.ArrayAttr.get(val_attrs)

    info_attrs = {}
    for k, v in info.items():
        if v in ("True", "False"):
            info_attrs[k] = ir.BoolAttr.get(v == "True")
        else:
            info_attrs[k] = ir.StringAttr.get(v)

    return {
        "cannir.device": ir.UnitAttr.get(),
        "cannir.cube_state_mode": ir.IntegerAttr.get(
            ir.IntegerType.get_signless(32), 0
        ),
        "cannir.template_signature": ir.DictAttr.get(sig_attrs),
        "cannir.template_method": ir.StringAttr.get(method),
        "cannir.template_info": ir.DictAttr.get(info_attrs),
    }


def materialize_all(output_dir: Path) -> None:
    """Generate a complete template directory or propagate the first error."""
    _materialize_all(output_dir)


def _materialize_all(output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    for generated_file in output_dir.glob("*.mlir"):
        generated_file.unlink()
    manifest_path = output_dir / "manifest.json"
    if manifest_path.exists():
        manifest_path.unlink()

    auto_discover_templates()

    from .vf_template import get_all_vf_templates

    entries = get_all_vf_templates()

    groups = {}
    manifest_entries = []

    for entry in entries:
        sig = entry["signature"]
        method = entry["method"]["name"]
        fn = entry["fn"]
        py_source = inspect.getfile(fn)
        py_source_name = Path(py_source).name

        op_names = sig["op"]
        operand_dtypes_list = sig["operand_dtypes"]

        for op_name in op_names:
            for dtype_tuple in operand_dtypes_list:
                mlir_file = f"{op_name}.mlir"
                func_name = _generate_func_name(op_name, dtype_tuple, sig, method)

                if mlir_file not in groups:
                    groups[mlir_file] = []
                groups[mlir_file].append(
                    {
                        "entry": entry,
                        "op_name": op_name,
                        "dtype_tuple": dtype_tuple,
                        "func_name": func_name,
                        "fn": fn,
                    }
                )

                sig_dict = {"op": op_name, "operand_dtypes": list(dtype_tuple)}
                attr_vals = sig.get("attr_values", [])
                if attr_vals:
                    sig_dict["attr_values"] = attr_vals

                manifest_entries.append(
                    {
                        "signature": sig_dict,
                        "method": method,
                        "info": {k: (v == "True" if v in ("True", "False") else v) for k, v in entry["info"].items()},
                        "mlir_file": mlir_file,
                        "func_name": func_name,
                        "py_source": py_source_name,
                    }
                )

    for mlir_file in sorted(groups):
        file_entries = sorted(groups[mlir_file], key=lambda item: item["func_name"])
        _materialize_file(output_dir, mlir_file, file_entries)

    manifest_entries.sort(
        key=lambda item: (
            item["signature"]["op"],
            tuple(item["signature"]["operand_dtypes"]),
            tuple(str(value) for value in item["signature"].get("attr_values", [])),
            item["method"],
            item["func_name"],
        )
    )

    manifest = {
        "version": "1.0",
        "entries": manifest_entries,
    }
    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    expected_files = set(groups)
    actual_files = {path.name for path in output_dir.glob("*.mlir")}
    if actual_files != expected_files:
        raise RuntimeError(
            f"VF template output is incomplete: expected={sorted(expected_files)}, actual={sorted(actual_files)}"
        )
    for entry in manifest_entries:
        path = output_dir / entry["mlir_file"]
        if not path.is_file() or not path.read_text(encoding="utf-8").strip():
            raise RuntimeError(f"VF template output is missing or empty: {path}")
    _LOG.info(f"Generated manifest.json with {len(manifest_entries)} entries")


def _materialize_file(output_dir: Path, mlir_file: str, file_entries: list) -> None:
    """Materialize all funcs into a single .mlir file."""
    with ir.Context() as ctx, ir.Location.unknown():
        module = ir.Module.create()

        for fe in file_entries:
            entry = fe["entry"]
            op_name = fe["op_name"]
            dtype_tuple = fe["dtype_tuple"]
            func_name = fe["func_name"]
            fn = fe["fn"]

            param_types = _build_func_param_types(dtype_tuple)
            func_type = ir.FunctionType.get(param_types, [])

            with ir.InsertionPoint(module.body):
                func_op = func.FuncOp(func_name, func_type)
                attrs = _build_func_attributes(ctx, entry, op_name, dtype_tuple)
                for k, v in attrs.items():
                    func_op.attributes[k] = v

            block = func_op.add_entry_block()

            kwargs = _build_kwargs(fn, dtype_tuple, op_name, entry["signature"])
            original_fn = getattr(fn, "_original_fn", fn)
            preprocessed = compile_function(original_fn).function

            with ir.InsertionPoint(block):
                args = list(block.arguments)
                num_params = len(inspect.signature(original_fn).parameters) - len(kwargs)
                preprocessed(*args[:num_params], **kwargs)
                func.ReturnOp([])

        module.operation.verify()

        out_path = output_dir / mlir_file
        out_path.write_text(str(module))
        _LOG.info(f"Materialized {out_path} with {len(file_entries)} funcs")


def main():
    parser = argparse.ArgumentParser(description="Materialize VF templates to MLIR")
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).parent / "mlir",
        help="Output directory for generated MLIR files",
    )
    parser.add_argument("--verbose", "-v", action="store_true", help="Enable verbose logging")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.WARNING,
        format="%(levelname)s: %(message)s",
    )

    _LOG.info(f"Materializing templates to {args.output_dir}")
    materialize_all(args.output_dir)
    _LOG.info("Done")


if __name__ == "__main__":
    main()
