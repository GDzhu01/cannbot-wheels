module {
  func.func @ub_copy_f16(%arg0: !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = true, can_front_fuse = true, vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {op = "ub_copy", operand_dtypes = ["f16", "f16"]}} {
    %0 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %7 = arith.muli %2, %6 : i64
    %8 = arith.trunci %7 : i64 to i32
    %c0_i64 = arith.constant 0 : i64
    %c128_i64 = arith.constant 128 : i64
    %9 = scf.for %arg2 = %c0_i64 to %7 step %c128_i64 iter_args(%arg3 = %8) -> (i32)  : i64 {
      %mask, %remaining_out = ascvec.update_mask %arg3 elem_bits 16 : !ascvec.mask
      %10 = arith.index_cast %arg2 : i64 to index
      %11 = cannir.raw_reg.load %arg1[%10] : !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index -> <f16>
      %12 = arith.index_cast %arg2 : i64 to index
      cannir.raw_reg.store %arg0[%12], %11, %mask : !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index, <f16>, !ascvec.mask
      scf.yield %remaining_out : i32
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
  func.func @ub_copy_f32(%arg0: !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = true, can_front_fuse = true, vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {op = "ub_copy", operand_dtypes = ["f32", "f32"]}} {
    %0 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %7 = arith.muli %2, %6 : i64
    %8 = arith.trunci %7 : i64 to i32
    %c0_i64 = arith.constant 0 : i64
    %c64_i64 = arith.constant 64 : i64
    %9 = scf.for %arg2 = %c0_i64 to %7 step %c64_i64 iter_args(%arg3 = %8) -> (i32)  : i64 {
      %mask, %remaining_out = ascvec.update_mask %arg3 : !ascvec.mask
      %10 = arith.index_cast %arg2 : i64 to index
      %11 = cannir.raw_reg.load %arg1[%10] : !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index -> <f32>
      %12 = arith.index_cast %arg2 : i64 to index
      cannir.raw_reg.store %arg0[%12], %11, %mask : !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index, <f32>, !ascvec.mask
      scf.yield %remaining_out : i32
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
  func.func @ub_copy_i16(%arg0: !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = true, can_front_fuse = true, vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {op = "ub_copy", operand_dtypes = ["i16", "i16"]}} {
    %0 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %7 = arith.muli %2, %6 : i64
    %8 = arith.trunci %7 : i64 to i32
    %c0_i64 = arith.constant 0 : i64
    %c128_i64 = arith.constant 128 : i64
    %9 = scf.for %arg2 = %c0_i64 to %7 step %c128_i64 iter_args(%arg3 = %8) -> (i32)  : i64 {
      %mask, %remaining_out = ascvec.update_mask %arg3 elem_bits 16 : !ascvec.mask
      %10 = arith.index_cast %arg2 : i64 to index
      %11 = cannir.raw_reg.load %arg1[%10] : !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index -> <i16>
      %12 = arith.index_cast %arg2 : i64 to index
      cannir.raw_reg.store %arg0[%12], %11, %mask : !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index, <i16>, !ascvec.mask
      scf.yield %remaining_out : i32
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
  func.func @ub_copy_i32(%arg0: !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = true, can_front_fuse = true, vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {op = "ub_copy", operand_dtypes = ["i32", "i32"]}} {
    %0 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %7 = arith.muli %2, %6 : i64
    %8 = arith.trunci %7 : i64 to i32
    %c0_i64 = arith.constant 0 : i64
    %c64_i64 = arith.constant 64 : i64
    %9 = scf.for %arg2 = %c0_i64 to %7 step %c64_i64 iter_args(%arg3 = %8) -> (i32)  : i64 {
      %mask, %remaining_out = ascvec.update_mask %arg3 : !ascvec.mask
      %10 = arith.index_cast %arg2 : i64 to index
      %11 = cannir.raw_reg.load %arg1[%10] : !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index -> <i32>
      %12 = arith.index_cast %arg2 : i64 to index
      cannir.raw_reg.store %arg0[%12], %11, %mask : !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index, <i32>, !ascvec.mask
      scf.yield %remaining_out : i32
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
}
