module {
  func.func @ub_format_convert_bf16_nd2nz(%arg0: !cannir.tensor<<ub, bf16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, bf16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg2: !cannir.copy_engine<nd2nz, bf16>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = "false", can_front_fuse = true, vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {attr_values = ["nd2nz"], op = "ub_format_convert", operand_dtypes = ["bf16", "bf16", "copy_engine:nd2nz"]}} {
    %0 = cannir.extract_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, bf16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %7 = cannir.extract_physical_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, bf16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %8 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %9 = cannir.extract_dim %8[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %10 = cannir.extract_dim %8[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %11 = cannir.extract_stride %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %12 = cannir.extract_dim %11[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %13 = cannir.extract_dim %11[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c16_i64 = arith.constant 16 : i64
    %14 = arith.addi %2, %c16_i64 : i64
    %c1_i64 = arith.constant 1 : i64
    %15 = arith.subi %14, %c1_i64 : i64
    %c16_i64_0 = arith.constant 16 : i64
    %16 = arith.divsi %15, %c16_i64_0 : i64
    %17 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, bf16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %18 = cannir.extract_stride %17 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %19 = cannir.extract_dim %18[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %20 = cannir.extract_dim %18[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c0_i64 = arith.constant 0 : i64
    %c1_i64_1 = arith.constant 1 : i64
    scf.for %arg3 = %c0_i64 to %2 step %c1_i64_1  : i64 {
      %21 = arith.trunci %6 : i64 to i32
      %c0_i64_2 = arith.constant 0 : i64
      %c128_i64 = arith.constant 128 : i64
      %22 = scf.for %arg4 = %c0_i64_2 to %6 step %c128_i64 iter_args(%arg5 = %21) -> (i32)  : i64 {
        %mask, %remaining_out = ascvec.update_mask %arg5 elem_bits 16 : !ascvec.mask
        %23 = arith.muli %arg3, %19 : i64
        %24 = arith.addi %23, %arg4 : i64
        %c2_i64 = arith.constant 2 : i64
        %25 = arith.muli %12, %c2_i64 : i64
        %c32_i64 = arith.constant 32 : i64
        %26 = arith.divsi %25, %c32_i64 : i64
        %c16_i64_3 = arith.constant 16 : i64
        %27 = arith.muli %arg3, %c16_i64_3 : i64
        %c16_i64_4 = arith.constant 16 : i64
        %28 = arith.divsi %arg4, %c16_i64_4 : i64
        %29 = arith.muli %28, %12 : i64
        %30 = arith.addi %27, %29 : i64
        %31 = arith.index_cast %24 : i64 to index
        %32 = cannir.raw_reg.load %arg1[%31] : !cannir.tensor<<ub, bf16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index -> <bf16>
        %33 = arith.index_cast %30 : i64 to index
        %34 = arith.index_cast %26 : i64 to index
        %c0 = arith.constant 0 : index
        cannir.raw_reg.store_strided %arg0[%33], %32, %mask, %34, %c0 : !cannir.tensor<<ub, bf16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, <bf16>, !ascvec.mask
        scf.yield %remaining_out : i32
      }
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
  func.func @ub_format_convert_bf16_nz2nd(%arg0: !cannir.tensor<<ub, bf16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, bf16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg2: !cannir.copy_engine<nz2nd, bf16>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = true, can_front_fuse = "false", vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {attr_values = ["nz2nd"], op = "ub_format_convert", operand_dtypes = ["bf16", "bf16", "copy_engine:nz2nd"]}} {
    %0 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, bf16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_stride %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %7 = cannir.extract_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, bf16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %8 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %9 = cannir.extract_dim %8[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %10 = cannir.extract_dim %8[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %11 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %12 = cannir.extract_dim %11[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %13 = cannir.extract_dim %11[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %14 = cannir.extract_physical_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, bf16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %15 = cannir.extract_stride %14 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %16 = cannir.extract_dim %15[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %17 = cannir.extract_dim %15[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c0_i64 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    scf.for %arg3 = %c0_i64 to %9 step %c1_i64  : i64 {
      %18 = arith.trunci %13 : i64 to i32
      %c0_i64_0 = arith.constant 0 : i64
      %c128_i64 = arith.constant 128 : i64
      %19 = scf.for %arg4 = %c0_i64_0 to %13 step %c128_i64 iter_args(%arg5 = %18) -> (i32)  : i64 {
        %mask, %remaining_out = ascvec.update_mask %arg5 elem_bits 16 : !ascvec.mask
        %20 = arith.muli %arg3, %16 : i64
        %21 = arith.addi %20, %arg4 : i64
        %c2_i64 = arith.constant 2 : i64
        %22 = arith.muli %5, %c2_i64 : i64
        %c32_i64 = arith.constant 32 : i64
        %23 = arith.divsi %22, %c32_i64 : i64
        %c16_i64 = arith.constant 16 : i64
        %24 = arith.muli %arg3, %c16_i64 : i64
        %25 = arith.muli %arg4, %5 : i64
        %c8_i64 = arith.constant 8 : i64
        %26 = arith.muli %25, %c8_i64 : i64
        %c2_i64_1 = arith.constant 2 : i64
        %27 = arith.divsi %26, %c2_i64_1 : i64
        %28 = arith.addi %24, %27 : i64
        %29 = arith.index_cast %28 : i64 to index
        %30 = arith.index_cast %23 : i64 to index
        %c0 = arith.constant 0 : index
        %31 = cannir.raw_reg.load_strided %arg1[%29], %mask, %30, %c0 : !cannir.tensor<<ub, bf16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, !ascvec.mask -> <bf16>
        %32 = arith.index_cast %21 : i64 to index
        cannir.raw_reg.store %arg0[%32], %31, %mask : !cannir.tensor<<ub, bf16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index, <bf16>, !ascvec.mask
        scf.yield %remaining_out : i32
      }
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
  func.func @ub_format_convert_f16_nd2nz(%arg0: !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg2: !cannir.copy_engine<nd2nz, f16>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = "false", can_front_fuse = true, vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {attr_values = ["nd2nz"], op = "ub_format_convert", operand_dtypes = ["f16", "f16", "copy_engine:nd2nz"]}} {
    %0 = cannir.extract_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %7 = cannir.extract_physical_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %8 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %9 = cannir.extract_dim %8[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %10 = cannir.extract_dim %8[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %11 = cannir.extract_stride %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %12 = cannir.extract_dim %11[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %13 = cannir.extract_dim %11[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c16_i64 = arith.constant 16 : i64
    %14 = arith.addi %2, %c16_i64 : i64
    %c1_i64 = arith.constant 1 : i64
    %15 = arith.subi %14, %c1_i64 : i64
    %c16_i64_0 = arith.constant 16 : i64
    %16 = arith.divsi %15, %c16_i64_0 : i64
    %17 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %18 = cannir.extract_stride %17 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %19 = cannir.extract_dim %18[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %20 = cannir.extract_dim %18[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c0_i64 = arith.constant 0 : i64
    %c1_i64_1 = arith.constant 1 : i64
    scf.for %arg3 = %c0_i64 to %2 step %c1_i64_1  : i64 {
      %21 = arith.trunci %6 : i64 to i32
      %c0_i64_2 = arith.constant 0 : i64
      %c128_i64 = arith.constant 128 : i64
      %22 = scf.for %arg4 = %c0_i64_2 to %6 step %c128_i64 iter_args(%arg5 = %21) -> (i32)  : i64 {
        %mask, %remaining_out = ascvec.update_mask %arg5 elem_bits 16 : !ascvec.mask
        %23 = arith.muli %arg3, %19 : i64
        %24 = arith.addi %23, %arg4 : i64
        %c2_i64 = arith.constant 2 : i64
        %25 = arith.muli %12, %c2_i64 : i64
        %c32_i64 = arith.constant 32 : i64
        %26 = arith.divsi %25, %c32_i64 : i64
        %c16_i64_3 = arith.constant 16 : i64
        %27 = arith.muli %arg3, %c16_i64_3 : i64
        %c16_i64_4 = arith.constant 16 : i64
        %28 = arith.divsi %arg4, %c16_i64_4 : i64
        %29 = arith.muli %28, %12 : i64
        %30 = arith.addi %27, %29 : i64
        %31 = arith.index_cast %24 : i64 to index
        %32 = cannir.raw_reg.load %arg1[%31] : !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index -> <f16>
        %33 = arith.index_cast %30 : i64 to index
        %34 = arith.index_cast %26 : i64 to index
        %c0 = arith.constant 0 : index
        cannir.raw_reg.store_strided %arg0[%33], %32, %mask, %34, %c0 : !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, <f16>, !ascvec.mask
        scf.yield %remaining_out : i32
      }
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
  func.func @ub_format_convert_f16_nz2nd(%arg0: !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg2: !cannir.copy_engine<nz2nd, f16>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = true, can_front_fuse = "false", vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {attr_values = ["nz2nd"], op = "ub_format_convert", operand_dtypes = ["f16", "f16", "copy_engine:nz2nd"]}} {
    %0 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_stride %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %7 = cannir.extract_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %8 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %9 = cannir.extract_dim %8[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %10 = cannir.extract_dim %8[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %11 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %12 = cannir.extract_dim %11[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %13 = cannir.extract_dim %11[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %14 = cannir.extract_physical_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %15 = cannir.extract_stride %14 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %16 = cannir.extract_dim %15[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %17 = cannir.extract_dim %15[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c0_i64 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    scf.for %arg3 = %c0_i64 to %9 step %c1_i64  : i64 {
      %18 = arith.trunci %13 : i64 to i32
      %c0_i64_0 = arith.constant 0 : i64
      %c128_i64 = arith.constant 128 : i64
      %19 = scf.for %arg4 = %c0_i64_0 to %13 step %c128_i64 iter_args(%arg5 = %18) -> (i32)  : i64 {
        %mask, %remaining_out = ascvec.update_mask %arg5 elem_bits 16 : !ascvec.mask
        %20 = arith.muli %arg3, %16 : i64
        %21 = arith.addi %20, %arg4 : i64
        %c2_i64 = arith.constant 2 : i64
        %22 = arith.muli %5, %c2_i64 : i64
        %c32_i64 = arith.constant 32 : i64
        %23 = arith.divsi %22, %c32_i64 : i64
        %c16_i64 = arith.constant 16 : i64
        %24 = arith.muli %arg3, %c16_i64 : i64
        %25 = arith.muli %arg4, %5 : i64
        %c8_i64 = arith.constant 8 : i64
        %26 = arith.muli %25, %c8_i64 : i64
        %c2_i64_1 = arith.constant 2 : i64
        %27 = arith.divsi %26, %c2_i64_1 : i64
        %28 = arith.addi %24, %27 : i64
        %29 = arith.index_cast %28 : i64 to index
        %30 = arith.index_cast %23 : i64 to index
        %c0 = arith.constant 0 : index
        %31 = cannir.raw_reg.load_strided %arg1[%29], %mask, %30, %c0 : !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, !ascvec.mask -> <f16>
        %32 = arith.index_cast %21 : i64 to index
        cannir.raw_reg.store %arg0[%32], %31, %mask : !cannir.tensor<<ub, f16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index, <f16>, !ascvec.mask
        scf.yield %remaining_out : i32
      }
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
  func.func @ub_format_convert_f32_nd2nz(%arg0: !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg2: !cannir.copy_engine<nd2nz, f32>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = "false", can_front_fuse = true, vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {attr_values = ["nd2nz"], op = "ub_format_convert", operand_dtypes = ["f32", "f32", "copy_engine:nd2nz"]}} {
    %0 = cannir.extract_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %7 = cannir.extract_physical_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %8 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %9 = cannir.extract_dim %8[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %10 = cannir.extract_dim %8[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %11 = cannir.extract_stride %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %12 = cannir.extract_dim %11[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %13 = cannir.extract_dim %11[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c16_i64 = arith.constant 16 : i64
    %14 = arith.addi %2, %c16_i64 : i64
    %c1_i64 = arith.constant 1 : i64
    %15 = arith.subi %14, %c1_i64 : i64
    %c16_i64_0 = arith.constant 16 : i64
    %16 = arith.divsi %15, %c16_i64_0 : i64
    %17 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %18 = cannir.extract_stride %17 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %19 = cannir.extract_dim %18[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %20 = cannir.extract_dim %18[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c0_i64 = arith.constant 0 : i64
    %c1_i64_1 = arith.constant 1 : i64
    scf.for %arg3 = %c0_i64 to %2 step %c1_i64_1  : i64 {
      %21 = arith.trunci %6 : i64 to i32
      %c0_i64_2 = arith.constant 0 : i64
      %c64_i64 = arith.constant 64 : i64
      %22 = scf.for %arg4 = %c0_i64_2 to %6 step %c64_i64 iter_args(%arg5 = %21) -> (i32)  : i64 {
        %mask, %remaining_out = ascvec.update_mask %arg5 : !ascvec.mask
        %23 = arith.muli %arg3, %19 : i64
        %24 = arith.addi %23, %arg4 : i64
        %c4_i64 = arith.constant 4 : i64
        %25 = arith.muli %12, %c4_i64 : i64
        %c32_i64 = arith.constant 32 : i64
        %26 = arith.divsi %25, %c32_i64 : i64
        %c8_i64 = arith.constant 8 : i64
        %27 = arith.muli %arg3, %c8_i64 : i64
        %c8_i64_3 = arith.constant 8 : i64
        %28 = arith.divsi %arg4, %c8_i64_3 : i64
        %29 = arith.muli %28, %12 : i64
        %30 = arith.addi %27, %29 : i64
        %31 = arith.index_cast %24 : i64 to index
        %32 = cannir.raw_reg.load %arg1[%31] : !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index -> <f32>
        %33 = arith.index_cast %30 : i64 to index
        %34 = arith.index_cast %26 : i64 to index
        %c0 = arith.constant 0 : index
        cannir.raw_reg.store_strided %arg0[%33], %32, %mask, %34, %c0 : !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, <f32>, !ascvec.mask
        scf.yield %remaining_out : i32
      }
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
  func.func @ub_format_convert_f32_nz2nd(%arg0: !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg2: !cannir.copy_engine<nz2nd, f32>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = true, can_front_fuse = "false", vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {attr_values = ["nz2nd"], op = "ub_format_convert", operand_dtypes = ["f32", "f32", "copy_engine:nz2nd"]}} {
    %0 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_stride %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %7 = cannir.extract_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %8 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %9 = cannir.extract_dim %8[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %10 = cannir.extract_dim %8[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %11 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %12 = cannir.extract_dim %11[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %13 = cannir.extract_dim %11[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %14 = cannir.extract_physical_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %15 = cannir.extract_stride %14 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %16 = cannir.extract_dim %15[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %17 = cannir.extract_dim %15[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c0_i64 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    scf.for %arg3 = %c0_i64 to %9 step %c1_i64  : i64 {
      %18 = arith.trunci %13 : i64 to i32
      %c0_i64_0 = arith.constant 0 : i64
      %c64_i64 = arith.constant 64 : i64
      %19 = scf.for %arg4 = %c0_i64_0 to %13 step %c64_i64 iter_args(%arg5 = %18) -> (i32)  : i64 {
        %mask, %remaining_out = ascvec.update_mask %arg5 : !ascvec.mask
        %20 = arith.muli %arg3, %16 : i64
        %21 = arith.addi %20, %arg4 : i64
        %c4_i64 = arith.constant 4 : i64
        %22 = arith.muli %5, %c4_i64 : i64
        %c32_i64 = arith.constant 32 : i64
        %23 = arith.divsi %22, %c32_i64 : i64
        %c8_i64 = arith.constant 8 : i64
        %24 = arith.muli %arg3, %c8_i64 : i64
        %25 = arith.muli %arg4, %5 : i64
        %c8_i64_1 = arith.constant 8 : i64
        %26 = arith.muli %25, %c8_i64_1 : i64
        %c4_i64_2 = arith.constant 4 : i64
        %27 = arith.divsi %26, %c4_i64_2 : i64
        %28 = arith.addi %24, %27 : i64
        %29 = arith.index_cast %28 : i64 to index
        %30 = arith.index_cast %23 : i64 to index
        %c0 = arith.constant 0 : index
        %31 = cannir.raw_reg.load_strided %arg1[%29], %mask, %30, %c0 : !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, !ascvec.mask -> <f32>
        %32 = arith.index_cast %21 : i64 to index
        cannir.raw_reg.store %arg0[%32], %31, %mask : !cannir.tensor<<ub, f32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index, <f32>, !ascvec.mask
        scf.yield %remaining_out : i32
      }
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
  func.func @ub_format_convert_f8e4m3_nd2nz(%arg0: !cannir.tensor<<ub, f8E4M3FN>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, f8E4M3FN>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg2: !cannir.copy_engine<nd2nz, f8E4M3FN>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = "false", can_front_fuse = true, vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {attr_values = ["nd2nz"], op = "ub_format_convert", operand_dtypes = ["f8e4m3", "f8e4m3", "copy_engine:nd2nz"]}} {
    %0 = cannir.extract_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f8E4M3FN>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %7 = cannir.extract_physical_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f8E4M3FN>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %8 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %9 = cannir.extract_dim %8[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %10 = cannir.extract_dim %8[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %11 = cannir.extract_stride %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %12 = cannir.extract_dim %11[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %13 = cannir.extract_dim %11[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c16_i64 = arith.constant 16 : i64
    %14 = arith.addi %2, %c16_i64 : i64
    %c1_i64 = arith.constant 1 : i64
    %15 = arith.subi %14, %c1_i64 : i64
    %c16_i64_0 = arith.constant 16 : i64
    %16 = arith.divsi %15, %c16_i64_0 : i64
    %17 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f8E4M3FN>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %18 = cannir.extract_stride %17 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %19 = cannir.extract_dim %18[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %20 = cannir.extract_dim %18[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c0_i64 = arith.constant 0 : i64
    %c1_i64_1 = arith.constant 1 : i64
    scf.for %arg3 = %c0_i64 to %2 step %c1_i64_1  : i64 {
      %21 = arith.trunci %6 : i64 to i32
      %c0_i64_2 = arith.constant 0 : i64
      %c256_i64 = arith.constant 256 : i64
      %22 = scf.for %arg4 = %c0_i64_2 to %6 step %c256_i64 iter_args(%arg5 = %21) -> (i32)  : i64 {
        %mask, %remaining_out = ascvec.update_mask %arg5 elem_bits 8 : !ascvec.mask
        %23 = arith.muli %arg3, %19 : i64
        %24 = arith.addi %23, %arg4 : i64
        %c1_i64_3 = arith.constant 1 : i64
        %25 = arith.muli %12, %c1_i64_3 : i64
        %c32_i64 = arith.constant 32 : i64
        %26 = arith.divsi %25, %c32_i64 : i64
        %c32_i64_4 = arith.constant 32 : i64
        %27 = arith.muli %arg3, %c32_i64_4 : i64
        %c32_i64_5 = arith.constant 32 : i64
        %28 = arith.divsi %arg4, %c32_i64_5 : i64
        %29 = arith.muli %28, %12 : i64
        %30 = arith.addi %27, %29 : i64
        %31 = arith.index_cast %24 : i64 to index
        %32 = cannir.raw_reg.load %arg1[%31] : !cannir.tensor<<ub, f8E4M3FN>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index -> <f8E4M3FN>
        %33 = arith.index_cast %30 : i64 to index
        %34 = arith.index_cast %26 : i64 to index
        %c0 = arith.constant 0 : index
        cannir.raw_reg.store_strided %arg0[%33], %32, %mask, %34, %c0 : !cannir.tensor<<ub, f8E4M3FN>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, <f8E4M3FN>, !ascvec.mask
        scf.yield %remaining_out : i32
      }
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
  func.func @ub_format_convert_f8e4m3_nz2nd(%arg0: !cannir.tensor<<ub, f8E4M3FN>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, f8E4M3FN>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg2: !cannir.copy_engine<nz2nd, f8E4M3FN>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = true, can_front_fuse = "false", vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {attr_values = ["nz2nd"], op = "ub_format_convert", operand_dtypes = ["f8e4m3", "f8e4m3", "copy_engine:nz2nd"]}} {
    %0 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f8E4M3FN>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_stride %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %7 = cannir.extract_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f8E4M3FN>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %8 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %9 = cannir.extract_dim %8[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %10 = cannir.extract_dim %8[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %11 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %12 = cannir.extract_dim %11[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %13 = cannir.extract_dim %11[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %14 = cannir.extract_physical_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f8E4M3FN>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %15 = cannir.extract_stride %14 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %16 = cannir.extract_dim %15[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %17 = cannir.extract_dim %15[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c0_i64 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    scf.for %arg3 = %c0_i64 to %9 step %c1_i64  : i64 {
      %18 = arith.trunci %13 : i64 to i32
      %c0_i64_0 = arith.constant 0 : i64
      %c256_i64 = arith.constant 256 : i64
      %19 = scf.for %arg4 = %c0_i64_0 to %13 step %c256_i64 iter_args(%arg5 = %18) -> (i32)  : i64 {
        %mask, %remaining_out = ascvec.update_mask %arg5 elem_bits 8 : !ascvec.mask
        %20 = arith.muli %arg3, %16 : i64
        %21 = arith.addi %20, %arg4 : i64
        %c1_i64_1 = arith.constant 1 : i64
        %22 = arith.muli %5, %c1_i64_1 : i64
        %c32_i64 = arith.constant 32 : i64
        %23 = arith.divsi %22, %c32_i64 : i64
        %c32_i64_2 = arith.constant 32 : i64
        %24 = arith.muli %arg3, %c32_i64_2 : i64
        %25 = arith.muli %arg4, %5 : i64
        %c8_i64 = arith.constant 8 : i64
        %26 = arith.muli %25, %c8_i64 : i64
        %c1_i64_3 = arith.constant 1 : i64
        %27 = arith.divsi %26, %c1_i64_3 : i64
        %28 = arith.addi %24, %27 : i64
        %29 = arith.index_cast %28 : i64 to index
        %30 = arith.index_cast %23 : i64 to index
        %c0 = arith.constant 0 : index
        %31 = cannir.raw_reg.load_strided %arg1[%29], %mask, %30, %c0 : !cannir.tensor<<ub, f8E4M3FN>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, !ascvec.mask -> <f8E4M3FN>
        %32 = arith.index_cast %21 : i64 to index
        cannir.raw_reg.store %arg0[%32], %31, %mask : !cannir.tensor<<ub, f8E4M3FN>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index, <f8E4M3FN>, !ascvec.mask
        scf.yield %remaining_out : i32
      }
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
  func.func @ub_format_convert_f8e5m2_nd2nz(%arg0: !cannir.tensor<<ub, f8E5M2>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, f8E5M2>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg2: !cannir.copy_engine<nd2nz, f8E5M2>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = "false", can_front_fuse = true, vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {attr_values = ["nd2nz"], op = "ub_format_convert", operand_dtypes = ["f8e5m2", "f8e5m2", "copy_engine:nd2nz"]}} {
    %0 = cannir.extract_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f8E5M2>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %7 = cannir.extract_physical_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f8E5M2>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %8 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %9 = cannir.extract_dim %8[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %10 = cannir.extract_dim %8[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %11 = cannir.extract_stride %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %12 = cannir.extract_dim %11[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %13 = cannir.extract_dim %11[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c16_i64 = arith.constant 16 : i64
    %14 = arith.addi %2, %c16_i64 : i64
    %c1_i64 = arith.constant 1 : i64
    %15 = arith.subi %14, %c1_i64 : i64
    %c16_i64_0 = arith.constant 16 : i64
    %16 = arith.divsi %15, %c16_i64_0 : i64
    %17 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f8E5M2>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %18 = cannir.extract_stride %17 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %19 = cannir.extract_dim %18[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %20 = cannir.extract_dim %18[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c0_i64 = arith.constant 0 : i64
    %c1_i64_1 = arith.constant 1 : i64
    scf.for %arg3 = %c0_i64 to %2 step %c1_i64_1  : i64 {
      %21 = arith.trunci %6 : i64 to i32
      %c0_i64_2 = arith.constant 0 : i64
      %c256_i64 = arith.constant 256 : i64
      %22 = scf.for %arg4 = %c0_i64_2 to %6 step %c256_i64 iter_args(%arg5 = %21) -> (i32)  : i64 {
        %mask, %remaining_out = ascvec.update_mask %arg5 elem_bits 8 : !ascvec.mask
        %23 = arith.muli %arg3, %19 : i64
        %24 = arith.addi %23, %arg4 : i64
        %c1_i64_3 = arith.constant 1 : i64
        %25 = arith.muli %12, %c1_i64_3 : i64
        %c32_i64 = arith.constant 32 : i64
        %26 = arith.divsi %25, %c32_i64 : i64
        %c32_i64_4 = arith.constant 32 : i64
        %27 = arith.muli %arg3, %c32_i64_4 : i64
        %c32_i64_5 = arith.constant 32 : i64
        %28 = arith.divsi %arg4, %c32_i64_5 : i64
        %29 = arith.muli %28, %12 : i64
        %30 = arith.addi %27, %29 : i64
        %31 = arith.index_cast %24 : i64 to index
        %32 = cannir.raw_reg.load %arg1[%31] : !cannir.tensor<<ub, f8E5M2>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index -> <f8E5M2>
        %33 = arith.index_cast %30 : i64 to index
        %34 = arith.index_cast %26 : i64 to index
        %c0 = arith.constant 0 : index
        cannir.raw_reg.store_strided %arg0[%33], %32, %mask, %34, %c0 : !cannir.tensor<<ub, f8E5M2>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, <f8E5M2>, !ascvec.mask
        scf.yield %remaining_out : i32
      }
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
  func.func @ub_format_convert_f8e5m2_nz2nd(%arg0: !cannir.tensor<<ub, f8E5M2>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, f8E5M2>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg2: !cannir.copy_engine<nz2nd, f8E5M2>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = true, can_front_fuse = "false", vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {attr_values = ["nz2nd"], op = "ub_format_convert", operand_dtypes = ["f8e5m2", "f8e5m2", "copy_engine:nz2nd"]}} {
    %0 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f8E5M2>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_stride %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %7 = cannir.extract_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f8E5M2>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %8 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %9 = cannir.extract_dim %8[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %10 = cannir.extract_dim %8[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %11 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %12 = cannir.extract_dim %11[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %13 = cannir.extract_dim %11[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %14 = cannir.extract_physical_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, f8E5M2>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %15 = cannir.extract_stride %14 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %16 = cannir.extract_dim %15[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %17 = cannir.extract_dim %15[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c0_i64 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    scf.for %arg3 = %c0_i64 to %9 step %c1_i64  : i64 {
      %18 = arith.trunci %13 : i64 to i32
      %c0_i64_0 = arith.constant 0 : i64
      %c256_i64 = arith.constant 256 : i64
      %19 = scf.for %arg4 = %c0_i64_0 to %13 step %c256_i64 iter_args(%arg5 = %18) -> (i32)  : i64 {
        %mask, %remaining_out = ascvec.update_mask %arg5 elem_bits 8 : !ascvec.mask
        %20 = arith.muli %arg3, %16 : i64
        %21 = arith.addi %20, %arg4 : i64
        %c1_i64_1 = arith.constant 1 : i64
        %22 = arith.muli %5, %c1_i64_1 : i64
        %c32_i64 = arith.constant 32 : i64
        %23 = arith.divsi %22, %c32_i64 : i64
        %c32_i64_2 = arith.constant 32 : i64
        %24 = arith.muli %arg3, %c32_i64_2 : i64
        %25 = arith.muli %arg4, %5 : i64
        %c8_i64 = arith.constant 8 : i64
        %26 = arith.muli %25, %c8_i64 : i64
        %c1_i64_3 = arith.constant 1 : i64
        %27 = arith.divsi %26, %c1_i64_3 : i64
        %28 = arith.addi %24, %27 : i64
        %29 = arith.index_cast %28 : i64 to index
        %30 = arith.index_cast %23 : i64 to index
        %c0 = arith.constant 0 : index
        %31 = cannir.raw_reg.load_strided %arg1[%29], %mask, %30, %c0 : !cannir.tensor<<ub, f8E5M2>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, !ascvec.mask -> <f8E5M2>
        %32 = arith.index_cast %21 : i64 to index
        cannir.raw_reg.store %arg0[%32], %31, %mask : !cannir.tensor<<ub, f8E5M2>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index, <f8E5M2>, !ascvec.mask
        scf.yield %remaining_out : i32
      }
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
  func.func @ub_format_convert_i16_nd2nz(%arg0: !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg2: !cannir.copy_engine<nd2nz, i16>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = "false", can_front_fuse = true, vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {attr_values = ["nd2nz"], op = "ub_format_convert", operand_dtypes = ["i16", "i16", "copy_engine:nd2nz"]}} {
    %0 = cannir.extract_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %7 = cannir.extract_physical_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %8 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %9 = cannir.extract_dim %8[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %10 = cannir.extract_dim %8[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %11 = cannir.extract_stride %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %12 = cannir.extract_dim %11[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %13 = cannir.extract_dim %11[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c16_i64 = arith.constant 16 : i64
    %14 = arith.addi %2, %c16_i64 : i64
    %c1_i64 = arith.constant 1 : i64
    %15 = arith.subi %14, %c1_i64 : i64
    %c16_i64_0 = arith.constant 16 : i64
    %16 = arith.divsi %15, %c16_i64_0 : i64
    %17 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %18 = cannir.extract_stride %17 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %19 = cannir.extract_dim %18[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %20 = cannir.extract_dim %18[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c0_i64 = arith.constant 0 : i64
    %c1_i64_1 = arith.constant 1 : i64
    scf.for %arg3 = %c0_i64 to %2 step %c1_i64_1  : i64 {
      %21 = arith.trunci %6 : i64 to i32
      %c0_i64_2 = arith.constant 0 : i64
      %c128_i64 = arith.constant 128 : i64
      %22 = scf.for %arg4 = %c0_i64_2 to %6 step %c128_i64 iter_args(%arg5 = %21) -> (i32)  : i64 {
        %mask, %remaining_out = ascvec.update_mask %arg5 elem_bits 16 : !ascvec.mask
        %23 = arith.muli %arg3, %19 : i64
        %24 = arith.addi %23, %arg4 : i64
        %c2_i64 = arith.constant 2 : i64
        %25 = arith.muli %12, %c2_i64 : i64
        %c32_i64 = arith.constant 32 : i64
        %26 = arith.divsi %25, %c32_i64 : i64
        %c16_i64_3 = arith.constant 16 : i64
        %27 = arith.muli %arg3, %c16_i64_3 : i64
        %c16_i64_4 = arith.constant 16 : i64
        %28 = arith.divsi %arg4, %c16_i64_4 : i64
        %29 = arith.muli %28, %12 : i64
        %30 = arith.addi %27, %29 : i64
        %31 = arith.index_cast %24 : i64 to index
        %32 = cannir.raw_reg.load %arg1[%31] : !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index -> <i16>
        %33 = arith.index_cast %30 : i64 to index
        %34 = arith.index_cast %26 : i64 to index
        %c0 = arith.constant 0 : index
        cannir.raw_reg.store_strided %arg0[%33], %32, %mask, %34, %c0 : !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, <i16>, !ascvec.mask
        scf.yield %remaining_out : i32
      }
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
  func.func @ub_format_convert_i16_nz2nd(%arg0: !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg2: !cannir.copy_engine<nz2nd, i16>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = true, can_front_fuse = "false", vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {attr_values = ["nz2nd"], op = "ub_format_convert", operand_dtypes = ["i16", "i16", "copy_engine:nz2nd"]}} {
    %0 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_stride %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %7 = cannir.extract_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %8 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %9 = cannir.extract_dim %8[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %10 = cannir.extract_dim %8[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %11 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %12 = cannir.extract_dim %11[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %13 = cannir.extract_dim %11[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %14 = cannir.extract_physical_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %15 = cannir.extract_stride %14 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %16 = cannir.extract_dim %15[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %17 = cannir.extract_dim %15[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c0_i64 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    scf.for %arg3 = %c0_i64 to %9 step %c1_i64  : i64 {
      %18 = arith.trunci %13 : i64 to i32
      %c0_i64_0 = arith.constant 0 : i64
      %c128_i64 = arith.constant 128 : i64
      %19 = scf.for %arg4 = %c0_i64_0 to %13 step %c128_i64 iter_args(%arg5 = %18) -> (i32)  : i64 {
        %mask, %remaining_out = ascvec.update_mask %arg5 elem_bits 16 : !ascvec.mask
        %20 = arith.muli %arg3, %16 : i64
        %21 = arith.addi %20, %arg4 : i64
        %c2_i64 = arith.constant 2 : i64
        %22 = arith.muli %5, %c2_i64 : i64
        %c32_i64 = arith.constant 32 : i64
        %23 = arith.divsi %22, %c32_i64 : i64
        %c16_i64 = arith.constant 16 : i64
        %24 = arith.muli %arg3, %c16_i64 : i64
        %25 = arith.muli %arg4, %5 : i64
        %c8_i64 = arith.constant 8 : i64
        %26 = arith.muli %25, %c8_i64 : i64
        %c2_i64_1 = arith.constant 2 : i64
        %27 = arith.divsi %26, %c2_i64_1 : i64
        %28 = arith.addi %24, %27 : i64
        %29 = arith.index_cast %28 : i64 to index
        %30 = arith.index_cast %23 : i64 to index
        %c0 = arith.constant 0 : index
        %31 = cannir.raw_reg.load_strided %arg1[%29], %mask, %30, %c0 : !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, !ascvec.mask -> <i16>
        %32 = arith.index_cast %21 : i64 to index
        cannir.raw_reg.store %arg0[%32], %31, %mask : !cannir.tensor<<ub, i16>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index, <i16>, !ascvec.mask
        scf.yield %remaining_out : i32
      }
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
  func.func @ub_format_convert_i32_nd2nz(%arg0: !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg2: !cannir.copy_engine<nd2nz, i32>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = "false", can_front_fuse = true, vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {attr_values = ["nd2nz"], op = "ub_format_convert", operand_dtypes = ["i32", "i32", "copy_engine:nd2nz"]}} {
    %0 = cannir.extract_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %7 = cannir.extract_physical_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %8 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %9 = cannir.extract_dim %8[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %10 = cannir.extract_dim %8[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %11 = cannir.extract_stride %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %12 = cannir.extract_dim %11[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %13 = cannir.extract_dim %11[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c16_i64 = arith.constant 16 : i64
    %14 = arith.addi %2, %c16_i64 : i64
    %c1_i64 = arith.constant 1 : i64
    %15 = arith.subi %14, %c1_i64 : i64
    %c16_i64_0 = arith.constant 16 : i64
    %16 = arith.divsi %15, %c16_i64_0 : i64
    %17 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %18 = cannir.extract_stride %17 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %19 = cannir.extract_dim %18[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %20 = cannir.extract_dim %18[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c0_i64 = arith.constant 0 : i64
    %c1_i64_1 = arith.constant 1 : i64
    scf.for %arg3 = %c0_i64 to %2 step %c1_i64_1  : i64 {
      %21 = arith.trunci %6 : i64 to i32
      %c0_i64_2 = arith.constant 0 : i64
      %c64_i64 = arith.constant 64 : i64
      %22 = scf.for %arg4 = %c0_i64_2 to %6 step %c64_i64 iter_args(%arg5 = %21) -> (i32)  : i64 {
        %mask, %remaining_out = ascvec.update_mask %arg5 : !ascvec.mask
        %23 = arith.muli %arg3, %19 : i64
        %24 = arith.addi %23, %arg4 : i64
        %c4_i64 = arith.constant 4 : i64
        %25 = arith.muli %12, %c4_i64 : i64
        %c32_i64 = arith.constant 32 : i64
        %26 = arith.divsi %25, %c32_i64 : i64
        %c8_i64 = arith.constant 8 : i64
        %27 = arith.muli %arg3, %c8_i64 : i64
        %c8_i64_3 = arith.constant 8 : i64
        %28 = arith.divsi %arg4, %c8_i64_3 : i64
        %29 = arith.muli %28, %12 : i64
        %30 = arith.addi %27, %29 : i64
        %31 = arith.index_cast %24 : i64 to index
        %32 = cannir.raw_reg.load %arg1[%31] : !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index -> <i32>
        %33 = arith.index_cast %30 : i64 to index
        %34 = arith.index_cast %26 : i64 to index
        %c0 = arith.constant 0 : index
        cannir.raw_reg.store_strided %arg0[%33], %32, %mask, %34, %c0 : !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, <i32>, !ascvec.mask
        scf.yield %remaining_out : i32
      }
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
  func.func @ub_format_convert_i32_nz2nd(%arg0: !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg1: !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, %arg2: !cannir.copy_engine<nz2nd, i32>) attributes {cannir.cube_state_mode = 0 : i32, cannir.device, cannir.template_info = {can_back_fuse = true, can_front_fuse = "false", vload_type = "normal", vstore_type = "normal"}, cannir.template_method = "default", cannir.template_signature = {attr_values = ["nz2nd"], op = "ub_format_convert", operand_dtypes = ["i32", "i32", "copy_engine:nz2nd"]}} {
    %0 = cannir.extract_physical_layout %arg1 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %1 = cannir.extract_shape %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %2 = cannir.extract_dim %1[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %3 = cannir.extract_dim %1[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %4 = cannir.extract_stride %0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %5 = cannir.extract_dim %4[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %6 = cannir.extract_dim %4[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %7 = cannir.extract_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %8 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %9 = cannir.extract_dim %8[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %10 = cannir.extract_dim %8[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %11 = cannir.extract_shape %7 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %12 = cannir.extract_dim %11[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %13 = cannir.extract_dim %11[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.shape<(-1, -1)>
    %14 = cannir.extract_physical_layout %arg0 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>
    %15 = cannir.extract_stride %14 {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : <<(-1, -1)>, <(-1, -1)>> -> <(-1, -1)>
    %16 = cannir.extract_dim %15[0] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %17 = cannir.extract_dim %15[1] {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64} : !cannir.stride<(-1, -1)>
    %c0_i64 = arith.constant 0 : i64
    %c1_i64 = arith.constant 1 : i64
    scf.for %arg3 = %c0_i64 to %9 step %c1_i64  : i64 {
      %18 = arith.trunci %13 : i64 to i32
      %c0_i64_0 = arith.constant 0 : i64
      %c64_i64 = arith.constant 64 : i64
      %19 = scf.for %arg4 = %c0_i64_0 to %13 step %c64_i64 iter_args(%arg5 = %18) -> (i32)  : i64 {
        %mask, %remaining_out = ascvec.update_mask %arg5 : !ascvec.mask
        %20 = arith.muli %arg3, %16 : i64
        %21 = arith.addi %20, %arg4 : i64
        %c4_i64 = arith.constant 4 : i64
        %22 = arith.muli %5, %c4_i64 : i64
        %c32_i64 = arith.constant 32 : i64
        %23 = arith.divsi %22, %c32_i64 : i64
        %c8_i64 = arith.constant 8 : i64
        %24 = arith.muli %arg3, %c8_i64 : i64
        %25 = arith.muli %arg4, %5 : i64
        %c8_i64_1 = arith.constant 8 : i64
        %26 = arith.muli %25, %c8_i64_1 : i64
        %c4_i64_2 = arith.constant 4 : i64
        %27 = arith.divsi %26, %c4_i64_2 : i64
        %28 = arith.addi %24, %27 : i64
        %29 = arith.index_cast %28 : i64 to index
        %30 = arith.index_cast %23 : i64 to index
        %c0 = arith.constant 0 : index
        %31 = cannir.raw_reg.load_strided %arg1[%29], %mask, %30, %c0 : !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, !ascvec.mask -> <i32>
        %32 = arith.index_cast %21 : i64 to index
        cannir.raw_reg.store %arg0[%32], %31, %mask : !cannir.tensor<<ub, i32>, <<(-1, -1)>, <(-1, -1)>>, <<(-1, -1)>, <(-1, -1)>>, identity>, index, <i32>, !ascvec.mask
        scf.yield %remaining_out : i32
      }
    } {cannir.vf_group = 0 : i64, cannir.vf_mode = "raw", cannir.vf_unroll = 1 : i64}
    return
  }
}
