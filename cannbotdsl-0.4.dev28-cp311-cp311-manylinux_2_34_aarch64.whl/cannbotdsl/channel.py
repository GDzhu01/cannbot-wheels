# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Bounded ring buffer Channel for NPU pipeline programming.

Channel provides a dual-cursor ring buffer abstraction over on-chip buffer
slots, replacing manual asc_lock/asc_unlock and sync_intra management.

Producer: acquire() → fill → commit()   [advances write_cursor]
Consumer: wait()    → use  → release()  [advances read_cursor]

For single-slot VF-internal scratch space (no ring-buffer semantics), use
``cannbotdsl.buffer.Buffer``. Buffer and Channel allocation declarations share
the pass-side address planner, and ``reinterpret`` creates a same-storage typed
alias without requesting another allocation.
"""
from __future__ import annotations

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir

from cannbotdsl._onchip import (
    _normalize_shape_capacity,
    _physical_layout_spec,
)
from cannbotdsl.arena import (
    ChannelArena,
    _CUBE_MEM_LOCS,
    _current_channel_arena,
    _reset_current_channel_arena,
    _set_current_channel_arena,
    channel_rewind,
)
from cannbotdsl.types._numeric import Int64
from cannbotdsl.ir_transport import unwrap_operand
from cannbotdsl.types import MemLoc, ChannelKind, Tensor


@ir.register_value_caster(cannir.ChannelType.get_static_typeid())
class _ChannelValue(ir.Value):
    """SSA-level Channel value. Auto-cast from ChannelType SSA values."""

    @property
    def dtype(self):
        memref_ty = cannir.TensorType(self.type.element)
        from cannbotdsl.core.contracts.elements import dtype_for_storage_mlir_type

        return dtype_for_storage_mlir_type(
            cannir.PointerType(memref_ty.pointer).dtype
        )

    @property
    def memloc(self):
        memref_ty = cannir.TensorType(self.type.element)
        return cannir.PointerType(memref_ty.pointer).memloc

    @property
    def layout(self):
        return cannir.extract_layout(self)

    @property
    def physical_layout(self):
        return cannir.extract_physical_layout(self)

    @property
    def shape(self):
        return self.layout.shape

    @property
    def stride(self):
        return self.layout.stride

    @property
    def physical_shape(self):
        return self.physical_layout.shape

    @property
    def physical_stride(self):
        return self.physical_layout.stride

    @property
    def depth(self):
        return self.type.depth

    @property
    def element(self):
        return self.type.element

    @property
    def kind(self):
        return self.type.kind

    @property
    def layout_map_kind(self):
        from cannbotdsl.tensor import LayoutMapKind

        memref_ty = cannir.TensorType(self.type.element)
        return LayoutMapKind(memref_ty.layout_map_kind)

    @property
    def logical_format(self):
        from cannbotdsl.tensor import LayoutMapKind

        kind = self.layout_map_kind
        if kind in (LayoutMapKind.ND2NZ, LayoutMapKind.DN2NZ):
            return "nd"
        return "nd"

    @property
    def physical_format(self):
        from cannbotdsl.tensor import LayoutMapKind

        kind = self.layout_map_kind
        if kind == LayoutMapKind.ND2NZ:
            return "nz"
        if kind == LayoutMapKind.DN2NZ:
            return "zn"
        return "nd"

    @property
    def data_format(self):
        return self.physical_format


def _build_typed_channel_ir(
    mem_loc, dtype, shape, kind, data_format, n1_pad, stride,
    fixed_addr, buf_ids, sync_ids, sync_epoch, *, source_slots=None,
):
    """Build a typed channel from pass-planned slots or same-storage aliases."""
    from cannbotdsl.tensor import (
        _make_onchip_allocation,
        _onchip_tensor_type,
        make_layout,
    )

    physical_shape, physical_stride = _physical_layout_spec(
        dtype, shape, data_format, n1_pad, mem_loc=mem_loc
    )
    if data_format == "nd" and physical_stride is None and stride is not None:
        physical_stride = stride
    logical_layout = (
        make_layout(shape) if stride is None
        else make_layout(shape, stride=stride)
    )
    physical_layout = (
        make_layout(physical_shape)
        if physical_stride is None
        else make_layout(physical_shape, stride=physical_stride)
    )
    if source_slots is None:
        raw_slots = _make_onchip_allocation(
            dtype,
            mem_loc,
            logical_layout,
            physical_layout,
            data_format=data_format,
            slots=len(buf_ids),
            fixed_addr=fixed_addr,
        )
    else:
        if len(source_slots) != len(buf_ids):
            raise ValueError("channel alias slot count must match buf_ids")
        from cannbotdsl.core.contracts.elements import storage_mlir_type_for_dtype

        storage_type = storage_mlir_type_for_dtype(dtype)
        dtype_attr = ir.TypeAttr.get(storage_type)
        result_type = _onchip_tensor_type(
            dtype,
            mem_loc,
            logical_layout,
            physical_layout,
            data_format=data_format,
        )
        raw_slots = tuple(
            cannir.reinterpret_view(
                result_type,
                unwrap_operand(source),
                dtype=dtype_attr,
            )
            for source in source_slots
        )

    slots = []
    for memref, bid in zip(raw_slots, buf_ids):
        slot = cannir.make_buf(unwrap_operand(memref), Int64(bid))
        slots.append(unwrap_operand(slot))

    attrs = {}
    if kind == ChannelKind.CrossCore:
        attrs["cannir.channel.sync_ids"] = ir.DenseI64ArrayAttr.get(sync_ids)
        attrs["cannir.channel.epoch"] = ir.IntegerAttr.get(
            ir.IntegerType.get_signless(64), sync_epoch
        )
    raw_op = cannir.MakeChannelOp.build_generic(
        operands=slots, attributes=attrs,
    )
    return raw_op.results[0], tuple(unwrap_operand(slot) for slot in raw_slots)


class Channel:
    """Bounded ring buffer: depth-N slot pool with dual cursors.

    Producer: acquire() → fill → commit()   [advances write_cursor]
    Consumer: wait()    → use  → release()  [advances read_cursor]
    """

    def __init_subclass__(cls, **kwargs):
        del cls, kwargs
        raise TypeError("Channel is a sealed CANNBotDSL resource type")

    def __init__(self, mem_loc, shape=None, dtype=None, *, depth,
                 capacity=None,
                 kind=ChannelKind.SameCore,
                 addr=None,
                 stride=None, data_format=None, n1_pad=0):
        if dtype is None or shape is None:
            raise TypeError("Channel requires shape and dtype")
        # Validate an explicit address before consuming scarce buf/sync IDs.
        if addr is not None:
            if type(addr) is not int:
                raise TypeError(
                    "Channel addr must be a non-negative Python int or None, "
                    f"got {type(addr).__name__}"
                )
            if addr < 0:
                raise ValueError(
                    f"Channel addr must be non-negative, got {addr}"
                )
        from cannbotdsl.core.contracts.elements import normalize_storage_dtype
        from cannbotdsl.tensor import _infer_contiguous_stride

        dtype = normalize_storage_dtype(dtype)
        shape, capacity, has_dynamic_shape = _normalize_shape_capacity(
            shape, capacity, owner="Channel"
        )
        if stride is None:
            capacity_stride = _infer_contiguous_stride(capacity)
            has_dynamic_stride = False
        else:
            if not isinstance(stride, tuple):
                raise TypeError(
                    "Channel stride must be a flat tuple of positive ints"
                )
            if len(stride) != len(capacity):
                raise ValueError(
                    f"Channel stride rank {len(stride)} does not match shape "
                    f"rank {len(capacity)}"
                )
            has_dynamic_stride = False
            for index, value in enumerate(stride):
                if type(value) is int:
                    if value <= 0:
                        raise ValueError(
                            f"Channel stride[{index}] must be positive, got {value}"
                        )
                    continue
                if isinstance(value, ir.Value):
                    value_type = value.type
                    if not (
                        isinstance(value_type, ir.IntegerType)
                        and value_type.width == 64
                        and value_type.is_signless
                    ):
                        raise TypeError(
                            f"Channel stride[{index}] SSA value must have "
                            f"canonical signless i64 type, got {value_type}"
                        )
                    has_dynamic_stride = True
                    continue
                else:
                    raise TypeError(
                        f"Channel stride[{index}] must be a positive Python "
                        f"int or i64 SSA value, got {type(value).__name__}"
                    )
            capacity_stride = stride
        if (has_dynamic_shape or shape != capacity) and has_dynamic_stride:
            raise TypeError(
                "Channel dynamic shape requires a static backing stride"
            )
        arena = _current_channel_arena()
        if mem_loc == MemLoc.UB and arena._ub_space_root is not None:
            raise ValueError(
                "ordinary UB Channel is not allowed after dsl.UB.view(); "
                "construct it from static UB views with make_channel"
            )
        if depth < 1:
            raise ValueError(f"Channel depth must be >= 1, got {depth}")
        is_cross_core = (kind == ChannelKind.CrossCore)
        if is_cross_core and depth > 8:
            raise ValueError(
                f"cross-core Channel depth must be <= 8, got {depth} "
                "(per-Channel select-chain policy; the allocation epoch has "
                "16 logical sync ids; see channel_design.md §7.5)"
            )
        self._kind = kind
        self._depth = depth
        self._mem_loc = mem_loc
        self._dtype = dtype
        self._shape = shape
        self._capacity = capacity
        self._has_dynamic_shape = has_dynamic_shape
        self._stride = capacity_stride
        if data_format is None:
            data_format = (
                "nz"
                if mem_loc in _CUBE_MEM_LOCS and mem_loc != MemLoc.BIAS
                else "nd"
            )
        self._data_format = data_format
        self._n1_pad = n1_pad

        self._buf_ids = arena.alloc_buf_ids(mem_loc, depth)
        if is_cross_core:
            # One sync_id per slot, shared by both directions: producer/consumer
            # alternate arrive/wait on the same id (the direction is encoded by
            # which core issues arrive vs wait, not by a separate id). See
            # channel_design.md / the hand-written FA baseline.
            self._sync_ids = arena.alloc_sync_ids(depth)
            self._sync_epoch = arena._sync_epoch
        else:
            self._sync_ids = None
            self._sync_epoch = None

        # A typed channel declares its full per-slot tile shape. When a writer's
        # source carries a smaller (tail) actual shape, the cannir-infer-layout
        # pass rewrites the channel's per-access views to that runtime extent
        # (docs/design/Layout_Inference.md).
        self._addr = addr
        root, self._slot_storage_values = _build_typed_channel_ir(
            mem_loc, dtype, capacity, kind, data_format, n1_pad,
            capacity_stride,
            addr, self._buf_ids, self._sync_ids, self._sync_epoch,
        )
        self._root_ir_value = root
        self._layout_ir_value = root
        self._dynamic_tiler = None
        self._manual_slot_roots = {}
        if has_dynamic_shape or shape != capacity:
            from cannbotdsl.tensor import local_slice, make_bounded_tiler

            self._dynamic_tiler = make_bounded_tiler(
                shape,
                capacity,
                (1,) * len(capacity),
            )
            view = local_slice(
                Channel._view(root),
                self._dynamic_tiler,
                stride=capacity_stride,
            )
            self._layout_ir_value = view._ir_value
            self._layout_ir_value.owner.attributes[
                "cannir.channel.declared_layout"
            ] = ir.UnitAttr.get()
        self._ir_value = root

    def acquire(self):
        self._require_manual_transaction("acquire")
        op = cannir.ChannelAcquireOp(self._root_ir_value)
        return self._manual_slot_view(op.res)

    def commit(self, slot):
        self._require_manual_transaction("commit")
        if not isinstance(slot, Tensor):
            raise TypeError(
                "Channel.commit expects the Tensor returned by acquire(), "
                f"got {type(slot).__name__}"
            )
        cannir.channel_commit(
            self._root_ir_value,
            self._manual_root_slot(slot, "commit"),
        )

    def wait(self):
        self._require_manual_transaction("wait")
        op = cannir.ChannelWaitOp(self._root_ir_value)
        return self._manual_slot_view(op.res)

    def release(self, slot):
        self._require_manual_transaction("release")
        if not isinstance(slot, Tensor):
            raise TypeError(
                "Channel.release expects the Tensor returned by wait(), "
                f"got {type(slot).__name__}"
            )
        cannir.channel_release(
            self._root_ir_value,
            self._manual_root_slot(slot, "release"),
        )

    def _manual_slot_view(self, root_slot):
        if self._dynamic_tiler is None:
            return root_slot
        from cannbotdsl.tensor import local_slice

        slot = local_slice(
            Tensor._from_ir(root_slot),
            self._dynamic_tiler,
            stride=self._stride,
        )
        self._manual_slot_roots[id(slot)] = unwrap_operand(root_slot)
        return slot

    def _manual_root_slot(self, slot, primitive):
        if self._dynamic_tiler is None:
            return unwrap_operand(slot)
        root_slot = self._manual_slot_roots.pop(id(slot), None)
        if root_slot is None:
            raise ValueError(
                f"Channel.{primitive} expects the exact Tensor returned by "
                f"this dynamic Channel's acquire()/wait()"
            )
        return root_slot

    @property
    def dtype(self):
        memref_ty = cannir.TensorType(self._ir_value.type.element)
        from cannbotdsl.core.contracts.elements import dtype_for_storage_mlir_type

        return dtype_for_storage_mlir_type(
            cannir.PointerType(memref_ty.pointer).dtype
        )

    @property
    def layout(self):
        return cannir.extract_layout(self._layout_ir_value)

    @property
    def physical_layout(self):
        return cannir.extract_physical_layout(self._layout_ir_value)

    @property
    def shape(self):
        return self.layout.shape

    @property
    def stride(self):
        return self.layout.stride

    @property
    def physical_shape(self):
        return self.physical_layout.shape

    @property
    def physical_stride(self):
        return self.physical_layout.stride

    @classmethod
    def _view(cls, ir_value):
        """Lightweight address/shape view of a Channel.

        Holds only the channel-typed view SSA value. The four transaction
        primitives are meaningless on a view: the data op that writes/reads it
        is bracketed against the ROOT channel by
        cannir-resolve-channel-operands (channel_first_class_design_v2 §9.4).
        """
        ch = object.__new__(cls)
        ch._ir_value = ir_value
        ch._layout_ir_value = ir_value
        ch._is_view = True
        return ch

    def _require_manual_transaction(self, prim):
        if getattr(self, "_is_view", False):
            raise RuntimeError(
                f"cannot {prim}() a Channel view; pass it "
                "to a data op (e.g. mem_copy) instead — the producer transaction is "
                "synthesized on the underlying channel"
            )

    def reinterpret(self, dtype, shape=None):
        """Typed same-storage alias of this channel's slots.

        The alias keeps the original allocation, buffer IDs, and sync IDs while
        emitting an IR channel whose dtype and shape describe the new view.
        """
        from cannbotdsl.core.contracts.elements import normalize_storage_dtype

        if getattr(self, "_ub_space_slots", False):
            raise NotImplementedError(
                "use dtype views before make_channel for UB-space slots"
            )

        if self._has_dynamic_shape or self._shape != self._capacity:
            raise NotImplementedError(
                "Channel.reinterpret does not support dynamic-layout Channel values"
            )
        dtype = normalize_storage_dtype(dtype)
        new_shape = shape if shape is not None else self._shape
        ch = object.__new__(Channel)
        ch._ir_value = self._ir_value
        ch._mem_loc = self._mem_loc
        ch._dtype = dtype
        ch._shape = new_shape
        ch._capacity = new_shape
        ch._has_dynamic_shape = False
        ch._data_format = self._data_format
        ch._n1_pad = self._n1_pad
        ch._stride = None
        ch._depth = self._depth
        ch._kind = self._kind
        ch._buf_ids = self._buf_ids
        ch._sync_ids = self._sync_ids
        ch._sync_epoch = self._sync_epoch
        ch._addr = self._addr
        ch._ir_value, ch._slot_storage_values = _build_typed_channel_ir(
            self._mem_loc, dtype, new_shape, self._kind,
            self._data_format, self._n1_pad, None, None,
            self._buf_ids, self._sync_ids, self._sync_epoch,
            source_slots=self._slot_storage_values,
        )
        ch._root_ir_value = ch._ir_value
        ch._layout_ir_value = ch._ir_value
        ch._dynamic_tiler = None
        ch._manual_slot_roots = {}
        return ch

    @property
    def depth(self):
        return self._ir_value.type.depth

    @property
    def is_cross_core(self):
        return self._ir_value.type.kind == int(ChannelKind.CrossCore)

    def __repr__(self):
        capacity = (
            f", capacity={self._capacity}"
            if self._capacity != self._shape
            else ""
        )
        return (f"Channel({self._mem_loc}, {self._shape}, {self._dtype}, "
                f"depth={self._depth}{capacity})")
