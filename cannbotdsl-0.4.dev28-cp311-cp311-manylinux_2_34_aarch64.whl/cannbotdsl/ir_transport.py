# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Private semantic-value/SSA transport boundary.

Only framework-owned value kinds are recognized.  This module intentionally
does not expose a registry or a duck-typed protocol: supporting a new semantic
value requires an explicit branch and an explicit rebuild policy here.
"""

from __future__ import annotations

from collections.abc import Iterable


def _raw_carrier(value):
    from cannbotdsl.types import Layout, Tensor

    if isinstance(value, (Tensor, Layout)):
        return object.__getattribute__(value, "_ssa_value")
    from cannbotdsl.types.tensor_list import TensorList

    if type(value) is TensorList:
        return object.__getattribute__(value, "_ssa_value")
    from cannbotdsl.channel import Channel

    if type(value) is Channel:
        return object.__getattribute__(value, "_ir_value")

    import cannbotdsl._mlir.ir as ir

    if isinstance(value, ir.Value):
        return value
    raise TypeError(
        "CANNIR operands must be framework Tensor, TensorList, Layout, Channel, "
        f"or an MLIR value; got {type(value).__name__}"
    )


def unwrap_operand(value):
    """Return the backend operand for one whitelisted semantic value."""

    return _raw_carrier(value)


def extract_ir_values(value) -> tuple:
    """Extract the SSA carriers owned by one supported dynamic leaf."""

    import cannbotdsl._mlir.ir as ir
    from cannbotdsl.types import Layout, Tensor

    if isinstance(value, (Tensor, Layout)):
        carrier = _raw_carrier(value)
        if not isinstance(carrier, ir.Value):  # pragma: no cover - invariant
            raise TypeError("framework semantic value has no MLIR carrier")
        return (carrier,)
    from cannbotdsl.types.tensor_list import TensorList

    if type(value) is TensorList:
        carrier = _raw_carrier(value)
        if not isinstance(carrier, ir.Value):  # pragma: no cover - invariant
            raise TypeError("TensorList semantic value has no MLIR carrier")
        return (carrier,)
    if isinstance(value, ir.Value):
        return (value,)
    raise TypeError(f"unsupported dynamic value {type(value).__name__}")


def rebuild_ir_values(template, values: Iterable):
    """Rebuild one semantic leaf from carriers using a closed policy."""

    carriers = tuple(values)
    if len(carriers) != 1:
        raise ValueError(f"semantic leaf expects one carrier, got {len(carriers)}")
    carrier = carriers[0]

    from cannbotdsl.types import Layout, Tensor

    if type(template) is Tensor:
        return Tensor._from_ir(carrier)
    if type(template) is Layout:
        return Layout._from_ir(carrier)
    from cannbotdsl.types.tensor_list import TensorList

    if type(template) is TensorList:
        return TensorList._from_ir(
            carrier,
            contract=object.__getattribute__(template, "_contract"),
        )

    import cannbotdsl._mlir.ir as ir

    if isinstance(template, ir.Value):
        template_type = type(template)
        if template_type is ir.Value:
            return carrier
        return template_type(carrier)
    raise TypeError(f"unsupported semantic template {type(template).__name__}")


def semantic_value_tag(value) -> tuple[object, ...] | None:
    """Return a stable identity for a framework composition leaf."""

    from cannbotdsl.types import Layout, Tensor

    if type(value) is Tensor:
        return ("tensor",)
    if type(value) is Layout:
        return ("layout",)
    from cannbotdsl.types.tensor_list import TensorList

    if type(value) is TensorList:
        contract = object.__getattribute__(value, "_contract")
        return ("tensor_list", contract)
    return None


def join_tensor_operands(values: Iterable):
    """Validate one dynamic Tensor selection and choose its rebuild template."""

    candidates = tuple(values)
    if not candidates:
        raise ValueError("Cannot dynamically index an empty list")

    from cannbotdsl.types import Tensor

    first = candidates[0]
    if not isinstance(first, Tensor):
        raise TypeError(
            "Dynamic list indexing requires all elements to be Tensor, but "
            f"element 0 is {type(first).__name__}"
        )
    carriers = (unwrap_operand(first),)
    carrier_type = carriers[0].type
    for index, candidate in enumerate(candidates[1:], 1):
        if not isinstance(candidate, Tensor):
            raise TypeError(
                "Dynamic list indexing requires all elements to be Tensor, "
                f"but element {index} is {type(candidate).__name__}"
            )
        carrier = unwrap_operand(candidate)
        if carrier.type != carrier_type:
            raise ValueError(
                "All tensors must have the same type for dynamic indexing. "
                f"Element 0 has {carrier_type}, element {index} has "
                f"{carrier.type}"
            )
        carriers += (carrier,)

    return carrier_type, carriers, first


def rebuild_joined_tensor(template, carrier):
    """Rebuild the semantic result chosen by :func:`join_tensor_operands`."""

    if template is None:
        from cannbotdsl.types import Tensor

        return Tensor._from_ir(carrier)
    return rebuild_ir_values(template, (carrier,))


__all__: list[str] = []
