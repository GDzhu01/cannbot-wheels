# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software and is made available under the terms and
# conditions of CANN Open Software License Agreement Version 2.0 (the "License).
# See LICENSE for the full text of the License.

"""AICPU kernel frontend (Phase-1, source-to-source trace).

Python tiling function -> portable C++ body -> ``.aicpu`` device kernel +
``.asc`` host shim -> bisheng -> ``.so`` -> ctypes launch via ``<<<>>>``.
The same traced program runs on the host for golden cross-checks.
"""

from cannbotdsl.aicpu.interp import AicpuTraceError
from cannbotdsl.aicpu.kernel import aicpu_kernel
from cannbotdsl.aicpu.types import GmIn, GmOut, I32, I64, U32, U64
from cannbotdsl.aicpu.launcher import X86Buffer, current_raw_stream, pack_struct_bytes

__all__ = [
    "aicpu_kernel",
    "AicpuTraceError",
    "GmIn",
    "GmOut",
    "I32",
    "I64",
    "U32",
    "U64",
    "X86Buffer",
    "current_raw_stream",
    "pack_struct_bytes",
]
