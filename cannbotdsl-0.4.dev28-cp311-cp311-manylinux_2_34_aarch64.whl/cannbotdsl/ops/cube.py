# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software; you can redistribute it and/or modify it under the terms of
# CANN Open Software License Version 2.0.

"""Persistent Cube compute-control setters for Ascend 3510."""

from __future__ import annotations

from contextvars import ContextVar
from dataclasses import dataclass
from enum import IntEnum
from typing import Literal, TypeAlias, TypeVar

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir
from cannbotdsl.core.scalar_conversion import coerce_scalar_value
from cannbotdsl.types import ScalarValue


class HF32RoundingMode(IntEnum):
    NEAREST_AWAY = 0
    NEAREST_EVEN = 1
    NEAREST_ZERO = 0


class _HF32ComputeMode(IntEnum):
    DISABLED = 0
    NEAREST_AWAY = 1
    NEAREST_EVEN = 2
    DYNAMIC = 3


class _Cube8BitMode(IntEnum):
    FP8 = 0
    HIF8 = 1


class _MmadDirection(IntEnum):
    M = 0
    N = 1


class _UnknownState:
    __slots__ = ()

    def __repr__(self) -> str:
        return "Unknown"


_UNKNOWN = _UnknownState()
_HF32EnabledState: TypeAlias = bool | _UnknownState | None
_HF32RoundModeState: TypeAlias = _HF32ComputeMode | _UnknownState | None
_HF32DynamicModeState: TypeAlias = ir.Value | _UnknownState | None
_Cube8BitModeState: TypeAlias = _Cube8BitMode | _UnknownState | None
_MmadDirectionState: TypeAlias = _MmadDirection | _UnknownState | None
_StateValue = TypeVar("_StateValue")
_STATE_FIELDS = (
    "hf32_enabled",
    "hf32_round_mode",
    "hf32_dynamic_mode",
    "cube_8bit_mode",
    "direction",
)


@dataclass(frozen=True, slots=True)
class _CubeState:
    # None is the frontend-only Unset state. _UNKNOWN is introduced by dynamic
    # CFG merges and is never used as kernel entry state.
    # HF32 enablement and its rounding configuration are separate persistent
    # hardware state domains.  In particular, set_fp32_mode() disables HF32
    # but does not clear a previously selected rounding mode.
    hf32_enabled: _HF32EnabledState = None
    hf32_round_mode: _HF32RoundModeState = None
    hf32_dynamic_mode: _HF32DynamicModeState = None
    cube_8bit_mode: _Cube8BitModeState = None
    direction: _MmadDirectionState = None


@dataclass(slots=True)
class _CubeRegionFrame:
    kind: str
    entry: _CubeState
    child_exits: dict[str, _CubeState]
    child_touches: dict[str, set[str]]
    current_child: str | None = None


class _CubeRegionObserver:
    def __init__(self) -> None:
        self.frames: list[_CubeRegionFrame] = []

    def enter(self, kind, operation, region_info):
        del operation, region_info
        frame = _CubeRegionFrame(kind, _CURRENT_CUBE_STATE.get(), {}, {})
        self.frames.append(frame)
        return frame

    def exit(self, kind, operation, region_info, token, error):
        del kind, operation, region_info
        frame = self.frames.pop()
        if frame is not token:
            raise RuntimeError("Cube region observer stack is inconsistent")
        if error is not None:
            _CURRENT_CUBE_STATE.set(frame.entry)
            return
        if frame.kind == "if":
            then_state = frame.child_exits.get("then", frame.entry)
            else_state = frame.child_exits.get("else", frame.entry)
            outgoing = _merge_cube_states(then_state, else_state)
        elif frame.kind == "for":
            outgoing = _merge_cube_states(
                frame.entry, frame.child_exits.get("body", frame.entry)
            )
        elif frame.kind == "while":
            before = frame.child_exits.get("before", frame.entry)
            after = frame.child_exits.get("after", before)
            after_touches = frame.child_touches.get("after", set())
            before_touches = frame.child_touches.get("before", set())
            outgoing = _CubeState(
                hf32_enabled=_while_exit_value(
                    "hf32_enabled", frame.entry.hf32_enabled,
                    before.hf32_enabled, after.hf32_enabled,
                    before_touches, after_touches,
                ),
                hf32_round_mode=_while_exit_value(
                    "hf32_round_mode", frame.entry.hf32_round_mode,
                    before.hf32_round_mode, after.hf32_round_mode,
                    before_touches, after_touches,
                ),
                hf32_dynamic_mode=_while_exit_value(
                    "hf32_dynamic_mode", frame.entry.hf32_dynamic_mode,
                    before.hf32_dynamic_mode, after.hf32_dynamic_mode,
                    before_touches, after_touches,
                ),
                cube_8bit_mode=_while_exit_value(
                    "cube_8bit_mode", frame.entry.cube_8bit_mode,
                    before.cube_8bit_mode, after.cube_8bit_mode,
                    before_touches, after_touches,
                ),
                direction=_while_exit_value(
                    "direction", frame.entry.direction, before.direction,
                    after.direction, before_touches, after_touches,
                ),
            )
        else:
            outgoing = _CubeState(
                _UNKNOWN, _UNKNOWN, _UNKNOWN, _UNKNOWN, _UNKNOWN
            )
        _CURRENT_CUBE_STATE.set(outgoing)

    def enter_child(self, kind, child, operation, region_info):
        del kind, operation, region_info
        frame = self.frames[-1]
        if frame.current_child is not None:
            raise RuntimeError("Cube region children cannot overlap")
        entry = frame.entry
        if frame.kind == "while" and child == "after":
            entry = frame.child_exits.get("before", frame.entry)
        frame.current_child = child
        frame.child_touches[child] = set()
        return _CURRENT_CUBE_STATE.set(entry)

    def exit_child(self, kind, child, operation, region_info, token, error):
        del kind, operation, region_info
        frame = self.frames[-1]
        try:
            if error is None:
                frame.child_exits[child] = _CURRENT_CUBE_STATE.get()
        finally:
            _CURRENT_CUBE_STATE.reset(token)
            frame.current_child = None


@dataclass(slots=True)
class _CubeTrace:
    function: object
    saw_explicit: bool = False
    state_token: object | None = None
    observer: _CubeRegionObserver | None = None
    observer_token: object | None = None


_CURRENT_CUBE_STATE: ContextVar[_CubeState] = ContextVar(
    "cannbotdsl_cube_state", default=_CubeState()
)
_CURRENT_CUBE_TRACE: ContextVar[_CubeTrace | None] = ContextVar(
    "cannbotdsl_cube_trace", default=None
)


def _enum_attr(value: IntEnum) -> ir.IntegerAttr:
    return ir.IntegerAttr.get(ir.IntegerType.get_signless(32), int(value))


def _mark_explicit() -> None:
    trace = _CURRENT_CUBE_TRACE.get()
    if trace is not None:
        trace.saw_explicit = True


def _same_state_value(lhs: object, rhs: object) -> bool:
    if lhs is rhs:
        return True
    if lhs is _UNKNOWN or rhs is _UNKNOWN:
        return False
    try:
        return bool(lhs == rhs)
    except Exception:
        return False


def _merge_state_value(
    lhs: _StateValue, rhs: _StateValue
) -> _StateValue | _UnknownState:
    return lhs if _same_state_value(lhs, rhs) else _UNKNOWN


def _while_exit_value(
    name: str,
    entry: _StateValue,
    before: _StateValue,
    after: _StateValue,
    before_touches: set[str],
    after_touches: set[str],
) -> _StateValue | _UnknownState:
    if name in before_touches:
        return before
    if name in after_touches:
        return _merge_state_value(entry, after)
    return entry


def _merge_cube_states(lhs: _CubeState, rhs: _CubeState) -> _CubeState:
    return _CubeState(
        hf32_enabled=_merge_state_value(lhs.hf32_enabled, rhs.hf32_enabled),
        hf32_round_mode=_merge_state_value(
            lhs.hf32_round_mode, rhs.hf32_round_mode
        ),
        hf32_dynamic_mode=_merge_state_value(
            lhs.hf32_dynamic_mode, rhs.hf32_dynamic_mode
        ),
        cube_8bit_mode=_merge_state_value(
            lhs.cube_8bit_mode, rhs.cube_8bit_mode
        ),
        direction=_merge_state_value(lhs.direction, rhs.direction),
    )


def _mark_domains(*names: str) -> None:
    trace = _CURRENT_CUBE_TRACE.get()
    if trace is None or trace.observer is None:
        return
    for frame in trace.observer.frames:
        if frame.current_child is not None:
            frame.child_touches[frame.current_child].update(names)


def _require_known_state(state: _CubeState) -> None:
    if any(getattr(state, name) is _UNKNOWN for name in _STATE_FIELDS):
        raise RuntimeError(
            "Cube state is unknown after dynamic control-flow; call explicit "
            "Cube setters before math.matmul"
        )


def _managed_matmul_attributes() -> dict[str, object]:
    state = _CURRENT_CUBE_STATE.get()
    _require_known_state(state)
    attrs: dict[str, object] = {}
    if state.hf32_enabled is False:
        attrs["hf32_mode"] = _HF32ComputeMode.DISABLED
    elif state.hf32_enabled is True:
        if state.hf32_round_mode is None:
            raise RuntimeError("enabled HF32 state has no rounding mode")
        attrs["hf32_mode"] = state.hf32_round_mode
        if state.hf32_round_mode == _HF32ComputeMode.DYNAMIC:
            if state.hf32_dynamic_mode is None:
                raise RuntimeError("dynamic HF32 state has no mode operand")
            attrs["hf32_dynamic_mode"] = state.hf32_dynamic_mode
    if state.cube_8bit_mode is not None:
        attrs["cube_8bit_mode"] = state.cube_8bit_mode
    if state.direction is not None:
        attrs["mmad_direction"] = state.direction
    return attrs


def _record_matmul(operation) -> None:
    """Validate that a created matmul retained the current state snapshot.

    This deliberately does not update Cube state or emit an operation: setter
    operations are the sole hardware-state source.
    """
    expected = _managed_matmul_attributes()
    for name, value in expected.items():
        if name == "hf32_dynamic_mode":
            if not any(operand == value for operand in operation.operands):
                raise RuntimeError("matmul lost dynamic HF32 mode operand")
            continue
        if name not in operation.attributes:
            raise RuntimeError(f"matmul lost managed Cube attribute '{name}'")
        actual = operation.attributes[name]
        if int(actual.value) != int(value):
            raise RuntimeError(f"matmul Cube attribute '{name}' differs from current state")


def _start_cube_trace(function):
    trace = _CubeTrace(function)
    trace_token = _CURRENT_CUBE_TRACE.set(trace)
    trace.state_token = _CURRENT_CUBE_STATE.set(_CubeState())
    from cannbotdsl.core.frontend.runtime.hooks import _push_region_observer

    trace.observer = _CubeRegionObserver()
    trace.observer_token = _push_region_observer(
        trace.observer, replace_same_type=True
    )
    return trace, trace_token


def _finish_cube_trace(trace, token, *, finalize: bool) -> None:
    try:
        if finalize:
            mode = 1 if trace.saw_explicit else 0  # EXPLICIT / UNMANAGED
            trace.function.attributes["cannir.cube_state_mode"] = _enum_attr(mode)
    finally:
        if trace.observer_token is not None:
            from cannbotdsl.core.frontend.runtime.hooks import _pop_region_observer

            _pop_region_observer(trace.observer_token)
        if trace.state_token is not None:
            _CURRENT_CUBE_STATE.reset(trace.state_token)
        _CURRENT_CUBE_TRACE.reset(token)


def enable_hf32() -> None:
    _mark_explicit()
    cannir.cube_enable_hf32()
    state = _CURRENT_CUBE_STATE.get()
    # The C API defaults to nearest-even on the first enable.  Once a setter
    # selected a rounding mode it remains persistent across set_fp32_mode().
    round_mode = state.hf32_round_mode or _HF32ComputeMode.NEAREST_EVEN
    dynamic_mode = state.hf32_dynamic_mode if round_mode == _HF32ComputeMode.DYNAMIC else None
    _CURRENT_CUBE_STATE.set(_CubeState(True, round_mode, dynamic_mode,
                                       state.cube_8bit_mode, state.direction))
    _mark_domains("hf32_enabled")
    if state.hf32_round_mode is None:
        _mark_domains("hf32_round_mode", "hf32_dynamic_mode")


def _require_hf32_enabled(api_name: str) -> _CubeState:
    state = _CURRENT_CUBE_STATE.get()
    if state.hf32_enabled is not True:
        raise RuntimeError(
            f"{api_name} requires cube.enable_hf32() on every active path"
        )
    return state


def set_hf32_round_mode(mode: HF32RoundingMode) -> None:
    if not isinstance(mode, HF32RoundingMode):
        raise TypeError("mode must be an HF32RoundingMode value")
    state = _require_hf32_enabled("cube.set_hf32_round_mode")
    _mark_explicit()
    cannir.cube_set_hf32_round_mode(mode=int(mode))
    hf32 = (_HF32ComputeMode.NEAREST_EVEN if mode == HF32RoundingMode.NEAREST_EVEN
            else _HF32ComputeMode.NEAREST_AWAY)
    _CURRENT_CUBE_STATE.set(_CubeState(state.hf32_enabled, hf32, None,
                                       state.cube_8bit_mode, state.direction))
    _mark_domains("hf32_round_mode", "hf32_dynamic_mode")


def enable_hf32_trans(mode: int | ScalarValue) -> None:
    if type(mode) is int:
        if mode not in (0, 1):
            raise ValueError("HF32 trans mode must be 0 or 1")
    else:
        value_type = getattr(mode, "type", None)
        if not (bool(getattr(mode, "unsigned", False)) and
                isinstance(value_type, ir.IntegerType) and
                value_type.width == 32 and value_type.is_signless):
            raise TypeError("dynamic HF32 trans mode must be a UInt32 scalar value")
    state = _require_hf32_enabled("cube.enable_hf32_trans")
    _mark_explicit()
    operand = coerce_scalar_value(mode, ir.IntegerType.get_signless(32),
                                  source_unsigned=True, target_unsigned=True)
    cannir.cube_enable_hf32_trans(operand)
    _CURRENT_CUBE_STATE.set(_CubeState(state.hf32_enabled,
                                       _HF32ComputeMode.DYNAMIC, operand,
                                       state.cube_8bit_mode, state.direction))
    _mark_domains("hf32_round_mode", "hf32_dynamic_mode")


def set_fp32_mode() -> None:
    _mark_explicit()
    cannir.cube_set_fp32_mode()
    state = _CURRENT_CUBE_STATE.get()
    _CURRENT_CUBE_STATE.set(_CubeState(False, state.hf32_round_mode,
                                       state.hf32_dynamic_mode,
                                       state.cube_8bit_mode, state.direction))
    _mark_domains("hf32_enabled")


def enable_hif8() -> None:
    _mark_explicit()
    cannir.cube_enable_hif8()
    state = _CURRENT_CUBE_STATE.get()
    _CURRENT_CUBE_STATE.set(_CubeState(state.hf32_enabled, state.hf32_round_mode,
                                       state.hf32_dynamic_mode, _Cube8BitMode.HIF8,
                                       state.direction))
    _mark_domains("cube_8bit_mode")


def enable_fp8() -> None:
    _mark_explicit()
    cannir.cube_enable_fp8()
    state = _CURRENT_CUBE_STATE.get()
    _CURRENT_CUBE_STATE.set(_CubeState(state.hf32_enabled, state.hf32_round_mode,
                                       state.hf32_dynamic_mode, _Cube8BitMode.FP8,
                                       state.direction))
    _mark_domains("cube_8bit_mode")


def set_mmad_direction(direction: Literal["m", "n"]) -> None:
    if type(direction) is not str or direction not in ("m", "n"):
        raise ValueError("MMAD direction must be exactly 'm' or 'n'")
    value = _MmadDirection.M if direction == "m" else _MmadDirection.N
    _mark_explicit()
    cannir.cube_set_mmad_direction(direction=int(value))
    state = _CURRENT_CUBE_STATE.get()
    _CURRENT_CUBE_STATE.set(_CubeState(state.hf32_enabled, state.hf32_round_mode,
                                       state.hf32_dynamic_mode,
                                       state.cube_8bit_mode, value))
    _mark_domains("direction")


__all__ = [
    "HF32RoundingMode", "enable_hf32", "set_hf32_round_mode",
    "enable_hf32_trans", "set_fp32_mode", "enable_hif8", "enable_fp8",
    "set_mmad_direction",
]
