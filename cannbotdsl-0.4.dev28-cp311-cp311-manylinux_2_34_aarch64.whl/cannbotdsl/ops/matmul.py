# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Matrix multiplication.

Split out of the former flat ``cannbotdsl/math.py``: matmul is a compute
paradigm of its own (cube unit / L0C, its own precision modes in
``cannbotdsl.ops.cube``) rather than an elementwise tensor op.
"""

from __future__ import annotations

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir

from cannbotdsl.core.scalar_conversion import coerce_scalar_value
from cannbotdsl.ops._operands import _tensor_operand
from cannbotdsl.types import Tensor


def matmul(
    dst: Tensor,
    lhs: Tensor,
    rhs: Tensor,
    *,
    bias: Tensor | None = None,
    init=True,
    unit_flag: int = 0,
    disable_gemv: bool = True,
):
    """Matrix multiplication with optional row bias.

    With ``bias=None``, computes ``dst = lhs @ rhs`` (or accumulates into
    ``dst`` if ``init=False``). With ``bias`` present and initialization
    enabled, computes ``dst = lhs @ rhs + bias`` and broadcasts the rank-1
    ``[N]`` bias over M. ``bias`` must reside in ``MemLoc.BIAS``; load it from
    an L1 fp16/bf16/fp32 buffer for float32 bias, or an L1 int32 buffer for
    int32 bias, with ``mem_copy`` before calling ``matmul``.

    FP8 inputs use regular ``asc_mmad`` when neither L0 input has an MX scale
    binding. If both inputs were loaded with
    ``mem_copy(l0_data, l1_data, mx_scale=l1_scale)``, matmul automatically
    uses OCP MXFP8. A scale binding on only one input is rejected.

    ``init`` is normally a Python bool. For runtime K-loop accumulation it may
    also be an SSA i1 expression (e.g. ``Int64(k) == Int64(0)``); the lowering
    then emits ``scf.if init`` over two static-init ``asccube.mmad`` calls.

    ``unit_flag`` may likewise be either a compile-time integer or a scalar SSA
    integer. Dynamic values are converted to i32 and forwarded directly to the
    hardware MMAD operand; static integers retain the legacy attribute path.

    ``disable_gemv`` mirrors the per-instruction C API parameter of
    ``asc_mmad``/``asc_mmad_mx`` (compile-time bool only). It only takes effect
    when M == 1: the default ``True`` keeps the fractal (NZ/ZZ) L0A read of the
    DSL cube path; ``False`` enables GEMV mode, which reads L0A as ND — the
    caller is then responsible for producing an ND-layout L0A, otherwise the
    M=1 results are silently wrong. It is a no-op for any other M.
    """
    if type(disable_gemv) is not bool:
        raise TypeError(
            "disable_gemv must be a bool, got "
            f"{type(disable_gemv).__name__}"
        )
    if isinstance(init, bool):
        kwargs = {"init": init}
    else:
        # SSA i1 (typically from `Int64(...) == Int64(...)` etc.). Pass via
        # the optional operand so MatMulOp lowering wraps in scf.if.
        kwargs = {"init_value": init}
    if bias is not None:
        kwargs["bias"] = _tensor_operand(bias)
    if isinstance(unit_flag, ir.Value):
        kwargs["unit_flag_value"] = coerce_scalar_value(
            unit_flag, ir.IntegerType.get_signless(32)
        )
    else:
        kwargs["unit_flag"] = int(unit_flag)
    kwargs["disable_gemv"] = disable_gemv
    from cannbotdsl.ops.cube import _managed_matmul_attributes, _record_matmul

    kwargs.update(_managed_matmul_attributes())
    operation = cannir.matmul(
        _tensor_operand(dst),
        _tensor_operand(lhs),
        _tensor_operand(rhs),
        **kwargs,
    )
    if hasattr(operation, "operation"):
        operation = operation.operation
    _record_matmul(operation)
