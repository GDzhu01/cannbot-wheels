# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode reduction ops."""

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import ascvec, cannir

from cannbotdsl.lang.vf import _require_raw_mode

from cannbotdsl.ops.reg._common import _raw_vreg_type, _tag_raw_op
from cannbotdsl.ops.reg.mask import Mask, _unary
from cannbotdsl.ops.reg.reg_defs import RawVReg


def vreduce_sum(src: RawVReg, *, mask: Mask) -> RawVReg:
    _require_raw_mode("vreduce_sum")
    op = ascvec.ReduceSumOp(_raw_vreg_type(src.dtype), src.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vreduce_max(src: RawVReg, *, mask: Mask) -> RawVReg:
    _require_raw_mode("vreduce_max")
    op = ascvec.ReduceMaxOp(_raw_vreg_type(src.dtype), src.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vreduce_min(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.ReduceMinOp, "vreduce_min")


def vreduce_max_datablock(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.ReduceMaxDatablockOp, "vreduce_max_datablock")


def _reduce_sum_datablock_dtype(dtype: ir.Type) -> ir.Type:
    text = str(dtype)
    if text == "i16":
        return ir.IntegerType.get_signless(32)
    if text == "ui16":
        return ir.IntegerType.get_unsigned(32)
    return dtype


def vreduce_sum_datablock(src: RawVReg, *, mask: Mask) -> RawVReg:
    _require_raw_mode("vreduce_sum_datablock")
    out_dtype = _reduce_sum_datablock_dtype(src.dtype)
    op = ascvec.ReduceSumDatablockOp(_raw_vreg_type(out_dtype), src.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, out_dtype)


def vreduce_min_datablock(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.ReduceMinDatablockOp, "vreduce_min_datablock")


def vpair_reduce_sum(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.PairReduceSumOp, "vpair_reduce_sum")
