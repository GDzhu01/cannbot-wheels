# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode vector store ops."""

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir

from cannbotdsl.lang.vf import _require_raw_mode

from cannbotdsl.ops.reg._common import _as_offset, _dtype_bits, _is_integer_dtype, _normalize_width, _raw_tensor_operand, _raw_vreg_type, _tag_raw_op
from cannbotdsl.ops.reg.mask import Mask
from cannbotdsl.ops.reg.reg_defs import MergeMode, PackMode, RawVReg, StoreUnalignReg


def _normalize_pack_mode(mode) -> str:
    if isinstance(mode, PackMode):
        return mode.value
    if isinstance(mode, str):
        # accept new semantic names and legacy granularities
        alias = {
            "pack_half": "pack_half",
            "pack_quarter": "pack_quarter",
            "lower": "lower",
            "highest": "highest",
        }
        key = mode.lower()
        if key in alias:
            return alias[key]
        try:
            return PackMode(mode).value
        except ValueError as err:
            allowed = "pack_half, pack_quarter, lower, highest"
            raise ValueError(f"mode must be one of {allowed}") from err
    raise TypeError("mode must be a PackMode or string")


def _normalize_mask_store_dist(dist) -> str:
    if not isinstance(dist, str):
        raise TypeError("vmask_store: dist must be a string")
    key = dist.lower()
    aliases = {
        "norm": "norm",
        "normal": "norm",
        "pack": "pack",
    }
    if key not in aliases:
        raise ValueError("vmask_store: dist must be 'norm' or 'pack'")
    return aliases[key]


def vstore(tensor, offset, value: RawVReg, mask: Mask, *,
           post_update: bool = False) -> None:
    """Masked store (asc_storealign).
    selects the addr_reg CAPI overload: asc_storealign(dst, src, ar, mask)."""
    _require_raw_mode("vstore")
    operand, _ = _raw_tensor_operand(tensor)
    op = cannir.RawRegStoreOp(operand, _as_offset(offset), value.value, mask.value, post_update=post_update)
    _tag_raw_op(op)


def vstore_strided(
    tensor, offset, value: RawVReg, mask: Mask, *, block_stride, repeat_stride=0
) -> None:
    """Masked NZ repeat-stride store: the raw counterpart of the high-level
    ``cast -> mem_copy(nd2nz)`` fold.

    Emits v5 ``asc_storealign(buf + off, v, (uint16_t)block_stride,
    (uint16_t)repeat_stride, mask)`` (via ``ascvec::StoreAlignStridedOp``), which
    scatters one register into an NZ-layout buffer. ``block_stride`` /
    ``repeat_stride`` are in DataBlock (32B) units; for an NZ destination derive
    ``block_stride`` from ``nzN1Stride / kN0`` (read off the dst physical layout).
    """
    _require_raw_mode("vstore_strided")
    operand, _ = _raw_tensor_operand(tensor)
    op = cannir.RawRegStoreStridedOp(
        operand,
        _as_offset(offset),
        value.value,
        mask.value,
        block_stride=_as_offset(block_stride),
        repeat_stride=_as_offset(repeat_stride),
    )
    _tag_raw_op(op)


def vstore_first(tensor, offset, value: RawVReg, *, post_update: bool = False) -> None:
    _require_raw_mode("vstore_first")
    operand, _ = _raw_tensor_operand(tensor)
    op = cannir.RawRegStoreFirstOp(operand, _as_offset(offset), value.value, post_update=post_update)
    _tag_raw_op(op)


def vstore_interleave(tensor, offset, src0: RawVReg, src1: RawVReg, *, width=None) -> None:
    """Interleave-store two raw registers to UB (src0 -> even lanes, src1 -> odd).

    Matches arch35 ``StoreAlign<T, DIST_INTLV_B32>(buf, src0, src1, preg)`` ->
    ``asc_storealign_intlv(dst, src0, src1)``. Both sources must share a dtype;
    the destination buffer is treated as raw storage and its address is
    reinterpreted to that dtype. The CAPI carries no execute mask.
    """
    _require_raw_mode("vstore_interleave")
    if src0.dtype != src1.dtype:
        raise ValueError(f"vstore_interleave: dtype mismatch {src0.dtype} vs {src1.dtype}")
    kwargs = {}
    if width is not None:
        width = _normalize_width(width, name="vstore_interleave")
        if _dtype_bits(src0.dtype) != int(width[1:]):
            raise TypeError(f"vstore_interleave(width='{width}'): src dtype bit-width must match width")
        kwargs["intlv_width"] = width
    operand, _ = _raw_tensor_operand(tensor)
    op = cannir.RawRegStoreInterleaveOp(
        operand, _as_offset(offset), src0.value, src1.value, **kwargs
    )
    _tag_raw_op(op)


def vstore_pack(tensor, offset, value: RawVReg, mask: Mask, *, pack_mode, post_update: bool = False) -> None:
    _require_raw_mode("vstore_pack")
    mode = _normalize_pack_mode(pack_mode)
    # new semantic names map onto legacy granularities by dtype widths
    operand, dtype = _raw_tensor_operand(tensor)
    tensor_bits = _dtype_bits(dtype)
    value_bits = _dtype_bits(value.dtype)
    if mode == "pack_half":
        mode = "b32_to_b16" if value_bits == 16 else "b16_to_b8"
    elif mode == "pack_quarter":
        mode = "b32_to_b8"
    if mode == PackMode.B16_TO_B8.value:
        if tensor_bits != 8:
            raise TypeError("vstore_pack(mode='b16_to_b8'): tensor dtype must be 8-bit")
        if value_bits != 16:
            raise TypeError("vstore_pack(mode='b16_to_b8'): value dtype must be 16-bit")
        if mask.elem_bits != 16:
            raise ValueError("vstore_pack(mode='b16_to_b8'): mask elem_bits must be 16")
    elif mode == PackMode.B32_TO_B16.value:
        if value_bits != 16:
            raise TypeError("vstore_pack(mode='b32_to_b16'): value dtype must be 16-bit")
        if mask.elem_bits != 32:
            raise ValueError("vstore_pack(mode='b32_to_b16'): mask elem_bits must be 32")
    elif mode == PackMode.B32_TO_B8.value:
        if tensor_bits != 8:
            raise TypeError("vstore_pack(mode='b32_to_b8'): tensor dtype must be 8-bit")
        fp8_types = (ir.Float8E4M3FNType, ir.Float8E5M2Type)
        if value_bits != 32 and not isinstance(value.dtype, fp8_types):
            raise TypeError("vstore_pack(mode='b32_to_b8'): value dtype must be 32-bit or fp8")
        if mask.elem_bits != 32:
            raise ValueError("vstore_pack(mode='b32_to_b8'): mask elem_bits must be 32")
    else:
        raise NotImplementedError("vstore_pack(mode='b64_to_b32') is not supported: arch3510 exposes no b64 mask update")
    op = cannir.RawRegStorePackOp(
        operand, _as_offset(offset), value.value, mask.value, mode=mode, post_update=post_update
    )
    _tag_raw_op(op)


def vmask_store(tensor, offset, mask: Mask, *, dist="norm") -> None:
    _require_raw_mode("vmask_store")
    operand, dtype = _raw_tensor_operand(tensor)
    bits = _dtype_bits(dtype)
    if not _is_integer_dtype(dtype) or bits not in (8, 16, 32):
        raise TypeError("vmask_store: tensor dtype must be 8-bit, 16-bit, or 32-bit integer storage")
    dist = _normalize_mask_store_dist(dist)
    op = cannir.RawRegMaskStoreOp(
        operand, _as_offset(offset), mask.value, dist
    )
    _tag_raw_op(op)


def vsqueeze_and_storeunalign_init(src: RawVReg, *, mask: Mask) -> RawVReg:
    """Mark the squeeze point of a stream-compaction store sequence.

    Selects the lanes of ``src`` where ``mask`` is true; the resulting register
    is a *squeeze value* that must be consumed exactly once by
    :func:`vsqueeze_and_storeunalign` (single-use, enforced by the emitter),
    which realizes the squeeze itself inside the combined CAPI
    ``asc_squeeze_and_storeunalign(dst, v, cursor, src, squeeze_mask)`` and
    writes the surviving-lane count into the AR special register as the
    cursor's write count. Must alternate one-to-one with
    :func:`vsqueeze_and_storeunalign`, bracketed by
    :func:`vstore_unalign_begin` ... :func:`vsqueeze_and_storeunalign_finalize`.
    """
    _require_raw_mode("vsqueeze_and_storeunalign_init")
    op = cannir.RawRegSqueezeStoreRegOp(_raw_vreg_type(src.dtype), src.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def _check_ureg(ureg, operand, name: str) -> None:
    if not isinstance(ureg, StoreUnalignReg):
        raise TypeError(f"{name}: ureg must be a vstore_unalign_begin() result")
    if ureg.operand != operand:
        raise ValueError(f"{name}: ureg belongs to a different buffer than tensor")


def vstore_unalign_begin(tensor, *, no_clear_ar: bool = False) -> StoreUnalignReg:
    """Open a stream-compaction store on ``tensor`` and claim the ureg cursor.

    Emits ``asc_squeeze_and_storeunalign_init()`` — the official successor of
    the deprecated ``asc_clear_ar_spr()`` — and declares the persistent
    ``vector_store_unalign`` cursor for ``tensor``, returned as the ureg
    handle. Pair with :func:`vsqueeze_and_storeunalign` /
    :func:`vsqueeze_and_storeunalign_finalize` on the same buffer, passing
    the ureg to each call.

    Set ``no_clear_ar=True`` to skip the init call so this sequence
    *appends* after a prior one: arch35 ``FindIdxEQ`` does this to continue the
    AR write-position left by ``FindIdxGT`` (the AR special register persists
    across ``__simd_vf__`` calls; only the local cursor is fresh).
    """
    _require_raw_mode("vstore_unalign_begin")
    operand, _ = _raw_tensor_operand(tensor)
    op = cannir.RawRegStoreUnalignBeginOp(
        operand, no_clear_ar=no_clear_ar
    )
    _tag_raw_op(op)
    return StoreUnalignReg(operand)


def vstore_unalign(tensor, offset, value: RawVReg, ureg: StoreUnalignReg) -> None:
    """AR-driven compacting store (combined ``asc_squeeze_and_storeunalign``).

    The emitter realizes squeeze + store in the single combined CAPI call
    ``asc_squeeze_and_storeunalign(dst, v, cursor, src, squeeze_mask)``: the
    AR-recorded number of compacted lanes is written from ``value`` at the
    cursor's running position on ``tensor`` and the cursor advances.
    ``ureg`` is the cursor returned by :func:`vstore_unalign_begin` for the
    same ``tensor``.
    """
    _require_raw_mode("vstore_unalign")
    operand, _ = _raw_tensor_operand(tensor)
    _check_ureg(ureg, operand, "vstore_unalign")
    op = cannir.RawRegStoreUnalignOp(operand, _as_offset(offset), value.value)
    _tag_raw_op(op)


def vsqueeze_and_storeunalign(tensor, offset, value: RawVReg, ureg: StoreUnalignReg) -> None:
    """AR-driven compacting store of a squeezed register (arch35 StoreUnAlign).

    Emitter fuses this call with the preceding
    :func:`vsqueeze_and_storeunalign_init` value into the combined CAPI
    ``asc_squeeze_and_storeunalign(dst, v, cursor, src, squeeze_mask)``:
    writes the AR-recorded number of compacted lanes from ``value`` at the
    cursor's running position on ``tensor`` and advances the cursor. Must
    follow a :func:`vsqueeze_and_storeunalign_init` on the same ``ureg``.
    """
    _require_raw_mode("vsqueeze_and_storeunalign")
    operand, _ = _raw_tensor_operand(tensor)
    _check_ureg(ureg, operand, "vsqueeze_and_storeunalign")
    op = cannir.RawRegStoreUnalignOp(
        operand, _as_offset(offset), value.value
    )
    _tag_raw_op(op)


def vstore_unalign_post(tensor, offset, ureg: StoreUnalignReg) -> None:
    """Flush the tail of an unaligned-store sequence.

    Lowers to ``asc_squeeze_and_storeunalign_finalize(dst, cursor)``.
    ``ureg`` is the cursor returned by :func:`vstore_unalign_begin` for the
    same ``tensor``.
    """
    _require_raw_mode("vstore_unalign_post")
    operand, _ = _raw_tensor_operand(tensor)
    _check_ureg(ureg, operand, "vstore_unalign_post")
    op = cannir.RawRegStoreUnalignPostOp(operand, _as_offset(offset))
    _tag_raw_op(op)


def vsqueeze_and_storeunalign_finalize(tensor, offset, ureg: StoreUnalignReg) -> None:
    """Flush the tail of a stream-compaction store (arch35 StoreUnAlignPost).

    Lowers to ``asc_squeeze_and_storeunalign_finalize(dst, cursor)``: flushes
    any bytes still held in the cursor after the final
    :func:`vsqueeze_and_storeunalign`. ``ureg`` is the cursor returned by
    :func:`vstore_unalign_begin` for the same ``tensor``.
    """
    _require_raw_mode("vsqueeze_and_storeunalign_finalize")
    operand, _ = _raw_tensor_operand(tensor)
    _check_ureg(ureg, operand, "vsqueeze_and_storeunalign_finalize")
    op = cannir.RawRegStoreUnalignPostOp(operand, _as_offset(offset))
    _tag_raw_op(op)


def vstorealign_squeeze_status(tensor, offset=0) -> None:
    """Store the squeeze status register (AR) into UB as one uint32 (sprsts).

    Emits ``sprsts(SPR_AR, (__ubuf__ uint32_t*)(buf + offset), 0)``: writes the
    AR special register — the compacted write position (in BYTES) recorded by
    the squeeze/unalign sequence — into ``tensor[offset]``. The tensor element
    type must be 32-bit (the store is a single uint32 and must stay 4-byte
    aligned at any element offset).
    """
    _require_raw_mode("vstorealign_squeeze_status")
    operand, dtype = _raw_tensor_operand(tensor)
    if _dtype_bits(dtype) != 32:
        raise TypeError(
            f"vstorealign_squeeze_status: tensor dtype must be 32-bit "
            f"(sprsts writes one 4-byte-aligned uint32), got {dtype}"
        )
    op = cannir.RawRegStoreAlignSqueezeStatusOp(operand, _as_offset(offset))
    _tag_raw_op(op)


def vstore_mask(tensor, offset, value: RawVReg, mask: Mask, *, merge_mode: "str | MergeMode" = MergeMode.ZEROING) -> None:
    """Masked store (asc_storealign with exec mask) — alias of vstore."""
    _require_raw_mode("vstore_mask")
    vstore(tensor, offset, value, mask)
