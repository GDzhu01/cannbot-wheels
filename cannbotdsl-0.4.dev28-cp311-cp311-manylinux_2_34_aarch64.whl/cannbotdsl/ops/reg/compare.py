# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode comparison and selection ops."""

from cannbotdsl._mlir.dialects import ascvec, cannir

from cannbotdsl.lang.vf import _require_raw_mode

from cannbotdsl.ops.reg._common import _raw_mask_type, _raw_vreg_type, _scalar_value, _tag_raw_op
from cannbotdsl.ops.reg.mask import Mask
from cannbotdsl.ops.reg.reg_defs import RawVReg


def vselect(src_true: RawVReg, src_false: RawVReg, *, cond_mask: Mask) -> RawVReg:
    _require_raw_mode("vselect")
    if src_true.dtype != src_false.dtype:
        raise ValueError(f"vselect: dtype mismatch {src_true.dtype} vs {src_false.dtype}")
    op = ascvec.VSelectOp(
        _raw_vreg_type(src_true.dtype),
        src_true.value,
        src_false.value,
        cond_mask.value,
    )
    _tag_raw_op(op)
    return RawVReg(op.result, src_true.dtype)


def vmerge(mask: Mask, new: RawVReg, old: RawVReg) -> RawVReg:
    return vselect(new, old, cond_mask=mask)


def _cmp(lhs: RawVReg, rhs: RawVReg, exec_mask: Mask, op_cls, name: str) -> Mask:
    _require_raw_mode(name)
    if lhs.dtype != rhs.dtype:
        raise ValueError(f"{name}: dtype mismatch {lhs.dtype} vs {rhs.dtype}")
    op = op_cls(_raw_mask_type(exec_mask.elem_bits), lhs.value, rhs.value, exec_mask.value)
    _tag_raw_op(op)
    return Mask(op.mask, exec_mask.elem_bits)


def vgt(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> Mask:
    return _cmp(lhs, rhs, mask, ascvec.VCmpGtOp, "vgt")


def vge(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> Mask:
    return _cmp(lhs, rhs, mask, ascvec.VCmpGeOp, "vge")


def veq(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> Mask:
    return _cmp(lhs, rhs, mask, ascvec.VCmpEqOp, "veq")


def vle(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> Mask:
    return _cmp(lhs, rhs, mask, ascvec.VCmpLeOp, "vle")


def vlt(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> Mask:
    return _cmp(lhs, rhs, mask, ascvec.VCmpLtOp, "vlt")


def vne(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> Mask:
    return _cmp(lhs, rhs, mask, ascvec.VCmpNeOp, "vne")


def _cmp_scalar(src: RawVReg, scalar, exec_mask: Mask, op_cls, name: str) -> Mask:
    _require_raw_mode(name)
    scalar_v = _scalar_value(scalar, src.dtype)
    op = op_cls(_raw_mask_type(exec_mask.elem_bits), src.value, scalar_v, exec_mask.value)
    _tag_raw_op(op)
    return Mask(op.mask, exec_mask.elem_bits)


def veqs(src: RawVReg, scalar, *, mask: Mask) -> Mask:
    return _cmp_scalar(src, scalar, mask, ascvec.VCmpEqScalarOp, "veqs")


def vgts(src: RawVReg, scalar, *, mask: Mask) -> Mask:
    return _cmp_scalar(src, scalar, mask, ascvec.VCmpGtScalarOp, "vgts")


def vges(src: RawVReg, scalar, *, mask: Mask) -> Mask:
    return _cmp_scalar(src, scalar, mask, ascvec.VCmpGeScalarOp, "vges")


def vlts(src: RawVReg, scalar, *, mask: Mask) -> Mask:
    """Elementwise `src < scalar`, returns a Mask. Lowers to `asc_lt_scalar`.

    `mask` is the execute mask; result mask bits for inactive lanes are 0.
    """
    return _cmp_scalar(src, scalar, mask, ascvec.VCmpLtScalarOp, "vlts")


def vles(src: RawVReg, scalar, *, mask: Mask) -> Mask:
    return _cmp_scalar(src, scalar, mask, ascvec.VCmpLeScalarOp, "vles")


def vnes(src: RawVReg, scalar, *, mask: Mask) -> Mask:
    return _cmp_scalar(src, scalar, mask, ascvec.VCmpNeScalarOp, "vnes")
