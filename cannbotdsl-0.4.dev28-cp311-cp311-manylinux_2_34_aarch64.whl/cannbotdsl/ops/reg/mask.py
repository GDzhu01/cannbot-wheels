# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw-mode mask values, mask construction and mask algebra."""

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import ascvec, cannir

from cannbotdsl.lang.vf import _require_raw_mode

from cannbotdsl.ops.reg._common import _raw_mask_type, _raw_vreg_type, _tag_raw_op
from cannbotdsl.ops.reg.reg_defs import RawVReg


def _as_i32(value):
    from cannbotdsl.core.scalar_conversion import coerce_scalar_value

    return coerce_scalar_value(value, ir.IntegerType.get_signless(32))


class Mask(ir.Value):
    """First-class SSA wrapper for ``!cannir.raw_mask``."""

    def __init__(self, value: ir.Value, elem_bits: int | None = None):
        if not isinstance(value, ir.Value):
            raise TypeError(f"Mask requires ir.Value, got {type(value).__name__}")
        if str(value.type) != "!ascvec.mask":
            raise TypeError(
                f"Mask requires !ascvec.mask SSA value, got {value.type}"
            )
        super().__init__(value)
        if elem_bits is None:
            elem_bits = _mask_provenance_elem_bits(value)
        self.elem_bits = (
            int(elem_bits) if elem_bits is not None else None
        )

    @property
    def value(self):
        """Deprecated internal compatibility view; the object is the SSA value."""

        return self


def _ascvec_mask_typeid():
    with ir.Context() as _ctx:
        return ir.Type.parse("!ascvec.mask").typeid


def _mask_provenance_elem_bits(value: ir.Value) -> int | None:
    """Best-effort elem_bits of a mask from its defining instruction."""
    owner = getattr(value, "owner", None)
    if owner is None:
        return None
    name = getattr(owner, "name", "")
    try:
        if name == "ascvec.create_mask":
            return int(owner.attributes["elem_bits"].value)
        if name == "ascvec.update_mask":
            return int(owner.attributes["elem_bits"].value)
    except (KeyError, AttributeError):
        return None
    return None


Mask = ir.register_value_caster(_ascvec_mask_typeid())(Mask)


class MaskCounter(ir.Value):
    """Mutable remaining-element counter for raw-VF tail masks.

    Holds the i32 remaining-element count and is threaded through scf.for as a
    loop-carried value via the same protocol as ``Mask`` / ``RawVReg``. Pass it
    to ``update_mask(counter, elem_bits)`` and explicitly bind both results as
    ``mask, counter = update_mask(counter, elem_bits)``. ``elem_bits`` is
    supplied per call, not stored on the counter.
    """

    def __init__(self, value: ir.Value):
        if not isinstance(value, ir.Value):
            raise TypeError(
                f"MaskCounter requires ir.Value, got {type(value).__name__}"
            )
        super().__init__(value)
        if not isinstance(value.type, ir.IntegerType) or value.type.width != 32:
            raise TypeError(
                f"MaskCounter requires an i32 SSA value, got {value.type}"
            )

    @property
    def value(self):
        return self


_PAT_MODES = {
    "all": "PAT_ALL", "allf": "PAT_ALLF",
    **{f"vl{n}": f"PAT_VL{n}" for n in (1, 2, 3, 4, 8, 16, 32, 64, 128)},
    "m3": "PAT_M3", "m4": "PAT_M4",
    "h": "PAT_H", "half": "PAT_H", "q": "PAT_Q", "quarter": "PAT_Q",
}


def _normalize_pat_mode(pattern) -> str:
    if isinstance(pattern, str):
        key = pattern.strip().lower()
        if key.startswith("pat_"):
            return pattern.strip().upper()
        if key in _PAT_MODES:
            return _PAT_MODES[key]
    raise ValueError(
        "create_mask: pattern must be one of "
        "'all', 'allf', 'vl1'..'vl128', 'm3', 'm4', 'h', 'q' (PAT_* pset modes)"
    )


def create_mask(pattern: str = "all", elem_bits: int = 32) -> Mask:
    """Create a mask register from a hardware pset pattern
    (asc_create_mask_b8/b16/b32(pat_mode)).

    ``pattern`` selects the hardware fill pattern:

    - ``"all"`` (PAT_ALL): all elements true; ``"allf"`` (PAT_ALLF): all false
    - ``"vl1"``..``"vl128"`` (PAT_VLn): lowest N elements true
    - ``"m3"``/``"m4"`` (PAT_M3/M4): every 3rd/4th element true
    - ``"h"`` (PAT_H): lowest half true; ``"q"`` (PAT_Q): lowest quarter true

    ``elem_bits`` selects the mask granularity (8/16/32).
    """
    _require_raw_mode("create_mask")
    pat = _normalize_pat_mode(pattern)
    op = ascvec.CreateMaskOp(
        _raw_mask_type(elem_bits), elem_bits=elem_bits, pat_mode=pat
    )
    _tag_raw_op(op)
    return Mask(op.mask, elem_bits)


def full_mask() -> Mask:
    """Deprecated alias of :func:`create_mask(pattern="all")`.

    A full mask needs no element bit width argument: PAT_ALL sets every bit,
    so the hardware result is identical at b8/b16/b32 granularity (an
    all-true b8 pset covers b16/b32 lanes too). The mask is still typed with
    the widest (b32) granularity internally so derived masks keep matching
    the vector dtypes they gate.
    """
    return create_mask(pattern="all", elem_bits=32)


def update_mask(remaining, elem_bits: int = 32):
    _require_raw_mode("update_mask")
    if isinstance(remaining, MaskCounter):
        op = ascvec.UpdateMaskOp(
            _raw_mask_type(elem_bits),
            ir.IntegerType.get_signless(32),
            remaining.value,
            elem_bits=elem_bits,
        )
        _tag_raw_op(op)
        return Mask(op.mask, elem_bits), MaskCounter(op.remaining_out)
    remaining = _as_i32(remaining)
    op = ascvec.UpdateMaskOp(
        _raw_mask_type(elem_bits),
        ir.IntegerType.get_signless(32),
        remaining,
        elem_bits=elem_bits,
    )
    _tag_raw_op(op)
    # ``remaining_out`` is physically signless i32, so MLIR's generic caster
    # cannot recover its signed semantic identity.  The operation contract is
    # explicitly a signed remaining-element count; restore that canonical
    # wrapper at the producer instead of asking control-flow transport to
    # guess from the carrier.
    from cannbotdsl.types._numeric import Int32

    return Mask(op.mask, elem_bits), Int32(op.remaining_out)


def mask_counter(logical) -> MaskCounter:
    """Create a mutable remaining-element counter for raw-VF tail masks.

    ``logical`` is the total logical element count; accepts ``int``, ``Int32``,
    or an ``ir.Value``. Inside a loop, explicitly update the carried value with
    ``mask, counter = update_mask(counter, elem_bits)``.
    """
    _require_raw_mode("mask_counter")
    return MaskCounter(_as_i32(logical))


def _binary(lhs: RawVReg, rhs: RawVReg, mask: Mask, op_cls, name: str) -> RawVReg:
    _require_raw_mode(name)
    if lhs.dtype != rhs.dtype:
        raise ValueError(f"{name}: dtype mismatch {lhs.dtype} vs {rhs.dtype}")
    op = op_cls(_raw_vreg_type(lhs.dtype), lhs.value, rhs.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, lhs.dtype)


def _unary(src: RawVReg, mask: Mask, op_cls, name: str) -> RawVReg:
    _require_raw_mode(name)
    op = op_cls(_raw_vreg_type(src.dtype), src.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vmask(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.VCopyOp, "vmask")


def mask_xor(lhs: Mask, rhs: Mask, *, exec_mask: Mask) -> Mask:
    """Mask-domain (predicate) XOR. Lowers to `asc_xor` on the vector_bool overload.

    arch35 ``MicroAPI::Xor`` predicate-register algebra. All three masks must
    share the same element bit width.
    """
    _require_raw_mode("mask_xor")
    if lhs.elem_bits != rhs.elem_bits or lhs.elem_bits != exec_mask.elem_bits:
        raise ValueError(
            f"mask_xor: elem_bits mismatch {lhs.elem_bits}/{rhs.elem_bits}/{exec_mask.elem_bits}"
        )
    op = ascvec.MaskXorOp(
        _raw_mask_type(lhs.elem_bits), lhs.value, rhs.value, exec_mask.value
    )
    _tag_raw_op(op)
    return Mask(op.result, lhs.elem_bits)


def mask_and(lhs: Mask, rhs: Mask, *, exec_mask: Mask) -> Mask:
    """Mask-domain (predicate) AND. Lowers to `asc_and` on the vector_bool overload.

    All three masks must share the same element bit width.
    """
    _require_raw_mode("mask_and")
    if lhs.elem_bits != rhs.elem_bits or lhs.elem_bits != exec_mask.elem_bits:
        raise ValueError(
            f"mask_and: elem_bits mismatch {lhs.elem_bits}/{rhs.elem_bits}/{exec_mask.elem_bits}"
        )
    op = ascvec.MaskAndOp(
        _raw_mask_type(lhs.elem_bits), lhs.value, rhs.value, exec_mask.value
    )
    _tag_raw_op(op)
    return Mask(op.result, lhs.elem_bits)


def mask_or(lhs: Mask, rhs: Mask, *, exec_mask: Mask) -> Mask:
    """Mask-domain (predicate) OR. Lowers to `asc_or` on the vector_bool overload.

    All three masks must share the same element bit width.
    """
    _require_raw_mode("mask_or")
    if lhs.elem_bits != rhs.elem_bits or lhs.elem_bits != exec_mask.elem_bits:
        raise ValueError(
            f"mask_or: elem_bits mismatch {lhs.elem_bits}/{rhs.elem_bits}/{exec_mask.elem_bits}"
        )
    op = ascvec.MaskOrOp(
        _raw_mask_type(lhs.elem_bits), lhs.value, rhs.value, exec_mask.value
    )
    _tag_raw_op(op)
    return Mask(op.result, lhs.elem_bits)


def mask_not(src: Mask, *, exec_mask: Mask) -> Mask:
    """Mask-domain (predicate) NOT. Lowers to `asc_not` on the vector_bool overload.

    Both masks must share the same element bit width.
    """
    _require_raw_mode("mask_not")
    if src.elem_bits != exec_mask.elem_bits:
        raise ValueError(
            f"mask_not: elem_bits mismatch {src.elem_bits}/{exec_mask.elem_bits}"
        )
    op = ascvec.MaskNotOp(
        _raw_mask_type(src.elem_bits), src.value, exec_mask.value
    )
    _tag_raw_op(op)
    return Mask(op.result, src.elem_bits)
