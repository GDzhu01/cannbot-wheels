# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode memory barrier ops."""

from cannbotdsl._mlir.dialects import cannir

from cannbotdsl.lang.vf import _require_raw_mode

from cannbotdsl.ops.reg._common import _tag_raw_op


def vmem_bar(mode="vst_vld") -> None:
    _require_raw_mode("vmem_bar")
    if mode not in ("vst_vld", "vld_vst"):
        raise ValueError("vmem_bar: mode must be 'vst_vld' or 'vld_vst'")
    op = cannir.RawRegMemBarOp(mode=mode)
    _tag_raw_op(op)
