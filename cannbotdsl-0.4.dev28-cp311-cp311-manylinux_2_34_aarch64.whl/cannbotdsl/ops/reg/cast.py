# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode dtype cast and rounding ops."""

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import ascvec, cannir

from cannbotdsl.types import RegLayout, RoundingMode
from cannbotdsl.lang.vf import _require_raw_mode

from cannbotdsl.ops.reg._common import _dtype_bits, _dtype_type, _raw_vreg_type, _tag_raw_op
from cannbotdsl.ops.reg.mask import Mask
from cannbotdsl.ops.reg.reg_defs import RawVReg


_ROUNDING_ALIASES = {
    "na": RoundingMode.NA,
    "rn": RoundingMode.RN,
    "rna": RoundingMode.RNA,
    "rd": RoundingMode.RD,
    "ru": RoundingMode.RU,
    "rz": RoundingMode.RZ,
    "ro": RoundingMode.RO,
}


def _normalize_rounding(rounding) -> RoundingMode:
    if isinstance(rounding, RoundingMode):
        return rounding
    if isinstance(rounding, str):
        key = rounding.lower()
        if key in _ROUNDING_ALIASES:
            return _ROUNDING_ALIASES[key]
    raise ValueError("vcast: rounding must be one of 'na', 'rn', 'rna', 'rd', 'ru', 'rz', or 'ro'")


def _normalize_reg_layout(reg_layout) -> RegLayout:
    if isinstance(reg_layout, RegLayout):
        return reg_layout
    raise TypeError("vcast: reg_layout must be a RegLayout")


def _is_full_mask(mask: "Mask") -> bool:
    """True when ``mask`` was produced by full_mask/create_mask (pset).

    A full mask is granularity-agnostic (b8 all-true covers b16/b32 lanes),
    so callers may accept it for any element bit width.
    """
    try:
        defining_op = mask.value.owner
        return getattr(defining_op, "name", "") == "cannir.raw_reg.full_mask"
    except Exception:
        return False


def vcast(
    src: RawVReg,
    dtype,
    *,
    mask: Mask,
    rounding=RoundingMode.NA,
    saturate=False,
    reg_layout=RegLayout.UNKNOWN,
) -> RawVReg:
    """Cast a raw vector register to ``dtype``.

    ``rounding=RoundingMode.NA`` (default) lets the DSL pick per AscendC
    conventions: widening casts carry no rounding (exact); narrowing casts
    auto-select RN. Pass an explicit RoundingMode to pin the behavior.
    """
    _require_raw_mode("vcast")
    dtype = _dtype_type(dtype)
    src_bits = _dtype_bits(src.dtype)
    dst_bits = _dtype_bits(dtype)
    if saturate and src_bits <= dst_bits:
        raise ValueError(
            "vcast: saturate only applies to narrowing casts (src wider than dst)"
        )
    rounding = _normalize_rounding(rounding)
    # NA: widening (src_bits < dst_bits, exact) keeps NA; narrowing auto-selects RN.
    if rounding == RoundingMode.NA and src_bits >= dst_bits:
        rounding = RoundingMode.RN
    fp8_types = (ir.Float8E4M3FNType, ir.Float8E5M2Type, cannir.HiFloat8Type)
    src_is_fp8 = isinstance(src.dtype, fp8_types)
    dst_is_fp8 = isinstance(dtype, fp8_types)
    src_is_f32 = isinstance(src.dtype, ir.F32Type)
    dst_is_f32 = isinstance(dtype, ir.F32Type)
    src_is_f16 = isinstance(src.dtype, ir.F16Type)
    dst_is_f16 = isinstance(dtype, ir.F16Type)
    src_is_hif8 = cannir.HiFloat8Type.isinstance(src.dtype)
    dst_is_hif8 = cannir.HiFloat8Type.isinstance(dtype)
    fp8_cast = (src_is_fp8 and dst_is_f32) or (src_is_f32 and dst_is_fp8)
    # hifloat8 has no direct f32 store path: the hardware provides
    # half<->hif8 and hif8->float only.
    hif8_cast = (
        (src_is_hif8 and (dst_is_f16 or dst_is_f32))
        or (src_is_f16 and dst_is_hif8)
    )
    if (src_is_hif8 or dst_is_hif8) and not hif8_cast:
        raise ValueError(
            "vcast: hifloat8 only casts to/from half and hifloat8 to float; "
            "cast float32 to half first"
        )
    # Both families pack a narrow float against a wider one, so the mask is
    # always denominated in source elements.
    narrow_float_cast = fp8_cast or hif8_cast
    reg_layout = _normalize_reg_layout(reg_layout)
    width_ratio = max(src_bits, dst_bits) // min(src_bits, dst_bits)
    if width_ratio == 1:
        if reg_layout != RegLayout.UNKNOWN:
            raise ValueError("vcast: same-width casts require RegLayout.UNKNOWN")
    elif width_ratio == 2:
        if reg_layout not in (
            RegLayout.UNKNOWN,
            RegLayout.ZERO,
            RegLayout.ONE,
        ):
            raise ValueError(
                "vcast: 1:2 and 2:1 casts require RegLayout.UNKNOWN, ZERO, or ONE"
            )
    elif width_ratio == 4:
        if reg_layout not in (
            RegLayout.UNKNOWN,
            RegLayout.ZERO,
            RegLayout.ONE,
            RegLayout.TWO,
            RegLayout.THREE,
        ):
            raise ValueError(
                "vcast: 1:4 and 4:1 casts require RegLayout.UNKNOWN, ZERO, ONE, TWO, or THREE"
            )
    if not isinstance(saturate, bool):
        raise TypeError("vcast: saturate must be a bool")
    if saturate and not (
        (src_is_f32 and dst_is_fp8) or (src_is_f16 and dst_is_hif8)
    ):
        raise ValueError(
            "vcast: saturate is only supported for f32 to fp8 and f16 to "
            "hifloat8 casts"
        )
    if fp8_cast and rounding not in (RoundingMode.RN, RoundingMode.NA):
        raise ValueError("vcast: fp8 casts only support RN rounding")
    # The half->hif8 store has round-half-to-even (spelled `_rh`) and
    # round-nearest-away variants; the widening direction is RN only.
    if hif8_cast and dst_is_hif8 and rounding not in (
        RoundingMode.RN,
        RoundingMode.RNA,
    ):
        raise ValueError(
            "vcast: half to hifloat8 casts only support RN or RNA rounding"
        )
    if hif8_cast and src_is_hif8 and rounding not in (RoundingMode.RN, RoundingMode.NA):
        raise ValueError("vcast: hifloat8 widening casts only support RN rounding")
    layout_selects_source = (
        src_bits < dst_bits and reg_layout != RegLayout.UNKNOWN
    )
    expected_mask_bits = (
        src_bits
        if narrow_float_cast or layout_selects_source
        else max(src_bits, dst_bits)
    )
    if mask.elem_bits != expected_mask_bits and not _is_full_mask(mask):
        if narrow_float_cast or layout_selects_source:
            raise ValueError(
                "vcast: layout-selecting cast mask elem_bits must match src_bits"
            )
        raise ValueError("vcast: mask elem_bits must match max(src_bits, dst_bits)")
    kwargs = {"rounding": rounding, "saturate": saturate}
    if reg_layout != RegLayout.UNKNOWN:
        kwargs["reg_layout"] = reg_layout
    op = ascvec.VCastOp(
        _raw_vreg_type(dtype), src.value, mask.value, **kwargs
    )
    _tag_raw_op(op)
    return RawVReg(op.result, dtype)


def vceil(src: RawVReg, *, mask: Mask) -> RawVReg:
    """Round toward +inf (asc_ceil / vtrc ROUND_C). Same-dtype unary op."""
    _require_raw_mode("vceil")
    from cannbotdsl.types import RoundingMode as _RM
    return vcast(src, src.dtype, mask=mask, rounding=_RM.RU)


def vfloor(src: RawVReg, *, mask: Mask) -> RawVReg:
    """Round toward -inf (asc_floor / vtrc ROUND_F). Same-dtype unary op."""
    _require_raw_mode("vfloor")
    from cannbotdsl.types import RoundingMode as _RM
    return vcast(src, src.dtype, mask=mask, rounding=_RM.RD)


def vtrunc(src: RawVReg, *, mask: Mask) -> RawVReg:
    """Round toward zero (asc_trunc / vtrc ROUND_TZ). Same-dtype unary op."""
    _require_raw_mode("vtrunc")
    from cannbotdsl.types import RoundingMode as _RM
    return vcast(src, src.dtype, mask=mask, rounding=_RM.RZ)
