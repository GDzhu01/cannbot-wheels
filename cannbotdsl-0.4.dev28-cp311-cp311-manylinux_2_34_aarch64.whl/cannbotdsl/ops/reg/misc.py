# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode histogram ops."""

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import ascvec, cannir

from cannbotdsl.lang.vf import _require_raw_mode

from cannbotdsl.ops.reg._common import _raw_vreg_type, _tag_raw_op
from cannbotdsl.ops.reg.mask import Mask
from cannbotdsl.ops.reg.reg_defs import RawVReg


def vhistogram_frequency(src: RawVReg, *, mask: Mask, bin: int = 0) -> RawVReg:
    """Accumulate per-bin element counts (uint8 src -> uint16 dst).

    bin=0: histogram over bits 7:0 of each element
    bin=1: histogram over bits 15:8 of each element
    """
    _require_raw_mode("vhistogram_frequency")
    if bin not in (0, 1):
        raise ValueError(f"bin must be 0 or 1, got {bin}")
    result_dtype = ir.IntegerType.get_unsigned(16)
    op = ascvec.VFrequencyHistogramOp(
        _raw_vreg_type(result_dtype),
        src.value,
        mask.value,
        bin=bin,
    )
    _tag_raw_op(op)
    return RawVReg(op.result, result_dtype)


def vhistogram_accumulate(acc: RawVReg, src: RawVReg, *, mask: Mask, bin: int = 0) -> RawVReg:
    """Accumulate per-bin counts into a running uint16 register (arch35 ACCUMULATE).

    Faithful port of ``MicroAPI::Histograms<u8, u16, BINx, ACCUMULATE>(acc, src,
    preg)`` (lowers to ``chistv2`` / ``asc_cumulative_histogram_bin0/1``): for
    each lane where ``mask`` is true, adds 1 to bin ``src[i]`` of ``acc`` and
    returns the updated register. Chain the result back into ``acc`` across
    chunks to build one 256-bin histogram in-register.

    bin=0: histogram over bits 7:0 of each element (bins 0..127)
    bin=1: histogram over bits 15:8 of each element (bins 128..255)
    """
    _require_raw_mode("vhistogram_accumulate")
    if bin not in (0, 1):
        raise ValueError(f"bin must be 0 or 1, got {bin}")
    result_dtype = ir.IntegerType.get_unsigned(16)
    op = ascvec.VCumulativeHistogramOp(
        _raw_vreg_type(result_dtype),
        acc.value,
        src.value,
        mask.value,
        bin=bin,
    )
    _tag_raw_op(op)
    return RawVReg(op.result, result_dtype)
