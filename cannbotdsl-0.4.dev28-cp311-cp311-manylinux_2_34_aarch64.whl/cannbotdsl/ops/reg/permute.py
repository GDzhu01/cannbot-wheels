# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode lane permute, pack and squeeze ops."""

from cannbotdsl._mlir.dialects import ascvec, cannir

from cannbotdsl.lang.vf import _require_raw_mode

from cannbotdsl.ops.reg._common import _dtype_bits, _dtype_type, _raw_mask_type, _raw_vreg_type, _tag_raw_op
from cannbotdsl.ops.reg.mask import Mask
from cannbotdsl.ops.reg.reg_defs import RawVReg


def vpack(src: RawVReg, dtype, *, part: str = "lower") -> RawVReg:
    """Pack narrow elements from 32/16-bit slots into contiguous bytes.

    arch35 ``Pack<T>(dst, src)``: extracts the low b8 payload from each b16
    slot (or low b16 from each b32 slot) and writes them contiguously into the
    destination register. ``part`` selects which half of each slot feeds the
    pack: only ``"lower"`` (asc_pack_to_low) and ``"highest"``
    (asc_pack_to_high) are accepted. ``dtype`` is the (narrower) result
    element type.
    """
    _require_raw_mode("vpack")
    if part == "lower":
        ir_part = "low"
    elif part == "highest":
        ir_part = "high"
    else:
        raise ValueError("vpack: part must be 'lower' or 'highest'")
    dtype = _dtype_type(dtype)
    if _dtype_bits(src.dtype) <= _dtype_bits(dtype):
        raise ValueError(f"vpack: src dtype {src.dtype} must be wider than dst {dtype}")
    op = ascvec.VPackOp(
        _raw_vreg_type(dtype), src.value,
        _dtype_bits(src.dtype), _dtype_bits(dtype), ir_part,
    )
    _tag_raw_op(op)
    return RawVReg(op.result, dtype)


def vunpack(src: RawVReg, dtype, *, part: str = "lower") -> RawVReg:
    """Expand packed bytes into wider slots (register-level unpack).

    Inverse of :func:`vpack`; ``part="lower"`` keeps each byte in the low half
    of its b16 slot (asc_unpack_lower), ``"upper"`` in the high half.
    """
    _require_raw_mode("vunpack")
    if part not in ("lower", "upper"):
        raise ValueError("vunpack: part must be 'lower' or 'upper'")
    dtype = _dtype_type(dtype)
    if _dtype_bits(src.dtype) >= _dtype_bits(dtype):
        raise ValueError(f"vunpack: src dtype {src.dtype} must be narrower than dst {dtype}")
    op = ascvec.VUnpackOp(_raw_vreg_type(dtype), src.value, part)
    _tag_raw_op(op)
    return RawVReg(op.result, dtype)


def vsqueeze(mask: Mask, dtype) -> RawVReg:
    """Expand a mask into per-lane prefix popcounts (arch35 ``vsqueeze``).

    For each lane ``i``, ``result[i]`` = number of set bits in ``mask[0..i-1]``.
    Lowers to ``asc_unsqueeze(dst, mask)``.
    """
    _require_raw_mode("vsqueeze")
    dtype = _dtype_type(dtype)
    op = ascvec.VUnsqueezeOp(_raw_vreg_type(dtype), mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, dtype)


def vdeinterleave(src0, src1):
    """Deinterleave two raw vector or predicate registers.

    Two ``RawVReg`` inputs lower to
    ``asc_deintlv(result0, result1, src0, src1)``. Two ``Mask`` inputs lower to
    ``asc_deintlv_b8/b16/b32`` according to their shared ``elem_bits``.
    """
    _require_raw_mode("vdeinterleave")
    if isinstance(src0, RawVReg) and isinstance(src1, RawVReg):
        if src0.dtype != src1.dtype:
            raise ValueError(f"vdeinterleave: dtype mismatch {src0.dtype} vs {src1.dtype}")
        bits = _dtype_bits(src0.dtype)
        if bits not in (8, 16, 32):
            raise TypeError("vdeinterleave: RawVReg dtype must be 8-bit, 16-bit, or 32-bit")
        result_ty = _raw_vreg_type(src0.dtype)
        op = ascvec.DeinterleaveOp(
            result_ty, result_ty, src0.value, src1.value
        )
        _tag_raw_op(op)
        return (
            RawVReg(op.result0, src0.dtype),
            RawVReg(op.result1, src0.dtype),
        )

    if isinstance(src0, Mask) and isinstance(src1, Mask):
        if src0.elem_bits != src1.elem_bits:
            raise ValueError(
                "vdeinterleave: mask elem_bits mismatch "
                f"{src0.elem_bits} vs {src1.elem_bits}"
            )
        if src0.elem_bits not in (8, 16, 32):
            raise ValueError("vdeinterleave: mask elem_bits must be 8, 16, or 32")
        result_ty = _raw_mask_type(src0.elem_bits)
        op = ascvec.MaskDeinterleaveOp(
            result_ty, result_ty, src0.value, src1.value,
            elem_bits=src0.elem_bits,
        )
        _tag_raw_op(op)
        return (
            Mask(op.result0, src0.elem_bits),
            Mask(op.result1, src0.elem_bits),
        )

    raise TypeError(
        "vdeinterleave: src0 and src1 must both be RawVReg or both be Mask"
    )


def vcompress(src: RawVReg, *, mask: Mask) -> RawVReg:
    """Compress vector: keep elements where mask is true, discard others
    (asc_squeeze element-compaction overload)."""
    _require_raw_mode("vcompress")
    op = ascvec.VSqueezeOp(_raw_vreg_type(src.dtype), src.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vinterleave(src0, src1):
    """Interleave two registers (asc_intlv family, wide = dtype bits).

    Returns ``(dst0, dst1)``: even-indexed source elements land in dst0,
    odd-indexed in dst1. Accepts two RawVReg (dtype must match) or two Mask
    (elem_bits must match). The arch35 intlv/deintlv CAPI and the underlying
    vintlv/vlds-DINTLV instructions carry no exec mask.
    """
    _require_raw_mode("vinterleave")
    if isinstance(src0, RawVReg) and isinstance(src1, RawVReg):
        if src0.dtype != src1.dtype:
            raise ValueError(f"vinterleave: dtype mismatch {src0.dtype} vs {src1.dtype}")
        bits = _dtype_bits(src0.dtype)
        if bits not in (8, 16, 32):
            raise TypeError("vinterleave: RawVReg dtype must be 8-bit, 16-bit, or 32-bit")
        result_ty = _raw_vreg_type(src0.dtype)
        op = ascvec.InterleaveOp(result_ty, result_ty, src0.value, src1.value)
        _tag_raw_op(op)
        return RawVReg(op.low, src0.dtype), RawVReg(op.high, src0.dtype)
    if isinstance(src0, Mask) and isinstance(src1, Mask):
        if src0.elem_bits != src1.elem_bits:
            raise ValueError(
                f"vinterleave: elem_bits mismatch {src0.elem_bits} vs {src1.elem_bits}"
            )
        if src0.elem_bits not in (8, 16, 32):
            raise TypeError("vinterleave: Mask elem_bits must be 8, 16, or 32")
        op = ascvec.MaskInterleaveOp(
            _raw_mask_type(src0.elem_bits), _raw_mask_type(src0.elem_bits),
            src0.value, src1.value,
            elem_bits=src0.elem_bits,
        )
        _tag_raw_op(op)
        return Mask(op.result0, src0.elem_bits), Mask(op.result1, src0.elem_bits)
    raise TypeError("vinterleave: src0 and src1 must both be RawVReg or both be Mask")
