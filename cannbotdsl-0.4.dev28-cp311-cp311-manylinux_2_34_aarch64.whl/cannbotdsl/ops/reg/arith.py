# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode arithmetic and elementwise math ops."""

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import ascvec, cannir

from cannbotdsl.lang.vf import _require_raw_mode

from cannbotdsl.ops.reg._common import _dtype_bits, _dtype_type, _raw_mask_type, _raw_vreg_type, _scalar_value, _tag_raw_op
from cannbotdsl.ops.reg.mask import Mask, _binary, _unary
from cannbotdsl.ops.reg.reg_defs import RawVReg


def _carry_dtype_check(name: str, src0: RawVReg, src1: RawVReg):
    if src0.dtype != src1.dtype:
        raise ValueError(f"{name}: dtype mismatch {src0.dtype} vs {src1.dtype}")
    if not isinstance(src0.dtype, ir.IntegerType) or src0.dtype.width != 32:
        raise ValueError(f"{name}: carry ops are uint32-only (CAPI asc_addc/asc_add overloads)")


def vaddc(src0: RawVReg, src1: RawVReg, carry_src: Mask, *, mask: Mask):
    """Vector add with per-lane carry-in / carry-out (arch35 ``vaddcs``).

    Returns ``(carry, dst)``: ``dst = src0 + src1 + carry_src`` with the
    per-lane carry flag ``carry``. Lowers to ``asc_addc(...)``. uint32-only.
    """
    _require_raw_mode("vaddc")
    _carry_dtype_check("vaddc", src0, src1)
    bits = _dtype_bits(src0.dtype)
    op = ascvec.VAddcOp(
        _raw_mask_type(bits), _raw_vreg_type(src0.dtype),
        src0.value, src1.value, mask.value, carry_src=carry_src.value,
    )
    _tag_raw_op(op)
    return Mask(op.carry, bits), RawVReg(op.dst, src0.dtype)


def vsubc(src0: RawVReg, src1: RawVReg, borrow_src: Mask, *, mask: Mask):
    """Vector subtract with per-lane borrow-in / borrow-out (arch35 ``vsubcs``).

    Returns ``(borrow, dst)``: ``dst = src0 - src1 - borrow_src`` with the
    per-lane borrow flag ``borrow``. Lowers to ``asc_subc(...)``. uint32-only.
    """
    _require_raw_mode("vsubc")
    _carry_dtype_check("vsubc", src0, src1)
    bits = _dtype_bits(src0.dtype)
    op = ascvec.VSubcOp(
        _raw_mask_type(bits), _raw_vreg_type(src0.dtype),
        src0.value, src1.value, mask.value, carry_src=borrow_src.value,
    )
    _tag_raw_op(op)
    return Mask(op.carry, bits), RawVReg(op.dst, src0.dtype)


def vaddco(src0: RawVReg, src1: RawVReg, *, mask: Mask):
    """Vector add with carry-out only (asc_add carry overload, 5-arg form).

    Returns ``(carry, dst)``: ``dst = src0 + src1`` with the per-lane carry
    flag ``carry`` (no carry-in). uint32-only.
    """
    _require_raw_mode("vaddco")
    _carry_dtype_check("vaddco", src0, src1)
    bits = _dtype_bits(src0.dtype)
    op = ascvec.VAddcOp(
        _raw_mask_type(bits), _raw_vreg_type(src0.dtype),
        src0.value, src1.value, mask.value,
    )
    _tag_raw_op(op)
    return Mask(op.carry, bits), RawVReg(op.dst, src0.dtype)


def vsubbo(src0: RawVReg, src1: RawVReg, *, mask: Mask):
    """Vector subtract with borrow-out only (asc_sub borrow overload, 5-arg form).

    Returns ``(borrow, dst)``: ``dst = src0 - src1`` with the per-lane borrow
    flag ``borrow`` (no borrow-in). uint32-only.
    """
    _require_raw_mode("vsubbo")
    _carry_dtype_check("vsubbo", src0, src1)
    bits = _dtype_bits(src0.dtype)
    op = ascvec.VSubcOp(
        _raw_mask_type(bits), _raw_vreg_type(src0.dtype),
        src0.value, src1.value, mask.value,
    )
    _tag_raw_op(op)
    return Mask(op.carry, bits), RawVReg(op.dst, src0.dtype)


def vmull(src0: RawVReg, src1: RawVReg, dtype, *, mask: Mask):
    """Wide vector multiply (arch35 ``vmull``).

    Returns ``(dst0, dst1)``: the 64-bit product of u32 lanes split into low
    (dst0) and high (dst1) 32-bit registers. Lowers to ``asc_mull(...)``.
    """
    _require_raw_mode("vmull")
    if src0.dtype != src1.dtype:
        raise ValueError(f"vmull: dtype mismatch {src0.dtype} vs {src1.dtype}")
    dtype = _dtype_type(dtype)
    # The CAPI only provides 32x32 -> (low32, high32) overloads (u32/i32).
    if _dtype_bits(src0.dtype) != 32 or _dtype_bits(dtype) != 32:
        raise ValueError(
            f"vmull: only 32-bit sources and 32-bit result are supported "
            f"(asc_mull has no {_dtype_bits(src0.dtype)}-bit overload), got "
            f"src={src0.dtype}, result={dtype}"
        )
    out_ty = _raw_vreg_type(dtype)
    op = ascvec.VMullOp(out_ty, out_ty, src0.value, src1.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.dst0, dtype), RawVReg(op.dst1, dtype)


def vadd(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    return _binary(lhs, rhs, mask, ascvec.VAddOp, "vadd")


def vsub(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    return _binary(lhs, rhs, mask, ascvec.VSubOp, "vsub")


def vmul(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    return _binary(lhs, rhs, mask, ascvec.VMulOp, "vmul")


def vdiv(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    return _binary(lhs, rhs, mask, ascvec.VDivOp, "vdiv")


def vmax(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    return _binary(lhs, rhs, mask, ascvec.VMaxOp, "vmax")


def vmin(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    return _binary(lhs, rhs, mask, ascvec.VMinOp, "vmin")


def vexp(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.VExpOp, "vexp")


def vlog(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.VLnOp, "vlog")


def vsqrt(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.VSqrtOp, "vsqrt")


def vrelu(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.VReluOp, "vrelu")


def vabs(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.VAbsOp, "vabs")


def vneg(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.VNegOp, "vneg")


def vabs_sub(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    return _binary(lhs, rhs, mask, ascvec.VAbsSubOp, "vabs_sub")


def vprelu(src: RawVReg, slope: RawVReg, *, mask: Mask) -> RawVReg:
    return _binary(src, slope, mask, ascvec.VPreluOp, "vprelu")


def vexp_sub(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    _require_raw_mode("vexp_sub")
    if lhs.dtype != rhs.dtype:
        raise ValueError(f"vexp_sub: dtype mismatch {lhs.dtype} vs {rhs.dtype}")
    if str(lhs.dtype) not in ("f16", "f32"):
        raise TypeError("vexp_sub: source dtype must be f16 or f32")
    out_dtype = ir.F32Type.get()
    op = ascvec.VExpSubOp(_raw_vreg_type(out_dtype), lhs.value, rhs.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, out_dtype)


def vcast_exp_sub(lhs: RawVReg, rhs: RawVReg, *, mask: Mask,
                  dtype=None) -> RawVReg:
    """exp(lhs) - exp(rhs) with implicit cast of mismatched inputs to f32.

    When ``lhs``/``rhs`` are f16 the result is f32 (asc_exp_sub_half2float);
    f32 inputs pass through unchanged. Unlike :func:`vexp_sub` this accepts
    mixed f16/f32 inputs by casting the f16 side to f32 first. ``dtype``
    selects the result element type; only f32 is supported today (default).
    """
    _require_raw_mode("vcast_exp_sub")
    dtype = ir.F32Type.get() if dtype is None else _dtype_type(dtype)
    if not isinstance(dtype, ir.F32Type):
        raise TypeError("vcast_exp_sub: only dtype=float32 is supported")
    if str(lhs.dtype) not in ("f16", "f32") or str(rhs.dtype) not in ("f16", "f32"):
        raise TypeError("vcast_exp_sub: source dtype must be f16 or f32")
    if lhs.dtype != rhs.dtype:
        # local import: cast.py is a peer module in this package
        from cannbotdsl.ops.reg.cast import vcast
        if str(lhs.dtype) == "f16":
            lhs = vcast(lhs, ir.F32Type.get(), mask=mask)
        if str(rhs.dtype) == "f16":
            rhs = vcast(rhs, ir.F32Type.get(), mask=mask)
    return vexp_sub(lhs, rhs, mask=mask)


def vmadd(acc: RawVReg, lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    """Multiply-accumulate: result = lhs * rhs + acc (asc_madd / vmadd).

    Pass the returned register as the next call's acc to chain
    accumulation (SSA-style in-place).
    """
    _require_raw_mode("vmadd")
    if acc.dtype != lhs.dtype or acc.dtype != rhs.dtype:
        raise ValueError(f"vmadd: dtype mismatch {acc.dtype}/{lhs.dtype}/{rhs.dtype}")
    op = ascvec.VMaddOp(_raw_vreg_type(acc.dtype), acc.value, lhs.value, rhs.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, acc.dtype)


def vmuls(src: RawVReg, scalar, *, mask: Mask) -> RawVReg:
    """Vector * scalar (same-dtype) with mask. Lowers to `asc_mul_scalar`."""
    _require_raw_mode("vmuls")
    scalar_v = _scalar_value(scalar, src.dtype)
    op = ascvec.VMulScalarOp(_raw_vreg_type(src.dtype), src.value, scalar_v, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vadds(src: RawVReg, scalar, *, mask: Mask) -> RawVReg:
    """Vector + scalar (same-dtype) with mask. Lowers to `asc_add_scalar`."""
    _require_raw_mode("vadds")
    scalar_v = _scalar_value(scalar, src.dtype)
    op = ascvec.VAddScalarOp(_raw_vreg_type(src.dtype), src.value, scalar_v, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vmaxs(src: RawVReg, scalar, *, mask: Mask) -> RawVReg:
    """Vector max scalar (same-dtype) with mask. Lowers to `asc_max_scalar`."""
    _require_raw_mode("vmaxs")
    scalar_v = _scalar_value(scalar, src.dtype)
    op = ascvec.VMaxScalarOp(_raw_vreg_type(src.dtype), src.value, scalar_v, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vmins(src: RawVReg, scalar, *, mask: Mask) -> RawVReg:
    """Vector min scalar (same-dtype) with mask. Lowers to `asc_min_scalar`."""
    _require_raw_mode("vmins")
    scalar_v = _scalar_value(scalar, src.dtype)
    op = ascvec.VMinScalarOp(_raw_vreg_type(src.dtype), src.value, scalar_v, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vleakyrelu(src: RawVReg, slope, *, mask: Mask) -> RawVReg:
    """Vector leaky ReLU with scalar slope. Lowers to `asc_leakyrelu`."""
    _require_raw_mode("vleakyrelu")
    scalar_v = _scalar_value(slope, src.dtype)
    op = ascvec.VLeakyReluOp(_raw_vreg_type(src.dtype), src.value, scalar_v, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vaxpy(acc: RawVReg, src: RawVReg, scalar, *, mask: Mask) -> RawVReg:
    """Vector AXPY into `acc`. Lowers to `asc_axpy(acc, src, scalar, mask)`."""
    _require_raw_mode("vaxpy")
    if acc.dtype != src.dtype:
        raise ValueError(f"vaxpy: dtype mismatch {acc.dtype} vs {src.dtype}")
    scalar_v = _scalar_value(scalar, src.dtype)
    op = ascvec.VAxpyOp(_raw_vreg_type(acc.dtype), acc.value, src.value, scalar_v, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, acc.dtype)
