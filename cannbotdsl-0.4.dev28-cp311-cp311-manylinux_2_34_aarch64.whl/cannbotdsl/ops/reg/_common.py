# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Shared private helpers for the raw register-mode VF ops."""

from contextvars import ContextVar

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir

from cannbotdsl.ir_transport import unwrap_operand
from cannbotdsl.lang.vf import _current_vf_mode, _tag_if_in_vf


_INSIDE_RAW_VF_LOOP_BODY: ContextVar[bool] = ContextVar("cannbotdsl_inside_raw_vf_loop_body", default=False)


def _dtype_type(dtype):
    if isinstance(dtype, ir.Type):
        return dtype
    from cannbotdsl.core.contracts.elements import storage_mlir_type_for_dtype

    return storage_mlir_type_for_dtype(dtype)


def _raw_tensor_operand(tensor, *, operation="raw register operation"):
    """Accept a memref Tensor *or* a high-level Channel as a raw-op target.

    Returns ``(operand_value, mlir_dtype)``. For a Channel the ChannelType SSA
    value is passed straight through; ``cannir-resolve-channel-operands`` then
    brackets the wait/release (in-place consume) or acquire/commit (produce)
    around the enclosing ``vf_group`` run (channel_first_class_design_v2 §9.3),
    so a raw-mode vf can read/write a channel slot channel-first.
    """
    from cannbotdsl.channel import Channel
    from cannbotdsl.core.contracts.elements import storage_mlir_type_for_dtype
    from cannbotdsl.types import Tensor

    if not isinstance(tensor, (Tensor, Channel)):
        raise TypeError(
            f"{operation}: memory operand must be Tensor or Channel, got "
            f"{type(tensor).__name__}"
        )
    return unwrap_operand(tensor), storage_mlir_type_for_dtype(tensor.dtype)


_ASC_TYPE_CACHE: dict[str, ir.Type] = {}


def _parse_asc_type(text: str) -> ir.Type:
    """Parse one AscVec register type string, caching per context."""
    cached = _ASC_TYPE_CACHE.get(text)
    if cached is not None and cached.context == ir.Context.current:
        return cached
    parsed = ir.Type.parse(text)
    _ASC_TYPE_CACHE[text] = parsed
    return parsed


def _raw_vreg_type(dtype: ir.Type) -> ir.Type:
    return _parse_asc_type(f"!ascvec.vreg<{dtype}>")


def _raw_mask_type(elem_bits: int) -> ir.Type:
    # The AscVec mask register type is unparameterized; elem_bits lives on
    # the mask-producing instruction.
    return _parse_asc_type("!ascvec.mask")


def _dtype_bits(dtype: ir.Type) -> int:
    from cannbotdsl.core.contracts.elements import dtype_for_storage_mlir_type

    try:
        return dtype_for_storage_mlir_type(dtype).bits
    except TypeError as error:
        raise TypeError(f"unsupported raw register dtype {dtype}") from error


def _is_integer_dtype(dtype: ir.Type) -> bool:
    text = str(dtype)
    return text.startswith("i") or text.startswith("ui")


def _normalize_width(width, *, name: str) -> str:
    if not isinstance(width, str):
        raise TypeError(f"{name}: width must be one of 'b8', 'b16', or 'b32'")
    key = width.lower()
    if key not in ("b8", "b16", "b32"):
        raise ValueError(f"{name}: width must be one of 'b8', 'b16', or 'b32'")
    return key


def _tag_raw_op(op) -> None:
    if _current_vf_mode() != "raw":
        return
    if not _INSIDE_RAW_VF_LOOP_BODY.get():
        _tag_if_in_vf(op)


def _as_offset(offset):
    from cannbotdsl.core.scalar_conversion import coerce_scalar_value

    return coerce_scalar_value(offset, ir.IndexType.get())


def _scalar_value(value, dtype: ir.Type):
    from cannbotdsl.core.scalar_conversion import coerce_scalar_value

    if isinstance(dtype, ir.IntegerType):
        # arith.constant requires signless integers; unsigned types (e.g. ui16)
        # must use the signless equivalent for the constant op itself.
        scalar_type = (
            ir.IntegerType.get_signless(dtype.width)
            if dtype.is_unsigned
            else dtype
        )
        return coerce_scalar_value(
            value,
            scalar_type,
            target_unsigned=dtype.is_unsigned,
        )
    return coerce_scalar_value(value, dtype)
