# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software; you can redistribute it and/or modify it under the terms and conditions of
# the CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Pure HCCL C-API wrapper layer.

Library loading, ctypes struct definitions, HCCL function bindings, and
stateless operation functions.  No datastruct, no CommContext, no CommGroup,
no business logic — those live in ``cannbotdsl.ops.distributed.context``.
"""

from __future__ import annotations

import ctypes
import os
import struct
from typing import Optional

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

COMM_ENGINE_AIV = 4
COMM_PROTOCOL_UBC_CTP = 4
COMM_PROTOCOL_UB_MEM = 6
CHANNEL_NOTIFY_NUM = 3

_HCCL_SUCCESS = 0

# ---------------------------------------------------------------------------
# Library loading (with _MissingLibrary fallback for CPU-only environments)
# ---------------------------------------------------------------------------


class _MissingFunction:
    """ctypes-compatible placeholder used by CPU-only contract tests."""

    argtypes = None
    restype = None

    def __init__(self, message: str):
        self._message = message

    def __call__(self, *args, **kwargs):
        raise RuntimeError(self._message)


class _MissingLibrary:
    def __init__(self, names: list[str]):
        self._message = (
            f"cannot find {names}; source the CANN environment before "
            "constructing CommGroup"
        )
        self._functions: dict[str, _MissingFunction] = {}

    def __getattr__(self, name: str):
        return self._functions.setdefault(name, _MissingFunction(self._message))


def _find_library(names: list[str]):
    search_paths = [
        os.environ.get("ASCEND_HOME_PATH", ""),
        os.environ.get("ASCEND_TOOLKIT_HOME", ""),
        os.environ.get("LD_LIBRARY_PATH", "").split(":"),
    ]
    flat: list[str] = []
    for p in search_paths:
        if isinstance(p, str) and p:
            flat.append(p)
        elif isinstance(p, list):
            flat.extend(x for x in p if x)
    for name in names:
        try:
            return ctypes.CDLL(name)
        except OSError:
            pass
        for d in flat:
            full = os.path.join(d, name)
            if os.path.isfile(full):
                try:
                    return ctypes.CDLL(full)
                except OSError:
                    pass
    return _MissingLibrary(names)


_libhccl = _find_library(["libhccl.so", "libhccl.so.0"])
_libhccl_fwk = _find_library(["libhccl_fwk.so"])
_libascendcl = _find_library(["libascendcl.so"])

_libascendcl.aclrtMemset.argtypes = [
    ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int32, ctypes.c_size_t,
]
_libascendcl.aclrtMemset.restype = ctypes.c_int32
_libascendcl.aclrtMemcpy.argtypes = [
    ctypes.c_void_p, ctypes.c_size_t,
    ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int32,
]
_libascendcl.aclrtMemcpy.restype = ctypes.c_int32

# ---------------------------------------------------------------------------
# ctypes struct definitions
# ---------------------------------------------------------------------------


class CommAbiHeader(ctypes.Structure):
    _fields_ = [
        ("version", ctypes.c_uint32),
        ("magicWord", ctypes.c_uint32),
        ("size", ctypes.c_uint32),
        ("reserved", ctypes.c_uint32),
    ]


class CommAddr(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_int32),
        ("raws", ctypes.c_uint8 * 36),
    ]


class EndpointLoc(ctypes.Structure):
    _fields_ = [
        ("locType", ctypes.c_int32),
        ("raws", ctypes.c_uint8 * 60),
    ]


class EndpointDesc(ctypes.Structure):
    _fields_ = [
        ("protocol", ctypes.c_int32),
        ("commAddr", CommAddr),
        ("loc", EndpointLoc),
        ("raws", ctypes.c_uint8 * 52),
    ]


class HcclChannelDesc(ctypes.Structure):
    _fields_ = [
        ("header", CommAbiHeader),
        ("remoteRank", ctypes.c_uint32),
        ("channelProtocol", ctypes.c_int32),
        ("localEndpoint", EndpointDesc),
        ("remoteEndpoint", EndpointDesc),
        ("notifyNum", ctypes.c_uint32),
        ("memHandles", ctypes.c_void_p),
        ("memHandleNum", ctypes.c_uint32),
        ("raws", ctypes.c_uint8 * 128),
    ]


class CommLinkAttr(ctypes.Union):
    _fields_ = [
        ("raws", ctypes.c_uint8 * 128),
        ("linkProtocol", ctypes.c_int32),
    ]


class CommLink(ctypes.Structure):
    _fields_ = [
        ("header", CommAbiHeader),
        ("srcEndpointDesc", EndpointDesc),
        ("dstEndpointDesc", EndpointDesc),
        ("linkAttr", CommLinkAttr),
    ]


class CommMem(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_int32),
        ("addr", ctypes.c_void_p),
        ("size", ctypes.c_uint64),
    ]


HCCL_CHANNEL_MAGIC_WORD = 0x0F0F0F0F
HCCL_CHANNEL_VERSION = 1

# ---------------------------------------------------------------------------
# HCCL function bindings
# ---------------------------------------------------------------------------

# --- libhccl.so (public) ---

_libhccl.HcclGetRankId.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32)]
_libhccl.HcclGetRankId.restype = ctypes.c_int32

_libhccl.HcclGetRankSize.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32)]
_libhccl.HcclGetRankSize.restype = ctypes.c_int32

# --- libhccl_fwk.so (framework) ---

_libhccl_fwk.HcomGetCommHandleByGroup.argtypes = [
    ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p),
]
_libhccl_fwk.HcomGetCommHandleByGroup.restype = ctypes.c_int32

_libhccl_fwk.HcclGetHcclBuffer.argtypes = [
    ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(ctypes.c_uint64),
]
_libhccl_fwk.HcclGetHcclBuffer.restype = ctypes.c_int32

_libhccl_fwk.HcclChannelAcquire.argtypes = [
    ctypes.c_void_p, ctypes.c_int32, ctypes.POINTER(HcclChannelDesc),
    ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint64),
]
_libhccl_fwk.HcclChannelAcquire.restype = ctypes.c_int32

_libhccl_fwk.HcclChannelGetHcclBuffer.argtypes = [
    ctypes.c_void_p, ctypes.c_uint64,
    ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(ctypes.c_uint64),
]
_libhccl_fwk.HcclChannelGetHcclBuffer.restype = ctypes.c_int32

_libhccl_fwk.HcclChannelGetRemoteMems.argtypes = [
    ctypes.c_void_p, ctypes.c_uint64,
    ctypes.POINTER(ctypes.c_uint32),
    ctypes.POINTER(ctypes.POINTER(CommMem)),
    ctypes.POINTER(ctypes.POINTER(ctypes.c_char_p)),
]
_libhccl_fwk.HcclChannelGetRemoteMems.restype = ctypes.c_int32

_libhccl_fwk.HcclCommMemReg.argtypes = [
    ctypes.c_void_p, ctypes.c_char_p,
    ctypes.POINTER(CommMem), ctypes.POINTER(ctypes.c_void_p),
]
_libhccl_fwk.HcclCommMemReg.restype = ctypes.c_int32

_libhccl_fwk.HcclEngineCtxCreate.argtypes = [
    ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int32,
    ctypes.c_uint64, ctypes.POINTER(ctypes.c_void_p),
]
_libhccl_fwk.HcclEngineCtxCreate.restype = ctypes.c_int32

_libhccl_fwk.HcclEngineCtxGet.argtypes = [
    ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int32,
    ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(ctypes.c_uint64),
]
_libhccl_fwk.HcclEngineCtxGet.restype = ctypes.c_int32

_libhccl_fwk.HcclEngineCtxCopy.argtypes = [
    ctypes.c_void_p, ctypes.c_int32, ctypes.c_char_p,
    ctypes.c_void_p, ctypes.c_uint64, ctypes.c_uint64,
]
_libhccl_fwk.HcclEngineCtxCopy.restype = ctypes.c_int32

_libhccl_fwk.HcclRankGraphGetLayers.argtypes = [
    ctypes.c_void_p,
    ctypes.POINTER(ctypes.POINTER(ctypes.c_uint32)),
    ctypes.POINTER(ctypes.c_uint32),
]
_libhccl_fwk.HcclRankGraphGetLayers.restype = ctypes.c_int32

_libhccl_fwk.HcclRankGraphGetLinks.argtypes = [
    ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32,
    ctypes.POINTER(ctypes.POINTER(CommLink)), ctypes.POINTER(ctypes.c_uint32),
]
_libhccl_fwk.HcclRankGraphGetLinks.restype = ctypes.c_int32

_libhccl_fwk.HcclRankGraphGetRankSizeByLayer.argtypes = [
    ctypes.c_void_p, ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32),
]
_libhccl_fwk.HcclRankGraphGetRankSizeByLayer.restype = ctypes.c_int32

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _check_hccl_result(ret, func_name):
    if ret != _HCCL_SUCCESS:
        raise RuntimeError(f"HCCL {func_name} failed with code {ret}")


def init_channel_desc(desc: HcclChannelDesc):
    """Initialize an HcclChannelDesc to default values."""
    ctypes.memset(ctypes.addressof(desc), 0xFF, ctypes.sizeof(HcclChannelDesc))
    desc.header.version = HCCL_CHANNEL_VERSION
    desc.header.magicWord = HCCL_CHANNEL_MAGIC_WORD
    desc.header.size = ctypes.sizeof(HcclChannelDesc)
    desc.header.reserved = 0
    desc.remoteRank = 0xFFFFFFFF
    desc.channelProtocol = -1
    desc.notifyNum = 0
    desc.memHandles = None
    desc.memHandleNum = 0


# ---------------------------------------------------------------------------
# Stateless HCCL operation functions
# ---------------------------------------------------------------------------


def get_comm_handle(group_name: str) -> int:
    """Resolve a torch.distributed group name to an HCCL comm handle."""
    handle = ctypes.c_void_p()
    ret = _libhccl_fwk.HcomGetCommHandleByGroup(
        group_name.encode("utf-8"), ctypes.byref(handle)
    )
    _check_hccl_result(ret, "HcomGetCommHandleByGroup")
    return handle.value


def get_rank_id(comm: int) -> int:
    rank = ctypes.c_uint32()
    ret = _libhccl.HcclGetRankId(comm, ctypes.byref(rank))
    _check_hccl_result(ret, "HcclGetRankId")
    return rank.value


def get_rank_size(comm: int) -> int:
    size = ctypes.c_uint32()
    ret = _libhccl.HcclGetRankSize(comm, ctypes.byref(size))
    _check_hccl_result(ret, "HcclGetRankSize")
    return size.value


def get_rank_graph_layers(comm: int) -> list[int]:
    layers_ptr = ctypes.POINTER(ctypes.c_uint32)()
    layer_num = ctypes.c_uint32()
    ret = _libhccl_fwk.HcclRankGraphGetLayers(
        comm, ctypes.byref(layers_ptr), ctypes.byref(layer_num)
    )
    _check_hccl_result(ret, "HcclRankGraphGetLayers")
    return [layers_ptr[i] for i in range(layer_num.value)]


def get_rank_size_by_layer(comm: int, layer_id: int) -> int:
    rank_num = ctypes.c_uint32()
    ret = _libhccl_fwk.HcclRankGraphGetRankSizeByLayer(
        comm, layer_id, ctypes.byref(rank_num)
    )
    _check_hccl_result(ret, "HcclRankGraphGetRankSizeByLayer")
    return rank_num.value


def get_links(comm: int, layer_id: int, src_rank: int, dst_rank: int):
    """Return (links_list, link_num)."""
    links_ptr = ctypes.POINTER(CommLink)()
    link_num = ctypes.c_uint32()
    ret = _libhccl_fwk.HcclRankGraphGetLinks(
        comm, layer_id, src_rank, dst_rank,
        ctypes.byref(links_ptr), ctypes.byref(link_num),
    )
    _check_hccl_result(ret, "HcclRankGraphGetLinks")
    return [links_ptr[i] for i in range(link_num.value)], link_num.value


def acquire_channel(
    comm: int,
    engine: int,
    protocol: int,
    peer: int,
    layer_id: int,
    links: list[CommLink],
    *,
    mem_handles: Optional[list[int]] = None,
) -> int:
    """Acquire an HCCL channel to a peer rank with the given engine/protocol."""
    desc = HcclChannelDesc()
    init_channel_desc(desc)
    desc.remoteRank = peer
    desc.channelProtocol = protocol
    desc.notifyNum = CHANNEL_NOTIFY_NUM

    if mem_handles is not None and len(mem_handles) > 0:
        arr = (ctypes.c_void_p * len(mem_handles))()
        for i, h in enumerate(mem_handles):
            arr[i] = h
        desc.memHandles = ctypes.cast(arr, ctypes.c_void_p)
        desc.memHandleNum = len(mem_handles)

    link_found = False
    for link in links:
        if link.linkAttr.linkProtocol == protocol:
            desc.localEndpoint = link.srcEndpointDesc
            desc.remoteEndpoint = link.dstEndpointDesc
            link_found = True
            break
    if not link_found:
        raise RuntimeError(
            f"No link with protocol {protocol} found between rank "
            f"and peer {peer}"
        )

    channel = ctypes.c_uint64()
    ret = _libhccl_fwk.HcclChannelAcquire(
        comm, engine, ctypes.byref(desc), 1, ctypes.byref(channel)
    )
    _check_hccl_result(ret, "HcclChannelAcquire")
    return channel.value


def get_hccl_buffer(comm: int) -> tuple[int, int]:
    """Return (addr, size) of the local HCCL built-in buffer."""
    buf = ctypes.c_void_p()
    size = ctypes.c_uint64()
    ret = _libhccl_fwk.HcclGetHcclBuffer(comm, ctypes.byref(buf), ctypes.byref(size))
    _check_hccl_result(ret, "HcclGetHcclBuffer")
    return buf.value, size.value


def get_channel_hccl_buffer(comm: int, channel: int) -> int:
    """Return the remote HCCL buffer address for a channel."""
    buf = ctypes.c_void_p()
    size = ctypes.c_uint64()
    ret = _libhccl_fwk.HcclChannelGetHcclBuffer(
        comm, channel, ctypes.byref(buf), ctypes.byref(size)
    )
    _check_hccl_result(ret, "HcclChannelGetHcclBuffer")
    return buf.value


def get_channel_remote_mems(comm: int, channel: int, tag: str):
    """Return the remote memory address matching tag, or None."""
    mem_num = ctypes.c_uint32()
    remote_mems = ctypes.POINTER(CommMem)()
    mem_tags = ctypes.POINTER(ctypes.c_char_p)()
    ret = _libhccl_fwk.HcclChannelGetRemoteMems(
        comm, channel, ctypes.byref(mem_num),
        ctypes.byref(remote_mems), ctypes.byref(mem_tags),
    )
    _check_hccl_result(ret, "HcclChannelGetRemoteMems")
    for i in range(mem_num.value):
        if mem_tags[i] and mem_tags[i].decode("utf-8") == tag:
            return remote_mems[i].addr
    if mem_num.value == 1:
        return remote_mems[0].addr
    return None


def register_mem(comm: int, tag: str, addr: int, size: int) -> int:
    """Register device memory and return a mem handle."""
    mem = CommMem()
    mem.type = 0
    mem.addr = addr
    mem.size = size
    handle = ctypes.c_void_p()
    ret = _libhccl_fwk.HcclCommMemReg(
        comm, tag.encode("utf-8"), ctypes.byref(mem), ctypes.byref(handle)
    )
    _check_hccl_result(ret, "HcclCommMemReg")
    return handle


# TODO: engine_ctx_{get,create,copy} hardcode COMM_ENGINE_AIV; parameterize
# when a non-AIV engine ctx is required (the engine axis currently flows only
# through acquire_channel, since get_device_ptr's miss path does not carry it).
def engine_ctx_get(comm: int, tag: str):
    """Return existing engine ctx device pointer, or None if not found."""
    ctx = ctypes.c_void_p()
    size = ctypes.c_uint64()
    ret = _libhccl_fwk.HcclEngineCtxGet(
        comm, tag.encode("utf-8"), COMM_ENGINE_AIV,
        ctypes.byref(ctx), ctypes.byref(size),
    )
    if ret == _HCCL_SUCCESS and ctx.value:
        return ctx.value
    return None


def engine_ctx_create(comm: int, tag: str, total_size: int) -> int:
    """Create a new engine ctx and return its device pointer."""
    ctx = ctypes.c_void_p()
    ret = _libhccl_fwk.HcclEngineCtxCreate(
        comm, tag.encode("utf-8"), COMM_ENGINE_AIV, total_size, ctypes.byref(ctx)
    )
    _check_hccl_result(ret, "HcclEngineCtxCreate")
    return ctx.value


def engine_ctx_copy(comm: int, tag: str, ctypes_ctx, ctx_size: int):
    """Copy a host-side ctypes struct into the engine ctx device memory."""
    ret = _libhccl_fwk.HcclEngineCtxCopy(
        comm, COMM_ENGINE_AIV, tag.encode("utf-8"),
        ctypes.byref(ctypes_ctx), ctx_size, 0,
    )
    _check_hccl_result(ret, "HcclEngineCtxCopy")


def mem_set(addr: int, size: int, value: int = 0):
    """Zero (or fill) device memory via aclrtMemset."""
    ret = _libascendcl.aclrtMemset(addr, size, value, size)
    if ret != 0:
        raise RuntimeError(f"aclrtMemset failed with code {ret}")


ACL_MEMCPY_HOST_TO_HOST = 0
ACL_MEMCPY_HOST_TO_DEVICE = 1
ACL_MEMCPY_DEVICE_TO_HOST = 2
ACL_MEMCPY_DEVICE_TO_DEVICE = 3


def aclrt_memcpy(dst: int, src: int, size: int, *, kind: int = ACL_MEMCPY_DEVICE_TO_DEVICE):
    """Copy memory via aclrtMemcpy (default device-to-device)."""
    ret = _libascendcl.aclrtMemcpy(dst, size, src, size, kind)
    if ret != 0:
        raise RuntimeError(f"aclrtMemcpy failed with code {ret}")
