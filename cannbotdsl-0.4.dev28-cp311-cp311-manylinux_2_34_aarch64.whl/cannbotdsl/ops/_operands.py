# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

from cannbotdsl.types import Tensor
from cannbotdsl.ir_transport import unwrap_operand

def _tensor_operand(x):
    """Validate and unwrap one public Tensor/Channel memory operand.

    Channel First-Class: data ops accept a Channel directly as an operand; the
    cannir-resolve-channel-operands pass turns the ChannelType operand into the
    acquired/waited slot plus four-primitive bracketing. See
    channel_first_class_design_v2.
    """
    from cannbotdsl.channel import Channel

    if not isinstance(x, (Tensor, Channel)):
        raise TypeError(
            "tensor operands must be Tensor or Channel, got "
            f"{type(x).__name__}"
        )
    return unwrap_operand(x)
