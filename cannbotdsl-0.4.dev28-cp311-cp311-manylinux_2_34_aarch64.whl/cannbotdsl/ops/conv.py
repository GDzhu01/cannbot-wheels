# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Conv2D geometry and tile-address planning.

The objects in this module do not perform convolution.  They describe the
static convolution geometry and turn public ``(M, N, Cin)`` tile coordinates
into tail-aware extents and clipped input windows.  Convolution-specific data
movement consumes this information; cube computation continues to use
``matmul``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import arith, cannir

import cannbotdsl.types.dtypes as dtypes
from cannbotdsl.ir_transport import unwrap_operand
from cannbotdsl.types._numeric import Int64, Integer


_PAIR = 2
_PADDING = 4


def _normalize_int_tuple(name: str, value: Sequence[int], length: int) -> tuple[int, ...]:
    if not isinstance(value, (tuple, list)) or len(value) != length:
        raise ValueError(f"{name} must contain exactly {length} integers")
    if not all(isinstance(item, int) and not isinstance(item, bool) for item in value):
        raise TypeError(f"{name} must contain only integers")
    return tuple(value)


def _positive(name: str, values: Sequence[int]) -> None:
    if any(value <= 0 for value in values):
        raise ValueError(f"{name} values must be positive, got {tuple(values)}")


def _bounded(name: str, values: Sequence[int], lower: int, upper: int) -> None:
    if any(value < lower or value > upper for value in values):
        raise ValueError(f"{name} values must be in [{lower}, {upper}], got {tuple(values)}")


def _as_i64(value):
    if isinstance(value, (int, Integer)):
        return value
    if isinstance(value, ir.Value):
        if isinstance(value.type, ir.IndexType):
            value = arith.index_cast(ir.IntegerType.get_signless(64), value)
        return Int64(value)
    raise TypeError(f"Conv2D coordinates must be Python integers or dynamic DSL integers, got {type(value).__name__}")


def _as_index(value):
    value = _as_i64(value)
    if isinstance(value, int):
        return arith.constant(ir.IndexType.get(), value)
    if isinstance(value.type, ir.IndexType):
        return value
    return arith.index_cast(ir.IndexType.get(), value)


def _unwrap_memref_or_channel(value):
    from cannbotdsl.channel import Channel
    from cannbotdsl.types import Tensor

    if not isinstance(value, (Tensor, Channel)):
        raise TypeError(f"Conv2D memory operands must be Tensor or Channel, got {type(value).__name__}")
    return unwrap_operand(value)


def _validate_l2_cache_ctl(value: int) -> None:
    if value not in (0, 1, 2, 4):
        raise ValueError("l2_cache_ctl must be one of 0, 1, 2, or 4")


def _select_i64(cond, true_value, false_value, *, template=None):
    if template is None:
        template = true_value if isinstance(true_value, ir.Value) else false_value
    if not isinstance(template, ir.Value):
        raise TypeError("dynamic Conv2D selection requires an integer SSA value")
    if isinstance(true_value, int):
        true_value = arith.constant(template.type, true_value)
    if isinstance(false_value, int):
        false_value = arith.constant(template.type, false_value)
    return type(template)(arith.select(cond, true_value, false_value))


def _minimum(value, upper: int):
    if isinstance(value, int):
        return min(value, upper)
    return _select_i64(value < upper, value, upper)


def _maximum(value, lower: int):
    if isinstance(value, int):
        return max(value, lower)
    return _select_i64(value > lower, value, lower)


def _clamp_tail(total: int, begin, block: int):
    remaining = total - begin
    return _maximum(_minimum(remaining, block), 0)


def _if_nonempty(actual, value):
    if isinstance(actual, int):
        return value if actual > 0 else 0
    return _select_i64(actual > 0, value, 0, template=actual)


@dataclass(frozen=True)
class Conv2dInputWindow:
    """Clipped input-height window and Load3D-local padding for one M tile."""

    h_raw_begin: object
    h_raw_end: object
    h_gm_begin: object
    h_gm_end: object
    l1_height: object
    l1_width: object
    pad_top: object
    pad_bottom: object
    pad_left: object
    pad_right: object
    m_start: object
    m_extension: object


@dataclass(frozen=True)
class Conv2dTile:
    """One tail-aware ``(M, N, Cin)`` tile of a :class:`Conv2dSpec`."""

    spec: "Conv2dSpec"
    tile_shape: tuple[int, int, int]
    coord: tuple[object, object, object]
    batch: object
    group: object

    @property
    def bm(self) -> int:
        return self.tile_shape[0]

    @property
    def bn(self) -> int:
        return self.tile_shape[1]

    @property
    def bc(self) -> int:
        return self.tile_shape[2]

    @property
    def m_begin(self):
        return self.coord[0] * self.bm

    @property
    def n_begin(self):
        return self.coord[1] * self.bn

    @property
    def ci_begin(self):
        return self.coord[2] * self.bc

    @property
    def m_actual(self):
        return _clamp_tail(self.spec.m_extent, self.m_begin, self.bm)

    @property
    def n_actual(self):
        return _clamp_tail(self.spec.output_channels_per_group, self.n_begin, self.bn)

    @property
    def ci_actual(self):
        return _clamp_tail(self.spec.input_channels_per_group, self.ci_begin, self.bc)

    @property
    def ci_program(self):
        return self.spec._program_channels(self.ci_actual)

    @property
    def k_program(self):
        return self.spec.kernel_height * self.spec.kernel_width * self.ci_program

    @property
    def input_window(self) -> Conv2dInputWindow:
        actual = self.m_actual
        m_last = self.m_begin + actual - 1
        oh_first = self.m_begin // self.spec.output_width
        ow_first = self.m_begin % self.spec.output_width
        oh_last = m_last // self.spec.output_width

        h_raw_begin = oh_first * self.spec.stride[0] - self.spec.padding[0]
        h_raw_end = (
            oh_last * self.spec.stride[0]
            - self.spec.padding[0]
            + (self.spec.kernel_height - 1) * self.spec.dilation[0]
            + 1
        )
        h_gm_begin = _maximum(h_raw_begin, 0)
        h_gm_end = _minimum(h_raw_end, self.spec.input_height)
        # A window wholly above or below the input has no valid GM interval.
        h_gm_begin = _minimum(h_gm_begin, self.spec.input_height)
        h_gm_end = _maximum(h_gm_end, 0)
        l1_height = _maximum(h_gm_end - h_gm_begin, 0)

        return Conv2dInputWindow(
            h_raw_begin=_if_nonempty(actual, h_raw_begin),
            h_raw_end=_if_nonempty(actual, h_raw_end),
            h_gm_begin=_if_nonempty(actual, h_gm_begin),
            h_gm_end=_if_nonempty(actual, h_gm_end),
            l1_height=_if_nonempty(actual, l1_height),
            l1_width=_if_nonempty(actual, self.spec.input_width),
            pad_top=_if_nonempty(actual, h_gm_begin - h_raw_begin),
            pad_bottom=_if_nonempty(actual, h_raw_end - h_gm_end),
            pad_left=_if_nonempty(actual, self.spec.padding[2]),
            pad_right=_if_nonempty(actual, self.spec.padding[3]),
            m_start=_if_nonempty(actual, ow_first),
            m_extension=actual,
        )

    @property
    def fmap_gm_offset(self):
        """Element offset of the clipped NCHW feature-map tile in GM."""
        window = self.input_window
        global_ci = self.group * self.spec.input_channels_per_group + self.ci_begin
        return (
            self.batch * self.spec.input_channels * self.spec.input_height * self.spec.input_width
            + global_ci * self.spec.input_height * self.spec.input_width
            + window.h_gm_begin * self.spec.input_width
        )

    @property
    def filter_gm_offset(self):
        """Element offset of the first OIHW filter element in this tile."""
        global_co = self.group * self.spec.output_channels_per_group + self.n_begin
        return (
            global_co * self.spec.input_channels_per_group * self.spec.kernel_height * self.spec.kernel_width
            + self.ci_begin * self.spec.kernel_height * self.spec.kernel_width
        )

    @property
    def output_gm_offset(self):
        """Element offset of the first NCHW output element in this tile."""
        global_co = self.group * self.spec.output_channels_per_group + self.n_begin
        return (self.batch * self.spec.output_channels + global_co) * self.spec.m_extent + self.m_begin

    def l0a_view(self, slot):
        """Tail-aware ``[mActual, kProgram]`` view of an L0A slot."""
        from cannbotdsl.tensor import local_slice

        return local_slice(slot, (self.m_actual, self.k_program))

    def l1b_view(self, slot):
        """Tail-aware ``[kProgram, nActual]`` view of a packed L1-B slot."""
        from cannbotdsl.tensor import local_slice

        return local_slice(slot, (self.k_program, self.n_actual))

    def l0b_view(self, slot):
        """Tail-aware ``[kProgram, nActual]`` view of an L0B slot."""
        from cannbotdsl.tensor import local_slice

        return local_slice(slot, (self.k_program, self.n_actual))

    def l0c_view(self, slot):
        """Tail-aware ``[mActual, nActual]`` view of an L0C slot."""
        from cannbotdsl.tensor import local_slice

        return local_slice(slot, (self.m_actual, self.n_actual))


@dataclass(frozen=True)
class Conv2dSpec:
    """Static Conv2D geometry used by convolution-specific movement ops."""

    dtype: object
    input_shape: tuple[int, int, int, int]
    filter_shape: tuple[int, int, int, int]
    stride: tuple[int, int]
    padding: tuple[int, int, int, int]
    dilation: tuple[int, int]
    groups: int
    data_format: str
    filter_format: str

    def __post_init__(self):
        if self.dtype not in (dtypes.float16, dtypes.bfloat16):
            raise ValueError("the initial Conv2D Load3D path supports dtypes.float16 and dtypes.bfloat16")
        if self.data_format != "nchw" or self.filter_format != "nchw":
            raise ValueError(
                "the initial Conv2D implementation supports only NCHW/OIHW (data_format='nchw', filter_format='nchw')"
            )
        if not isinstance(self.groups, int) or isinstance(self.groups, bool):
            raise TypeError("groups must be an integer")
        if self.groups <= 0:
            raise ValueError(f"groups must be positive, got {self.groups}")

        _positive("input_shape", self.input_shape)
        _positive("filter_shape", self.filter_shape)
        _bounded("stride", self.stride, 1, 63)
        _bounded("padding", self.padding, 0, 255)
        _bounded("dilation", self.dilation, 1, 255)
        _bounded(
            "filter spatial dimensions",
            (self.kernel_height, self.kernel_width),
            1,
            511,
        )
        if self.kernel_height * self.kernel_width > 65535:
            raise ValueError("Kh * Kw must fit the uint16 filter n_value field")

        if self.input_channels % self.groups != 0:
            raise ValueError(f"input channels {self.input_channels} are not divisible by groups {self.groups}")
        if self.output_channels % self.groups != 0:
            raise ValueError(f"output channels {self.output_channels} are not divisible by groups {self.groups}")
        if self.filter_input_channels != self.input_channels_per_group:
            raise ValueError(
                "filter input channels must equal input_channels // groups, "
                f"got {self.filter_input_channels} and {self.input_channels_per_group}"
            )
        if self.output_height <= 0 or self.output_width <= 0:
            raise ValueError(
                f"Conv2D output spatial dimensions must be positive, got ({self.output_height}, {self.output_width})"
            )
        if self.input_height > 65535 or self.input_width > 65535:
            raise ValueError("the initial Load3D FMatrix path requires input height/width to fit uint16")

    @property
    def batch_size(self) -> int:
        return self.input_shape[0]

    @property
    def input_channels(self) -> int:
        return self.input_shape[1]

    @property
    def input_height(self) -> int:
        return self.input_shape[2]

    @property
    def input_width(self) -> int:
        return self.input_shape[3]

    @property
    def output_channels(self) -> int:
        return self.filter_shape[0]

    @property
    def filter_input_channels(self) -> int:
        return self.filter_shape[1]

    @property
    def kernel_height(self) -> int:
        return self.filter_shape[2]

    @property
    def kernel_width(self) -> int:
        return self.filter_shape[3]

    @property
    def input_channels_per_group(self) -> int:
        return self.input_channels // self.groups

    @property
    def output_channels_per_group(self) -> int:
        return self.output_channels // self.groups

    @property
    def effective_kernel_height(self) -> int:
        return self.dilation[0] * (self.kernel_height - 1) + 1

    @property
    def effective_kernel_width(self) -> int:
        return self.dilation[1] * (self.kernel_width - 1) + 1

    @property
    def output_height(self) -> int:
        return (self.input_height + self.padding[0] + self.padding[1] - self.effective_kernel_height) // self.stride[
            0
        ] + 1

    @property
    def output_width(self) -> int:
        return (self.input_width + self.padding[2] + self.padding[3] - self.effective_kernel_width) // self.stride[
            1
        ] + 1

    @property
    def output_shape(self) -> tuple[int, int, int, int]:
        return (
            self.batch_size,
            self.output_channels,
            self.output_height,
            self.output_width,
        )

    @property
    def m_extent(self) -> int:
        return self.output_height * self.output_width

    def tile_count(self, tile: Sequence[int]) -> tuple[int, int, int]:
        bm, bn, bc = self._validate_tile_shape(tile)
        return (
            (self.m_extent + bm - 1) // bm,
            (self.output_channels_per_group + bn - 1) // bn,
            (self.input_channels_per_group + bc - 1) // bc,
        )

    def fmap_l1_shape(self, *, tile: Sequence[int]) -> tuple[int]:
        """Raw L1 capacity for a feature window or all-padding zero staging."""
        if not isinstance(tile, (tuple, list)) or len(tile) != 2:
            raise ValueError("tile must contain exactly (BM, BC)")
        bm, bc = tile
        self._validate_tile_shape((bm, 16, bc))
        max_l1_height = self._max_l1_height(bm)
        feature_elements = bc * max_l1_height * self.input_width
        zero_staging_elements = bm * self.kernel_height * self.kernel_width * bc
        return (max(feature_elements, zero_staging_elements),)

    def tile(
        self,
        *,
        tile: Sequence[int],
        coord: Sequence[object],
        batch=0,
        group=0,
    ) -> Conv2dTile:
        tile_shape = self._validate_tile_shape(tile)
        if not isinstance(coord, (tuple, list)) or len(coord) != 3:
            raise ValueError("coord must contain exactly three (M, N, Cin) tile indices")
        coord = tuple(_as_i64(item) for item in coord)
        batch = _as_i64(batch)
        group = _as_i64(group)
        for name, value, upper in (
            ("batch", batch, self.batch_size),
            ("group", group, self.groups),
        ):
            if isinstance(value, int) and not 0 <= value < upper:
                raise ValueError(f"{name} must be in [0, {upper}), got {value}")
        for name, value in zip(("M", "N", "Cin"), coord):
            if isinstance(value, int) and value < 0:
                raise ValueError(f"{name} tile coordinate must be non-negative, got {value}")
        tile_counts = (
            (self.m_extent + tile_shape[0] - 1) // tile_shape[0],
            (self.output_channels_per_group + tile_shape[1] - 1) // tile_shape[1],
            (self.input_channels_per_group + tile_shape[2] - 1) // tile_shape[2],
        )
        for name, value, count in zip(("M", "N", "Cin"), coord, tile_counts):
            if isinstance(value, int) and value >= count:
                raise ValueError(f"{name} tile coordinate must be in [0, {count}), got {value}")
        return Conv2dTile(self, tile_shape, coord, batch, group)

    def _validate_tile_shape(self, tile: Sequence[int]) -> tuple[int, int, int]:
        bm, bn, bc = _normalize_int_tuple("tile", tile, 3)
        _positive("tile", (bm, bn, bc))
        if bm % 16 != 0:
            raise ValueError(f"BM must be a multiple of 16 (cube M0), got {bm}")
        if bn % 16 != 0:
            raise ValueError(f"BN must be a multiple of 16, got {bn}")
        if bm > 65535:
            raise ValueError(f"BM must fit the uint16 M extent field, got {bm}")
        if bn > 65535:
            raise ValueError(f"BN must fit the uint16 N extent field, got {bn}")
        if bc > 32:
            raise ValueError(f"BC must be at most 32 for the initial Load3D path, got {bc}")
        if bc % 16 != 0:
            raise ValueError(f"BC must be a multiple of the fp16/bf16 cube K0 (16), got {bc}")
        if self.kernel_height * self.kernel_width * bc > 32767:
            raise ValueError("Kh * Kw * BC must fit the 15-bit all-padding L1 Fill block field")
        if self._max_l1_height(bm) * self.input_width > 65535:
            raise ValueError(
                "the maximum l1_height * input_width for one M tile must fit the uint16 feature-map n_value field"
            )
        return bm, bn, bc

    def _max_l1_height(self, bm: int) -> int:
        max_output_rows = (bm + self.output_width - 2) // self.output_width + 1
        return min(
            self.input_height,
            (max_output_rows - 1) * self.stride[0] + self.effective_kernel_height,
        )

    def _program_channels(self, actual):
        # Match Conv2DV2's ordinary path: each kernel point occupies one or
        # more complete k0FmapTail=16 blocks in both Load3D A and DN2NZ B.
        if isinstance(actual, int):
            return ((actual + 15) // 16) * 16
        return ((actual + 15) // 16) * 16


def make_conv2d_spec(
    *,
    dtype,
    input_shape: Sequence[int],
    filter_shape: Sequence[int],
    stride: Sequence[int] = (1, 1),
    padding: Sequence[int] = (0, 0, 0, 0),
    dilation: Sequence[int] = (1, 1),
    groups: int = 1,
    data_format: str = "nchw",
    filter_format: str = "nchw",
) -> Conv2dSpec:
    """Build and validate a static Conv2D movement specification."""
    return Conv2dSpec(
        dtype=dtype,
        input_shape=_normalize_int_tuple("input_shape", input_shape, 4),
        filter_shape=_normalize_int_tuple("filter_shape", filter_shape, 4),
        stride=_normalize_int_tuple("stride", stride, _PAIR),
        padding=_normalize_int_tuple("padding", padding, _PADDING),
        dilation=_normalize_int_tuple("dilation", dilation, _PAIR),
        groups=groups,
        data_format=data_format.lower(),
        filter_format=filter_format.lower(),
    )


def make_conv2d_fmap_l1(dtype, spec: Conv2dSpec, *, tile: Sequence[int]):
    """Allocate raw NC1HWC0-capacity L1 storage for one feature-map tile."""
    from cannbotdsl.buffer import Buffer
    from cannbotdsl.types import MemLoc

    if not isinstance(spec, Conv2dSpec):
        raise TypeError(f"spec must be a Conv2dSpec, got {type(spec).__name__}")
    if dtype is not spec.dtype:
        raise ValueError("dtype must match spec.dtype")

    return Buffer(MemLoc.L1, spec.fmap_l1_shape(tile=tile), dtype, data_format="nd")


def conv2d_load_fmap(dst, src, tile: Conv2dTile, *, l2_cache_ctl: int = 0):
    """Load a clipped NCHW feature-map tile from GM to raw NC1HWC0 L1."""
    if not isinstance(tile, Conv2dTile):
        raise TypeError(f"tile must be a Conv2dTile, got {type(tile).__name__}")
    _validate_l2_cache_ctl(l2_cache_ctl)
    window = tile.input_window
    cannir.conv_fmap_gm2l1(
        _unwrap_memref_or_channel(dst),
        _unwrap_memref_or_channel(src),
        _as_index(tile.fmap_gm_offset),
        _as_index(window.l1_height),
        _as_index(tile.ci_actual),
        input_height=tile.spec.input_height,
        input_width=tile.spec.input_width,
        l2_cache_ctl=l2_cache_ctl,
    )


def conv2d_load_im2col(dst, src, tile: Conv2dTile):
    """Load3D-expand a feature-map L1 tile into its L0A matrix view."""
    if not isinstance(tile, Conv2dTile):
        raise TypeError(f"tile must be a Conv2dTile, got {type(tile).__name__}")
    window = tile.input_window
    spec = tile.spec
    cannir.conv_load3d(
        _unwrap_memref_or_channel(dst),
        _unwrap_memref_or_channel(src),
        _as_index(window.l1_height),
        _as_index(window.pad_top),
        _as_index(window.pad_bottom),
        _as_index(window.m_start),
        _as_index(window.m_extension),
        _as_index(tile.k_program),
        _as_index(tile.ci_program),
        input_width=spec.input_width,
        pad_left=spec.padding[2],
        pad_right=spec.padding[3],
        stride_h=spec.stride[0],
        stride_w=spec.stride[1],
        filter_h=spec.kernel_height,
        filter_w=spec.kernel_width,
        dilation_h=spec.dilation[0],
        dilation_w=spec.dilation[1],
    )


def conv2d_load_filter(dst, src, tile: Conv2dTile, *, l2_cache_ctl: int = 0):
    """Pack one OIHW filter tile from GM into an L1 ZN matrix."""
    if not isinstance(tile, Conv2dTile):
        raise TypeError(f"tile must be a Conv2dTile, got {type(tile).__name__}")
    _validate_l2_cache_ctl(l2_cache_ctl)
    spec = tile.spec
    cannir.conv_filter_gm2l1(
        _unwrap_memref_or_channel(dst),
        _unwrap_memref_or_channel(src),
        _as_index(tile.filter_gm_offset),
        _as_index(tile.ci_actual),
        _as_index(tile.n_actual),
        input_channels_per_group=spec.input_channels_per_group,
        filter_h=spec.kernel_height,
        filter_w=spec.kernel_width,
        bn=tile.bn,
        l2_cache_ctl=l2_cache_ctl,
    )


def conv2d_store_output(dst, src, tile: Conv2dTile, *, l2_cache_ctl: int = 0):
    """Store an L0C tile to its NCHW output position with NZ2DN."""
    if not isinstance(tile, Conv2dTile):
        raise TypeError(f"tile must be a Conv2dTile, got {type(tile).__name__}")
    _validate_l2_cache_ctl(l2_cache_ctl)
    cannir.conv_store_gm(
        _unwrap_memref_or_channel(dst),
        _unwrap_memref_or_channel(src),
        _as_index(tile.output_gm_offset),
        _as_index(tile.m_actual),
        _as_index(tile.n_actual),
        output_spatial_stride=tile.spec.m_extent,
        l2_cache_ctl=l2_cache_ctl,
    )
