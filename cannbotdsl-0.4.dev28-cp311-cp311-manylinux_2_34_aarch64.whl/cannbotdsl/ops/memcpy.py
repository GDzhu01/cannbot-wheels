# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Data movement: ``mem_copy`` and the copy-engine configuration it accepts.

The engine enums, the ``CopyEngine`` value wrapper and ``make_copy_engine``
live here rather than in ``cannbotdsl.tensor`` so that every setting and data
structure a caller needs to configure a copy sits next to the copy interface
itself.  ``copy_type`` selects the identity, format or fixpipe parameter group;
omitting it retains the legacy interface.
"""

from enum import IntEnum
from typing import Optional

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir

from cannbotdsl.ir_transport import unwrap_operand
from cannbotdsl.tensor import PartitionTiler, _operand_memref_type
from cannbotdsl.types import Tensor


class FormatTransform(IntEnum):
    Identity = 0
    ND2NZ = 1
    NZ2ND = 2
    DN2NZ = 3
    MX_SCALE_A = 4
    MX_SCALE_B = 5
    TRANSPOSE = 6
    MX_SCALE_BND = 7
    MX_SCALE_BDN = 8
    MX_SCALE_AND = 9
    MX_SCALE_ADN = 10


class CopyLayoutTransform(IntEnum):
    None_ = 0
    NZ_FOLD_N_TO_M = 1


class CopyEngineKind(IntEnum):
    Default = 0
    NDDMA = 1


class CopyTailAlignment(IntEnum):
    Tiler = 0
    UB = 1


class NDDMAPaddingMode(IntEnum):
    Constant = 0
    Nearest = 1


@ir.register_value_caster(cannir.CopyEngineType.get_static_typeid())
class CopyEngine(ir.Value):
    @property
    def format_transform(self):
        return FormatTransform(self.type.format_transform)

    @property
    def layout_transform(self):
        return CopyLayoutTransform(self.type.layout_transform)

    @property
    def kind(self):
        return CopyEngineKind(self.type.kind)

    @property
    def tail_alignment(self):
        return CopyTailAlignment(self.type.tail_alignment)

    @property
    def dtype(self):
        return self.type.dtype

    @property
    def deq_scale(self):
        return self.type.deq_scale


_FORMAT_TRANSFORM_MAP = {
    "identity": FormatTransform.Identity,
    "nd2nz": FormatTransform.ND2NZ,
    "nz2nd": FormatTransform.NZ2ND,
    "dn2nz": FormatTransform.DN2NZ,
    "mx_scale_a": FormatTransform.MX_SCALE_A,
    "mx_scale_b": FormatTransform.MX_SCALE_B,
    "transpose": FormatTransform.TRANSPOSE,
    "mx_scale_bnd": FormatTransform.MX_SCALE_BND,
    "mx_scale_bdn": FormatTransform.MX_SCALE_BDN,
    "mx_scale_and": FormatTransform.MX_SCALE_AND,
    "mx_scale_adn": FormatTransform.MX_SCALE_ADN,
}

_COPY_LAYOUT_TRANSFORM_MAP = {
    "none": CopyLayoutTransform.None_,
    "nz_fold_n_to_m": CopyLayoutTransform.NZ_FOLD_N_TO_M,
}

_COPY_ENGINE_KIND_MAP = {
    "default": CopyEngineKind.Default,
    "nddma": CopyEngineKind.NDDMA,
}

_COPY_TAIL_ALIGNMENT_MAP = {
    "tiler": CopyTailAlignment.Tiler,
    "ub": CopyTailAlignment.UB,
}

_NDDMA_PADDING_MODE_MAP = {
    "constant": NDDMAPaddingMode.Constant,
    "nearest": NDDMAPaddingMode.Nearest,
}


# Parameters shared across families retain their existing meanings.  In
# particular, C0 strides are used by both formatted loads and FIXPIPE stores.
_COPY_TYPE_OPTIONS = {
    "identity": frozenset((
        "kind", "tail_alignment", "pad_value",
        "left_padding", "right_padding", "padding_mode",
        "left_padding_count", "right_padding_count",
    )),
    "format": frozenset((
        "format_transform", "layout_transform", "pad_value",
        "nd_num", "src_nd_stride", "dst_nd_stride",
        "dst_c0_stride", "src_c0_stride", "smallc0_en",
    )),
    "fixpipe": frozenset((
        "dual_dst_ctl", "sub_block_id", "unit_flag_mode", "deq_scale",
        "dst_c0_stride", "src_c0_stride",
    )),
}


def make_copy_engine(
    *,
    copy_type: Optional[str] = None,
    kind: str = "default",
    format_transform: str = "identity",
    layout_transform: str = "none",
    tail_alignment: str = "tiler",
    dtype,
    pad_value: float = 0.0,
    left_padding: Optional[tuple[int, ...] | list[int]] = None,
    right_padding: Optional[tuple[int, ...] | list[int]] = None,
    padding_mode: str = "constant",
    dual_dst_ctl: int = 0,
    sub_block_id: int = 0,
    nd_num: int = 1,
    src_nd_stride: int = 0,
    dst_nd_stride: int = 0,
    dst_c0_stride: int = 0,
    src_c0_stride: int = 0,
    unit_flag_mode: int = 0,
    deq_scale: float = 1.0,
    smallc0_en: bool = False,
    left_padding_count: int = 0,
    right_padding_count: int = 0,
):
    """Create a copy engine with an optional explicit parameter group.

    ``copy_type`` is ``"identity"``, ``"format"`` or ``"fixpipe"``:

    * Identity accepts tail alignment, padding and ``kind="nddma"``.
    * Format accepts format/layout transforms, ND and C0 strides, and padding
      values. Use ``format_transform="identity"`` with C0 strides for a
      diagonal copy, or with ``layout_transform="nz_fold_n_to_m"``.
    * FIXPIPE accepts split/dequant controls, unit flags and C0 strides for
      L0C stores, including stores to L1.

    Non-default options from other groups are rejected. Neutral defaults may
    be forwarded by generic callers. Omit ``copy_type`` (or pass ``None``) to
    preserve the legacy parameter combinations and validation. The selector
    only validates frontend configuration; all groups produce the existing
    ``CopyEngineType`` and copy routes still depend on the source/destination.

    Examples::

        make_copy_engine(copy_type="identity", dtype=dtypes.float16)
        make_copy_engine(copy_type="format", format_transform="nd2nz", dtype=dtypes.float16)
        make_copy_engine(copy_type="fixpipe", dtype=dtypes.float32, dual_dst_ctl=1)

    ``kind="nddma"`` selects the 1--5 dimensional GM-to-UB NDDMA engine.
    NDDMA is never selected implicitly by :func:`mem_copy`. Padding tuples use
    normal DSL axis order (outermost to innermost); omitted tuples mean zero
    padding on every axis. ``padding_mode`` is ``"constant"`` or ``"nearest"``.

    ``tail_alignment`` controls the physical UB row pitch for an Identity
    GM-to-UB tail. ``"tiler"`` retains the declared UB tiler's row stride;
    ``"ub"`` packs the actual tail and rounds its innermost extent up to the
    UB 32-byte alignment. InferLayout propagates the selected pitch to later
    reads of the same UB storage, including UB-to-GM copies. This option does
    not initialize the residual bytes between the 32-byte-aligned actual row
    and a larger tiler pitch.

    ``pad_value`` remains the value used by NDDMA's explicit multidimensional
    padding and by raw GM-to-L1 partial-DataBlock padding. Ordinary Identity
    GM-to-UB uses zero for its final partial DataBlock.

    ``smallc0_en=True`` selects the compact four-element C0 layout of the
    DN2NZ GM-to-L1 CAPI. It is valid only for ``format_transform="dn2nz"``;
    callers must keep the DN ``D`` extent at or below four as required by the
    hardware interface.

    ``left_padding_count`` and ``right_padding_count`` expose the corresponding
    GM-to-L1 alignment-copy fields. They apply only to the default Identity
    engine and count elements, with per-side limits of 32 for 8-bit, 16 for
    16-bit, and 8 for 32-bit element types. The generated CAPI always selects
    ``data_select_bit=false``, which is the mode supported by the 3510 API.

    MXFP8 paired-scale GM layouts use distinct transforms:
    ``mx_scale_and`` expects ``[..., M, G, 2]`` and
    ``mx_scale_adn`` expects ``[..., G, M, 2]``; both produce the
    ScaleA L1 logical layout ``[..., M, 2 * G]``.
    ``mx_scale_bnd`` expects ``[..., G, N, 2]`` and
    ``mx_scale_bdn`` expects ``[..., N, G, 2]``, where
    ``G = ceil(K / 64)`` and the final axis is the paired e8m0 lane.
    The ScaleB transforms produce ``[..., 2 * G, N]``.
    ``mx_scale_a`` and ``mx_scale_b`` remain compatibility paths for flat
    two-dimensional ScaleA and ScaleB inputs.
    """
    if copy_type is not None:
        if not isinstance(copy_type, str):
            raise TypeError("copy_type must be a string or None")
        if copy_type not in _COPY_TYPE_OPTIONS:
            raise ValueError(
                f"Unknown copy_type: {copy_type!r}; expected 'identity', 'format', or 'fixpipe'"
            )
    kind_enum = _COPY_ENGINE_KIND_MAP.get(kind)
    if kind_enum is None:
        raise ValueError(f"Unknown copy engine kind: {kind!r}")
    ft_enum = _FORMAT_TRANSFORM_MAP.get(format_transform)
    if ft_enum is None:
        raise ValueError(f"Unknown format_transform: {format_transform!r}")
    layout_transform_enum = _COPY_LAYOUT_TRANSFORM_MAP.get(layout_transform)
    if layout_transform_enum is None:
        raise ValueError(f"Unknown layout_transform: {layout_transform!r}")
    tail_alignment_enum = _COPY_TAIL_ALIGNMENT_MAP.get(tail_alignment)
    if tail_alignment_enum is None:
        raise ValueError(f"Unknown tail_alignment: {tail_alignment!r}")
    if tail_alignment_enum != CopyTailAlignment.Tiler and (
        kind_enum != CopyEngineKind.Default
        or ft_enum != FormatTransform.Identity
        or layout_transform_enum != CopyLayoutTransform.None_
    ):
        raise ValueError(
            "tail_alignment='ub' requires kind='default', format_transform='identity', and layout_transform='none'"
        )
    padding_mode_enum = _NDDMA_PADDING_MODE_MAP.get(padding_mode)
    if padding_mode_enum is None:
        raise ValueError(f"Unknown NDDMA padding_mode: {padding_mode!r}")

    def _normalize_padding(name, value):
        if value is None:
            return None
        if not isinstance(value, (tuple, list)):
            raise TypeError(f"{name} must be a tuple/list of integers")
        normalized = tuple(int(item) for item in value)
        if not 1 <= len(normalized) <= 5:
            raise ValueError(f"{name} rank must be in [1, 5], got {len(normalized)}")
        if any(item < 0 or item > 255 for item in normalized):
            raise ValueError(f"{name} values must be in [0, 255]")
        return normalized

    left_padding_value = _normalize_padding("left_padding", left_padding)
    right_padding_value = _normalize_padding("right_padding", right_padding)
    if (
        left_padding_value is not None
        and right_padding_value is not None
        and len(left_padding_value) != len(right_padding_value)
    ):
        raise ValueError("left_padding and right_padding must have the same rank")
    nd_num_value = int(nd_num)
    src_nd_stride_value = int(src_nd_stride)
    dst_nd_stride_value = int(dst_nd_stride)
    dst_c0_stride_value = int(dst_c0_stride)
    src_c0_stride_value = int(src_c0_stride)
    unit_flag_mode_value = int(unit_flag_mode)
    if copy_type is not None:
        non_default_options = {
            "kind": kind_enum != CopyEngineKind.Default,
            "format_transform": ft_enum != FormatTransform.Identity,
            "layout_transform": layout_transform_enum != CopyLayoutTransform.None_,
            "tail_alignment": tail_alignment_enum != CopyTailAlignment.Tiler,
            "pad_value": float(pad_value) != 0.0,
            "left_padding": left_padding_value is not None,
            "right_padding": right_padding_value is not None,
            "padding_mode": padding_mode_enum != NDDMAPaddingMode.Constant,
            "dual_dst_ctl": int(dual_dst_ctl) != 0,
            "sub_block_id": int(sub_block_id) != 0,
            "nd_num": nd_num_value != 1,
            "src_nd_stride": src_nd_stride_value != 0,
            "dst_nd_stride": dst_nd_stride_value != 0,
            "dst_c0_stride": dst_c0_stride_value != 0,
            "src_c0_stride": src_c0_stride_value != 0,
            "unit_flag_mode": unit_flag_mode_value != 0,
            "deq_scale": float(deq_scale) != 1.0,
            "smallc0_en": bool(smallc0_en),
            "left_padding_count": int(left_padding_count) != 0,
            "right_padding_count": int(right_padding_count) != 0,
        }
        unsupported = [
            name for name, active in non_default_options.items()
            if active and name not in _COPY_TYPE_OPTIONS[copy_type]
        ]
        if unsupported:
            raise ValueError(
                f"copy_type={copy_type!r} does not support non-default options: "
                + ", ".join(unsupported)
            )
    if nd_num_value < 1:
        raise ValueError(f"nd_num must be >= 1, got {nd_num_value}")
    if src_nd_stride_value < 0 or dst_nd_stride_value < 0:
        raise ValueError("src_nd_stride and dst_nd_stride must be non-negative")
    if dst_c0_stride_value < 0:
        raise ValueError("dst_c0_stride must be non-negative")
    if src_c0_stride_value < 0:
        raise ValueError("src_c0_stride must be non-negative")
    if unit_flag_mode_value < 0:
        raise ValueError("unit_flag_mode must be non-negative")
    if not isinstance(smallc0_en, bool):
        raise TypeError("smallc0_en must be a bool")
    if smallc0_en and ft_enum != FormatTransform.DN2NZ:
        raise ValueError("smallc0_en=True requires format_transform='dn2nz'")
    left_padding_count = int(left_padding_count)
    right_padding_count = int(right_padding_count)
    if left_padding_count < 0 or right_padding_count < 0:
        raise ValueError(
            "left_padding_count and right_padding_count must be non-negative"
        )
    if (left_padding_count or right_padding_count) and (
        kind_enum != CopyEngineKind.Default
        or ft_enum != FormatTransform.Identity
        or layout_transform_enum != CopyLayoutTransform.None_
    ):
        raise ValueError(
            "GM-to-L1 alignment padding requires the default identity copy engine"
        )
    dtype_bits = int(getattr(dtype, "bits", 0))
    if (left_padding_count or right_padding_count) and dtype_bits not in (8, 16, 32):
        raise ValueError(
            "GM-to-L1 alignment padding supports 8-, 16-, or 32-bit dtypes"
        )
    max_padding = {8: 32, 16: 16, 32: 8}.get(dtype_bits, 0)
    if left_padding_count > max_padding or right_padding_count > max_padding:
        raise ValueError("GM-to-L1 alignment padding exceeds the dtype limit")
    if (nd_num_value != 1 or src_nd_stride_value != 0 or dst_nd_stride_value != 0) and ft_enum not in (
        FormatTransform.ND2NZ,
        FormatTransform.DN2NZ,
    ):
        raise ValueError("strided ND copy options require nd2nz or dn2nz format_transform")
    if layout_transform_enum != CopyLayoutTransform.None_:
        if ft_enum != FormatTransform.Identity:
            raise ValueError("layout_transform='nz_fold_n_to_m' requires format_transform='identity'")
        if (
            int(dual_dst_ctl) != 0
            or int(sub_block_id) != 0
            or nd_num_value != 1
            or src_nd_stride_value != 0
            or dst_nd_stride_value != 0
            or dst_c0_stride_value != 0
            or src_c0_stride_value != 0
            or unit_flag_mode_value != 0
            or float(deq_scale) != 1.0
            or float(pad_value) != 0.0
        ):
            raise ValueError(
                "layout_transform='nz_fold_n_to_m' cannot be combined with "
                "padding, FIXPIPE, strided-copy, or dequant options"
            )
    nddma_only_options = (
        left_padding_value is not None
        or right_padding_value is not None
        or padding_mode_enum != NDDMAPaddingMode.Constant
    )
    if kind_enum != CopyEngineKind.NDDMA and nddma_only_options:
        raise ValueError("left_padding, right_padding, and non-constant padding_mode require kind='nddma'")
    if kind_enum == CopyEngineKind.NDDMA:
        if ft_enum != FormatTransform.Identity:
            raise ValueError("kind='nddma' requires format_transform='identity'")
        if layout_transform_enum != CopyLayoutTransform.None_:
            raise ValueError("kind='nddma' requires layout_transform='none'")
        if (
            int(dual_dst_ctl) != 0
            or int(sub_block_id) != 0
            or nd_num_value != 1
            or src_nd_stride_value != 0
            or dst_nd_stride_value != 0
            or dst_c0_stride_value != 0
            or src_c0_stride_value != 0
            or unit_flag_mode_value != 0
            or float(deq_scale) != 1.0
        ):
            raise ValueError(
                "kind='nddma' cannot be combined with FIXPIPE, formatted-copy, or strided-copy engine options"
            )
    from cannbotdsl.core.contracts.elements import storage_mlir_type_for_dtype

    dtype_ty = storage_mlir_type_for_dtype(dtype)
    engine_ty = cannir.CopyEngineType.get(
        int(ft_enum),
        dtype_ty,
        dual_dst_ctl=dual_dst_ctl,
        sub_block_id=sub_block_id,
        nd_num=nd_num_value,
        src_nd_stride=src_nd_stride_value,
        dst_nd_stride=dst_nd_stride_value,
        dst_c0_stride=dst_c0_stride_value,
        src_c0_stride=src_c0_stride_value,
        unit_flag_mode=unit_flag_mode_value,
        deq_scale=float(deq_scale),
        layout_transform=int(layout_transform_enum),
        kind=int(kind_enum),
        tail_alignment=int(tail_alignment_enum),
    )
    op_kwargs = {
        "pad_value": pad_value,
        "padding_mode": padding_mode_enum,
        "smallc0_en": smallc0_en,
        "gm2l1_left_padding": left_padding_count,
        "gm2l1_right_padding": right_padding_count,
    }
    if left_padding_value is not None:
        op_kwargs["left_padding"] = ir.DenseI64ArrayAttr.get(left_padding_value)
    if right_padding_value is not None:
        op_kwargs["right_padding"] = ir.DenseI64ArrayAttr.get(right_padding_value)
    return cannir.make_copy_engine(engine_ty, **op_kwargs)


def mem_copy(
    dst: Tensor,
    src: Tensor,
    engine: Optional[object] = None,
    transpose: bool = False,
    deq_scale_buf: Optional[Tensor] = None,
    deq_scale_val: Optional[object] = None,
    mx_scale: Optional[Tensor] = None,
    partition: Optional[PartitionTiler] = None,
    l2_cache_ctl: int = 0,
    atomic_add=False,
):
    """Copy ``src`` to ``dst``.

    ``atomic_add`` may be a Python ``bool`` or a runtime i1 SSA value. Atomic
    add is supported for UB/L0C writes to GM; the GM destination dtype selects
    the AscendC atomic setter.
    """
    from cannbotdsl.lang.vf import _tag_if_in_vf

    # Validate the semantic memory boundary even when an explicit engine
    # bypasses auto-inference.
    _operand_memref_type(dst)
    _operand_memref_type(src)
    if mx_scale is not None:
        _operand_memref_type(mx_scale)
    if deq_scale_buf is not None:
        _operand_memref_type(deq_scale_buf)
    if partition is not None and not isinstance(partition, PartitionTiler):
        raise TypeError(f"partition must be a PartitionTiler, got {type(partition).__name__}")
    if l2_cache_ctl not in (0, 1, 2, 4):
        raise ValueError("l2_cache_ctl must be one of 0 (disable), 1 (normal), 2 (last), or 4 (persistent)")
    # Vector (per-N-channel) dequant: an L1 uint64 scale table drives the
    # int8-matmul int32 L0C -> fp16/bf16 fixpipe store in VDEQF16 /
    # VQS322BF16_PRE mode. Passed as an extra operand; the store engine still
    # carries the fp16/bf16 dst dtype.
    #
    # Scalar (whole-tile) dequant: `deq_scale_val` is a *runtime* f32 scale
    # (e.g. a Float32 kernel arg) that programs the DEQSCALE register at launch
    # time — one compiled kernel handles any scale. A Python number is lifted
    # to an fp32 constant. This is the dynamic counterpart of the compile-time
    # `make_copy_engine(deq_scale=...)`; the two are mutually exclusive with
    # `deq_scale_buf` (vector) and with each other's precedence handled in
    # codegen (buf > val > engine attr).
    if deq_scale_val is not None and deq_scale_buf is not None:
        raise ValueError("mem_copy: pass at most one of deq_scale_val (scalar) or deq_scale_buf (per-channel)")
    kwargs = {"transpose": transpose, "l2_cache_ctl": l2_cache_ctl}
    if isinstance(atomic_add, bool):
        kwargs["atomic_add"] = atomic_add
    elif (
        isinstance(atomic_add, ir.Value) and isinstance(atomic_add.type, ir.IntegerType) and atomic_add.type.width == 1
    ):
        kwargs["atomic_add_value"] = atomic_add
    else:
        raise TypeError("atomic_add must be a bool or an i1 SSA value")
    if engine is not None:
        kwargs["engine"] = engine
    if mx_scale is not None:
        kwargs["mx_scale"] = unwrap_operand(mx_scale)
    if deq_scale_buf is not None:
        kwargs["deq_scale_buf"] = unwrap_operand(deq_scale_buf)
    if deq_scale_val is not None:
        from cannbotdsl.types._numeric import Float32

        if isinstance(deq_scale_val, (int, float)):
            deq_scale_val = Float32(float(deq_scale_val))
        kwargs["deq_scale_val"] = deq_scale_val
    if partition is not None:
        kwargs["partition"] = partition
    op = cannir.mem_copy(unwrap_operand(dst), unwrap_operand(src), **kwargs)
    _tag_if_in_vf(op)


__all__ = [
    "CopyEngine",
    "CopyEngineKind",
    "CopyLayoutTransform",
    "CopyTailAlignment",
    "FormatTransform",
    "NDDMAPaddingMode",
    "make_copy_engine",
    "mem_copy",
]
