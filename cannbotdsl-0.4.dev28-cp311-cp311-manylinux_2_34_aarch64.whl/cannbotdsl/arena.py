# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Frontend allocation of non-memory Channel hardware resource IDs."""

from __future__ import annotations

from contextvars import ContextVar

from cannbotdsl._mlir.dialects import cannir
from cannbotdsl.types import MemLoc

_CUBE_MEM_LOCS = {
    MemLoc.L1,
    MemLoc.L0A,
    MemLoc.L0B,
    MemLoc.L0C,
    MemLoc.BIAS,
}
_VEC_MEM_LOCS = {MemLoc.UB}


class ChannelArena:
    """Per-trace allocator for buf_id, sync_id, and flag_id."""

    MAX_BUF_ID = 32
    MAX_SYNC_ID = 16
    # FFTS cross-core sync flags. Codegen packs the id into a 4-bit field
    # (`flagId & 0xf` in lib/CANNIR/Translate/TranslateToAscendC.cpp), so this
    # is a hard hardware bound, not a policy choice. A count, so the largest id
    # handed out is one less -- sync.MAX_SYNC_BLOCK_FLAG_ID states that bound
    # and test_flag_budget_matches_the_id_range keeps the two in step.
    MAX_FLAG_ID = 16

    def __init__(self):
        self._cube_buf_id = 0
        self._vec_buf_id = 0
        self._sync_id = 0
        # Distinguishes lexically disjoint Channel allocation epochs.  The
        # epoch is attached to make_channel so the early CSE pass cannot merge
        # two stages that deliberately reuse the same address/buf_id/sync_id.
        self._sync_epoch = 0
        self._flag_id = 0
        # A UB space root is an exclusive, function-local storage declaration.
        # It is populated by ``dsl.UB.view`` and consumed by the static
        # view-binding MVP.  Keeping it on the per-trace arena prevents a root
        # from leaking between independently traced functions.
        self._ub_space_root = None
        self._ub_space_capacity = None
        self._ub_space_legacy_allocs = 0
        self._ub_space_bootstrap = False

    def alloc_buf_ids(self, mem_loc, count):
        if mem_loc in _CUBE_MEM_LOCS:
            start = self._cube_buf_id
            self._cube_buf_id += count
            if self._cube_buf_id > self.MAX_BUF_ID:
                raise RuntimeError(
                    f"CUBE buf_id exhausted: need {count}, "
                    f"have {self.MAX_BUF_ID - start} remaining (max {self.MAX_BUF_ID})"
                )
            return list(range(start, start + count))
        if mem_loc in _VEC_MEM_LOCS:
            start = self._vec_buf_id
            self._vec_buf_id += count
            if self._vec_buf_id > self.MAX_BUF_ID:
                raise RuntimeError(
                    f"VEC buf_id exhausted: need {count}, "
                    f"have {self.MAX_BUF_ID - start} remaining (max {self.MAX_BUF_ID})"
                )
            return list(range(start, start + count))
        raise ValueError(f"unsupported mem_loc for channel: {mem_loc!r}")

    def alloc_sync_ids(self, count):
        """Allocate intra-block sync ids, consumed by sync_intra_arrive/wait.

        Not the same space as alloc_flag_ids despite the identical shape: these
        ids reach the device through __builtin_cce_set_intra_block /
        _wait_intra_block, which index the block's own counters.  Reusing an id
        across the two allocators is harmless -- different hardware, different
        instruction.

        The budget of 16 is unrelated to the flag budget's 16.  Only `count`
        logical ids in [0,15] are handed out.  On CUBE each logical id is also
        emitted as id+16 so the same handshake reaches VECCORE1; this consumes
        the corresponding counter on each vector core, but does not halve the
        16-id logical namespace (channel_design.md §7.5).
        """
        start = self._sync_id
        self._sync_id += count
        if self._sync_id > self.MAX_SYNC_ID:
            raise RuntimeError(
                f"sync_id exhausted: need {count}, "
                f"have {self.MAX_SYNC_ID - start} remaining (max {self.MAX_SYNC_ID})"
            )
        return list(range(start, start + count))

    def alloc_flag_ids(self, count):
        """Allocate FFTS cross-core sync flag ids, consumed by sync_block_*.

        A third hardware space, distinct from both buf_id and sync_id.  The
        shape matches alloc_sync_ids exactly, but the two are not
        interchangeable: sync_ids reach the device via
        __builtin_cce_set_intra_block, flag_ids via
        __builtin_cce_ffts_cross_core_sync and wait_flag_dev.  Different
        instructions, different registers -- an id issued by one allocator
        never aliases one issued by the other.

        The matching 16-id budgets are coincidence.  This one is the 4-bit
        field codegen packs flag_id into; the sync_id budget comes from
        counter doubling (see alloc_sync_ids).  Codegen masks with & 0xf and
        the sync_block ops declare no verifier, so going over budget would be
        silently truncated into an aliased flag rather than rejected -- hence
        the explicit check here.
        """
        start = self._flag_id
        self._flag_id += count
        if self._flag_id > self.MAX_FLAG_ID:
            raise RuntimeError(
                f"flag_id exhausted: need {count}, "
                f"have {self.MAX_FLAG_ID - start} remaining (max {self.MAX_FLAG_ID})"
            )
        return list(range(start, start + count))

    def rewind(self, reset_sync_id=True):
        if self._ub_space_root is not None:
            raise ValueError("channel_rewind is not supported in UB-space mode")
        self._cube_buf_id = 0
        self._vec_buf_id = 0
        # LowerChannel primes/drains every CrossCore Channel at its lexical
        # lifetime boundaries.  A caller may therefore reset sync ids at a
        # stage boundary once execution has made the two stages disjoint.
        # Incrementing the epoch keeps otherwise-identical make_channel ops
        # distinct through the early CSE pass.
        #
        # _flag_id is intentionally never reset: FFTS flags have a separate
        # lifetime and global sync does not make arbitrary flag reuse safe.
        if reset_sync_id:
            self._sync_id = 0
            self._sync_epoch += 1


_CURRENT_CHANNEL_ARENA: ContextVar[ChannelArena | None] = ContextVar(
    "cannbotdsl_current_channel_arena", default=None
)


def _set_current_channel_arena(arena):
    return _CURRENT_CHANNEL_ARENA.set(arena)


def _reset_current_channel_arena(token):
    _CURRENT_CHANNEL_ARENA.reset(token)


def _current_channel_arena():
    arena = _CURRENT_CHANNEL_ARENA.get()
    if arena is None:
        raise RuntimeError("Buffer and Channel require an active CANNBotDSL lowering context")
    return arena


def channel_rewind(reset_sync_id=True):
    """Mark address reuse and reset Channel hardware ID counters.

    The emitted ``cannir.onchip_rewind`` marker resets pass-side allocation
    cursors, while frontend ``buf_id`` counters are always reset. ``sync_id``
    is reset only when ``reset_sync_id=True``; in that case a new allocation
    epoch also prevents CSE from merging Channels across stages.

    Reusing sync ids is valid only when the caller has made the old and new
    stages execution-disjoint (normally with a full-core barrier). LowerChannel
    drains each old Channel before its lexical lifetime ends and primes the new
    Channel where it is created.
    """
    cannir.OnChipRewindOp()
    _current_channel_arena().rewind(reset_sync_id=reset_sync_id)
