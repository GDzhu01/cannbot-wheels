# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Python syntax sugar for constructing an on-chip :class:`Tensor`."""

from __future__ import annotations

from cannbotdsl._onchip import (
    _normalize_shape_capacity,
    _physical_layout_spec,
)
from cannbotdsl.tensor import (
    _make_onchip_allocation,
    _onchip_tensor_type,
    _infer_contiguous_stride,
    make_layout,
)
from cannbotdsl.types import Layout, MemLoc, Tensor


_BUFFER_MEM_LOCS = frozenset(
    (MemLoc.UB, MemLoc.L1, MemLoc.L0A, MemLoc.L0B, MemLoc.L0C,
     MemLoc.BIAS, MemLoc.SSBUF, MemLoc.FBUF)
)
_BUFFER_FORMATS = frozenset(("nd", "nz", "zn"))


def _normalize_mem_loc(mem_loc):
    if not isinstance(mem_loc, MemLoc):
        raise TypeError(f"Buffer mem_loc must be a MemLoc value, got {type(mem_loc).__name__}")
    if mem_loc not in _BUFFER_MEM_LOCS:
        supported = ", ".join(item.name for item in _BUFFER_MEM_LOCS)
        raise ValueError(f"Buffer does not support MemLoc.{mem_loc.name}; supported: {supported}")
    return mem_loc


def _normalize_stride(stride, shape):
    if stride is None:
        return _infer_contiguous_stride(shape)
    if not isinstance(stride, tuple):
        raise TypeError("Buffer stride must be a flat tuple of positive ints")
    if len(stride) != len(shape):
        raise ValueError(f"Buffer stride rank {len(stride)} does not match shape rank {len(shape)}")
    for index, value in enumerate(stride):
        if type(value) is not int:
            raise TypeError(f"Buffer stride[{index}] must be a positive Python int, got {type(value).__name__}")
        if value <= 0:
            raise ValueError(f"Buffer stride[{index}] must be positive, got {value}")
    return stride


def _normalize_dtype(dtype):
    from cannbotdsl.core.contracts.elements import normalize_storage_dtype

    dtype = normalize_storage_dtype(dtype)
    width = getattr(dtype, "width", None)
    if type(width) is not int or width <= 0 or width % 8:
        raise ValueError(f"Buffer dtype must have a positive whole-byte storage width, got {dtype!r} ({width!r} bits)")
    return dtype


def _normalize_addr(addr):
    if addr is None:
        return None
    if type(addr) is not int:
        raise TypeError(f"Buffer addr must be a non-negative Python int or None, got {type(addr).__name__}")
    if addr < 0:
        raise ValueError(f"Buffer addr must be non-negative, got {addr}")
    return addr


def _normalize_format(mem_loc, shape, data_format, n1_pad):
    if data_format is None:
        data_format = "nd" if mem_loc in (MemLoc.UB, MemLoc.BIAS, MemLoc.SSBUF, MemLoc.FBUF) else "nz"
    if type(data_format) is not str:
        raise TypeError(f"Buffer data_format must be one of 'nd', 'nz', or 'zn', got {type(data_format).__name__}")
    if data_format not in _BUFFER_FORMATS:
        raise ValueError(f"Buffer data_format must be one of 'nd', 'nz', or 'zn', got {data_format!r}")
    if mem_loc in (MemLoc.BIAS, MemLoc.SSBUF, MemLoc.FBUF) and data_format != "nd":
        raise ValueError(f"{mem_loc.name} Buffer requires data_format='nd'")
    if data_format in ("nz", "zn") and len(shape) not in (2, 3):
        raise ValueError(f"Buffer data_format={data_format!r} requires rank 2 or 3, got rank {len(shape)}")
    if type(n1_pad) is not int:
        raise TypeError(f"Buffer n1_pad must be a non-negative Python int, got {type(n1_pad).__name__}")
    if n1_pad < 0:
        raise ValueError(f"Buffer n1_pad must be non-negative, got {n1_pad}")
    if n1_pad and data_format != "nz":
        raise ValueError("Buffer n1_pad is only supported for data_format='nz'")
    return data_format, n1_pad


def _build_buffer_tensor(
    mem_loc,
    shape,
    dtype,
    fixed_addr,
    stride,
    data_format,
    n1_pad,
):
    physical_shape, physical_stride = _physical_layout_spec(dtype, shape, data_format, n1_pad, mem_loc=mem_loc)
    if data_format == "nd":
        physical_stride = stride
    logical_layout = make_layout(shape, stride=stride)
    physical_layout = (
        make_layout(physical_shape) if physical_stride is None else make_layout(physical_shape, stride=physical_stride)
    )
    return _make_onchip_allocation(
        dtype,
        mem_loc,
        logical_layout,
        physical_layout,
        data_format=data_format,
        fixed_addr=fixed_addr,
    )[0]


def Buffer(
    mem_loc,
    shape=None,
    dtype=None,
    *,
    capacity=None,
    layout=None,
    physical_layout=None,
    addr=None,
    stride=None,
    data_format=None,
    n1_pad=0,
) -> Tensor:
    """Construct one ordinary on-chip Tensor.

    ``Buffer`` has no runtime value kind of its own. It emits an on-chip
    allocation declaration; the memory-planning pass assigns its byte address
    and materializes the pointer/Tensor root.
    """

    mem_loc = _normalize_mem_loc(mem_loc)
    # Once a function opts into the explicit UB-space model, every UB tensor
    # must be a view of that root.  The root itself is created by UB.view before
    # it is recorded in the arena, so this check does not reject root creation.
    if mem_loc == MemLoc.UB:
        try:
            from cannbotdsl.arena import _current_channel_arena

            arena = _current_channel_arena()
        except RuntimeError:
            arena = None
        if arena is not None and arena._ub_space_root is not None:
            raise ValueError(
                "ordinary UB Buffer is not allowed after dsl.UB.view(); "
                "derive it from the UB space and call make_buffer(view)"
            )
        if arena is not None and not arena._ub_space_bootstrap:
            arena._ub_space_legacy_allocs += 1
    if dtype is None:
        raise TypeError("Buffer requires dtype and a declared layout")
    if layout is not None:
        if shape is not None or stride is not None:
            raise TypeError("Buffer layout form does not accept shape or stride")
        if not isinstance(layout, Layout):
            raise TypeError(
                f"Buffer layout must be a Layout, got {type(layout).__name__}"
            )
        if not isinstance(physical_layout, Layout):
            raise TypeError("Buffer layout form requires physical_layout as a Layout")
        if capacity is None:
            raise TypeError("Buffer layout form requires a static capacity tuple")
        shape = layout.shape
    elif shape is None:
        raise TypeError("Buffer requires shape/dtype or layout/dtype")
    elif physical_layout is not None:
        raise TypeError("Buffer physical_layout is accepted only with layout")

    shape, capacity, has_dynamic_shape = _normalize_shape_capacity(
        shape, capacity, owner="Buffer"
    )
    addr = _normalize_addr(addr)
    if mem_loc == MemLoc.SSBUF and addr is None:
        raise TypeError("SSBUF Buffer requires an explicit byte address via addr=")
    dtype = _normalize_dtype(dtype)
    capacity_stride = _normalize_stride(stride, capacity)
    data_format, n1_pad = _normalize_format(
        mem_loc, capacity, data_format, n1_pad
    )
    if layout is not None:
        capacity_physical_shape, capacity_physical_stride = (
            _physical_layout_spec(
                dtype,
                capacity,
                data_format,
                n1_pad,
                mem_loc=mem_loc,
            )
        )
        if data_format == "nd":
            capacity_physical_stride = capacity_stride
        capacity_layout = make_layout(capacity, stride=capacity_stride)
        capacity_physical_layout = (
            make_layout(capacity_physical_shape)
            if capacity_physical_stride is None
            else make_layout(
                capacity_physical_shape,
                stride=capacity_physical_stride,
            )
        )
        storage_type = _onchip_tensor_type(
            dtype,
            mem_loc,
            capacity_layout,
            capacity_physical_layout,
            data_format=data_format,
        )
        declared_layout = make_layout(layout.shape, stride=layout.stride)
        return _make_onchip_allocation(
            dtype,
            mem_loc,
            declared_layout,
            physical_layout,
            data_format=data_format,
            fixed_addr=addr,
            storage_type=storage_type,
        )[0]

    root = _build_buffer_tensor(
        mem_loc,
        capacity,
        dtype,
        addr,
        capacity_stride,
        data_format,
        n1_pad,
    )
    if not has_dynamic_shape and shape == capacity:
        return root

    from cannbotdsl.tensor import local_slice, make_bounded_tiler

    bounded = make_bounded_tiler(shape, capacity, (1,) * len(capacity))
    return local_slice(root, bounded, stride=capacity_stride)


__all__ = ["Buffer"]
