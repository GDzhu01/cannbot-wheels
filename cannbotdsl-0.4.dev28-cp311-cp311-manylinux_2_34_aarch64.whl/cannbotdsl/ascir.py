# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You should not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Hybrid AscIR direct-call bridge.

``extract_buffer`` exposes a Tensor's or Channel slot's physical backing
buffer so user kernels can emit Asc-level ops (``ascvec`` / ``asccube`` /
``ascscalar`` bindings) directly with real memref operands::

    from cannbotdsl._mlir.dialects import ascvec

    ub_buf, ub_off = cannbotdsl.extract_buffer(ub, access="write")
    gm_buf, gm_off = cannbotdsl.extract_buffer(gm, access="read")
    ascvec.copy_gm2ub(
        ub_buf, ub_off, gm_buf, gm_off,
        Int32(2), Int32(burst_bytes), Int64(src_stride), Int32(dst_stride),
        Int32(0), Int32(0),
    )

The offset result is an element offset relative to the returned buffer; add
the user offset on top (``arith.addi`` folds constants). On a Channel source
the ``access`` mode drives the automatic four-primitive bracketing
(write: acquire/commit, read: wait/release) around the ops that consume the
extracted buffer. On a plain Tensor no synchronization is inserted — keep the
manual sync discipline.
"""

import cannbotdsl._mlir.ir as ir
from cannbotdsl.ir_transport import unwrap_operand
from cannbotdsl._mlir.dialects import cannir
from cannbotdsl.core.mlir_context import (
    _has_current_context,
    _has_current_insertion_point,
)
from cannbotdsl.types import MemLoc, Tensor

_ACCESS_MODES = ("read", "write", "read_write")

# Mirrors memLocToAddrSpace in CANNIRToAsc/Support.cpp.
_MEMLOC_TO_ADDR_SPACE = {
    MemLoc.GM: 0,
    MemLoc.UB: 1,
    MemLoc.L1: 2,
    MemLoc.L0A: 3,
    MemLoc.L0B: 4,
    MemLoc.L0C: 5,
    MemLoc.L0A_MX: 6,
    MemLoc.L0B_MX: 7,
    MemLoc.BIAS: 8,
    MemLoc.SSBUF: 9,
}


def _carrier_and_pointer_type(src, *, api_name):
    """Return ``(ssa_carrier, cannir.PointerType)`` for a Tensor or Channel."""

    from cannbotdsl.channel import Channel

    if isinstance(src, Tensor):
        from cannbotdsl.tensor import _tensor_pointer_type

        return unwrap_operand(src), _tensor_pointer_type(src)
    if isinstance(src, Channel):
        carrier = unwrap_operand(src)
        element = cannir.ChannelType(carrier.type).element
        return carrier, cannir.PointerType(cannir.TensorType(element).pointer)
    raise TypeError(
        f"{api_name}: source must be a Tensor or Channel, got "
        f"{type(src).__name__}"
    )


def extract_buffer(src, *, access: str):
    """Return ``(buf, offset)`` SSA values for direct Asc-level ops.

    Args:
        src: a Tensor or Channel whose physical backing buffer is requested.
        access: "read", "write", or "read_write" — the intended use. On a
            Channel this selects the auto-sync direction (read: wait/release,
            write: acquire/commit) bracketing every op that consumes the
            returned buffer; on a Tensor it declares effects only.

    Returns:
        ``(buf, offset)``: a flat memref value in the source's memory space
        plus its element offset. Offsets passed to Asc ops must be relative
        to ``buf`` (add to ``offset``).
    """
    from cannbotdsl.lang.vf import _current_vf_mode

    api_name = "extract_buffer"
    if access not in _ACCESS_MODES:
        raise ValueError(
            f"{api_name}: access must be one of {_ACCESS_MODES}, got "
            f"{access!r}"
        )
    if not _has_current_context() or not _has_current_insertion_point():
        raise RuntimeError(
            f"cannbotdsl.{api_name} can only be called inside a traced "
            "@jit/@kernel function"
        )
    if _current_vf_mode() == "raw":
        raise RuntimeError(
            f"cannbotdsl.{api_name} cannot be called inside "
            "`with cannbotdsl.lang.vf(mode='raw'):` — extract the buffer outside "
            "the vf block and pass the memref in"
        )

    carrier, pointer_type = _carrier_and_pointer_type(src, api_name=api_name)
    memloc = MemLoc(pointer_type.memloc)
    addr_space = _MEMLOC_TO_ADDR_SPACE.get(memloc)
    if addr_space is None:
        raise ValueError(
            f"{api_name}: memory location {memloc.name} has no flat address "
            "space and cannot back direct Asc ops"
        )
    buf_type = ir.MemRefType.get(
        [ir.ShapedType.get_dynamic_size()],
        pointer_type.dtype,
        memory_space=ir.IntegerAttr.get(
            ir.IntegerType.get_signless(64), addr_space
        ),
    )

    op = cannir.ExtractBufferOp(
        buf_type, ir.IndexType.get(), carrier, access=access
    )
    return op.buf, op.offset
