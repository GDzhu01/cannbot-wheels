# Generated from the distribution metadata; do not edit.
__version__ = "0.4.dev28"
