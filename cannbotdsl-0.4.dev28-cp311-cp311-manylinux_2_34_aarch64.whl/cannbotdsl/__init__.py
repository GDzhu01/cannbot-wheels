# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""CANNBotDSL: Python frontend for building CANNIR MLIR from Python."""

import sys

from cannbotdsl.core.utils.logger import init_logger as _init_logger

_init_logger()

# AttrBuilder registrations must run before any dialect op constructor sees
# a PipeEnum / RoundingModeEnum argument. Imported for side effect only.
from cannbotdsl.core.frontend import attr_builders  # noqa: F401

from cannbotdsl.ops.arch import (
    get_block_idx,
    get_block_num,
    get_core_id,
    get_squeeze_status,
    get_status,
    get_subblock_dim,
    get_subblock_id,
    get_system_cycle,
    get_vf_len,
)
from cannbotdsl.ops.info import (
    PlatformInfo,
    get_mem_size,
    get_platform_info,
)
from cannbotdsl.types.array import IntArray, alloc_array
from cannbotdsl.lang.constexpr import const_expr, range_constexpr, target_version
from cannbotdsl.ops.conv import (
    Conv2dSpec,
    Conv2dTile,
    conv2d_load_filter,
    conv2d_load_fmap,
    conv2d_load_im2col,
    conv2d_store_output,
    make_conv2d_fmap_l1,
    make_conv2d_spec,
)
from cannbotdsl.lang.control_flow import range
from cannbotdsl.types.delay_line import DelayLine, DelayLineGroup
from cannbotdsl.core.compiler import (
    ProviderCallable,
    clear_compile_cache,
    load,
)
from cannbotdsl.core.diag.diagnostics import (
    CANNBotError,
    CANNBotInternalError,
    CANNBotRuntimeError,
    CANNBotTypeError,
    CANNBotValueError,
    DiagnosticCode,
)
from cannbotdsl.core.diag.debug import print_scalar, print_tensor
from cannbotdsl.types.datastruct import (
    CArray,
    StructField,
    StructRef,
    StructSchema,
    datastruct,
)
from cannbotdsl.types import dtypes
from cannbotdsl.ops import cube
from cannbotdsl.ops import scalar
from cannbotdsl.types.dtypes import DType
from cannbotdsl.types._numeric import (
    Float8E4M3FN,
    Float8E5M2,
    Float8E8M0,
    HIFloat8,
)
from cannbotdsl.lang.jit import jit
from cannbotdsl.lang.kernel import kernel
from cannbotdsl import profiler
from cannbotdsl.profiler import ProfileSpec
from cannbotdsl.core.frontend.runtime.expressions import select
from cannbotdsl.ops.matmul import matmul
from cannbotdsl.ops.memcpy import make_copy_engine, mem_copy
from cannbotdsl.lang.spec import (
    Constexpr,
    Dim,
    StructSpec,
    TensorListSpec,
    TensorSpec,
)
from cannbotdsl.types.tensor_list import TensorList
from cannbotdsl.ops.sync import (
    busy_wait,
    cube_get_buf,
    cube_release_buf,
    cube_sync_all,
    cube_sync_block_arrive,
    cube_sync_block_wait,
    cube_sync_intra_arrive,
    cube_sync_intra_wait,
    cube_sync_pipe,
    dcci_entire_atomic,
    dcci_entire_out,
    dcci_single,
    dci,
    global_sync_all,
    try_wait,
    vec_get_buf,
    vec_release_buf,
    vec_sync_all,
    vec_sync_block_arrive,
    vec_sync_block_wait,
    vec_sync_intra_arrive,
    vec_sync_intra_wait,
)
from cannbotdsl.tensor import (
    BoundedTiler,
    PartitionTiler,
    ceil_div,
    crd2idx,
    local_slice,
    make_layout,
    make_tensor,
    permute,
    reinterpret,
    idx2crd,
    partition_view,
    make_bounded_tiler,
    make_partition_tiler,
    size,
    tile_view,
)
from cannbotdsl.types import (
    ChannelKind,
    Coord,
    Layout,
    MemLoc,
    PIPE,
    RegLayout,
    RoundingMode,
    CmpOp,
    ScalarValue,
    Shape,
    Stride,
    Tensor,
    Tile,
    Tiler,
)
from cannbotdsl.ub_space import UB, make_buffer, make_channel
from cannbotdsl.ascir import extract_buffer
from cannbotdsl.lang.vf import vf

# The raw-register and collective surfaces are namespaced, not flattened:
# `cb.reg.vadd(...)` and `cb.distributed.get_comm_context(...)`. Registering
# them in sys.modules under the short names keeps `import cannbotdsl.reg` and
# `from cannbotdsl.reg import vadd` working alongside attribute access.
#
# Namespacing `reg` is also what removes the old `vmax` / `vselect` collision:
from cannbotdsl.ops import distributed, reg  # noqa: F401

sys.modules[__name__ + ".reg"] = reg
sys.modules[__name__ + ".distributed"] = distributed

try:
    from cannbotdsl._version import __version__
except ModuleNotFoundError:
    try:
        from importlib.metadata import PackageNotFoundError, version

        __version__ = version("cannbotdsl")
    except PackageNotFoundError:
        __version__ = "0.0.0+source"

__all__ = [
    "profiler",
    "ProfileSpec",
    "__version__",
    "Buffer",
    "BoundedTiler",
    "CArray",
    "Channel",
    "ChannelKind",
    "CANNBotError",
    "CANNBotInternalError",
    "CANNBotRuntimeError",
    "CANNBotTypeError",
    "CANNBotValueError",
    "CmpOp",
    "Constexpr",
    "Conv2dSpec",
    "Conv2dTile",
    "Coord",
    "DelayLine",
    "DelayLineGroup",
    "DiagnosticCode",
    "Dim",
    "DType",
    "Float8E4M3FN",
    "Float8E5M2",
    "Float8E8M0",
    "HIFloat8",
    "IntArray",
    "Layout",
    "MemLoc",
    "PIPE",
    "PartitionTiler",
    "PlatformInfo",
    "ProviderCallable",
    "RegLayout",
    "RoundingMode",
    "ScalarValue",
    "Shape",
    "Stride",
    "StructField",
    "StructRef",
    "StructSchema",
    "StructSpec",
    "Tensor",
    "UB",
    "TensorList",
    "TensorListSpec",
    "TensorSpec",
    "Tile",
    "Tiler",
    "alloc_array",
    "busy_wait",
    "ceil_div",
    "channel_rewind",
    "clear_compile_cache",
    "const_expr",
    "conv2d_load_filter",
    "conv2d_load_fmap",
    "conv2d_load_im2col",
    "conv2d_store_output",
    "crd2idx",
    "cube",
    "cube_get_buf",
    "cube_release_buf",
    "cube_sync_all",
    "cube_sync_block_arrive",
    "cube_sync_block_wait",
    "cube_sync_intra_arrive",
    "cube_sync_intra_wait",
    "cube_sync_pipe",
    "datastruct",
    "dcci_entire_atomic",
    "dcci_entire_out",
    "dcci_single",
    "dci",
    "distributed",
    "dtypes",
    "extract_buffer",
    "get_block_idx",
    "get_block_num",
    "get_core_id",
    "get_mem_size",
    "get_platform_info",
    "get_squeeze_status",
    "get_status",
    "get_subblock_dim",
    "get_subblock_id",
    "get_system_cycle",
    "get_vf_len",
    "global_sync_all",
    "idx2crd",
    "jit",
    "kernel",
    "load",
    "local_slice",
    "make_bounded_tiler",
    "make_conv2d_fmap_l1",
    "make_conv2d_spec",
    "make_copy_engine",
    "make_layout",
    "make_buffer",
    "make_channel",
    "make_partition_tiler",
    "make_tensor",
    "matmul",
    "mem_copy",
    "partition_view",
    "permute",
    "print_scalar",
    "print_tensor",
    "range",
    "range_constexpr",
    "reg",
    "reinterpret",
    "scalar",
    "select",
    "size",
    "target_version",
    "tile_view",
    "try_wait",
    "vec_get_buf",
    "vec_release_buf",
    "vec_sync_all",
    "vec_sync_block_arrive",
    "vec_sync_block_wait",
    "vec_sync_intra_arrive",
    "vec_sync_intra_wait",
    "vf",
]


def __getattr__(name):
    if name == "Buffer":
        from cannbotdsl.buffer import Buffer

        globals()[name] = Buffer
        return Buffer
    if name == "Channel":
        from cannbotdsl.channel import Channel

        globals()[name] = Channel
        return Channel
    if name == "channel_rewind":
        from cannbotdsl.arena import channel_rewind

        globals()[name] = channel_rewind
        return channel_rewind
    raise AttributeError(f"module 'cannbotdsl' has no attribute {name!r}")
