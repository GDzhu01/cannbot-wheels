# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms of
# the CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details.

"""Static UB-space partitioning frontend.

This module is the first implementation slice of the UB-space design.  It
deliberately supports only static byte-addressed views.  A UB space owns one
full-size backing Tensor; ``make_buffer`` adds a ``make_buf`` identity to a
view without allocating another UB region.
"""

from __future__ import annotations

from functools import reduce
from operator import mul

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir

from cannbotdsl.arena import _current_channel_arena
from cannbotdsl.ir_transport import unwrap_operand
from cannbotdsl.types import MemLoc, Tensor, dtypes
from cannbotdsl.types._numeric import Int64


_UB_CAPACITY_BYTES = 256 * 1024
_STATIC_VIEW_OPS = frozenset(
    {
        "cannir.reshape_view",
        "cannir.memref_slice",
        "cannir.local_slice",
        "cannir.tile_view",
        "cannir.reinterpret_view",
        "cannir.dtype_view",
        "cannir.permute_view",
        "cannir.make_buf",
    }
)


def _static_product(shape) -> int:
    values = []
    for dim in shape:
        if type(dim) is not int or dim <= 0:
            raise TypeError(
                "UB space views require a non-empty static shape of positive ints"
            )
        values.append(dim)
    if not values:
        raise ValueError("UB space view shape must not be empty")
    return reduce(mul, values, 1)


def _ensure_static_view(view: Tensor) -> None:
    shape = view.shape
    stride = view.stride
    _static_product(shape)
    for name, values in (("stride", stride),):
        for index, value in enumerate(values):
            if type(value) is not int or value <= 0:
                raise TypeError(
                    f"UB space view {name}[{index}] must be a positive static int"
                )


def _find_ub_root(value):
    """Find the explicit UB root through the supported static view chain."""

    current = unwrap_operand(value)
    visited = set()
    while current is not None and current not in visited:
        visited.add(current)
        owner = getattr(current, "owner", None)
        name = str(getattr(owner, "name", ""))
        if name == "cannir.onchip_alloc":
            if "cannir.ub_space_root" in owner.attributes:
                return current
            return None
        if name not in _STATIC_VIEW_OPS:
            return None
        current = unwrap_operand(owner.operands[0])
    return None


def _has_bound_resource(value) -> bool:
    """Return whether a view chain already contains a make_buf boundary."""

    current = unwrap_operand(value)
    visited = set()
    while current is not None and current not in visited:
        visited.add(current)
        owner = getattr(current, "owner", None)
        name = str(getattr(owner, "name", ""))
        if name == "cannir.make_buf":
            return True
        if name not in _STATIC_VIEW_OPS:
            return False
        current = unwrap_operand(owner.operands[0])
    return False


class _UBSpace:
    """Function-local static UB storage root facade."""

    __slots__ = ()

    def view(self, *shape, dtype=None):
        """Return a static view covering the complete UB space.

        The root is byte-addressed in the MVP.  ``shape`` must therefore
        contain exactly 256 KiB worth of uint8 elements.  All later UB
        resources must be derived from the returned view.
        """

        if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
            shape = tuple(shape[0])
        else:
            shape = tuple(shape)
        if dtype is not None and dtype != dtypes.uint8:
            raise ValueError(
                "dsl.UB.view is byte-addressed in the MVP; dtype must be dtypes.uint8"
            )
        if _static_product(shape) != _UB_CAPACITY_BYTES:
            raise ValueError(
                "dsl.UB.view must cover the complete 256 KiB UB space "
                f"({ _UB_CAPACITY_BYTES } uint8 elements), got shape={shape!r}"
            )

        arena = _current_channel_arena()
        if arena._ub_space_legacy_allocs:
            raise ValueError(
                "dsl.UB.view must be declared before ordinary UB Buffer allocations"
            )
        root = arena._ub_space_root
        if root is None:
            from cannbotdsl.buffer import Buffer
            arena._ub_space_bootstrap = True
            try:
                root = Buffer(
                    MemLoc.UB,
                    shape=(_UB_CAPACITY_BYTES,),
                    dtype=dtypes.uint8,
                    addr=0,
                )
            finally:
                arena._ub_space_bootstrap = False
            root_value = unwrap_operand(root)
            root_value.owner.attributes["cannir.ub_space_root"] = ir.UnitAttr.get()
            arena._ub_space_root = root
            arena._ub_space_capacity = _UB_CAPACITY_BYTES
        return root.view(shape)


UB = _UBSpace()


def make_buffer(view: Tensor, *, dtype=None) -> Tensor:
    """Bind a static UB view to a hardware Buffer identity.

    The operation reuses the view's storage root and address.  It emits no
    ``onchip_alloc``; only a ``make_buf`` marker and a buf-id are added.
    """

    if not isinstance(view, Tensor):
        raise TypeError(
            f"make_buffer expects a Tensor view, got {type(view).__name__}"
        )
    if view.memloc != MemLoc.UB:
        raise ValueError("make_buffer currently supports only UB views")
    _ensure_static_view(view)

    root = _find_ub_root(view)
    if root is None:
        raise ValueError(
            "make_buffer requires a static view derived from dsl.UB.view()"
        )

    # A view of an already-bound Buffer keeps that resource.  A dtype view is
    # formed before this check by the caller (or by the implementation below),
    # so no second buf-id can be introduced accidentally.
    if dtype is not None:
        from cannbotdsl.core.contracts.elements import normalize_storage_dtype

        dtype = normalize_storage_dtype(dtype)
        if dtype != view.dtype:
            view = view.view(dtype=dtype)
            _ensure_static_view(view)
    if _has_bound_resource(view):
        return view

    arena = _current_channel_arena()
    buf_id = arena.alloc_buf_ids(MemLoc.UB, 1)[0]
    marker = cannir.make_buf(unwrap_operand(view), Int64(buf_id))
    marker_value = unwrap_operand(marker)
    marker_value.owner.attributes["cannir.buffer.explicit_binding"] = ir.UnitAttr.get()
    return Tensor._from_ir(marker_value)


def make_channel(views, *, dtype=None, kind=None):
    """Create a Channel whose slots are unbound static UB-space views.

    Slots may have different origins, but must have identical Tensor types.
    Buffer-to-Channel ownership transfer is outside the first version.
    """
    from cannbotdsl.channel import Channel
    from cannbotdsl.types import ChannelKind

    if kind is None:
        kind = ChannelKind.SameCore
    if kind not in (ChannelKind.SameCore, ChannelKind.CrossCore):
        raise ValueError("make_channel kind must be SameCore or CrossCore")
    if not isinstance(views, (list, tuple)) or not views:
        raise ValueError("make_channel requires a non-empty list or tuple of views")
    if kind == ChannelKind.CrossCore and len(views) > 8:
        raise ValueError("cross-core Channel depth must be <= 8")
    slots = []
    for view in views:
        if not isinstance(view, Tensor) or _find_ub_root(view) is None:
            raise ValueError("make_channel requires views derived from dsl.UB.view()")
        if _has_bound_resource(view):
            raise ValueError("make_channel requires unbound views; Buffer ownership transfer is not supported")
        if dtype is not None:
            from cannbotdsl.core.contracts.elements import normalize_storage_dtype

            target = normalize_storage_dtype(dtype)
            if view.dtype != target:
                view = view.view(dtype=target)
        _ensure_static_view(view)
        if slots and unwrap_operand(view).type != unwrap_operand(slots[0]).type:
            raise ValueError("make_channel slots must have identical dtype, shape, stride and layout")
        slots.append(view)

    arena = _current_channel_arena()
    ch = object.__new__(Channel)
    ch._kind = kind
    ch._depth = len(slots)
    ch._mem_loc = MemLoc.UB
    ch._dtype = slots[0].dtype
    ch._shape = ch._capacity = slots[0].shape
    ch._stride = slots[0].stride
    ch._has_dynamic_shape = False
    ch._data_format = "nd"
    ch._n1_pad = 0
    ch._addr = None
    ch._buf_ids = arena.alloc_buf_ids(MemLoc.UB, len(slots))
    ch._sync_ids = arena.alloc_sync_ids(len(slots)) if kind == ChannelKind.CrossCore else None
    ch._sync_epoch = arena._sync_epoch if ch._sync_ids is not None else None
    ch._slot_storage_values = tuple(unwrap_operand(slot) for slot in slots)
    bound = []
    for slot, buf_id in zip(slots, ch._buf_ids):
        marker = unwrap_operand(cannir.make_buf(unwrap_operand(slot), Int64(buf_id)))
        marker.owner.attributes["cannir.buffer.explicit_binding"] = ir.UnitAttr.get()
        bound.append(marker)
    attrs = {}
    if ch._sync_ids is not None:
        attrs["cannir.channel.sync_ids"] = ir.DenseI64ArrayAttr.get(ch._sync_ids)
        attrs["cannir.channel.epoch"] = ir.IntegerAttr.get(ir.IntegerType.get_signless(64), ch._sync_epoch)
    op = cannir.MakeChannelOp.build_generic(operands=bound, attributes=attrs)
    ch._ir_value = ch._root_ir_value = ch._layout_ir_value = op.results[0]
    ch._dynamic_tiler = None
    ch._manual_slot_roots = {}
    ch._ub_space_slots = True
    return ch


__all__ = ["UB", "make_buffer", "make_channel"]
