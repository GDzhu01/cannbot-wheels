# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Private physical-layout support for on-chip memory declarations."""

from __future__ import annotations

import math

from cannbotdsl.types import MemLoc


def _normalize_shape_capacity(shape, capacity, *, owner):
    """Validate a flat logical shape and its static allocation capacity."""
    import cannbotdsl._mlir.ir as ir

    if not isinstance(shape, tuple):
        raise TypeError(
            f"{owner} shape must be a flat tuple of positive ints or i64 SSA values"
        )
    if not shape:
        raise ValueError(f"{owner} shape must not be empty")

    has_dynamic = False
    for index, dim in enumerate(shape):
        if type(dim) is int:
            if dim <= 0:
                raise ValueError(
                    f"{owner} shape[{index}] must be positive, got {dim}"
                )
            continue
        if isinstance(dim, ir.Value):
            dim_type = dim.type
            if not (
                isinstance(dim_type, ir.IntegerType)
                and dim_type.width == 64
                and dim_type.is_signless
            ):
                raise TypeError(
                    f"{owner} shape[{index}] SSA value must have canonical "
                    f"signless i64 type, got {dim_type}"
                )
            has_dynamic = True
            continue
        raise TypeError(
            f"{owner} shape[{index}] must be a positive Python int or i64 "
            f"SSA value, got {type(dim).__name__}"
        )

    if capacity is None:
        if has_dynamic:
            raise TypeError(
                f"{owner} dynamic shape requires a static capacity tuple"
            )
        capacity = shape
    if not isinstance(capacity, tuple):
        raise TypeError(
            f"{owner} capacity must be a flat tuple of positive ints"
        )
    if len(capacity) != len(shape):
        raise ValueError(
            f"{owner} capacity rank {len(capacity)} does not match shape rank "
            f"{len(shape)}"
        )
    for index, (dim, bound) in enumerate(zip(shape, capacity)):
        if type(bound) is not int:
            raise TypeError(
                f"{owner} capacity[{index}] must be a positive Python int, "
                f"got {type(bound).__name__}"
            )
        if bound <= 0:
            raise ValueError(
                f"{owner} capacity[{index}] must be positive, got {bound}"
            )
        if type(dim) is int and dim > bound:
            raise ValueError(
                f"{owner} shape[{index}] ({dim}) exceeds capacity[{index}] "
                f"({bound})"
            )
    return shape, capacity, has_dynamic


def _nd2nz_inner_dims(
    mem_loc, storage_width, *, l0c_width32_accumulator=False
):
    """Return the physical ``(M0, N0)`` for one mapped NZ fractal."""
    if (
        mem_loc == MemLoc.L0C
        and storage_width == 32
        and l0c_width32_accumulator
    ):
        return 16, 16
    return 16, 256 // storage_width


def _nd2nz_shape(dtype, shape, *, mem_loc=None):
    """Return the C++-derived physical NZ shape."""
    return _mapped_physical_layout(dtype, shape, "nz", 0, mem_loc=mem_loc)[0]


def _dn2nz_shape(dtype, shape):
    """Return the C++-derived physical ZN shape."""
    return _mapped_physical_layout(dtype, shape, "zn", 0)[0]


def _contiguous_stride(shape):
    stride = 1
    result = []
    for dim in reversed(shape):
        result.append(stride)
        stride *= dim
    return tuple(reversed(result))


def _mapped_physical_layout(
    dtype, logical_shape, physical_format, n1_pad, *, mem_loc=MemLoc.L1
):
    """Call the canonical C++ physical-layout implementation."""
    if mem_loc is None:
        mem_loc = MemLoc.L1
    import cannbotdsl._mlir.ir as ir
    from cannbotdsl._mlir.dialects import cannir
    from cannbotdsl.core.contracts.elements import storage_mlir_type_for_dtype
    from cannbotdsl.core.mlir_context import _has_current_context

    def derive():
        layout_map_kind = {"nz": 1, "zn": 2}[physical_format]
        logical_layout = cannir.LayoutType.get(
            logical_shape, _contiguous_stride(logical_shape)
        )
        pointer = cannir.PointerType.get(
            int(mem_loc), storage_mlir_type_for_dtype(dtype)
        )
        physical_layout = cannir.derive_physical_layout(
            pointer, logical_layout, layout_map_kind, n1_pad
        )
        return tuple(physical_layout.shape), tuple(physical_layout.stride)

    if _has_current_context():
        return derive()
    with ir.Context():
        return derive()


def _physical_layout_spec(
    dtype, logical_shape, physical_format, n1_pad, *, mem_loc=None
):
    """Return ``(physical_shape, physical_stride)`` for on-chip storage."""
    if mem_loc == MemLoc.SSBUF:
        if physical_format != "nd":
            raise ValueError("SSBUF buffers require data_format='nd'")
        if n1_pad:
            raise ValueError("n1_pad is not supported for SSBUF buffers")
        return logical_shape, None

    if mem_loc == MemLoc.BIAS:
        if physical_format != "nd" or len(logical_shape) != 1:
            raise ValueError("BIAS buffers require rank-1 data_format='nd'")
        if dtype.width != 32:
            raise ValueError("BIAS buffers require float32 or int32 elements")
        if n1_pad:
            raise ValueError("n1_pad is not supported for BIAS buffers")
        n = logical_shape[0]
        if not isinstance(n, int) or n <= 0:
            raise ValueError("BIAS buffers require a positive static N")
        # L1 -> BT writes float32/int32 data in 64-byte units.
        return (math.ceil(n / 16) * 16,), None

    if physical_format == "nz" and len(logical_shape) in (2, 3):
        return _mapped_physical_layout(
            dtype, logical_shape, physical_format, n1_pad, mem_loc=mem_loc
        )
    if physical_format == "zn" and len(logical_shape) in (2, 3):
        if n1_pad:
            raise ValueError("n1_pad only meaningful for data_format='nz'")
        return _mapped_physical_layout(
            dtype, logical_shape, physical_format, n1_pad, mem_loc=mem_loc
        )
    if n1_pad:
        raise ValueError("n1_pad only meaningful for data_format='nz'")
    return logical_shape, None
