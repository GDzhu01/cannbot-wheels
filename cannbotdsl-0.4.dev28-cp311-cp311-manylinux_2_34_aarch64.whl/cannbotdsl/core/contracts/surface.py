# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Safe Python surface signatures shared by binding and lowering.

This module deliberately keeps two decisions together:

* whether descriptor binding reserves the first positional parameter as a
  receiver; and
* how string annotations are interpreted without executing user code.

The resolver is intentionally smaller than Python's expression language.  It
accepts names and statically-read attributes plus the trusted annotation forms
used by CANNBotDSL; ``Annotated`` metadata remains documentation-only.  In
particular it never evaluates calls, comprehensions, descriptors, or general
operators.
"""

from __future__ import annotations

import ast
import inspect
import sys
import types
import typing
from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Callable, Mapping

from cannbotdsl.types.dtypes import DType, _resolve_dtype
from cannbotdsl.lang.spec import Constexpr
from cannbotdsl.types import ScalarValue
from cannbotdsl.core.diag.diagnostics import (
    CANNBotTypeError,
    ST102_NON_VOID_ENTRY_RETURN,
)


_EMPTY = inspect.Parameter.empty
_BUILTIN_ANNOTATION_NAMES = {
    "bool": bool,
    "bytes": bytes,
    "complex": complex,
    "float": float,
    "int": int,
    "object": object,
    "str": str,
    "type": type,
}


class AnnotationPolicy(Enum):
    """How much annotation meaning a surface is allowed to consume."""

    FULL = "full"
    STAGING_ONLY = "staging_only"


class _StagedRole(Enum):
    RECEIVER = "receiver"
    CONSTEXPR = "constexpr"
    ABSENT = "absent"
    RUNTIME = "runtime"


@dataclass(frozen=True, slots=True)
class _StagedParameter:
    parameter: inspect.Parameter
    annotation: object
    scalar_semantics: "ScalarAnnotationSemantics | None"
    role: _StagedRole


@dataclass(frozen=True, slots=True)
class _StagedBinding:
    """One fully-defaulted call classified at a real staging boundary."""

    bound: inspect.BoundArguments
    supplied_names: frozenset[str]
    receiver_parameter: str | None
    parameters: tuple[_StagedParameter, ...]

    def parameter(self, name: str) -> _StagedParameter:
        for item in self.parameters:
            if item.parameter.name == name:
                return item
        raise KeyError(name)


@dataclass(frozen=True, slots=True, eq=False, repr=False)
class _ResolvedConstexpr:
    """Non-executable representation of a string ``Constexpr[T]``."""

    payload: object


@dataclass(frozen=True, slots=True, eq=False, repr=False)
class _ResolvedUnion:
    """Non-executable representation of a string Optional/Union form."""

    members: tuple[object, ...]


@dataclass(frozen=True, slots=True, eq=False, repr=False)
class _ResolvedNestedScalar:
    """Marker for a textual container containing a DSL scalar annotation."""


@dataclass(frozen=True, slots=True)
class ResolvedSurfaceType:
    """One cached, non-executing annotation resolution result."""

    raw: object = field(default=_EMPTY, repr=False)
    value: object = field(default=_EMPTY, repr=False)
    error: str | None = None
    staging_candidate: bool = False

    @property
    def is_present(self) -> bool:
        return self.raw is not _EMPTY

    @property
    def is_resolved(self) -> bool:
        return self.error is None and self.value is not _EMPTY


class _UnsafeAnnotation(ValueError):
    pass


def _is_plain_mapping(value) -> bool:
    return type(value) is dict or type(value) is types.MappingProxyType


def unwrap_surface_annotation(annotation):
    """Discard documentation-only ``Annotated`` metadata."""

    if typing.get_origin(annotation) is typing.Annotated:
        arguments = typing.get_args(annotation)
        if arguments:
            return arguments[0]
    return annotation


def surface_constexpr_payload(annotation):
    """Return a constexpr payload, or ``inspect.Parameter.empty``."""

    annotation = unwrap_surface_annotation(annotation)
    if type(annotation) is _ResolvedConstexpr:
        return annotation.payload
    if typing.get_origin(annotation) is Constexpr:
        arguments = typing.get_args(annotation)
        return arguments[0] if arguments else typing.Any
    return _EMPTY


def surface_union_members(annotation) -> tuple[object, ...] | None:
    """Return members for safe textual and already-materialized unions."""

    annotation = unwrap_surface_annotation(annotation)
    if type(annotation) is _ResolvedUnion:
        return annotation.members
    origin = typing.get_origin(annotation)
    if origin is typing.Union or origin is types.UnionType:
        return typing.get_args(annotation)
    return None


def is_tensor_annotation(annotation) -> bool:
    """Return whether an annotation is Tensor, optionally unioned with None."""

    from cannbotdsl.types import Tensor

    annotation = unwrap_surface_annotation(annotation)
    variants = surface_union_members(annotation)
    if variants is not None:
        non_none = tuple(item for item in variants if item is not type(None))
        return bool(non_none) and all(is_tensor_annotation(item) for item in non_none)
    return annotation is Tensor


def is_tensor_list_annotation(annotation) -> bool:
    """Return whether an annotation is the exact runtime TensorList marker."""

    from cannbotdsl.types.tensor_list import TensorList

    return unwrap_surface_annotation(annotation) is TensorList


def surface_annotation_name(annotation) -> str:
    """Render an annotation without calling user ``repr`` or descriptors."""

    annotation = unwrap_surface_annotation(annotation)
    if type(annotation) is _ResolvedConstexpr:
        return "Constexpr"
    if type(annotation) is _ResolvedUnion:
        return "Union"
    if inspect.isclass(annotation):
        try:
            return type.__getattribute__(annotation, "__name__")
        except (AttributeError, TypeError):
            return "type"
    annotation_type = type(annotation)
    try:
        return type.__getattribute__(annotation_type, "__name__")
    except (AttributeError, TypeError):  # pragma: no cover - type invariant
        return "annotation"


def validate_constexpr_value(name: str, annotation: object, value: object) -> None:
    expected = surface_constexpr_payload(annotation)
    if expected is _EMPTY or expected is typing.Any:
        return
    members = surface_union_members(expected)
    matches = (
        type(value) is expected
        if members is None
        else any(type(value) is member for member in members)
    )
    if not matches:
        raise TypeError(
            f"constexpr parameter {name!r} expects "
            f"{surface_annotation_name(expected)}, got {type(value).__name__}"
        )


@dataclass(frozen=True, slots=True)
class ScalarAnnotationSemantics:
    """Canonical meaning of one supported scalar parameter annotation."""

    class Mode(Enum):
        GENERIC = "generic"
        DTYPE = "dtype"
        PYTHON = "python"

    mode: Mode
    dtype: DType | None = None


def _is_private_scalar_wrapper(annotation: object) -> bool:
    from cannbotdsl.core.contracts.elements import element_for_dsl_type

    try:
        element_for_dsl_type(annotation)
    except TypeError:
        return False
    return True


def _is_scalar_annotation_leaf(annotation: object) -> bool:
    annotation = unwrap_surface_annotation(annotation)
    return (
        annotation is ScalarValue
        or type(annotation) is DType
        or _is_private_scalar_wrapper(annotation)
    )


def _contains_nested_scalar_annotation(annotation: object) -> bool:
    annotation = unwrap_surface_annotation(annotation)
    if type(annotation) is _ResolvedNestedScalar:
        return True
    variants = surface_union_members(annotation)
    arguments = variants if variants is not None else typing.get_args(annotation)
    for argument in arguments:
        if _is_scalar_annotation_leaf(argument):
            return True
        if _contains_nested_scalar_annotation(argument):
            return True
    return False


def classify_scalar_annotation(
    name: str,
    annotation: object,
) -> ScalarAnnotationSemantics | None:
    """Recognize and canonicalize the closed scalar annotation grammar.

    This function deliberately has no value-dependent or lowering behavior.
    Host binding and trace lowering consume the classification independently.
    """

    annotation = unwrap_surface_annotation(annotation)
    if annotation is ScalarValue:
        return ScalarAnnotationSemantics(
            ScalarAnnotationSemantics.Mode.GENERIC,
        )
    if type(annotation) is DType:
        try:
            canonical = _resolve_dtype(annotation)
        except TypeError as exc:
            raise TypeError(
                f"parameter {name!r} uses a non-canonical CANNBotDSL dtype annotation"
            ) from exc
        return ScalarAnnotationSemantics(
            ScalarAnnotationSemantics.Mode.DTYPE,
            canonical,
        )
    if annotation is bool or annotation is int or annotation is float:
        return ScalarAnnotationSemantics(
            ScalarAnnotationSemantics.Mode.PYTHON,
            _resolve_dtype(annotation, allow_python=True),
        )
    if _is_private_scalar_wrapper(annotation):
        raise TypeError(
            f"parameter {name!r} uses scalar value wrapper "
            f"{surface_annotation_name(annotation)} as an annotation; use "
            "ScalarValue, bool/int/float, or a canonical dtypes.* descriptor"
        )
    if _contains_nested_scalar_annotation(annotation):
        raise TypeError(
            f"parameter {name!r} uses ScalarValue or a concrete DType inside "
            "a union or container annotation; only direct ScalarValue, "
            "Annotated[ScalarValue, ...], and direct canonical dtypes.* "
            "descriptors are supported"
        )
    return None


def _select_staging_annotation(annotation: object) -> tuple[object, bool]:
    if surface_constexpr_payload(annotation) is not _EMPTY:
        return annotation, True
    try:
        semantics = classify_scalar_annotation("<bound>", annotation)
    except TypeError:
        # Preserve invalid scalar spellings so the consuming boundary can issue
        # the ordinary parameter-specific diagnostic.
        return annotation, True
    if semantics is not None and semantics.mode in {
        ScalarAnnotationSemantics.Mode.GENERIC,
        ScalarAnnotationSemantics.Mode.DTYPE,
    }:
        return annotation, True
    return _EMPTY, False


def _raw_annotations(target) -> dict[str, object]:
    if inspect.isfunction(target):
        annotations = object.__getattribute__(target, "__annotations__")
    elif inspect.isclass(target):
        annotations = type.__getattribute__(target, "__dict__").get("__annotations__", {})
    else:
        try:
            annotations = inspect.getattr_static(target, "__annotations__")
        except AttributeError:
            return {}
    if annotations is None:
        return {}
    if not _is_plain_mapping(annotations):
        raise TypeError("__annotations__ must be a plain mapping")
    return dict(annotations)


def class_local_namespace(owner: type) -> dict[str, object]:
    """Return an MRO namespace snapshot without invoking descriptors."""

    namespace: dict[str, object] = {}
    mro = type.__getattribute__(owner, "__mro__")
    for base in reversed(mro):
        namespace.update(type.__getattribute__(base, "__dict__"))
    return namespace


class SurfaceTypeResolver:
    """Resolve the closed CANNBotDSL annotation grammar once per name."""

    __slots__ = (
        "_annotations",
        "_cache",
        "_globalns",
        "_localns",
        "_policy",
    )

    def __init__(
        self,
        annotations: Mapping[str, object],
        *,
        globalns: Mapping[str, object] | None = None,
        localns: Mapping[str, object] | None = None,
        policy: AnnotationPolicy = AnnotationPolicy.FULL,
    ) -> None:
        if not _is_plain_mapping(annotations):
            raise TypeError("surface annotations must be a plain mapping")
        if globalns is not None and not _is_plain_mapping(globalns):
            raise TypeError("surface globals must be a plain mapping")
        if localns is not None and not _is_plain_mapping(localns):
            raise TypeError("surface locals must be a plain mapping")
        self._annotations = dict(annotations)
        self._globalns = globalns if globalns is not None else {}
        self._localns = {} if localns is None else dict(localns)
        self._policy = policy
        self._cache: dict[str, ResolvedSurfaceType] = {}

    @classmethod
    def for_target(
        cls,
        target,
        *,
        localns: Mapping[str, object] | None = None,
        policy: AnnotationPolicy = AnnotationPolicy.FULL,
        annotations: Mapping[str, object] | None = None,
    ) -> "SurfaceTypeResolver":
        if inspect.isfunction(target):
            globalns = object.__getattribute__(target, "__globals__")
        else:
            globalns = None
        if globalns is None:
            if inspect.isclass(target):
                module_name = type.__getattribute__(target, "__module__")
            else:
                try:
                    module_name = inspect.getattr_static(target, "__module__")
                except AttributeError:
                    module_name = None
                if not isinstance(module_name, str):
                    module_name = None
            module = sys.modules.get(module_name) if module_name else None
            globalns = types.ModuleType.__getattribute__(module, "__dict__") if module is not None else {}
        return cls(
            _raw_annotations(target) if annotations is None else annotations,
            globalns=globalns,
            localns=localns,
            policy=policy,
        )

    @property
    def policy(self) -> AnnotationPolicy:
        return self._policy

    @property
    def local_namespace(self) -> dict[str, object]:
        return dict(self._localns)

    def raw(self, name: str) -> object:
        return self._annotations.get(name, _EMPTY)

    def resolve(self, name: str) -> ResolvedSurfaceType:
        cached = self._cache.get(name)
        if cached is not None:
            return cached

        raw = self.raw(name)
        if raw is _EMPTY:
            result = ResolvedSurfaceType()
        elif not isinstance(raw, str):
            value = raw
            staging = surface_constexpr_payload(raw) is not _EMPTY
            if self._policy is AnnotationPolicy.STAGING_ONLY:
                value, staging = _select_staging_annotation(raw)
            result = ResolvedSurfaceType(
                raw=raw,
                value=value,
                staging_candidate=staging,
            )
        else:
            result = self._resolve_text(raw)
        self._cache[name] = result
        return result

    def constexpr_annotation(self, name: str) -> object:
        result = self.resolve(name)
        if result.error is not None:
            if result.staging_candidate:
                self._raise_parameter_error(name, result.error)
            return _EMPTY
        if result.value is _EMPTY:
            return _EMPTY
        if surface_constexpr_payload(result.value) is _EMPTY:
            return _EMPTY
        return result.value

    def runtime_annotation(self, name: str) -> object:
        result = self.resolve(name)
        if result.error is not None:
            if self._policy is AnnotationPolicy.STAGING_ONLY and not result.staging_candidate:
                return _EMPTY
            self._raise_parameter_error(name, result.error)
        return result.value

    def required_annotation(self, name: str, *, subject: str) -> object:
        result = self.resolve(name)
        if result.error is not None:
            raise TypeError(f"{subject} annotation cannot be resolved safely: {result.error}") from None
        if result.value is _EMPTY:
            raise TypeError(f"{subject} annotation is missing")
        return result.value

    @staticmethod
    def _raise_parameter_error(name: str, detail: str) -> typing.NoReturn:
        raise TypeError(f"parameter {name!r} annotation cannot be resolved safely: {detail}") from None

    def _resolve_text(self, text: str) -> ResolvedSurfaceType:
        try:
            node = self._parse_root(text)
        except _UnsafeAnnotation as exc:
            return ResolvedSurfaceType(raw=text, error=str(exc))

        staging_candidate = self._is_staging_syntax(node)
        try:
            if self._contains_nested_scalar_syntax(node):
                value = _ResolvedNestedScalar()
            elif self._policy is AnnotationPolicy.STAGING_ONLY:
                value = self._evaluate_staging_only(node)
            else:
                value = self._evaluate(node)
        except _UnsafeAnnotation as exc:
            return ResolvedSurfaceType(
                raw=text,
                error=str(exc),
                staging_candidate=staging_candidate,
            )
        return ResolvedSurfaceType(
            raw=text,
            value=value,
            staging_candidate=staging_candidate,
        )

    def _parse_root(self, text: str) -> ast.AST:
        current = text
        for _ in range(2):
            try:
                node = ast.parse(current, mode="eval").body
            except (SyntaxError, ValueError):
                raise _UnsafeAnnotation("invalid annotation syntax") from None
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                current = node.value
                continue
            return node
        raise _UnsafeAnnotation("nested string annotations are not supported")

    def _lookup_name(self, name: str):
        if name in self._localns:
            return self._localns[name]
        if name in self._globalns:
            return self._globalns[name]
        if name in _BUILTIN_ANNOTATION_NAMES:
            return _BUILTIN_ANNOTATION_NAMES[name]
        if name == "NoneType":
            return type(None)
        raise _UnsafeAnnotation(f"name {name!r} is not available")

    @staticmethod
    def _static_attribute(owner, name: str):
        if name.startswith("_"):
            raise _UnsafeAnnotation("private attributes are not supported")
        if isinstance(owner, types.ModuleType):
            namespace = types.ModuleType.__getattribute__(owner, "__dict__")
            if name not in namespace:
                module_name = namespace.get("__name__")
                if type(module_name) is not str:
                    module_name = "module"
                raise _UnsafeAnnotation(f"module {module_name!r} has no attribute {name!r}")
            return namespace[name]
        if inspect.isclass(owner):
            for base in type.__getattribute__(owner, "__mro__"):
                namespace = type.__getattribute__(base, "__dict__")
                if name in namespace:
                    return namespace[name]
            owner_name = type.__getattribute__(owner, "__qualname__")
            raise _UnsafeAnnotation(f"class {owner_name!r} has no attribute {name!r}")
        raise _UnsafeAnnotation(
            f"attributes on {type.__getattribute__(type(owner), '__name__')} values are not supported"
        )

    def _evaluate_reference(self, node: ast.AST):
        if isinstance(node, ast.Name):
            return self._lookup_name(node.id)
        if isinstance(node, ast.Attribute):
            owner = self._evaluate_reference(node.value)
            return self._static_attribute(owner, node.attr)
        raise _UnsafeAnnotation("annotation target must be a name or attribute")

    def _is_constexpr_syntax(self, node: ast.AST) -> bool:
        if isinstance(node, (ast.Name, ast.Attribute)):
            try:
                return surface_constexpr_payload(self._evaluate_reference(node)) is not _EMPTY
            except _UnsafeAnnotation:
                return False
        if not isinstance(node, ast.Subscript):
            return False
        try:
            target = self._evaluate_reference(node.value)
        except _UnsafeAnnotation:
            return False
        if target is Constexpr:
            return True
        if target is typing.Annotated:
            items = self._subscript_items(node.slice)
            return bool(items) and self._is_constexpr_syntax(items[0])
        return False

    def _reference_is_scalar_staging(self, node: ast.AST) -> bool:
        try:
            value = self._evaluate_reference(node)
        except _UnsafeAnnotation:
            return False
        try:
            semantics = classify_scalar_annotation("<text>", value)
        except TypeError:
            return True
        return semantics is not None and semantics.mode in {
            ScalarAnnotationSemantics.Mode.GENERIC,
            ScalarAnnotationSemantics.Mode.DTYPE,
        }

    def _is_direct_scalar_syntax(self, node: ast.AST) -> bool:
        if isinstance(node, (ast.Name, ast.Attribute)):
            return self._reference_is_scalar_staging(node)
        if not isinstance(node, ast.Subscript):
            return False
        try:
            target = self._evaluate_reference(node.value)
        except _UnsafeAnnotation:
            return False
        items = self._subscript_items(node.slice)
        if target is typing.Annotated:
            return bool(items) and self._is_direct_scalar_syntax(items[0])
        return False

    def _contains_scalar_syntax(self, node: ast.AST) -> bool:
        if self._is_direct_scalar_syntax(node):
            return True
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.BitOr):
            return self._contains_scalar_syntax(node.left) or self._contains_scalar_syntax(node.right)
        if not isinstance(node, ast.Subscript):
            return False
        try:
            target = self._evaluate_reference(node.value)
        except _UnsafeAnnotation:
            target = None
        items = self._subscript_items(node.slice)
        if target is Constexpr:
            return False
        # CArray[dtype, N] is an existing closed datastruct-field grammar, not
        # a general-purpose parameter container.  Let the ordinary safe
        # evaluator preserve it; datastruct validation remains authoritative
        # for its element and extent rules.
        from cannbotdsl.types.datastruct import CArray

        if target is CArray:
            return False
        if target is typing.Annotated:
            return bool(items) and self._contains_scalar_syntax(items[0])
        if self._reference_is_scalar_staging(node.value):
            return True
        return any(self._contains_scalar_syntax(item) for item in items)

    def _contains_nested_scalar_syntax(self, node: ast.AST) -> bool:
        if self._is_direct_scalar_syntax(node):
            return False
        return self._contains_scalar_syntax(node)

    def _is_staging_syntax(self, node: ast.AST) -> bool:
        if self._is_constexpr_syntax(node):
            return True
        if self._is_direct_scalar_syntax(node):
            return True
        return self._contains_nested_scalar_syntax(node)

    def _evaluate_staging_only(self, node: ast.AST):
        if isinstance(node, (ast.Name, ast.Attribute)):
            value = self._evaluate_reference(node)
            selected, _ = _select_staging_annotation(value)
            return selected
        if not isinstance(node, ast.Subscript):
            return _EMPTY
        try:
            target = self._evaluate_reference(node.value)
        except _UnsafeAnnotation:
            return _EMPTY
        items = self._subscript_items(node.slice)
        if target is typing.Annotated:
            if not items:
                raise _UnsafeAnnotation("Annotated requires a base annotation")
            if len(items) < 2:
                raise _UnsafeAnnotation("Annotated expects a type and at least one metadata value")
            return self._evaluate_staging_only(items[0])
        if target is not Constexpr:
            return _EMPTY
        if len(items) != 1:
            raise _UnsafeAnnotation("Constexpr expects exactly one type argument")
        payload = self._evaluate(items[0])
        return _ResolvedConstexpr(payload)

    @staticmethod
    def _subscript_items(node: ast.AST) -> tuple[ast.AST, ...]:
        if isinstance(node, ast.Tuple):
            return tuple(node.elts)
        return (node,)

    def _evaluate(self, node: ast.AST):
        if isinstance(node, (ast.Name, ast.Attribute)):
            return self._evaluate_reference(node)
        if isinstance(node, ast.Constant):
            if node.value is None or type(node.value) in {
                bool,
                int,
                float,
                str,
                bytes,
            }:
                return node.value
            raise _UnsafeAnnotation(f"literal {type(node.value).__name__} is not supported")
        if isinstance(node, ast.Subscript):
            target = self._evaluate_reference(node.value)
            items = self._subscript_items(node.slice)
            return self._apply_subscript(target, items)
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.BitOr):
            lhs = self._evaluate(node.left)
            rhs = self._evaluate(node.right)
            members: list[object] = []
            for value in (lhs, rhs):
                if value is None:
                    value = type(None)
                if type(value) is _ResolvedUnion:
                    members.extend(value.members)
                else:
                    members.append(value)
            return _ResolvedUnion(tuple(members))
        if isinstance(node, ast.Call):
            if (
                isinstance(node.func, ast.Name)
                and node.func.id == "type"
                and self._evaluate_reference(node.func) is type
                and len(node.args) == 1
                and not node.keywords
                and isinstance(node.args[0], ast.Constant)
                and node.args[0].value is None
            ):
                return type(None)
            raise _UnsafeAnnotation("function calls are not allowed")
        if isinstance(
            node,
            (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp),
        ):
            raise _UnsafeAnnotation("comprehensions are not allowed")
        raise _UnsafeAnnotation(f"{type(node).__name__} expressions are not supported")

    def _apply_subscript(self, target, nodes: tuple[ast.AST, ...]):
        if target is Constexpr:
            if len(nodes) != 1:
                raise _UnsafeAnnotation("Constexpr expects exactly one type argument")
            payload = self._evaluate(nodes[0])
            return _ResolvedConstexpr(payload)

        if target is typing.Annotated:
            if len(nodes) < 2:
                raise _UnsafeAnnotation("Annotated expects a type and at least one metadata value")
            # Metadata does not affect runtime ABI semantics.  Leaving it
            # unevaluated also ensures a call/descriptor placed in metadata
            # cannot execute during compilation.
            return self._evaluate(nodes[0])

        if target is typing.Optional:
            if len(nodes) != 1:
                raise _UnsafeAnnotation("Optional expects exactly one type argument")
            value = self._evaluate(nodes[0])
            return _ResolvedUnion((value, type(None)))

        if target is typing.Union:
            if len(nodes) < 1:
                raise _UnsafeAnnotation("Union expects at least one type argument")
            values = tuple(type(None) if value is None else value for value in (self._evaluate(node) for node in nodes))
            return _ResolvedUnion(values)

        # Lazy import avoids a datastruct -> surface -> datastruct cycle.
        from cannbotdsl.types.datastruct import CArray, StructRef

        if target is CArray:
            if len(nodes) != 2:
                raise _UnsafeAnnotation("CArray expects a dtype and a length")
            values = tuple(self._evaluate(node) for node in nodes)
            try:
                return CArray[values]
            except (TypeError, ValueError) as exc:
                raise _UnsafeAnnotation(str(exc)) from None

        if target is StructRef:
            if len(nodes) != 1:
                raise _UnsafeAnnotation("StructRef expects one @datastruct type")
            value = self._evaluate(nodes[0])
            try:
                return StructRef[value]
            except (TypeError, ValueError) as exc:
                raise _UnsafeAnnotation(str(exc)) from None

        raise _UnsafeAnnotation(
            "subscription is only supported for Constexpr, Annotated, "
            "Optional, Union, CArray, and StructRef"
        )


@dataclass(frozen=True, slots=True)
class SurfaceSignature:
    """One authoritative signature/receiver/annotation boundary."""

    function: Callable[..., object]
    signature: inspect.Signature
    resolver: SurfaceTypeResolver
    receiver_parameter: str | None = None
    receiver_label: str | None = None
    descriptor_bound: bool = False

    @classmethod
    def from_callable(
        cls,
        fn: Callable[..., object],
        *,
        localns: Mapping[str, object] | None = None,
        annotation_policy: AnnotationPolicy = AnnotationPolicy.FULL,
        signature: inspect.Signature | None = None,
    ) -> "SurfaceSignature":
        return cls(
            fn,
            inspect.signature(fn) if signature is None else signature,
            SurfaceTypeResolver.for_target(
                fn,
                localns=localns,
                policy=annotation_policy,
            ),
        )

    @property
    def annotation_policy(self) -> AnnotationPolicy:
        return self.resolver.policy

    @property
    def has_receiver(self) -> bool:
        return self.descriptor_bound

    @property
    def public_signature(self) -> inspect.Signature:
        if self.receiver_parameter is None:
            return self.signature
        parameters = tuple(self.signature.parameters.values())
        return self.signature.replace(parameters=parameters[1:])

    def with_local_namespace(self, localns: Mapping[str, object]) -> "SurfaceSignature":
        if self.receiver_parameter is not None:
            raise RuntimeError("cannot replace locals after receiver binding")
        return SurfaceSignature.from_callable(
            self.function,
            localns=localns,
            annotation_policy=self.annotation_policy,
            signature=self.signature,
        )

    def bind_receiver(self, *, label: str) -> "SurfaceSignature":
        if self.receiver_parameter is not None:
            return self
        parameters = tuple(self.signature.parameters.values())
        if not parameters:
            raise TypeError(f"{label} must declare a receiver parameter")
        receiver = parameters[0]
        if receiver.kind not in {
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        }:
            raise TypeError(f"{label} receiver must be the first positional parameter")
        return replace(
            self,
            receiver_parameter=receiver.name,
            receiver_label=label,
            descriptor_bound=True,
        )

    def retarget_without_receiver(
        self,
        fn: Callable[..., object],
    ) -> "SurfaceSignature":
        """Retarget a bound entry to its synthetic receiver-free wrapper.

        The wrapper is defined in the kernel-class implementation module, not
        beside the user's entry method.  Keep the original resolver so textual
        annotations continue to use the definition-time globals/class locals,
        and so binding and lowering share one cached resolution result.
        """

        if self.receiver_parameter is None:
            raise RuntimeError("only a bound surface can drop its receiver")
        return replace(
            self,
            function=fn,
            signature=self.public_signature,
            receiver_parameter=None,
            receiver_label=None,
        )

    def is_receiver(self, index: int, parameter: inspect.Parameter) -> bool:
        return self.receiver_parameter is not None and index == 0 and parameter.name == self.receiver_parameter

    def bind(self, args: tuple, kwargs: dict) -> inspect.BoundArguments:
        return self.signature.bind(*args, **kwargs)

    def bind_staged(self, args: tuple, kwargs: dict) -> _StagedBinding:
        """Bind and classify arguments at a host or materialized boundary."""

        bound = self.bind(args, kwargs)
        supplied_names = frozenset(bound.arguments)
        bound.apply_defaults()
        return self.classify_bound(bound, supplied_names=supplied_names)

    def classify_bound(
        self,
        bound: inspect.BoundArguments,
        *,
        supplied_names: frozenset[str] | None = None,
    ) -> _StagedBinding:
        """Classify an existing ``BoundArguments`` using this surface."""

        if bound.signature != self.signature:
            raise TypeError("bound arguments belong to a different surface signature")
        if supplied_names is None:
            supplied_names = frozenset(bound.arguments)
        bound.apply_defaults()
        classified: list[_StagedParameter] = []
        for index, parameter in enumerate(self.signature.parameters.values()):
            if self.is_receiver(index, parameter):
                classified.append(
                    _StagedParameter(
                        parameter,
                        _EMPTY,
                        None,
                        _StagedRole.RECEIVER,
                    )
                )
                continue
            annotation = self.resolver.runtime_annotation(parameter.name)
            constexpr = surface_constexpr_payload(annotation)
            semantics = classify_scalar_annotation(parameter.name, annotation)
            value = bound.arguments[parameter.name]
            if constexpr is not _EMPTY:
                role = _StagedRole.CONSTEXPR
                validate_constexpr_value(parameter.name, annotation, value)
            elif value is None and is_tensor_annotation(annotation):
                role = _StagedRole.ABSENT
            else:
                role = _StagedRole.RUNTIME
            classified.append(
                _StagedParameter(parameter, annotation, semantics, role)
            )
        return _StagedBinding(
            bound,
            supplied_names,
            self.receiver_parameter,
            tuple(classified),
        )

    def resolved_return_annotation(self) -> ResolvedSurfaceType:
        """Resolve the return annotation through the non-executing grammar."""

        result = self.resolver.resolve("return")
        if result.is_present or self.signature.return_annotation is _EMPTY:
            return result
        annotation = self.signature.return_annotation
        if not isinstance(annotation, str):
            return ResolvedSurfaceType(raw=annotation, value=annotation)
        resolver = SurfaceTypeResolver(
            {"return": annotation},
            globalns=self.resolver._globalns,
            localns=self.resolver.local_namespace,
            policy=AnnotationPolicy.FULL,
        )
        return resolver.resolve("return")

    def validate_void_return_annotation(self, *, path: str | None = None) -> None:
        result = self.resolved_return_annotation()
        if not result.is_present:
            return
        if result.error is None and (
            result.value is None or result.value is type(None)
        ):
            return
        detail = (
            f"cannot be resolved safely: {result.error}"
            if result.error is not None
            else f"declares {surface_annotation_name(result.value)}"
        )
        target = path or getattr(self.function, "__qualname__", "entry")
        raise CANNBotTypeError(
            ST102_NON_VOID_ENTRY_RETURN,
            f"Entry {target!r} must return None, but its return annotation {detail}.",
            phase="staging",
            path=target,
            hint="Remove the value return/annotation; only nested @jit and inline kernels may return values.",
        )


__all__ = [
    "AnnotationPolicy",
    "ResolvedSurfaceType",
    "SurfaceSignature",
    "SurfaceTypeResolver",
    "class_local_namespace",
    "is_tensor_annotation",
    "is_tensor_list_annotation",
    "surface_annotation_name",
    "surface_constexpr_payload",
    "surface_union_members",
    "validate_constexpr_value",
    "unwrap_surface_annotation",
]
