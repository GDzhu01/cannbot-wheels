# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Normalize public specs into canonical compiler contracts."""

from __future__ import annotations

from cannbotdsl.core.contracts.elements import element_for_dtype
from cannbotdsl.core.contracts.model import (
    BinaryExpr,
    ConstantExpr,
    DimensionContract,
    DimensionExpr,
    ShapeExpr,
    TemplateLayout,
    TensorContract,
    TensorListContract,
)
from cannbotdsl.core.contracts.storage import fractal_nz_storage_encoding
from cannbotdsl.lang.spec import Dim, TensorListSpec, TensorSpec, _DimExpr


class ContractNormalizer:
    def __init__(self) -> None:
        self._dimensions: dict[str, DimensionContract] = {}
        self._referenced: set[str] = set()
        self._directly_bound: set[str] = set()

    def _observe_dim(self, dim: Dim, *, direct: bool) -> DimensionExpr:
        candidate = DimensionContract(
            dim.name, dim.min, dim.max, dim.multiple_of
        )
        previous = self._dimensions.setdefault(dim.name, candidate)
        if previous != candidate:
            raise ValueError(
                f"conflicting declarations for Dim {dim.name!r}: "
                f"(min={previous.minimum}, max={previous.maximum}, "
                f"multiple_of={previous.multiple_of}) versus "
                f"(min={candidate.minimum}, max={candidate.maximum}, "
                f"multiple_of={candidate.multiple_of})"
            )
        self._referenced.add(dim.name)
        if direct:
            self._directly_bound.add(dim.name)
        return DimensionExpr(dim.name)

    def expression(self, value, *, direct: bool = False) -> ShapeExpr:
        if isinstance(value, int):
            return ConstantExpr(value)
        if isinstance(value, Dim):
            return self._observe_dim(value, direct=direct)
        if isinstance(value, _DimExpr):
            return BinaryExpr(
                value.op,
                self.expression(value.lhs),
                self.expression(value.rhs),
            )
        raise TypeError(f"unsupported tensor dimension expression {value!r}")

    def tensor(self, spec: TensorSpec) -> TensorContract:
        info = element_for_dtype(spec.dtype)
        shape = tuple(
            self.expression(value, direct=isinstance(value, Dim))
            for value in spec.shape
        )
        stride = tuple(
            self.expression(value, direct=isinstance(value, Dim))
            for value in spec.stride
        )
        storage_encoding = None
        if spec.storage_format == "nz":
            storage_encoding = fractal_nz_storage_encoding(
                shape,
                element=info.tag,
            )
        return TensorContract(
            element=info.tag,
            shape=shape,
            stride=stride,
            storage_encoding=storage_encoding,
        )

    def tensor_list(self, spec: TensorListSpec) -> TensorListContract:
        # TensorList element dimensions live in a deliberately separate
        # binding scope.  A same-named Dim used by a normal Tensor, by the list
        # length, or by another TensorList therefore cannot couple element
        # layouts across those domains.
        element_normalizer = ContractNormalizer()
        element = element_normalizer.tensor(spec.element)
        return TensorListContract(
            element_type=element.element,
            element_rank=element.rank,
            address_space=element.address_space,
            length=self.expression(
                spec.length,
                direct=isinstance(spec.length, Dim),
            ),
            layout=TemplateLayout(
                element_dimensions=element_normalizer.dimensions(
                    tensor_list_element=True
                ),
                shape_expressions=element.shape,
                stride_expressions=element.stride,
            ),
        )

    def dimensions(
        self, *, tensor_list_element: bool = False
    ) -> tuple[DimensionContract, ...]:
        unbound = sorted(self._referenced - self._directly_bound)
        if unbound:
            rendered = ", ".join(repr(name) for name in unbound)
            if tensor_list_element:
                raise ValueError(
                    "every TensorList element Dim must appear directly in at "
                    "least one complete shape/stride slot; only derived "
                    f"occurrences were found for {rendered}"
                )
            raise ValueError(
                "every Dim must appear directly in at least one "
                "shape/stride/TensorList-length slot; "
                f"only derived occurrences were found for {rendered}"
            )
        return tuple(self._dimensions[name] for name in sorted(self._dimensions))


def static_tensor_contract(snapshot) -> TensorContract:
    from cannbotdsl.core.contracts.elements import element_for_dlpack

    info = element_for_dlpack(
        snapshot.dtype_code,
        snapshot.dtype_bits,
        snapshot.dtype_lanes,
    )
    shape = tuple(int(value) for value in snapshot.shape)
    stride = tuple(int(value) for value in snapshot.stride)
    if len(shape) != len(stride):
        raise ValueError(
            f"provider tensor shape rank {len(shape)} does not match stride rank {len(stride)}"
        )
    for field, values in (("shape", shape), ("stride", stride)):
        for index, value in enumerate(values):
            if value < 0:
                raise ValueError(
                    f"provider tensor {field}[{index}] must be non-negative, got {value}"
                )
            if value > (1 << 63) - 1:
                raise ValueError(
                    f"provider tensor {field}[{index}]={value} is outside signed int64 range"
                )
    return TensorContract(
        element=info.tag,
        shape=tuple(ConstantExpr(value) for value in shape),
        stride=tuple(ConstantExpr(value) for value in stride),
        storage_encoding=(
            None
            if snapshot.physical_layout is None
            else snapshot.physical_layout.to_contract()
        ),
    )


def validate_struct_ref_snapshot(snapshot, schema, *, path: str) -> None:
    """Validate the exact DLPack carrier required by ``StructRef``."""

    from cannbotdsl.core.contracts.elements import element_for_dlpack

    info = element_for_dlpack(
        snapshot.dtype_code,
        snapshot.dtype_bits,
        snapshot.dtype_lanes,
    )
    if info.tag != "u8":
        raise TypeError(
            f"{path} StructRef storage must have dtype uint8, got {info.dtype.name}"
        )
    shape = tuple(int(value) for value in snapshot.shape)
    stride = tuple(int(value) for value in snapshot.stride)
    if len(shape) != 1:
        raise ValueError(
            f"{path} StructRef storage must be rank-1, got rank {len(shape)}"
        )
    if len(stride) != 1:
        raise ValueError(
            f"{path} StructRef storage stride rank must be 1, got {len(stride)}"
        )
    if shape[0] != schema.size:
        raise ValueError(
            f"{path} StructRef storage length must equal sizeof({schema.c_name}) "
            f"({schema.size}), got {shape[0]}"
        )
    if stride[0] != 1:
        raise ValueError(
            f"{path} StructRef storage must be contiguous with stride 1, "
            f"got {stride[0]}"
        )
    if snapshot.byte_offset != 0:
        raise ValueError(
            f"{path} StructRef storage must have DLPack byte_offset 0, "
            f"got {snapshot.byte_offset}"
        )
    if snapshot.data == 0:
        raise ValueError(f"{path} StructRef storage has a null device address")
    if snapshot.data % schema.alignment:
        raise ValueError(
            f"{path} StructRef device address must be aligned to "
            f"{schema.alignment} bytes"
        )


def format_expression(expression: ShapeExpr) -> str:
    if isinstance(expression, ConstantExpr):
        return str(expression.value)
    if isinstance(expression, DimensionExpr):
        return expression.name
    operator = {
        "add": "+",
        "sub": "-",
        "mul": "*",
        "floordiv": "//",
    }[expression.op]
    return f"({format_expression(expression.lhs)} {operator} {format_expression(expression.rhs)})"


__all__ = [
    "ContractNormalizer",
    "format_expression",
    "static_tensor_contract",
    "validate_struct_ref_snapshot",
]
