# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Python-signature validation for immutable call contracts.

Provider exchange, device/dtype/layout guards, scalar conversion, and binary
buffer size checks belong to the native :class:`HostCallPlan`.
"""

from __future__ import annotations

import inspect

from cannbotdsl.core.contracts.codec import (
    literal_to_python,
    validate_call_contract,
)
from cannbotdsl.core.contracts.elements import element_for_tag
from cannbotdsl.core.contracts.model import (
    ScalarContract,
    StructRefContract,
    TensorContract,
    TensorListContract,
)


def _annotation_for_argument(argument):
    if isinstance(argument, TensorContract):
        from cannbotdsl.types import Tensor

        return Tensor
    if isinstance(argument, TensorListContract):
        from cannbotdsl.types.tensor_list import TensorList

        return TensorList
    if isinstance(argument, ScalarContract):
        return element_for_tag(argument.element).runtime_annotation
    if isinstance(argument, StructRefContract):
        from cannbotdsl.types.datastruct import _struct_ref_from_schema

        return _struct_ref_from_schema(
            argument.schema,
            address_space=argument.address_space,
            access=argument.access,
        )
    return inspect.Parameter.empty


def runtime_signature(contract) -> inspect.Signature:
    """Return the public runtime-only signature persisted by *contract*."""

    parameters = []
    for parameter in contract.runtime_parameters:
        default = inspect.Parameter.empty
        if parameter.has_runtime_default:
            default = literal_to_python(parameter.runtime_default)
        parameters.append(
            inspect.Parameter(
                parameter.name,
                getattr(inspect.Parameter, parameter.kind),
                default=default,
                annotation=_annotation_for_argument(parameter.argument),
            )
        )
    return inspect.Signature(parameters, return_annotation=None)


class ValidationPlan:
    """Pre-resolved Python binding plan for runtime contract parameters."""

    __slots__ = (
        "contract",
        "signature",
        "_runtime_parameter_names",
    )

    def __init__(self, contract):
        self.contract = validate_call_contract(contract)
        self.signature = runtime_signature(self.contract)
        self._runtime_parameter_names = tuple(
            parameter.name for parameter in self.contract.runtime_parameters
        )

    def bind(self, args, kwargs):
        bound = self.signature.bind(*args, **kwargs)
        bound.apply_defaults()
        return bound

    def validate(self, bound) -> tuple[object, ...]:
        """Return values in runtime-parameter order.

        Native code owns tensor and scalar physical guards.  Each persisted
        runtime parameter maps to exactly one host slot.
        """

        return tuple(
            bound.arguments[name] for name in self._runtime_parameter_names
        )


__all__ = ["ValidationPlan", "runtime_signature"]
