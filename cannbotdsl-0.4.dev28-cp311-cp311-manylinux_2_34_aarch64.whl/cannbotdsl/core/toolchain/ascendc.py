# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""AscendC source -> shared library compilation via bisheng."""

import logging
import os
import platform
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

from cannbotdsl.core.utils.env import _getenv_binary_bool
from cannbotdsl.core.utils.timer import timer as _timer

_LOG = logging.getLogger(__name__)
_DEFAULT_NPU_ARCH = "dav-3510"
_NPU_ARCH_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]*$")
L0C2L1_ABI_LEGACY_VOID_21 = "legacy_void_21"
L0C2L1_ABI_TYPED_18 = "typed_18"


@dataclass(frozen=True)
class BishengResolution:
    """Resolved external compiler and the candidates considered."""

    path: Optional[str]
    ascend_home: Optional[str]
    checked: Tuple[str, ...]


def _host_sdk_directory(machine: Optional[str] = None) -> Optional[str]:
    """Map the Python host architecture to CANN's SDK directory name."""

    normalized = (machine or platform.machine()).strip().lower()
    if normalized in {"x86_64", "amd64"}:
        return "x86_64-linux"
    if normalized in {"aarch64", "arm64"}:
        return "aarch64-linux"
    return None


def _cann_release_version(
    ascend_home: str,
) -> Tuple[Optional[str], Tuple[str, ...]]:
    """Read the active CANN release without invoking an external compiler."""

    host_dir = _host_sdk_directory()
    candidates = []
    if host_dir:
        candidates.append(
            (
                os.path.join(
                    ascend_home,
                    host_dir,
                    "ascend_toolkit_install.info",
                ),
                "version",
            )
        )
    candidates.append(
        (os.path.join(ascend_home, "compiler", "version.info"), "Version")
    )

    checked = []
    for path, key in candidates:
        checked.append(path)
        try:
            lines = Path(path).read_text(
                encoding="utf-8", errors="replace"
            ).splitlines()
        except OSError:
            continue
        for line in lines:
            name, separator, value = line.partition("=")
            if separator and name.strip() == key and value.strip():
                return value.strip(), tuple(checked)
    return None, tuple(checked)


def resolve_l0c2l1_abi(
    ascend_home: Optional[str], *, required: bool
) -> str:
    """Map a supported CANN release to its dav-3510 L0C-to-L1 ABI."""

    if not ascend_home:
        if not required:
            return L0C2L1_ABI_TYPED_18
        raise RuntimeError(
            "Cannot select the dav-3510 L0C-to-L1 ABI: "
            "ASCEND_HOME_PATH is unset; supported releases are "
            "CANN 9.1.x and 9.2.x"
        )

    version, checked = _cann_release_version(ascend_home)
    if version:
        try:
            release = tuple(int(field) for field in version.split(".")[:2])
        except ValueError:
            release = ()
        if release == (9, 1):
            return L0C2L1_ABI_LEGACY_VOID_21
        if release == (9, 2):
            return L0C2L1_ABI_TYPED_18

    detail = (
        f"discovered version {version!r}"
        if version
        else f"missing release metadata in {checked!r}"
    )
    raise RuntimeError(
        "Cannot select the dav-3510 L0C-to-L1 ABI for "
        f"ASCEND_HOME_PATH={ascend_home!r}: {detail}; supported releases "
        "are CANN 9.1.x and 9.2.x"
    )


def _detect_npu_arch() -> str:
    """Best-effort runtime SoC query; empty when CANN is unavailable.

    Imported lazily so that toolchain resolution stays importable on hosts
    without CANN libraries.
    """

    try:
        from cannbotdsl.ops.info import _detect_npu_arch as detect

        return detect()
    except Exception as error:
        _LOG.debug("runtime NPU arch detection failed: %s", error)
        return ""


def resolve_npu_arch(value: Optional[str] = None) -> str:
    """Return and validate the Bisheng ``--npu-arch`` value.

    Priority: explicit ``value`` argument, ``CANNBOTDSL_NPU_ARCH``, a runtime
    SoC query, then ``dav-3510``.  The environment variable wins over the
    query so cross-compilation setups stay deterministic.
    """

    arch = value or os.environ.get("CANNBOTDSL_NPU_ARCH") or _detect_npu_arch() or _DEFAULT_NPU_ARCH
    if not _NPU_ARCH_PATTERN.fullmatch(arch):
        raise ValueError(
            f"CANNBOTDSL_NPU_ARCH must contain only letters, digits, '.', '_' or '-'; got {arch!r}"
        )
    return arch


def resolve_bisheng(*, required: bool = True) -> BishengResolution:
    """Resolve Bisheng for both compilation and cache-key computation.

    Search order is an explicit CANNBotDSL override, the architecture-specific
    locations below ``ASCEND_HOME_PATH``, the toolchain-generic locations,
    then ``PATH``. The function is deliberately side-effect free and does not
    alter process-wide loader paths.
    """

    ascend_home_value = os.environ.get("ASCEND_HOME_PATH")
    ascend_home = (
        os.path.realpath(os.path.expanduser(ascend_home_value))
        if ascend_home_value
        else None
    )
    override = os.environ.get("CANNBOTDSL_BISHENG_PATH") or os.environ.get(
        "CANNBOTDSL_BISHENG"
    )
    candidates = []
    checked = []

    if override:
        candidates.append(
            (
                "CANNBOTDSL_BISHENG_PATH/CANNBOTDSL_BISHENG",
                os.path.realpath(os.path.expanduser(override)),
            )
        )
    else:
        checked.append("CANNBOTDSL_BISHENG_PATH/CANNBOTDSL_BISHENG: <unset>")

    if ascend_home:
        host_dir = _host_sdk_directory()
        if host_dir:
            candidates.extend(
                (
                    (
                        f"ASCEND_HOME_PATH {host_dir} ccec compiler",
                        os.path.join(
                            ascend_home, host_dir, "ccec_compiler", "bin", "bisheng"
                        ),
                    ),
                    (
                        f"ASCEND_HOME_PATH {host_dir} bin",
                        os.path.join(ascend_home, host_dir, "bin", "bisheng"),
                    ),
                )
            )
        else:
            checked.append(
                f"ASCEND_HOME_PATH host bin: unsupported host {platform.machine()!r}"
            )
        candidates.extend(
            (
                (
                    "ASCEND_HOME_PATH bin",
                    os.path.join(ascend_home, "bin", "bisheng"),
                ),
                (
                    "ASCEND_HOME_PATH compiler",
                    os.path.join(ascend_home, "compiler", "bin", "bisheng"),
                ),
                (
                    "ASCEND_HOME_PATH tools compiler",
                    os.path.join(
                        ascend_home, "tools", "bisheng_compiler", "bin", "bisheng"
                    ),
                ),
            )
        )
    else:
        checked.append("ASCEND_HOME_PATH: <unset>")

    seen = set()
    for label, candidate in candidates:
        candidate = os.path.abspath(candidate)
        if candidate in seen:
            continue
        seen.add(candidate)
        checked.append(f"{label}: {candidate}")
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return BishengResolution(candidate, ascend_home, tuple(checked))

    path_candidate = shutil.which("bisheng")
    checked.append(
        f"PATH bisheng: {path_candidate}"
        if path_candidate
        else "PATH bisheng: <not found>"
    )
    if path_candidate:
        return BishengResolution(
            os.path.realpath(path_candidate), ascend_home, tuple(checked)
        )

    resolution = BishengResolution(None, ascend_home, tuple(checked))
    if required:
        searched = "\n".join(f"  - {item}" for item in resolution.checked)
        raise RuntimeError(
            "bisheng compiler was not found. Checked:\n"
            f"{searched}\n"
            "Set CANNBOTDSL_BISHENG_PATH, configure ASCEND_HOME_PATH, or add "
            "bisheng to PATH. MLIR transformation and AscendC translation do "
            "not require CANN; only native kernel compilation does."
        )
    return resolution


def _run_subprocess(cmd, *, input=None, env=None, check=False):
    """Run a subprocess with proper Ctrl-C (SIGINT) handling.

    ``subprocess.run(capture_output=True)`` can swallow KeyboardInterrupt
    while waiting on pipe reads.  Using ``Popen`` directly lets us kill
    the child and re-raise immediately.
    """
    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    try:
        stdout, stderr = proc.communicate(
            input=input.encode() if isinstance(input, str) else input
        )
    except KeyboardInterrupt:
        proc.kill()
        proc.wait()
        raise
    stdout = stdout.decode() if stdout else ""
    stderr = stderr.decode() if stderr else ""
    if check and proc.returncode != 0:
        raise subprocess.CalledProcessError(
            proc.returncode, cmd, output=stdout, stderr=stderr
        )
    return subprocess.CompletedProcess(
        cmd, proc.returncode, stdout=stdout, stderr=stderr
    )


class AscendCCompiler:
    """Compile generated AscendC source into a shared library."""

    def __init__(
        self,
        *,
        project_root=None,
        npu_arch: Optional[str] = None,
        barall: Optional[bool] = None,
    ):
        # Retain ``project_root`` for source compatibility. A wheel must not
        # derive loader paths from either the repository or its install tree.
        self.project_root = project_root
        self.npu_arch = resolve_npu_arch(npu_arch)
        self.barall = (
            _getenv_binary_bool("CANNBOTDSL_BARALL")
            if barall is None
            else barall
        )

    def _get_env(self):
        return os.environ.copy()

    @_timer("compile:compile_asc_to_so")
    def compile_ascendc_to_so(
        self,
        c_code: str,
        *,
        output_path: Optional[str] = None,
        keep_object: bool = False,
    ) -> str:
        """Compile AscendC C++ source directly to a shared library (.so).

        This method never deletes the .so it produces — the caller owns
        the returned file. The intermediate .asc
        and (by default) .o are cleaned up.

        :param output_path: If set, the .so is written directly to this path
            and the tempdir is cleaned up. If None, the .so is left under
            ``tempfile.mkdtemp(prefix='cannbotdsl_aot_')`` and the caller is
            responsible for unlinking it (and optionally rmtree-ing its
            parent dir whose basename starts with ``cannbotdsl_aot_``).
        :param keep_object: If True, keep the intermediate ``kernel.o`` next
            to the .so for AOT debugging. Default False.

        Raises :class:`RuntimeError` only when the compile stage is entered and
        no compiler can be resolved.
        """
        resolution = resolve_bisheng()
        return self._compile_and_link(
            c_code,
            resolution.path,
            resolution.ascend_home,
            output_path=output_path,
            keep_object=keep_object,
        )

    def _compile_and_link(
        self,
        c_code,
        bisheng,
        ascend_home,
        *,
        output_path: Optional[str] = None,
        keep_object: bool = False,
    ):
        """Compile AscendC source to .o, then link to .so via bisheng."""
        workdir = tempfile.mkdtemp(prefix="cannbotdsl_aot_")
        asc_path = os.path.join(workdir, "kernel.asc")
        obj_path = os.path.join(workdir, "kernel.o")
        # When output_path is set, link directly there and rmtree workdir
        # afterwards; otherwise leave .so inside workdir for the caller.
        intermediate_so = os.path.join(workdir, "kernel.so")
        final_so = output_path if output_path is not None else intermediate_so

        with open(asc_path, "w", encoding="utf-8") as f:
            f.write(c_code)

        try:
            env = self._get_env()
            if ascend_home:
                env["ASCEND_HOME_PATH"] = ascend_home

            # Step 1: Compile .asc -> .o
            from cannbotdsl.core.utils.timer import time_block as _time_block

            with _time_block("compile:bisheng_asc_to_obj"):
                compile_command = [
                    bisheng,
                    "-fPIC",
                    f"--npu-arch={self.npu_arch}",
                    "-c",
                    "-O3",
                    "-x",
                    "asc",
                ]
                if self.barall:
                    compile_command.extend(
                        ["-mllvm", "-cce-aicore-sync-bar-all=true"]
                    )
                compile_command.extend([asc_path, "-o", obj_path])
                _run_subprocess(
                    compile_command,
                    check=True,
                    env=env,
                )
            _LOG.debug("AscendC compiled: %s", obj_path)

            # Step 2: Link .o -> .so
            with _time_block("compile:bisheng_obj_to_so"):
                _run_subprocess(
                    [
                        bisheng,
                        "-shared",
                        "-fPIC",
                        f"--npu-arch={self.npu_arch}",
                        "-o",
                        final_so,
                        obj_path,
                        # Host-side scalar fmod/minnum/maxnum lower to libm.
                        # Device-side variants use AICore intrinsics and do
                        # not leave host-library references.
                        "-lm",
                    ],
                    check=True,
                    env=env,
                )
            _LOG.debug("AscendC linked: %s", final_so)
            return final_so
        except subprocess.CalledProcessError as e:
            failed_cmd = " ".join(e.cmd) if isinstance(e.cmd, list) else str(e.cmd)
            error_msg = f"bisheng compilation failed!\nCOMMAND:\n{failed_cmd}\nSTDOUT:\n{e.stdout}\nSTDERR:\n{e.stderr}"
            _LOG.error(error_msg)
            # Clean up workdir on failure; caller never sees a partial .so.
            shutil.rmtree(workdir, ignore_errors=True)
            # An explicit output_path lives outside workdir, so a partially
            # linked .so there would survive the rmtree above.
            if output_path is not None and os.path.exists(output_path):
                try:
                    os.unlink(output_path)
                except OSError:
                    pass
            raise RuntimeError(error_msg) from e
        finally:
            if os.path.exists(asc_path):
                os.unlink(asc_path)
            if not keep_object and os.path.exists(obj_path):
                os.unlink(obj_path)
            # If output_path was provided, the final .so lives outside workdir;
            # the workdir itself is no longer needed.
            if output_path is not None and os.path.isdir(workdir):
                shutil.rmtree(workdir, ignore_errors=True)
