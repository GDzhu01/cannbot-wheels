# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Hygienic AST lowering driven only by an immutable :class:`FrontendPlan`."""

from __future__ import annotations

import ast
from dataclasses import dataclass

from cannbotdsl.core.frontend.analysis import (
    ExpressionPlan,
    FrontendPlan,
    RegionKind,
    RegionPlan,
)
from cannbotdsl.core.frontend.source import SourceUnit
from cannbotdsl.core.frontend.symbols import MarkerKind


def _node_key(node: ast.AST) -> tuple[int, int, int, int]:
    return (
        int(getattr(node, "lineno", 0)),
        int(getattr(node, "col_offset", 0)),
        int(getattr(node, "end_lineno", 0)),
        int(getattr(node, "end_col_offset", 0)),
    )


class NameAllocator:
    """Allocate deterministic names outside the complete user namespace."""

    __slots__ = ("_used", "_next")

    def __init__(
        self,
        target: ast.AST,
        *,
        reserved_names: set[str] | None = None,
    ) -> None:
        used = set(reserved_names) if reserved_names is not None else set()
        if reserved_names is None:
            for node in ast.walk(target):
                if isinstance(node, ast.Name):
                    used.add(node.id)
                elif isinstance(node, ast.arg):
                    used.add(node.arg)
                elif isinstance(
                    node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)
                ):
                    used.add(node.name)
                elif isinstance(node, (ast.Global, ast.Nonlocal)):
                    used.update(node.names)
                elif isinstance(node, ast.alias):
                    used.add(node.asname or node.name.split(".", 1)[0])
        self._used = used
        self._next: dict[str, int] = {}

    def allocate(self, purpose: str) -> str:
        base = f"__cannbotdsl_{purpose}"
        index = self._next.get(base, 0)
        while True:
            candidate = base if index == 0 else f"{base}_{index}"
            index += 1
            if candidate not in self._used:
                self._used.add(candidate)
                self._next[base] = index
                return candidate


@dataclass(frozen=True, slots=True)
class LoweringResult:
    module: ast.Module
    target: ast.FunctionDef | ast.AsyncFunctionDef
    runtime_name: str

    def unparse(self) -> str:
        return ast.unparse(self.module) + "\n"


def _arguments(names: tuple[str, ...]) -> ast.arguments:
    return ast.arguments(
        posonlyargs=[],
        args=[ast.arg(arg=name, annotation=None) for name in names],
        vararg=None,
        kwonlyargs=[],
        kw_defaults=[],
        kwarg=None,
        defaults=[],
    )


def _function(
    name: str,
    argument_names: tuple[str, ...],
    body: list[ast.stmt],
) -> ast.FunctionDef:
    kwargs = {
        "name": name,
        "args": _arguments(argument_names),
        "body": body,
        "decorator_list": [],
        "returns": None,
        "type_comment": None,
    }
    if "type_params" in ast.FunctionDef._fields:
        kwargs["type_params"] = []
    return ast.FunctionDef(**kwargs)


class _Lowerer(ast.NodeTransformer):
    def __init__(
        self,
        plan: FrontendPlan,
        allocator: NameAllocator,
        runtime_name: str,
        root: ast.FunctionDef | ast.AsyncFunctionDef,
    ) -> None:
        self.plan = plan
        self.allocator = allocator
        self.runtime_name = runtime_name
        self.root = root
        self._regions = {
            (region.kind, region.span.sort_key()): region
            for region in plan.regions
        }
        self._expressions = {
            (expression.kind, expression.span.sort_key()): expression
            for expression in plan.expressions
        }

    @staticmethod
    def _load(name: str) -> ast.Name:
        return ast.Name(id=name, ctx=ast.Load())

    @staticmethod
    def _store(name: str) -> ast.Name:
        return ast.Name(id=name, ctx=ast.Store())

    @staticmethod
    def _empty_lambda(value: ast.expr) -> ast.Lambda:
        return ast.Lambda(args=_arguments(()), body=value)

    def _runtime_attr(self, name: str) -> ast.Attribute:
        return ast.Attribute(
            value=self._load(self.runtime_name),
            attr=name,
            ctx=ast.Load(),
        )

    def _info(self, region_id: int, *, expression: bool = False) -> ast.Call:
        return ast.Call(
            func=self._runtime_attr(
                "expression_info" if expression else "region_info"
            ),
            args=[ast.Constant(region_id)],
            keywords=[],
        )

    def _region(
        self, kind: RegionKind, node: ast.AST
    ) -> RegionPlan | None:
        return self._regions.get((kind, _node_key(node)))

    def _expression(
        self, kind: str, node: ast.AST
    ) -> ExpressionPlan | None:
        return self._expressions.get((kind, _node_key(node)))

    def _statements(self, statements: list[ast.stmt]) -> list[ast.stmt]:
        result: list[ast.stmt] = []
        for statement in statements:
            transformed = self.visit(statement)
            if transformed is None:
                continue
            if isinstance(transformed, list):
                result.extend(transformed)
            else:
                result.append(transformed)
        return result

    def _state_tuple(
        self, names: tuple[str, ...], *, store: bool = False
    ) -> ast.Tuple:
        return ast.Tuple(
            elts=[
                self._store(name) if store else self._load(name)
                for name in names
            ],
            ctx=ast.Store() if store else ast.Load(),
        )

    def _call_statement(
        self,
        call: ast.Call,
        state: tuple[str, ...],
        location: ast.AST,
    ) -> ast.stmt:
        if not state:
            return ast.copy_location(ast.Expr(value=call), location)
        assignment = ast.Assign(
            targets=[self._state_tuple(state, store=True)],
            value=call,
        )
        return ast.copy_location(assignment, location)

    def _callback(
        self,
        purpose: str,
        arguments: tuple[str, ...],
        body: list[ast.stmt],
        location: ast.AST,
    ) -> tuple[str, ast.FunctionDef]:
        name = self.allocator.allocate(purpose)
        callback = _function(name, arguments, body)
        return name, ast.copy_location(callback, location)

    def transform_root(
        self,
    ) -> ast.FunctionDef | ast.AsyncFunctionDef:
        self.root.decorator_list = []
        self.root.body = self._statements(self.root.body)
        return self.root

    def visit_FunctionDef(self, node: ast.FunctionDef):
        # Nested ordinary functions retain their decorators and Python body.
        return node

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef):
        return node

    def visit_Lambda(self, node: ast.Lambda):
        return node

    def visit_ListComp(self, node: ast.ListComp):
        return node

    visit_SetComp = visit_ListComp
    visit_DictComp = visit_ListComp
    visit_GeneratorExp = visit_ListComp

    def visit_Name(self, node: ast.Name):
        return node

    def visit_Constant(self, node: ast.Constant):
        return node

    def visit_Attribute(self, node: ast.Attribute):
        node.value = self.visit(node.value)
        return node

    def visit_BinOp(self, node: ast.BinOp):
        node.left = self.visit(node.left)
        node.right = self.visit(node.right)
        return node

    def visit_Tuple(self, node: ast.Tuple):
        node.elts = [self.visit(element) for element in node.elts]
        return node

    def visit_List(self, node: ast.List):
        node.elts = [self.visit(element) for element in node.elts]
        return node

    def visit_Set(self, node: ast.Set):
        node.elts = [self.visit(element) for element in node.elts]
        return node

    def visit_Dict(self, node: ast.Dict):
        node.keys = [
            self.visit(key) if key is not None else None
            for key in node.keys
        ]
        node.values = [self.visit(value) for value in node.values]
        return node

    def visit_For(self, node: ast.For):
        region = self._region(RegionKind.FOR, node)
        if region is None:
            return self.generic_visit(node)
        assert region.range is not None
        assert isinstance(node.iter, ast.Call)
        assert isinstance(node.target, ast.Name)

        call_args = node.iter.args
        if len(call_args) == 1:
            start, stop, step = ast.Constant(0), call_args[0], ast.Constant(1)
        elif len(call_args) == 2:
            start, stop, step = call_args[0], call_args[1], ast.Constant(1)
        else:
            start, stop, step = call_args
        start = self.visit(start)
        stop = self.visit(stop)
        step = self.visit(step)

        options = {keyword.arg: keyword.value for keyword in node.iter.keywords}
        unroll = self.visit(options.get("unroll", ast.Constant(None)))
        unroll_full = self.visit(
            options.get("unroll_full", ast.Constant(False))
        )

        callback_body = self._statements(node.body)
        callback_body.append(
            ast.Return(value=self._state_tuple(region.state))
        )
        callback_name, callback = self._callback(
            f"for_body_{region.id}",
            (node.target.id, *region.state),
            callback_body,
            node,
        )
        call = ast.Call(
            func=self._runtime_attr("for_region"),
            args=[
                start,
                stop,
                step,
                self._state_tuple(region.state),
                self._load(callback_name),
                self._info(region.id),
            ],
            keywords=[
                ast.keyword(arg="unroll", value=unroll),
                ast.keyword(arg="unroll_full", value=unroll_full),
            ],
        )
        lowered = [callback, self._call_statement(call, region.state, node)]
        lowered.extend(self._statements(node.orelse))
        return lowered

    def visit_If(self, node: ast.If):
        region = self._region(RegionKind.IF, node)
        if region is None:
            return self.generic_visit(node)

        then_body = self._statements(node.body)
        then_body.append(ast.Return(value=self._state_tuple(region.state)))
        then_name, then_callback = self._callback(
            f"if_then_{region.id}",
            region.state,
            then_body,
            node,
        )

        callbacks: list[ast.stmt] = [then_callback]
        else_name: str | None = None
        if node.orelse or region.state:
            else_body = self._statements(node.orelse)
            else_body.append(
                ast.Return(value=self._state_tuple(region.state))
            )
            else_name, else_callback = self._callback(
                f"if_else_{region.id}",
                region.state,
                else_body,
                node,
            )
            callbacks.append(else_callback)

        call = ast.Call(
            func=self._runtime_attr("if_region"),
            args=[
                self.visit(node.test),
                self._state_tuple(region.state),
                self._load(then_name),
                (
                    self._load(else_name)
                    if else_name is not None
                    else ast.Constant(None)
                ),
                self._info(region.id),
            ],
            keywords=[],
        )
        callbacks.append(self._call_statement(call, region.state, node))
        return callbacks

    def visit_While(self, node: ast.While):
        region = self._region(RegionKind.WHILE, node)
        if region is None:
            return self.generic_visit(node)

        condition_name, condition_callback = self._callback(
            f"while_condition_{region.id}",
            region.state,
            [ast.Return(value=self.visit(node.test))],
            node,
        )
        body = self._statements(node.body)
        body.append(ast.Return(value=self._state_tuple(region.state)))
        body_name, body_callback = self._callback(
            f"while_body_{region.id}",
            region.state,
            body,
            node,
        )
        call = ast.Call(
            func=self._runtime_attr("while_region"),
            args=[
                self._state_tuple(region.state),
                self._load(condition_name),
                self._load(body_name),
                self._info(region.id),
            ],
            keywords=[],
        )
        lowered: list[ast.stmt] = [
            condition_callback,
            body_callback,
            self._call_statement(call, region.state, node),
        ]
        lowered.extend(self._statements(node.orelse))
        return lowered

    def visit_BoolOp(self, node: ast.BoolOp):
        expression = self._expression("boolop", node)
        if expression is None:
            return self.generic_visit(node)
        operands = [
            self._empty_lambda(self.visit(value)) for value in node.values
        ]
        call = ast.Call(
            func=self._runtime_attr("boolop"),
            args=[
                ast.Constant(type(node.op).__name__),
                ast.Tuple(elts=operands, ctx=ast.Load()),
                self._info(expression.id, expression=True),
            ],
            keywords=[],
        )
        return ast.copy_location(call, node)

    def visit_Compare(self, node: ast.Compare):
        expression = self._expression("comparison", node)
        if expression is None:
            return self.generic_visit(node)
        call = ast.Call(
            func=self._runtime_attr("comparison"),
            args=[
                self._empty_lambda(self.visit(node.left)),
                ast.Tuple(
                    elts=[
                        self._empty_lambda(self.visit(comparator))
                        for comparator in node.comparators
                    ],
                    ctx=ast.Load(),
                ),
                ast.Tuple(
                    elts=[
                        ast.Constant(type(operator).__name__)
                        for operator in node.ops
                    ],
                    ctx=ast.Load(),
                ),
                self._info(expression.id, expression=True),
            ],
            keywords=[],
        )
        return ast.copy_location(call, node)

    def visit_IfExp(self, node: ast.IfExp):
        expression = self._expression("ifexp", node)
        if expression is None:
            return self.generic_visit(node)
        call = ast.Call(
            func=self._runtime_attr("if_expression"),
            args=[
                self.visit(node.test),
                self._empty_lambda(self.visit(node.body)),
                self._empty_lambda(self.visit(node.orelse)),
                self._info(expression.id, expression=True),
            ],
            keywords=[],
        )
        return ast.copy_location(call, node)

    def visit_UnaryOp(self, node: ast.UnaryOp):
        if not isinstance(node.op, ast.Not):
            node.operand = self.visit(node.operand)
            return node
        expression = self._expression("not", node)
        if expression is None:
            return self.generic_visit(node)
        call = ast.Call(
            func=self._runtime_attr("logical_not"),
            args=[self.visit(node.operand)],
            keywords=[],
        )
        return ast.copy_location(call, node)

    def visit_Subscript(self, node: ast.Subscript):
        expression = self._expression("subscript", node)
        if expression is None:
            node.value = self.visit(node.value)
            node.slice = self.visit(node.slice)
            return node
        call = ast.Call(
            func=self._runtime_attr("dynamic_getitem"),
            args=[self.visit(node.value), self.visit(node.slice)],
            keywords=[],
        )
        return ast.copy_location(call, node)

    def visit_Call(self, node: ast.Call):
        expression = self._expression("builtin", node)
        if expression is None or expression.marker is None:
            node.func = self.visit(node.func)
            node.args = [self.visit(argument) for argument in node.args]
            for keyword in node.keywords:
                keyword.value = self.visit(keyword.value)
            return node
        marker = expression.marker
        if marker in {MarkerKind.MIN, MarkerKind.MAX}:
            return ast.copy_location(
                ast.Call(
                    func=self._runtime_attr("minmax"),
                    args=[
                        ast.Constant(marker.value),
                        *(self.visit(argument) for argument in node.args),
                    ],
                    keywords=[
                        ast.keyword(
                            arg=keyword.arg,
                            value=self.visit(keyword.value),
                        )
                        for keyword in node.keywords
                    ],
                ),
                node,
            )

        if marker in {MarkerKind.ANY, MarkerKind.ALL}:
            if (
                len(node.args) != 1
                or node.keywords
                or not isinstance(node.args[0], (ast.Tuple, ast.List))
            ):
                return self.generic_visit(node)
            container = node.args[0]
            thunks = [
                self._empty_lambda(self.visit(element))
                for element in container.elts
            ]
            thunk_container: ast.expr
            if isinstance(container, ast.Tuple):
                thunk_container = ast.Tuple(elts=thunks, ctx=ast.Load())
            else:
                thunk_container = ast.List(elts=thunks, ctx=ast.Load())
            return ast.copy_location(
                ast.Call(
                    func=self._runtime_attr("any_all"),
                    args=[
                        ast.Constant(marker.value),
                        thunk_container,
                        self._info(expression.id, expression=True),
                    ],
                    keywords=[],
                ),
                node,
            )
        return self.generic_visit(node)


def lower(source: SourceUnit, plan: FrontendPlan) -> LoweringResult:
    """Create a fresh lowered tree without consulting function globals."""

    target = source.fresh_target()
    allocator = NameAllocator(
        target,
        reserved_names=set(plan.reserved_names),
    )
    runtime_name = allocator.allocate("runtime")
    transformer = _Lowerer(plan, allocator, runtime_name, target)
    lowered_target = transformer.transform_root()
    module = ast.Module(body=[lowered_target], type_ignores=[])
    ast.fix_missing_locations(module)
    return LoweringResult(module, lowered_target, runtime_name)


__all__ = ["LoweringResult", "NameAllocator", "lower"]
