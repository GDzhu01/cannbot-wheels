# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Stateless orchestration for source analysis, lowering, and materialization."""

from __future__ import annotations

from collections.abc import Callable
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Iterator

from cannbotdsl.core.frontend.analysis import analyze
from cannbotdsl.core.frontend.api import (
    FrontendArtifact,
    FrontendDebugArtifacts,
    FrontendDumpKind,
    FrontendOptions,
)
from cannbotdsl.core.frontend.diagnostics import (
    FE501_MATERIALIZATION_FAILED,
    FrontendError,
)
from cannbotdsl.core.frontend.lowering import lower
from cannbotdsl.core.frontend.materialize import materialize
from cannbotdsl.core.frontend.source import SourceUnit
from cannbotdsl.core.diag.diagnostics import (
    CANNBotError,
    CANNBotInternalError,
    IN001_COMPILER_INVARIANT,
)


class FrontendCompiler:
    """A reentrant compiler with no session, cache, or counter fields."""

    __slots__ = ()

    def compile(
        self,
        fn: Callable[..., object],
        options: FrontendOptions,
    ) -> FrontendArtifact:
        source = SourceUnit.capture(fn)
        plan = analyze(source)
        try:
            lowered = lower(source, plan)
            lowered_debug = (
                lowered.unparse()
                if FrontendDumpKind.LOWERED in options.dumps
                else None
            )
            rebuilt = materialize(source, plan, lowered, options)
        except FrontendError:
            raise
        except CANNBotError:
            raise
        except AssertionError as exc:
            raise CANNBotInternalError(
                IN001_COMPILER_INVARIANT,
                f"Frontend invariant failed while compiling {fn.__qualname__!r}: {exc}",
                phase="compiler",
                path=fn.__qualname__,
                hint="Report this compiler invariant failure with the source function and chained exception.",
            ) from exc
        except Exception as exc:
            raise source.error(
                FE501_MATERIALIZATION_FAILED,
                "Failed to lower or materialize function "
                f"{fn.__qualname__!r}: {exc}",
                node=source.target,
                hint=(
                    "Inspect the frontend dumps, when available, and the "
                    "chained exception."
                ),
            ) from exc

        debug: FrontendDebugArtifacts | None = None
        if options.dumps:
            debug = FrontendDebugArtifacts(
                source=(
                    source.source
                    if FrontendDumpKind.SOURCE in options.dumps
                    else None
                ),
                plan=(
                    plan.format()
                    if FrontendDumpKind.PLAN in options.dumps
                    else None
                ),
                lowered=lowered_debug,
            )
        return FrontendArtifact(
            function=rebuilt,
            plan=plan,
            source_digest=source.source_digest,
            debug=debug,
        )


def compile_frontend(
    fn: Callable[..., object],
    options: FrontendOptions,
) -> FrontendArtifact:
    return FrontendCompiler().compile(fn, options)


_CURRENT_FRONTEND_OPTIONS: ContextVar[FrontendOptions | None] = ContextVar(
    "cannbotdsl_frontend_options", default=None
)


def options_from_snapshot(snapshot) -> FrontendOptions:
    return FrontendOptions(
        emit_line_info=snapshot.frontend_line_info,
        dumps=snapshot.frontend_dumps,
    )


def options_for_entry(*, snapshot=None) -> FrontendOptions:
    """Use the active compilation snapshot or capture a fresh one."""

    active = _CURRENT_FRONTEND_OPTIONS.get()
    if active is not None:
        return active
    if snapshot is None:
        from cannbotdsl.core.utils.env import env

        snapshot = env()
    return options_from_snapshot(snapshot)


@contextmanager
def frontend_options_scope(options: FrontendOptions) -> Iterator[None]:
    token = _CURRENT_FRONTEND_OPTIONS.set(options)
    try:
        yield
    finally:
        _CURRENT_FRONTEND_OPTIONS.reset(token)


def compile_function(
    fn: Callable[..., object],
    *,
    snapshot=None,
    struct_ref_parameters=frozenset(),
) -> FrontendArtifact:
    from cannbotdsl.core.frontend.analysis import (
        _struct_ref_parameters_scope,
    )

    options = options_for_entry(snapshot=snapshot)
    with _struct_ref_parameters_scope(struct_ref_parameters):
        return compile_frontend(fn, options)


__all__ = [
    "FrontendCompiler",
    "compile_frontend",
    "compile_function",
    "frontend_options_scope",
    "options_for_entry",
    "options_from_snapshot",
]
