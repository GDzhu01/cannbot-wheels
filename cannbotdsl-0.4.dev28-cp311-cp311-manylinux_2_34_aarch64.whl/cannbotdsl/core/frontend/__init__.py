# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Public contracts for the CANNBotDSL Python frontend."""

from cannbotdsl.core.frontend.api import (
    FrontendArtifact,
    FrontendDebugArtifacts,
    FrontendDumpKind,
    FrontendOptions,
    SourceSpan,
)
from cannbotdsl.core.frontend.compiler import FrontendCompiler
from cannbotdsl.core.frontend.diagnostics import (
    FrontendError,
    FrontendErrorCode,
)

__all__ = [
    "FrontendArtifact",
    "FrontendCompiler",
    "FrontendDebugArtifacts",
    "FrontendDumpKind",
    "FrontendError",
    "FrontendErrorCode",
    "FrontendOptions",
    "SourceSpan",
]
