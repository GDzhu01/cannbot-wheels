# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Deterministic semantic planning for the CANNBotDSL AST frontend."""

from __future__ import annotations

import ast
import builtins
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, replace
from enum import Enum
import types

from cannbotdsl.core.frontend.api import SourceSpan
from cannbotdsl.core.frontend.dataflow import (
    RegionInput,
    analyze_dataflow,
)
from cannbotdsl.core.frontend.diagnostics import (
    FE101_UNSUPPORTED_SYNTAX,
    FE102_UNSAFE_EARLY_EXIT,
    FE103_STRUCT_REF_REBIND,
    FE301_INVALID_RANGE,
    FE303_NON_POSITIVE_STEP,
)
from cannbotdsl.core.frontend.source import SourceUnit
from cannbotdsl.core.frontend.symbols import MarkerKind, SafeSymbolResolver

_TRY_NODES = (ast.Try,) + (
    (ast.TryStar,) if hasattr(ast, "TryStar") else ()
)

_STRUCT_REF_PARAMETERS: ContextVar[frozenset[str]] = ContextVar(
    "cannbotdsl_frontend_struct_ref_parameters",
    default=frozenset(),
)


@contextmanager
def _struct_ref_parameters_scope(parameters):
    names = frozenset(parameters)
    if any(type(name) is not str or not name for name in names):
        raise TypeError("StructRef parameter names must be non-empty strings")
    token = _STRUCT_REF_PARAMETERS.set(names)
    try:
        yield
    finally:
        _STRUCT_REF_PARAMETERS.reset(token)


class RegionKind(str, Enum):
    FOR = "for"
    IF = "if"
    WHILE = "while"


@dataclass(frozen=True, slots=True)
class RangeSpec:
    marker: MarkerKind
    positional_args: int
    keywords: tuple[str, ...]
    start_source: str
    stop_source: str
    step_source: str
    unroll_source: str | None = None
    unroll_full_source: str | None = None


@dataclass(frozen=True, slots=True)
class RegionPlan:
    id: int
    kind: RegionKind
    span: SourceSpan
    state: tuple[str, ...] = ()
    captures: tuple[str, ...] = ()
    locals: tuple[str, ...] = ()
    range: RangeSpec | None = None
    has_else: bool = False

    @property
    def region_id(self) -> int:
        return self.id


@dataclass(frozen=True, slots=True)
class ExpressionPlan:
    id: int
    kind: str
    span: SourceSpan
    marker: MarkerKind | None = None


@dataclass(frozen=True, slots=True)
class FrontendPlan:
    function_name: str
    qualified_name: str
    filename: str
    source_digest: str
    reserved_names: tuple[str, ...]
    decorators: tuple[str, ...]
    regions: tuple[RegionPlan, ...]
    expressions: tuple[ExpressionPlan, ...]

    def find_region(self, kind: str | RegionKind, node: ast.AST) -> RegionPlan:
        expected = RegionKind(kind)
        key = (
            int(getattr(node, "lineno", 0)),
            int(getattr(node, "col_offset", 0)),
            int(getattr(node, "end_lineno", 0)),
            int(getattr(node, "end_col_offset", 0)),
        )
        for region in self.regions:
            if region.kind is expected and region.span.sort_key() == key:
                return region
        raise KeyError(f"No {expected.value} region plan for source span {key}")

    def find_expression(self, kind: str, node: ast.AST) -> ExpressionPlan:
        key = (
            int(getattr(node, "lineno", 0)),
            int(getattr(node, "col_offset", 0)),
            int(getattr(node, "end_lineno", 0)),
            int(getattr(node, "end_col_offset", 0)),
        )
        for expression in self.expressions:
            if expression.kind == kind and expression.span.sort_key() == key:
                return expression
        raise KeyError(f"No {kind} expression plan for source span {key}")

    def format(self) -> str:
        """Return a stable, review-friendly plan snapshot."""

        lines = [
            f"function {self.qualified_name}",
            f"source {self.filename}",
            f"digest {self.source_digest}",
            f"reserved_names {list(self.reserved_names)!r}",
        ]
        for decorator in self.decorators:
            lines.append(f"decorator {decorator}")
        for region in self.regions:
            span = region.span
            lines.append(
                f"region {region.id} {region.kind.value} "
                f"{span.start_line}:{span.start_col}-"
                f"{span.end_line}:{span.end_col} "
                f"state={list(region.state)!r} "
                f"captures={list(region.captures)!r} "
                f"locals={list(region.locals)!r} "
                f"else={region.has_else}"
            )
            if region.range is not None:
                spec = region.range
                lines.append(
                    f"  range marker={spec.marker.value} "
                    f"args={spec.positional_args} "
                    f"keywords={list(spec.keywords)!r} "
                    f"start={spec.start_source!r} "
                    f"stop={spec.stop_source!r} "
                    f"step={spec.step_source!r} "
                    f"unroll={spec.unroll_source!r} "
                    f"unroll_full={spec.unroll_full_source!r}"
                )
        for expression in self.expressions:
            span = expression.span
            marker = (
                f" marker={expression.marker.value}"
                if expression.marker is not None
                else ""
            )
            lines.append(
                f"expression {expression.id} {expression.kind} "
                f"{span.start_line}:{span.start_col}-"
                f"{span.end_line}:{span.end_col}{marker}"
            )
        return "\n".join(lines) + "\n"


@dataclass(slots=True)
class _RegionDraft:
    plan: RegionPlan
    node: ast.If | ast.For | ast.While


def _reserved_names(source: SourceUnit) -> tuple[str, ...]:
    """Collect identifiers from the root and every nested code object."""

    names = {
        *source.symbol_table.get_identifiers(),
        source.target.name,
    }
    pending = [source.function.__code__]
    while pending:
        code = pending.pop()
        names.update(code.co_names)
        names.update(code.co_varnames)
        names.update(code.co_freevars)
        names.update(code.co_cellvars)
        pending.extend(
            constant
            for constant in code.co_consts
            if isinstance(constant, types.CodeType)
        )
    return tuple(sorted(names))


def _region_writes(node: ast.If | ast.For | ast.While) -> dict[str, ast.Name]:
    """Return the first write to each name in one dynamic region."""

    writes: dict[str, ast.Name] = {}

    class Visitor(ast.NodeVisitor):
        def visit_Name(self, name: ast.Name) -> None:
            if isinstance(name.ctx, (ast.Store, ast.Del)):
                previous = writes.get(name.id)
                position = (name.lineno, name.col_offset)
                if previous is None or position < (
                    previous.lineno,
                    previous.col_offset,
                ):
                    writes[name.id] = name

        def visit_FunctionDef(self, definition: ast.FunctionDef) -> None:
            return

        visit_AsyncFunctionDef = visit_FunctionDef

        def visit_ClassDef(self, definition: ast.ClassDef) -> None:
            return

        def visit_Lambda(self, expression: ast.Lambda) -> None:
            return

    Visitor().visit(node)
    return writes


def _validate_struct_ref_bindings(
    source: SourceUnit,
    protected_names: frozenset[str],
) -> None:
    """Reject rebinding a StructRef parameter in the root lexical scope."""

    if not protected_names:
        return

    class Visitor(ast.NodeVisitor):
        def reject(self, node: ast.AST, name: str, action: str) -> None:
            if name not in protected_names:
                return
            raise source.error(
                FE103_STRUCT_REF_REBIND,
                f"StructRef parameter {name!r} cannot be {action} in its "
                "function scope.",
                node=node,
                hint=(
                    "Keep the original StructRef parameter binding; aliases "
                    "such as `alias = parameter` are allowed."
                ),
            )

        def visit_Name(self, node: ast.Name) -> None:
            if isinstance(node.ctx, ast.Store):
                self.reject(node, node.id, "rebound")
            elif isinstance(node.ctx, ast.Del):
                self.reject(node, node.id, "deleted")

        def _visit_definition_expressions(self, node) -> None:
            for decorator in node.decorator_list:
                self.visit(decorator)
            arguments = node.args
            for default in (*arguments.defaults, *arguments.kw_defaults):
                if default is not None:
                    self.visit(default)
            for argument in (
                *arguments.posonlyargs,
                *arguments.args,
                *arguments.kwonlyargs,
            ):
                if argument.annotation is not None:
                    self.visit(argument.annotation)
            if arguments.vararg is not None and arguments.vararg.annotation is not None:
                self.visit(arguments.vararg.annotation)
            if arguments.kwarg is not None and arguments.kwarg.annotation is not None:
                self.visit(arguments.kwarg.annotation)
            if node.returns is not None:
                self.visit(node.returns)

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
            self.reject(node, node.name, "rebound")
            self._visit_definition_expressions(node)

        visit_AsyncFunctionDef = visit_FunctionDef

        def visit_ClassDef(self, node: ast.ClassDef) -> None:
            self.reject(node, node.name, "rebound")
            for decorator in node.decorator_list:
                self.visit(decorator)
            for base in node.bases:
                self.visit(base)
            for keyword in node.keywords:
                self.visit(keyword.value)

        def visit_Lambda(self, node: ast.Lambda) -> None:
            for default in (*node.args.defaults, *node.args.kw_defaults):
                if default is not None:
                    self.visit(default)

        def _visit_comprehension(self, node, values: tuple[ast.AST, ...]) -> None:
            # Comprehension targets live in an implicit nested scope.  Their
            # iterables, filters, and value expressions can still contain a
            # walrus that binds the containing function scope.
            for generator in node.generators:
                self.visit(generator.iter)
                for condition in generator.ifs:
                    self.visit(condition)
            for value in values:
                self.visit(value)

        def visit_ListComp(self, node: ast.ListComp) -> None:
            self._visit_comprehension(node, (node.elt,))

        visit_SetComp = visit_ListComp
        visit_GeneratorExp = visit_ListComp

        def visit_DictComp(self, node: ast.DictComp) -> None:
            self._visit_comprehension(node, (node.key, node.value))

        def visit_Import(self, node: ast.Import) -> None:
            for alias in node.names:
                self.reject(alias, alias.asname or alias.name.split(".", 1)[0], "rebound")

        def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
            for alias in node.names:
                if alias.name != "*":
                    self.reject(alias, alias.asname or alias.name, "rebound")

        def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
            if node.type is not None:
                self.visit(node.type)
            if node.name is not None:
                self.reject(node, node.name, "rebound")
            for statement in node.body:
                self.visit(statement)

        def visit_MatchAs(self, node: ast.MatchAs) -> None:
            if node.pattern is not None:
                self.visit(node.pattern)
            if node.name is not None:
                self.reject(node, node.name, "rebound")

        def visit_MatchStar(self, node: ast.MatchStar) -> None:
            if node.name is not None:
                self.reject(node, node.name, "rebound")

        def visit_MatchMapping(self, node: ast.MatchMapping) -> None:
            for key in node.keys:
                self.visit(key)
            for pattern in node.patterns:
                self.visit(pattern)
            if node.rest is not None:
                self.reject(node, node.rest, "rebound")

    visitor = Visitor()
    for statement in source.target.body:
        visitor.visit(statement)


class _Planner(ast.NodeVisitor):
    _UNSUPPORTED_IN_REGION = (
        ast.AsyncFor,
        ast.AsyncWith,
        ast.Await,
        ast.Yield,
        ast.YieldFrom,
        *_TRY_NODES,
        ast.ListComp,
        ast.SetComp,
        ast.DictComp,
        ast.GeneratorExp,
        ast.Lambda,
        ast.Delete,
    )

    def __init__(self, source: SourceUnit) -> None:
        self.source = source
        self.resolver = SafeSymbolResolver(source)
        self.regions: list[_RegionDraft] = []
        self.expressions: list[ExpressionPlan] = []
        self.dynamic_depth = 0
        self.loop_stack: list[bool] = []
        self.global_names = {
            name
            for name in source.symbol_table.get_identifiers()
            if source.symbol_table.lookup(name).is_declared_global()
        }
        self.nonlocal_names = set(source.symbol_table.get_nonlocals())

    def _unsupported(
        self, node: ast.AST, message: str, hint: str
    ) -> None:
        raise self.source.error(
            FE101_UNSUPPORTED_SYNTAX,
            message,
            node=node,
            hint=hint,
        )

    def _early_exit(self, node: ast.AST, kind: str) -> None:
        raise self.source.error(
            FE102_UNSAFE_EARLY_EXIT,
            f"{kind} cannot cross the boundary of a dynamic control-flow region.",
            node=node,
            hint="Rewrite the control flow so every dynamic region reaches its implicit yield.",
        )

    def _expression(
        self,
        node: ast.AST,
        kind: str,
        marker: MarkerKind | None = None,
    ) -> None:
        self.expressions.append(
            ExpressionPlan(
                id=len(self.expressions),
                kind=kind,
                span=self.source.span(node),
                marker=marker,
            )
        )

    def _is_meta_predicate(self, node: ast.AST) -> bool:
        if not isinstance(node, ast.Call):
            return False
        marker = self.resolver.marker_kind(node.func)
        if marker not in {
            MarkerKind.CONST_EXPR,
            MarkerKind.TARGET_VERSION,
        }:
            return False
        self._validate_meta_call(node, marker)
        return True

    def _validate_meta_call(
        self, call: ast.Call, marker: MarkerKind
    ) -> None:
        starred = next(
            (
                argument
                for argument in call.args
                if isinstance(argument, ast.Starred)
            ),
            None,
        )
        if starred is not None:
            self._unsupported(
                starred,
                f"{marker.value} does not accept starred arguments.",
                f"Pass exactly one expression as {marker.value}(value).",
            )
        if call.keywords:
            keyword = call.keywords[0]
            self._unsupported(
                keyword.value,
                f"{marker.value} does not accept keyword arguments.",
                f"Pass exactly one expression as {marker.value}(value).",
            )
        if len(call.args) != 1:
            self._unsupported(
                call,
                f"{marker.value} expects exactly one positional argument, "
                f"got {len(call.args)}.",
                f"Use {marker.value}(value).",
            )

    def _range_parts(
        self,
        call: ast.Call,
        marker: MarkerKind,
        *,
        static_iteration: bool = False,
    ) -> RangeSpec:
        if not 1 <= len(call.args) <= 3:
            raise self.source.error(
                FE301_INVALID_RANGE,
                f"{marker.value} expects 1 to 3 positional arguments, got {len(call.args)}.",
                node=call,
                hint="Use range(stop), range(start, stop), or range(start, stop, step).",
            )
        starred = next(
            (argument for argument in call.args if isinstance(argument, ast.Starred)),
            None,
        )
        if starred is not None:
            raise self.source.error(
                FE301_INVALID_RANGE,
                f"{marker.value} does not accept starred arguments in a DSL loop.",
                node=starred,
                hint="Pass one to three range bounds explicitly.",
            )

        keyword_names: list[str] = []
        seen: set[str] = set()
        for keyword in call.keywords:
            if keyword.arg is None:
                raise self.source.error(
                    FE301_INVALID_RANGE,
                    f"{marker.value} does not accept **kwargs in a DSL loop.",
                    node=keyword.value,
                    hint="Pass unroll options as explicit keyword arguments.",
                )
            if keyword.arg in seen:
                raise self.source.error(
                    FE301_INVALID_RANGE,
                    f"{marker.value} received duplicate keyword {keyword.arg!r}.",
                    node=keyword.value,
                    hint="Specify each range option once.",
                )
            seen.add(keyword.arg)
            keyword_names.append(keyword.arg)

        if marker is MarkerKind.DSL_RANGE:
            unknown = seen - {"unroll", "unroll_full"}
            if unknown:
                name = min(unknown)
                raise self.source.error(
                    FE301_INVALID_RANGE,
                    f"cannbotdsl.range() got an unexpected keyword argument {name!r}.",
                    node=call,
                    hint="Only unroll= and unroll_full= are supported.",
                )
        elif seen:
            raise self.source.error(
                FE301_INVALID_RANGE,
                f"{marker.value} does not accept keyword arguments in a DSL loop.",
                node=call,
                hint="Remove the keyword arguments or use cannbotdsl.range for unroll controls.",
            )

        if len(call.args) == 1:
            start, stop, step = ast.Constant(0), call.args[0], ast.Constant(1)
        elif len(call.args) == 2:
            start, stop, step = call.args[0], call.args[1], ast.Constant(1)
        else:
            start, stop, step = call.args

        def integer_literal(node: ast.AST) -> int | None:
            if (
                isinstance(node, ast.Constant)
                and isinstance(node.value, int)
                and not isinstance(node.value, bool)
            ):
                return node.value
            if isinstance(node, ast.UnaryOp) and isinstance(
                node.op, (ast.UAdd, ast.USub)
            ):
                operand = integer_literal(node.operand)
                if operand is not None:
                    return operand if isinstance(node.op, ast.UAdd) else -operand
            return None

        step_literal = integer_literal(step)
        if (
            marker is not MarkerKind.RANGE_CONSTEXPR
            and not static_iteration
            and step_literal is not None
            and step_literal <= 0
        ):
            raise self.source.error(
                FE303_NON_POSITIVE_STEP,
                f"Dynamic DSL range step must be strictly positive, got {step_literal}.",
                node=step,
                hint="Use a positive step and express reverse traversal explicitly.",
            )

        keyword_values = {keyword.arg: keyword.value for keyword in call.keywords}
        if marker is MarkerKind.DSL_RANGE:
            unroll_node = keyword_values.get("unroll")
            if (
                isinstance(unroll_node, ast.Constant)
                and unroll_node.value is not None
            ):
                unroll_value = unroll_node.value
                if (
                    isinstance(unroll_value, bool)
                    or not isinstance(unroll_value, int)
                    or unroll_value <= 0
                ):
                    raise self.source.error(
                        FE301_INVALID_RANGE,
                        "cannbotdsl.range() unroll must be a positive compile-time int.",
                        node=unroll_node,
                        hint="Pass a positive integer literal to unroll=.",
                    )
            unroll_full_node = keyword_values.get("unroll_full")
            if (
                isinstance(unroll_full_node, ast.Constant)
                and not isinstance(unroll_full_node.value, bool)
            ):
                raise self.source.error(
                    FE301_INVALID_RANGE,
                    "cannbotdsl.range() unroll_full must be a compile-time bool.",
                    node=unroll_full_node,
                    hint="Pass unroll_full=True or unroll_full=False directly.",
                )
            if (
                unroll_node is not None
                and isinstance(unroll_full_node, ast.Constant)
                and unroll_full_node.value is True
            ):
                raise self.source.error(
                    FE301_INVALID_RANGE,
                    "cannbotdsl.range() unroll and unroll_full=True are mutually exclusive.",
                    node=call,
                    hint="Choose either a fixed unroll factor or full unrolling.",
                )
        return RangeSpec(
            marker=marker,
            positional_args=len(call.args),
            keywords=tuple(keyword_names),
            start_source=self.source.text(start),
            stop_source=self.source.text(stop),
            step_source=self.source.text(step),
            unroll_source=(
                self.source.text(keyword_values["unroll"])
                if "unroll" in keyword_values
                else None
            ),
            unroll_full_source=(
                self.source.text(keyword_values["unroll_full"])
                if "unroll_full" in keyword_values
                else None
            ),
        )

    def _is_static_iterable(self, node: ast.AST) -> bool:
        """Recognize fixed Python iteration without invoking user protocols."""

        if isinstance(node, (ast.Tuple, ast.List)):
            return True
        if not isinstance(node, ast.Call):
            return False
        container = self.resolver.resolve_callee(node.func)
        if container is not builtins.tuple and container is not builtins.list:
            return False
        if (
            len(node.args) != 1
            or isinstance(node.args[0], ast.Starred)
            or node.keywords
        ):
            self._unsupported(
                node,
                "A static tuple/list loop expects one explicit range argument.",
                "Use tuple(range(...)), list(range(...)), or a tuple/list literal.",
            )
        range_call = node.args[0]
        if not isinstance(range_call, ast.Call):
            return False
        marker = self.resolver.marker_kind(range_call.func)
        if marker not in {
            MarkerKind.BUILTIN_RANGE,
            MarkerKind.RANGE_CONSTEXPR,
        }:
            return False
        self._range_parts(range_call, marker, static_iteration=True)
        return True

    def _enter_region(
        self,
        node: ast.If | ast.For | ast.While,
        kind: RegionKind,
        *,
        range_spec: RangeSpec | None = None,
    ) -> None:
        if self.global_names or self.nonlocal_names:
            writes = _region_writes(node)
            for scope, declared_names in (
                ("global", self.global_names),
                ("nonlocal", self.nonlocal_names),
            ):
                written = sorted(
                    declared_names.intersection(writes),
                    key=lambda name: (
                        writes[name].lineno,
                        writes[name].col_offset,
                        name,
                    ),
                )
                if written:
                    name = written[0]
                    self._unsupported(
                        writes[name],
                        f"{scope} name {name!r} cannot be written inside a dynamic region.",
                        "Carry a DSL value through explicit local region state instead.",
                    )
        draft = _RegionDraft(
            RegionPlan(
                id=len(self.regions),
                kind=kind,
                span=self.source.span(node),
                range=range_spec,
                has_else=bool(node.orelse),
            ),
            node,
        )
        self.regions.append(draft)

    def visit_If(self, node: ast.If) -> None:
        if self._is_meta_predicate(node.test):
            self.visit(node.test)
            for statement in node.body:
                self.visit(statement)
            for statement in node.orelse:
                self.visit(statement)
            return

        self._enter_region(node, RegionKind.IF)
        self.visit(node.test)
        self.dynamic_depth += 1
        try:
            for statement in node.body:
                self.visit(statement)
            for statement in node.orelse:
                self.visit(statement)
        finally:
            self.dynamic_depth -= 1

    def visit_While(self, node: ast.While) -> None:
        if self._is_meta_predicate(node.test):
            self.visit(node.test)
            self.loop_stack.append(False)
            try:
                for statement in node.body:
                    self.visit(statement)
                for statement in node.orelse:
                    self.visit(statement)
            finally:
                self.loop_stack.pop()
            return

        self._enter_region(node, RegionKind.WHILE)
        self.visit(node.test)
        self.dynamic_depth += 1
        self.loop_stack.append(True)
        try:
            for statement in node.body:
                self.visit(statement)
        finally:
            self.loop_stack.pop()
            self.dynamic_depth -= 1
        for statement in node.orelse:
            self.visit(statement)

    def visit_For(self, node: ast.For) -> None:
        marker = (
            self.resolver.marker_kind(node.iter.func)
            if isinstance(node.iter, ast.Call)
            else None
        )
        if marker is MarkerKind.RANGE_CONSTEXPR:
            self._range_parts(node.iter, marker)
            self.visit(node.iter)
            self.loop_stack.append(False)
            try:
                for statement in node.body:
                    self.visit(statement)
                for statement in node.orelse:
                    self.visit(statement)
            finally:
                self.loop_stack.pop()
            return

        if self._is_static_iterable(node.iter):
            self.visit(node.iter)
            self.loop_stack.append(False)
            try:
                for statement in node.body:
                    self.visit(statement)
                for statement in node.orelse:
                    self.visit(statement)
            finally:
                self.loop_stack.pop()
            return

        if marker not in {MarkerKind.BUILTIN_RANGE, MarkerKind.DSL_RANGE}:
            if self.dynamic_depth:
                self._unsupported(
                    node.iter,
                    "Only recognized dynamic ranges and fixed Python tuple/list "
                    "iteration are supported inside a dynamic region.",
                    "Use range_constexpr, tuple(range(...)), a tuple/list literal, "
                    "or a recognized range for SCF.",
                )
            self.generic_visit(node)
            return

        if not isinstance(node.target, ast.Name):
            self._unsupported(
                node.target,
                "Dynamic DSL for-loops require a single name as the induction variable.",
                "Assign tuple unpacking inside the loop body instead.",
            )
        range_spec = self._range_parts(node.iter, marker)
        self._enter_region(node, RegionKind.FOR, range_spec=range_spec)
        self.visit(node.iter)
        self.dynamic_depth += 1
        self.loop_stack.append(True)
        try:
            for statement in node.body:
                self.visit(statement)
        finally:
            self.loop_stack.pop()
            self.dynamic_depth -= 1
        for statement in node.orelse:
            self.visit(statement)

    def visit_Break(self, node: ast.Break) -> None:
        if self.dynamic_depth and (not self.loop_stack or self.loop_stack[-1]):
            self._early_exit(node, "break")

    def visit_Continue(self, node: ast.Continue) -> None:
        if self.dynamic_depth and (not self.loop_stack or self.loop_stack[-1]):
            self._early_exit(node, "continue")

    def visit_Return(self, node: ast.Return) -> None:
        if self.dynamic_depth:
            self._early_exit(node, "return")
        self.generic_visit(node)

    def visit_Raise(self, node: ast.Raise) -> None:
        if self.dynamic_depth:
            self._early_exit(node, "raise")
        self.generic_visit(node)

    def visit_Global(self, node: ast.Global) -> None:
        return

    def visit_Nonlocal(self, node: ast.Nonlocal) -> None:
        return

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        if self.dynamic_depth:
            self._unsupported(
                node,
                "Nested function definitions are not supported inside dynamic regions.",
                "Define the helper outside the dynamic region.",
            )
        # A nested ordinary function remains ordinary Python. Its decorators
        # and body are deliberately not treated as part of the root DSL scope.

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        if self.dynamic_depth:
            self._unsupported(
                node,
                "Class definitions are not supported inside dynamic regions.",
                "Define the class outside the compiled function.",
            )

    def visit_Lambda(self, node: ast.Lambda) -> None:
        if self.dynamic_depth:
            self._unsupported(
                node,
                "Lambda expressions are not supported inside dynamic regions.",
                "Define the helper outside the dynamic region.",
            )

    def _visit_comprehension_scope(self, node: ast.AST) -> None:
        if self.dynamic_depth:
            self._unsupported(
                node,
                f"{type(node).__name__} is not supported inside a dynamic region.",
                "Use explicit frontend control flow or build the container at compile time.",
            )

    visit_ListComp = _visit_comprehension_scope
    visit_SetComp = _visit_comprehension_scope
    visit_DictComp = _visit_comprehension_scope
    visit_GeneratorExp = _visit_comprehension_scope

    def visit_Match(self, node: ast.Match) -> None:
        if self.dynamic_depth:
            self._unsupported(
                node,
                "match statements are not supported inside dynamic regions.",
                "Use an explicit chain of DSL if statements.",
            )
        self.generic_visit(node)

    def generic_visit(self, node: ast.AST) -> None:
        if self.dynamic_depth and isinstance(node, self._UNSUPPORTED_IN_REGION):
            self._unsupported(
                node,
                f"{type(node).__name__} is not supported inside a dynamic region.",
                "Move this construct to compile-time Python code outside the region.",
            )
        super().generic_visit(node)

    def visit_Name(self, node: ast.Name) -> None:
        return

    def visit_Constant(self, node: ast.Constant) -> None:
        return

    def visit_Attribute(self, node: ast.Attribute) -> None:
        self.visit(node.value)

    def visit_BinOp(self, node: ast.BinOp) -> None:
        self.visit(node.left)
        self.visit(node.right)

    def visit_BoolOp(self, node: ast.BoolOp) -> None:
        self._expression(node, "boolop")
        for value in node.values:
            self.visit(value)

    def visit_Compare(self, node: ast.Compare) -> None:
        self._expression(node, "comparison")
        self.visit(node.left)
        for comparator in node.comparators:
            self.visit(comparator)

    def visit_IfExp(self, node: ast.IfExp) -> None:
        self._expression(node, "ifexp")
        self.generic_visit(node)

    def visit_UnaryOp(self, node: ast.UnaryOp) -> None:
        if isinstance(node.op, ast.Not):
            self._expression(node, "not")
        self.visit(node.operand)

    def visit_Subscript(self, node: ast.Subscript) -> None:
        if isinstance(node.ctx, ast.Load) and not isinstance(node.slice, ast.Slice):
            self._expression(node, "subscript")
        self.visit(node.value)
        self.visit(node.slice)

    def visit_Call(self, node: ast.Call) -> None:
        marker = self.resolver.marker_kind(node.func)
        if marker in {
            MarkerKind.CONST_EXPR,
            MarkerKind.TARGET_VERSION,
        }:
            self._validate_meta_call(node, marker)
        if marker in {MarkerKind.ANY, MarkerKind.ALL}:
            fixed_sequence = (
                len(node.args) == 1
                and not node.keywords
                and isinstance(node.args[0], (ast.Tuple, ast.List))
            )
            if not fixed_sequence:
                if self.dynamic_depth:
                    self._unsupported(
                        node,
                        f"Dynamic {marker.value} requires a fixed tuple or list expression.",
                        "Replace the generator or iterator with a literal tuple/list.",
                    )
                self.visit(node.func)
                for argument in node.args:
                    self.visit(argument)
                for keyword in node.keywords:
                    self.visit(keyword.value)
                return
        if marker in {
            MarkerKind.ANY,
            MarkerKind.ALL,
            MarkerKind.MIN,
            MarkerKind.MAX,
        }:
            self._expression(node, "builtin", marker)
        self.visit(node.func)
        for argument in node.args:
            self.visit(argument)
        for keyword in node.keywords:
            self.visit(keyword.value)


def analyze(source: SourceUnit) -> FrontendPlan:
    """Analyze a captured function without evaluating or mutating its AST."""

    _validate_struct_ref_bindings(source, _STRUCT_REF_PARAMETERS.get())
    planner = _Planner(source)
    for statement in source.target.body:
        planner.visit(statement)

    region_inputs = tuple(
        RegionInput(draft.plan.id, draft.plan.kind.value, draft.node)
        for draft in planner.regions
    )
    dataflow = analyze_dataflow(source, region_inputs)
    regions = tuple(
        replace(
            draft.plan,
            state=dataflow[draft.plan.id].state,
            captures=dataflow[draft.plan.id].captures,
            locals=dataflow[draft.plan.id].locals,
        )
        for draft in planner.regions
    )
    decorators = tuple(
        source.text(item) for item in source.target.decorator_list
    )
    return FrontendPlan(
        function_name=source.target.name,
        qualified_name=source.function.__qualname__,
        filename=source.filename,
        source_digest=source.source_digest,
        reserved_names=_reserved_names(source),
        decorators=decorators,
        regions=regions,
        expressions=tuple(planner.expressions),
    )


__all__ = [
    "ExpressionPlan",
    "FrontendPlan",
    "RangeSpec",
    "RegionKind",
    "RegionPlan",
    "analyze",
]
