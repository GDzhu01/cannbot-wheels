# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Unified Python ValueTree-to-SSA transport for every frontend boundary.

``ValueTreeLayout`` is the only implementation of structural reconciliation and
semantic-leaf rebuilding. ``BoundaryPolicy`` controls the small boundary
differences: loop/if state rejects ``None``; conditional expressions allow
matching ``None`` and reconcile untyped branch literals; parameters use the
exact same tree and leaf machinery with a call-contract-provided schema.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Iterator

import cannbotdsl._mlir.ir as ir
from cannbotdsl.ir_transport import extract_ir_values, rebuild_ir_values, semantic_value_tag

from cannbotdsl.core.canonical import (
    encode_primitive,
)
from cannbotdsl.core.frontend.diagnostics import (
    FE401_STATE_STRUCTURE_MISMATCH,
    FE402_STATE_TYPE_MISMATCH,
    FE404_AMBIGUOUS_CARRIER_TYPE,
    FrontendError,
)
from cannbotdsl.core.frontend.runtime.hooks import RegionInfo
from cannbotdsl.core.scalar_conversion import materialize_literal, validate_literal


class BoundaryPolicy(str, Enum):
    STATE = "state"
    CONDITIONAL = "conditional"
    PARAMETER = "parameter"


class _TreeKind(str, Enum):
    TUPLE = "tuple"
    LIST = "list"
    DICT = "dict"
    LEAF = "leaf"
    NONE = "none"


class _CapturedLeafKind(str, Enum):
    DYNAMIC = "dynamic"
    LITERAL = "literal"


@dataclass(frozen=True, slots=True)
class ScalarLeafKey:
    dtype_name: str


@dataclass(frozen=True, slots=True)
class WrapperLeafKey:
    module: str
    qualname: str
    carrier_tag: str


@dataclass(frozen=True, slots=True)
class CarrierLeafKey:
    carrier_tag: str


@dataclass(frozen=True, slots=True)
class FrameworkLeafKey:
    semantic_tag: tuple[object, ...]
    carrier_tag: str


@dataclass(frozen=True, slots=True)
class AmbiguousLeafKey:
    module: str
    qualname: str
    carrier_tag: str


SemanticLeafKey = (
    ScalarLeafKey
    | WrapperLeafKey
    | CarrierLeafKey
    | FrameworkLeafKey
    | AmbiguousLeafKey
)


def _error(
    region_info: RegionInfo | None,
    code,
    message: str,
    hint: str,
) -> FrontendError:
    if region_info is not None:
        return region_info.error(code, message, hint=hint)
    return FrontendError(code, message, hint=hint)


def _semantic_leaf_key(value: object) -> SemanticLeafKey:
    """Return an MLIR-independent semantic identity for one SSA leaf."""

    framework_tag = semantic_value_tag(value)
    if framework_tag is not None:
        carriers = extract_ir_values(value)
        if len(carriers) != 1:  # pragma: no cover - closed current invariant
            raise TypeError("framework semantic leaves must have one carrier")
        return FrameworkLeafKey(framework_tag, str(carriers[0].type))
    if not isinstance(value, ir.Value):
        raise TypeError(f"semantic leaf key requires an ir.Value, got {type(value).__name__}")

    from cannbotdsl.core.contracts.elements import (
        element_for_dsl_type,
        element_for_integer,
        element_for_name,
    )

    try:
        info = element_for_dsl_type(type(value))
    except TypeError:
        info = None
    if info is not None:
        return ScalarLeafKey(info.dtype.name)

    value_type = type(value)
    from cannbotdsl.types._numeric import Float
    from cannbotdsl.types._numeric import Integer

    # Float carriers are canonical only when the registry proves a unique
    # carrier-to-dtype mapping.  There is intentionally no analogous signless
    # integer fallback.
    float_name = None
    if isinstance(value.type, ir.F16Type):
        float_name = "float16"
    elif isinstance(value.type, ir.F32Type):
        float_name = "float32"
    elif isinstance(value.type, ir.BF16Type):
        float_name = "bfloat16"
    if float_name is not None and value_type in {Float, ir.Value}:
        info = element_for_name(float_name)
        if info.mlir_scalar_name == str(value.type):
            return ScalarLeafKey(float_name)

    if isinstance(value.type, ir.IntegerType):
        width = value.type.width
        if width == 1:
            return ScalarLeafKey("bool")
        if value.type.is_signed or value.type.is_unsigned:
            signed = bool(value.type.is_signed)
            try:
                info = element_for_integer(width, signed)
            except TypeError:
                pass
            else:
                return ScalarLeafKey(info.dtype.name)
        if value_type in {Integer, ir.Value}:
            return AmbiguousLeafKey(
                value_type.__module__,
                value_type.__qualname__,
                str(value.type),
            )

    if value_type is ir.Value:
        return CarrierLeafKey(str(value.type))
    return WrapperLeafKey(value_type.__module__, value_type.__qualname__, str(value.type))


def _semantic_key_text(key: SemanticLeafKey) -> str:
    if isinstance(key, ScalarLeafKey):
        return key.dtype_name
    if isinstance(key, WrapperLeafKey):
        return f"wrapper {key.module}.{key.qualname}"
    if isinstance(key, AmbiguousLeafKey):
        return f"ambiguous {key.module}.{key.qualname} carrier {key.carrier_tag}"
    if isinstance(key, FrameworkLeafKey):
        return f"{key.semantic_tag[0]} carrier {key.carrier_tag}"
    return f"bare carrier {key.carrier_tag}"


def _semantic_key_identity(key: SemanticLeafKey) -> tuple:
    if isinstance(key, ScalarLeafKey):
        return ("scalar", key.dtype_name)
    if isinstance(key, WrapperLeafKey):
        return ("wrapper", key.module, key.qualname, key.carrier_tag)
    if isinstance(key, AmbiguousLeafKey):
        return ("ambiguous", key.module, key.qualname, key.carrier_tag)
    if isinstance(key, FrameworkLeafKey):
        return ("framework", key.semantic_tag, key.carrier_tag)
    return ("carrier", key.carrier_tag)


def _semantic_key_content_identity(key: SemanticLeafKey) -> tuple:
    """Return a deterministic boundary identity with no live object ids."""
    return _semantic_key_identity(key)


def _check_semantic_key(
    expected: SemanticLeafKey,
    actual: SemanticLeafKey,
    *,
    carrier: ir.Type,
    context: str,
    region_info: RegionInfo | None,
) -> None:
    if expected == actual:
        return
    ambiguous = isinstance(expected, (CarrierLeafKey, AmbiguousLeafKey)) or isinstance(
        actual, (CarrierLeafKey, AmbiguousLeafKey)
    )
    raise _error(
        region_info,
        FE404_AMBIGUOUS_CARRIER_TYPE if ambiguous else FE402_STATE_TYPE_MISMATCH,
        f"{context} changed semantic leaf type from "
        f"{_semantic_key_text(expected)} to {_semantic_key_text(actual)} "
        f"while both use MLIR carrier {carrier}.",
        (
            "Wrap the producer result in the intended canonical DSL value or "
            "cast it explicitly before the control-flow boundary."
            if ambiguous
            else "Cast the yielded value explicitly to the incoming semantic type."
        ),
    )


def _ambiguous_leaf_error(
    key: AmbiguousLeafKey,
    region_info: RegionInfo | None,
    context: str,
) -> FrontendError:
    return _error(
        region_info,
        FE404_AMBIGUOUS_CARRIER_TYPE,
        f"{context} has {_semantic_key_text(key)} with no recoverable integer signedness.",
        "Fix the producer to return a canonical Int/UInt/Boolean wrapper or cast explicitly.",
    )


def _is_numeric_literal(value: object) -> bool:
    return type(value) in {bool, int, float}


def _normalized_literal(literal: bool | int | float, value_type: ir.Type) -> bool | int | float:
    if isinstance(value_type, ir.IntegerType):
        if value_type.width == 1 and type(literal) is int and literal in {0, 1}:
            return bool(literal)
        if value_type.width != 1 and type(literal) is bool:
            return int(literal)
    if isinstance(value_type, ir.IndexType) and type(literal) is bool:
        return int(literal)
    if isinstance(value_type, (ir.F16Type, ir.F32Type, ir.F64Type, ir.BF16Type)) and type(literal) is bool:
        return int(literal)
    return literal


def _validate_literal(
    literal: bool | int | float,
    value_type: ir.Type,
    region_info: RegionInfo | None,
    *,
    semantic_unsigned: bool | None = None,
) -> None:
    try:
        validate_literal(
            _normalized_literal(literal, value_type),
            value_type,
            semantic_unsigned=semantic_unsigned,
        )
    except (TypeError, ValueError) as exc:
        raise _error(
            region_info,
            FE402_STATE_TYPE_MISMATCH,
            f"Cannot materialize literal {literal!r} as {value_type}: {exc}.",
            "Use a representable literal or cast the value explicitly.",
        ) from exc


def _materialize_literal(
    literal: bool | int | float,
    value_type: ir.Type,
    region_info: RegionInfo | None,
    *,
    semantic_unsigned: bool | None = None,
) -> ir.Value:
    _validate_literal(
        literal,
        value_type,
        region_info,
        semantic_unsigned=semantic_unsigned,
    )
    return materialize_literal(
        _normalized_literal(literal, value_type),
        value_type,
        semantic_unsigned=semantic_unsigned,
    )


def _default_literal_leaf(
    values: tuple[bool | int | float, ...],
    region_info: RegionInfo | None,
) -> "_LeafLayout":
    if any(type(value) is float for value in values):
        value_type = ir.F32Type.get()
        key = ScalarLeafKey("float32")
    elif all(type(value) is bool for value in values):
        value_type = ir.IntegerType.get_signless(1)
        key = ScalarLeafKey("bool")
    else:
        value_type = ir.IntegerType.get_signless(64)
        key = ScalarLeafKey("int64")
    for value in values:
        _validate_literal(value, value_type, region_info)
    return _LeafLayout(None, (value_type,), (key,))


def _default_dynamic_literal(value: bool | int | float) -> object:
    if type(value) is bool:
        from cannbotdsl.types._numeric import Boolean

        return Boolean(value)
    if type(value) is int:
        from cannbotdsl.types._numeric import Int64

        return Int64(value)
    from cannbotdsl.types._numeric import Float32

    return Float32(value)


def _semantic_unsigned(key: SemanticLeafKey) -> bool | None:
    if not isinstance(key, ScalarLeafKey):
        return None
    from cannbotdsl.core.contracts.elements import element_for_name

    return element_for_name(key.dtype_name).dtype.signed is False


@dataclass(frozen=True, slots=True)
class _LeafLayout:
    template: object | None
    types: tuple[ir.Type, ...]
    semantic_keys: tuple[SemanticLeafKey, ...]

    def __post_init__(self) -> None:
        if not self.types or len(self.types) != len(self.semantic_keys):
            raise ValueError("trace leaf MLIR types and semantic keys must be non-empty and equal length")

    def _cache_identity(self) -> tuple:
        return tuple(
            (str(value_type), _semantic_key_identity(key)) for value_type, key in zip(self.types, self.semantic_keys)
        )

    def _content_identity(self) -> tuple:
        return tuple(
            (str(value_type), _semantic_key_content_identity(key))
            for value_type, key in zip(self.types, self.semantic_keys)
        )

    @classmethod
    def capture_dynamic(
        cls,
        value: object,
        region_info: RegionInfo | None,
        *,
        context: str,
    ) -> tuple["_LeafLayout", tuple[ir.Value, ...]]:
        try:
            values = extract_ir_values(value)
        except TypeError:
            raise _error(
                region_info,
                FE402_STATE_TYPE_MISMATCH,
                f"{context} must be a supported semantic or SSA value, got {type(value).__name__}.",
                "Use a Python numeric literal or an explicitly typed DSL value.",
            )
        key = _semantic_leaf_key(value)
        if isinstance(key, AmbiguousLeafKey):
            raise _ambiguous_leaf_error(key, region_info, context)
        if len(values) != 1:  # pragma: no cover - closed current invariant
            raise AssertionError("one semantic leaf unexpectedly has multiple carriers")
        return cls(value, tuple(item.type for item in values), (key,)), values

    def validate_dynamic(
        self,
        value: object,
        *,
        context: str,
        region_info: RegionInfo | None,
    ) -> tuple[ir.Value, ...]:
        try:
            values = extract_ir_values(value)
            keys = (_semantic_leaf_key(value),)
        except TypeError:
            raise _error(
                region_info,
                FE402_STATE_TYPE_MISMATCH,
                f"{context} changed an SSA leaf to {type(value).__name__}.",
                "Keep every dynamic leaf at the same semantic DSL type.",
            )
        if len(values) != len(self.types):
            raise _error(
                region_info,
                FE401_STATE_STRUCTURE_MISMATCH,
                f"{context} changed a leaf from {len(self.types)} SSA values to {len(values)}.",
                "Keep the leaf count fixed across the boundary.",
            )
        for index, (actual, expected_type, expected_key, actual_key) in enumerate(
            zip(values, self.types, self.semantic_keys, keys)
        ):
            if actual.type != expected_type:
                raise _error(
                    region_info,
                    FE402_STATE_TYPE_MISMATCH,
                    f"{context} changed MLIR leaf {index} from {expected_type} to {actual.type}.",
                    "Cast the value explicitly to the incoming carrier type.",
                )
            _check_semantic_key(
                expected_key,
                actual_key,
                carrier=actual.type,
                context=f"{context} leaf {index}",
                region_info=region_info,
            )
        return values

    def materialize_literal(
        self,
        literal: bool | int | float,
        region_info: RegionInfo | None,
    ) -> tuple[ir.Value, ...]:
        if len(self.types) != 1:
            raise _error(
                region_info,
                FE401_STATE_STRUCTURE_MISMATCH,
                "One Python literal cannot match a multi-value leaf.",
                "Return matching values from both paths.",
            )
        key = self.semantic_keys[0]
        if isinstance(key, AmbiguousLeafKey) or (
            isinstance(key, CarrierLeafKey) and isinstance(self.types[0], ir.IntegerType)
        ):
            raise _error(
                region_info,
                FE404_AMBIGUOUS_CARRIER_TYPE,
                f"A Python literal cannot recover semantics from {_semantic_key_text(key)}.",
                "Cast the literal and producer to an explicit DSL scalar type.",
            )
        return (
            _materialize_literal(
                literal,
                self.types[0],
                region_info,
                semantic_unsigned=_semantic_unsigned(key),
            ),
        )

    def rebuild(self, values: tuple[ir.Value, ...]) -> object:
        value = values[0]
        key = self.semantic_keys[0]
        if isinstance(key, FrameworkLeafKey):
            return rebuild_ir_values(self.template, values)
        if isinstance(key, ScalarLeafKey):
            from cannbotdsl.core.contracts.elements import element_for_name

            return element_for_name(key.dtype_name).dsl_type(value)
        if isinstance(key, CarrierLeafKey):
            return value
        if isinstance(key, AmbiguousLeafKey):
            raise _ambiguous_leaf_error(key, None, "trace result")
        template_type = type(self.template)
        if template_type.__module__ != key.module or template_type.__qualname__ != key.qualname:
            raise RuntimeError("wrapper template does not match semantic key")
        return template_type(value)


@dataclass(frozen=True, slots=True)
class _CapturedLeaf:
    kind: _CapturedLeafKind
    dynamic_layout: _LeafLayout | None = None
    dynamic_values: tuple[ir.Value, ...] = ()
    literal: bool | int | float | None = None


@dataclass(frozen=True, slots=True)
class _CapturedValueTree:
    kind: _TreeKind
    children: tuple["_CapturedValueTree", ...] = ()
    keys: tuple[object, ...] = ()
    key_identities: tuple[object, ...] = ()
    leaf: _CapturedLeaf | None = None


def _capture_tree(
    value: object,
    policy: BoundaryPolicy,
    region_info: RegionInfo | None,
    *,
    path: str,
) -> _CapturedValueTree:
    if type(value) is tuple:
        return _CapturedValueTree(
            _TreeKind.TUPLE,
            tuple(
                _capture_tree(child, policy, region_info, path=f"{path}[{index}]") for index, child in enumerate(value)
            ),
        )
    if type(value) is list:
        return _CapturedValueTree(
            _TreeKind.LIST,
            tuple(
                _capture_tree(child, policy, region_info, path=f"{path}[{index}]") for index, child in enumerate(value)
            ),
        )
    if type(value) is dict:
        keys = tuple(value.keys())
        try:
            key_identities = tuple(encode_primitive(key) for key in keys)
        except TypeError as exc:
            raise _error(
                region_info,
                FE401_STATE_STRUCTURE_MISMATCH,
                f"{path} has a non-canonical dictionary key: {exc}.",
                "Use only closed primitive dictionary keys in dynamic values.",
            ) from exc
        return _CapturedValueTree(
            _TreeKind.DICT,
            tuple(_capture_tree(value[key], policy, region_info, path=f"{path}[{key!r}]") for key in keys),
            keys=keys,
            key_identities=key_identities,
        )
    if value is None:
        if policy is BoundaryPolicy.CONDITIONAL:
            return _CapturedValueTree(_TreeKind.NONE)
        raise _error(
            region_info,
            FE402_STATE_TYPE_MISMATCH,
            f"{path} cannot carry None through a {policy.value} boundary.",
            "Use matching None only in a conditional expression or remove it from dynamic state.",
        )
    if _is_numeric_literal(value) and policy is BoundaryPolicy.CONDITIONAL:
        return _CapturedValueTree(
            _TreeKind.LEAF,
            leaf=_CapturedLeaf(_CapturedLeafKind.LITERAL, literal=value),
        )
    if _is_numeric_literal(value):
        value = _default_dynamic_literal(value)
    layout, values = _LeafLayout.capture_dynamic(value, region_info, context=path)
    return _CapturedValueTree(
        _TreeKind.LEAF,
        leaf=_CapturedLeaf(
            _CapturedLeafKind.DYNAMIC,
            dynamic_layout=layout,
            dynamic_values=values,
        ),
    )


def _single_layout(
    captured: _CapturedValueTree,
    region_info: RegionInfo | None,
) -> "ValueTreeLayout":
    if captured.kind is _TreeKind.LEAF:
        assert captured.leaf is not None
        leaf = captured.leaf
        if leaf.kind is _CapturedLeafKind.DYNAMIC:
            assert leaf.dynamic_layout is not None
            return ValueTreeLayout(_TreeKind.LEAF, leaf=leaf.dynamic_layout)
        assert leaf.literal is not None
        return ValueTreeLayout(
            _TreeKind.LEAF,
            leaf=_default_literal_leaf((leaf.literal,), region_info),
        )
    return ValueTreeLayout(
        captured.kind,
        tuple(_single_layout(child, region_info) for child in captured.children),
        keys=captured.keys,
        key_identities=captured.key_identities,
    )


def _reconcile_trees(
    lhs: _CapturedValueTree,
    rhs: _CapturedValueTree,
    region_info: RegionInfo | None,
    *,
    path: str,
) -> "ValueTreeLayout":
    if lhs.kind is _TreeKind.NONE or rhs.kind is _TreeKind.NONE:
        if lhs.kind is rhs.kind:
            return ValueTreeLayout(_TreeKind.NONE)
        raise _error(
            region_info,
            FE402_STATE_TYPE_MISMATCH,
            f"Conditional {path} returns None on only one path.",
            "Return matching None or matching dynamic values from both paths.",
        )
    if lhs.kind is not rhs.kind:
        raise _error(
            region_info,
            FE401_STATE_STRUCTURE_MISMATCH,
            f"Conditional {path} structure differs: {lhs.kind.value} versus {rhs.kind.value}.",
            "Return the same container kind and exact shape from both paths.",
        )
    if lhs.kind is _TreeKind.LEAF:
        assert lhs.leaf is not None and rhs.leaf is not None
        lhs_dynamic = lhs.leaf.kind is _CapturedLeafKind.DYNAMIC
        rhs_dynamic = rhs.leaf.kind is _CapturedLeafKind.DYNAMIC
        if lhs_dynamic and rhs_dynamic:
            assert lhs.leaf.dynamic_layout is not None
            assert rhs.leaf.dynamic_layout is not None
            left = lhs.leaf.dynamic_layout
            right = rhs.leaf.dynamic_layout
            if left.types != right.types:
                raise _error(
                    region_info,
                    FE402_STATE_TYPE_MISMATCH,
                    f"Conditional {path} has different MLIR types: {left.types!s} versus {right.types!s}.",
                    "Cast both values explicitly to the same DSL type.",
                )
            if len(left.semantic_keys) != len(right.semantic_keys):
                raise _error(
                    region_info,
                    FE401_STATE_STRUCTURE_MISMATCH,
                    f"Conditional {path} has different semantic leaf counts.",
                    "Return the same semantic leaf structure from both paths.",
                )
            for index, (expected, actual) in enumerate(zip(left.semantic_keys, right.semantic_keys)):
                _check_semantic_key(
                    expected,
                    actual,
                    carrier=left.types[index],
                    context=f"Conditional {path} leaf {index}",
                    region_info=region_info,
                )
            leaf = left
        elif lhs_dynamic or rhs_dynamic:
            dynamic = lhs.leaf if lhs_dynamic else rhs.leaf
            literal = rhs.leaf if lhs_dynamic else lhs.leaf
            assert dynamic.dynamic_layout is not None
            assert literal.literal is not None
            dynamic.dynamic_layout.materialize_literal(literal.literal, region_info)
            leaf = dynamic.dynamic_layout
        else:
            assert lhs.leaf.literal is not None and rhs.leaf.literal is not None
            leaf = _default_literal_leaf((lhs.leaf.literal, rhs.leaf.literal), region_info)
        return ValueTreeLayout(_TreeKind.LEAF, leaf=leaf)
    if lhs.kind is _TreeKind.DICT and lhs.key_identities != rhs.key_identities:
        raise _error(
            region_info,
            FE401_STATE_STRUCTURE_MISMATCH,
            f"Conditional {path} dictionary keys or order differ.",
            "Return dictionaries with the same keys in the same insertion order.",
        )
    if len(lhs.children) != len(rhs.children):
        raise _error(
            region_info,
            FE401_STATE_STRUCTURE_MISMATCH,
            f"Conditional {path} lengths differ: {len(lhs.children)} versus {len(rhs.children)}.",
            "Return containers with the same exact length.",
        )
    keys = lhs.keys if lhs.kind is _TreeKind.DICT else ()
    children = tuple(
        _reconcile_trees(
            left,
            right,
            region_info,
            path=(f"{path}[{keys[index]!r}]" if keys else f"{path}[{index}]"),
        )
        for index, (left, right) in enumerate(zip(lhs.children, rhs.children))
    )
    return ValueTreeLayout(
        lhs.kind,
        children,
        keys=lhs.keys,
        key_identities=lhs.key_identities,
    )


@dataclass(frozen=True, slots=True)
class ValueTreeLayout:
    kind: _TreeKind
    children: tuple["ValueTreeLayout", ...] = ()
    keys: tuple[object, ...] = ()
    key_identities: tuple[object, ...] = ()
    leaf: _LeafLayout | None = None

    @classmethod
    def capture(
        cls,
        value: object,
        region_info: RegionInfo | None = None,
        *,
        policy: BoundaryPolicy = BoundaryPolicy.STATE,
    ) -> "ValueTreeLayout":
        captured = _capture_tree(value, policy, region_info, path=policy.value)
        return _single_layout(captured, region_info)

    @classmethod
    def capture_with_values(
        cls,
        value: object,
        region_info: RegionInfo | None = None,
        *,
        policy: BoundaryPolicy = BoundaryPolicy.STATE,
    ) -> tuple["ValueTreeLayout", tuple[ir.Value, ...]]:
        captured = _capture_tree(value, policy, region_info, path=policy.value)
        layout = _single_layout(captured, region_info)
        return layout, layout._materialize(captured, region_info)

    @classmethod
    def reconcile(
        cls,
        lhs: object,
        rhs: object,
        region_info: RegionInfo | None = None,
        *,
        policy: BoundaryPolicy = BoundaryPolicy.CONDITIONAL,
    ) -> tuple["ValueTreeLayout", tuple[ir.Value, ...], tuple[ir.Value, ...]]:
        if policy is not BoundaryPolicy.CONDITIONAL:
            raise ValueError("ValueTreeLayout.reconcile is only valid for CONDITIONAL")
        left = _capture_tree(lhs, policy, region_info, path="conditional true branch")
        right = _capture_tree(rhs, policy, region_info, path="conditional false branch")
        layout = _reconcile_trees(left, right, region_info, path="result")
        return (
            layout,
            layout._materialize(left, region_info),
            layout._materialize(right, region_info),
        )

    @property
    def leaf_count(self) -> int:
        if self.kind is _TreeKind.NONE:
            return 0
        if self.kind is _TreeKind.LEAF:
            assert self.leaf is not None
            return len(self.leaf.types)
        return sum(child.leaf_count for child in self.children)

    @property
    def mlir_types(self) -> tuple[ir.Type, ...]:
        if self.kind is _TreeKind.NONE:
            return ()
        if self.kind is _TreeKind.LEAF:
            assert self.leaf is not None
            return self.leaf.types
        return tuple(item for child in self.children for item in child.mlir_types)

    def _cache_identity(self) -> tuple:
        if self.kind is _TreeKind.NONE:
            return ("none",)
        if self.kind is _TreeKind.LEAF:
            assert self.leaf is not None
            return ("leaf", self.leaf._cache_identity())
        children = tuple(child._cache_identity() for child in self.children)
        if self.kind is _TreeKind.DICT:
            return ("dict", self.key_identities, children)
        return (self.kind.value, children)

    def _content_identity(self) -> tuple:
        if self.kind is _TreeKind.NONE:
            return ("none",)
        if self.kind is _TreeKind.LEAF:
            assert self.leaf is not None
            return ("leaf", self.leaf._content_identity())
        children = tuple(child._content_identity() for child in self.children)
        if self.kind is _TreeKind.DICT:
            return ("dict", self.key_identities, children)
        return (self.kind.value, children)

    def _raise_structure(
        self,
        value: object,
        context: str,
        region_info: RegionInfo | None,
    ) -> None:
        actual = type(value).__name__
        if type(value) in {tuple, list, dict}:
            actual += f"[{len(value)}]"
        expected = self.kind.value
        if self.kind is _TreeKind.DICT:
            expected += f"{self.keys!r}"
        elif self.kind not in {_TreeKind.LEAF, _TreeKind.NONE}:
            expected += f"[{len(self.children)}]"
        raise _error(
            region_info,
            FE401_STATE_STRUCTURE_MISMATCH,
            f"{context} structure mismatch: expected {expected}, got {actual}.",
            "Keep container kind, length, and dictionary order fixed.",
        )

    def flatten(
        self,
        value: object,
        *,
        context: str = "region yield",
        region_info: RegionInfo | None = None,
    ) -> tuple[ir.Value, ...]:
        if self.kind is _TreeKind.NONE:
            if value is not None:
                self._raise_structure(value, context, region_info)
            return ()
        if self.kind is _TreeKind.LEAF:
            assert self.leaf is not None
            if _is_numeric_literal(value):
                return self.leaf.materialize_literal(value, region_info)
            if type(value) in {tuple, list, dict} or value is None:
                self._raise_structure(value, context, region_info)
            return self.leaf.validate_dynamic(value, context=context, region_info=region_info)
        if self.kind is _TreeKind.TUPLE:
            if type(value) is not tuple or len(value) != len(self.children):
                self._raise_structure(value, context, region_info)
            items = value
        elif self.kind is _TreeKind.LIST:
            if type(value) is not list or len(value) != len(self.children):
                self._raise_structure(value, context, region_info)
            items = value
        elif self.kind is _TreeKind.DICT:
            if type(value) is not dict:
                self._raise_structure(value, context, region_info)
            try:
                actual_keys = tuple(encode_primitive(key) for key in value.keys())
            except TypeError:
                self._raise_structure(value, context, region_info)
            if actual_keys != self.key_identities:
                self._raise_structure(value, context, region_info)
            items = tuple(value[key] for key in value)
        else:  # pragma: no cover - enum exhaustiveness
            raise AssertionError(f"unknown value-tree kind {self.kind!r}")
        return tuple(
            leaf
            for child, item in zip(self.children, items)
            for leaf in child.flatten(item, context=context, region_info=region_info)
        )

    def _materialize(
        self,
        captured: _CapturedValueTree,
        region_info: RegionInfo | None,
    ) -> tuple[ir.Value, ...]:
        if self.kind is _TreeKind.NONE:
            return ()
        if self.kind is _TreeKind.LEAF:
            assert self.leaf is not None and captured.leaf is not None
            if captured.leaf.kind is _CapturedLeafKind.LITERAL:
                assert captured.leaf.literal is not None
                return self.leaf.materialize_literal(captured.leaf.literal, region_info)
            assert captured.leaf.dynamic_layout is not None
            # Revalidate through semantic keys so producer mistakes cannot
            # bypass reconciliation merely because the values were captured.
            values = captured.leaf.dynamic_values
            for index, (actual, expected_type, expected_key, actual_key) in enumerate(
                zip(
                    values,
                    self.leaf.types,
                    self.leaf.semantic_keys,
                    captured.leaf.dynamic_layout.semantic_keys,
                )
            ):
                if actual.type != expected_type:
                    raise _error(
                        region_info,
                        FE402_STATE_TYPE_MISMATCH,
                        f"Captured leaf {index} has {actual.type}, expected {expected_type}.",
                        "Cast both paths to the same physical type.",
                    )
                _check_semantic_key(
                    expected_key,
                    actual_key,
                    carrier=actual.type,
                    context=f"captured leaf {index}",
                    region_info=region_info,
                )
            return values
        return tuple(
            value
            for child, captured_child in zip(self.children, captured.children)
            for value in child._materialize(captured_child, region_info)
        )

    def rebuild(self, values: tuple[ir.Value, ...] | list[ir.Value]) -> object:
        flat = tuple(values)
        if len(flat) != self.leaf_count:
            raise ValueError(f"ValueTreeLayout expected {self.leaf_count} values, got {len(flat)}")
        iterator = iter(flat)
        result = self._rebuild(iterator)
        try:
            next(iterator)
        except StopIteration:
            return result
        raise AssertionError("ValueTreeLayout rebuild left unconsumed values")

    def _rebuild(self, values: Iterator[ir.Value]) -> object:
        if self.kind is _TreeKind.NONE:
            return None
        if self.kind is _TreeKind.TUPLE:
            return tuple(child._rebuild(values) for child in self.children)
        if self.kind is _TreeKind.LIST:
            return [child._rebuild(values) for child in self.children]
        if self.kind is _TreeKind.DICT:
            return {key: child._rebuild(values) for key, child in zip(self.keys, self.children)}
        assert self.leaf is not None
        leaf_values = tuple(next(values) for _ in self.leaf.types)
        return self.leaf.rebuild(leaf_values)
