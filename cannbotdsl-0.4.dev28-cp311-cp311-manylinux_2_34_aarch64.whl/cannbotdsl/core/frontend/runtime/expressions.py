# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Lazy dynamic expression semantics and eager public ``select``."""

from __future__ import annotations

import builtins
from collections.abc import Iterable, Sequence
from contextlib import contextmanager
import operator
from typing import Callable, Iterator

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import arith, scf

from cannbotdsl.core.frontend.diagnostics import (
    FE401_STATE_STRUCTURE_MISMATCH,
    FE402_STATE_TYPE_MISMATCH,
    FrontendError,
)
from cannbotdsl.core.frontend.runtime.control_flow import (
    to_i1,
    to_mlir_value,
)
from cannbotdsl.core.frontend.runtime.hooks import (
    _detach_on_failure,
    _DeferredRegionOperation,
    RegionInfo,
    region_child_scope,
    region_hook_scope,
)
from cannbotdsl.core.frontend.runtime.value_tree_layout import ValueTreeLayout
from cannbotdsl.core.frontend.runtime.trace_value import is_trace_value
from cannbotdsl.core.scalar_conversion import materialize_literal


def _is_dynamic(value: object) -> bool:
    return is_trace_value(value)


def bool_cast(value: object) -> bool | ir.Value:
    if isinstance(value, bool):
        return value
    if _is_dynamic(value):
        return to_i1(value, context="boolean expression")
    return bool(value)


def _as_boolean(value: bool | ir.Value):
    if isinstance(value, bool):
        return value
    from cannbotdsl.types._numeric import Boolean

    return Boolean(value)


@contextmanager
def _source_location(region_info: RegionInfo) -> Iterator[None]:
    if not region_info.emit_line_info:
        yield
        return
    with ir.Location.file(
        region_info.span.filename,
        region_info.span.start_line,
        region_info.span.display_start_col,
    ):
        yield


def _lazy_boolean_if(
    predicate: ir.Value,
    then_fn: Callable[[], object],
    else_fn: Callable[[], object],
    region_info: RegionInfo,
) -> object:
    i1 = ir.IntegerType.get_signless(1)
    operation = scf.IfOp(predicate, [i1], hasElse=True)
    with _detach_on_failure(operation):
        with region_hook_scope("if", operation, region_info):
            with region_child_scope("if", "then", operation, region_info):
                with ir.InsertionPoint(operation.then_block):
                    then_value = bool_cast(then_fn())
                    scf.YieldOp([to_i1(then_value, context="lazy then result")])
            with region_child_scope("if", "else", operation, region_info):
                with ir.InsertionPoint(operation.else_block):
                    else_value = bool_cast(else_fn())
                    scf.YieldOp([to_i1(else_value, context="lazy else result")])
    return _as_boolean(operation.results[0])


def boolop(
    op_name: str,
    operands: Sequence[Callable[[], object]],
    region_info: RegionInfo,
) -> object:
    """Evaluate Python ``and``/``or`` lazily, outlining dynamic tails."""

    if op_name not in {"And", "Or"}:
        raise ValueError(f"Unsupported BoolOp {op_name!r}")
    if not operands:
        return op_name == "And"

    def evaluate(index: int) -> object:
        value = operands[index]()
        if index == len(operands) - 1:
            predicate = bool_cast(value)
            return value if isinstance(predicate, bool) else _as_boolean(predicate)
        predicate = bool_cast(value)
        if isinstance(predicate, bool):
            if op_name == "And":
                return evaluate(index + 1) if predicate else value
            return value if predicate else evaluate(index + 1)
        if op_name == "And":
            return _lazy_boolean_if(
                predicate,
                lambda: evaluate(index + 1),
                lambda: False,
                region_info,
            )
        return _lazy_boolean_if(
            predicate,
            lambda: True,
            lambda: evaluate(index + 1),
            region_info,
        )

    return evaluate(0)


_COMPARISON_OPERATORS: dict[str, Callable[[object, object], object]] = {
    "Eq": operator.eq,
    "NotEq": operator.ne,
    "Lt": operator.lt,
    "LtE": operator.le,
    "Gt": operator.gt,
    "GtE": operator.ge,
    "Is": operator.is_,
    "IsNot": operator.is_not,
    "In": lambda lhs, rhs: lhs in rhs,
    "NotIn": lambda lhs, rhs: lhs not in rhs,
}


def comparison(
    left_fn: Callable[[], object],
    comparator_fns: Sequence[Callable[[], object]],
    operators: Sequence[str],
    region_info: RegionInfo,
) -> object:
    """Evaluate a chained comparison with CPython-compatible laziness."""

    if len(comparator_fns) != len(operators):
        raise ValueError("comparison requires the same number of comparators and operators")
    left = left_fn()

    def evaluate(index: int, current: object) -> object:
        right = comparator_fns[index]()
        op_name = operators[index]
        try:
            operation = _COMPARISON_OPERATORS[op_name]
        except KeyError as exc:
            raise ValueError(f"Unsupported comparison operator {op_name!r}") from exc
        predicate = bool_cast(operation(current, right))
        if index == len(operators) - 1:
            return _as_boolean(predicate)
        if isinstance(predicate, bool):
            if not predicate:
                return False
            return evaluate(index + 1, right)
        return _lazy_boolean_if(
            predicate,
            lambda: evaluate(index + 1, right),
            lambda: False,
            region_info,
        )

    if not operators:
        return True
    return evaluate(0, left)


def logical_not(value: object) -> object:
    predicate = bool_cast(value)
    if isinstance(predicate, bool):
        return not predicate
    one = arith.ConstantOp(ir.IntegerType.get_signless(1), 1).result
    return _as_boolean(arith.XOrIOp(predicate, one).result)


def if_expression(
    predicate: object,
    then_fn: Callable[[], object],
    else_fn: Callable[[], object],
    region_info: RegionInfo,
) -> object:
    pred = bool_cast(predicate)
    if isinstance(pred, bool):
        return then_fn() if pred else else_fn()

    # The branch result types are not known until both Python thunks have been
    # traced.  Build into a detached result-less scf.if first, then attach a
    # correctly typed operation only after the branch contract is validated.
    # This keeps all branch IR transactional on errors.
    with _source_location(region_info):
        staging = scf.IfOp(pred, [], hasElse=True)
    staging.detach_from_parent()
    deferred = _DeferredRegionOperation(staging)
    final_operation = None
    final_attached = False

    try:
        with region_hook_scope("if", deferred, region_info):
            with _source_location(region_info):
                with region_child_scope("if", "then", deferred, region_info):
                    with ir.InsertionPoint(staging.then_block):
                        true_value = then_fn()
                with region_child_scope("if", "else", deferred, region_info):
                    with ir.InsertionPoint(staging.else_block):
                        false_value = else_fn()
            layout, true_values, false_values = ValueTreeLayout.reconcile(
                true_value, false_value, region_info
            )
            with _source_location(region_info):
                with ir.InsertionPoint(staging.then_block):
                    scf.YieldOp(list(true_values))
                with ir.InsertionPoint(staging.else_block):
                    scf.YieldOp(list(false_values))

                final_operation = scf.IfOp(pred, list(layout.mlir_types), hasElse=True)
                final_attached = True

            for source, target in (
                (staging.then_block, final_operation.then_block),
                (staging.else_block, final_operation.else_block),
            ):
                for child_operation in list(source.operations):
                    target.append(child_operation)
            deferred.bind(final_operation)
            result = layout.rebuild(tuple(final_operation.results))
        return result
    except BaseException:
        if final_operation is not None and final_attached:
            final_operation.detach_from_parent()
        raise


def any_all(
    name: str,
    operands: tuple[Callable[[], object], ...] | list[Callable[[], object]],
    region_info: RegionInfo,
) -> object:
    if not isinstance(operands, (tuple, list)):
        raise region_info.error(
            FE401_STATE_STRUCTURE_MISMATCH,
            f"Dynamic {name} requires a fixed tuple or list expression.",
            hint="Replace the generator or iterator with a literal tuple/list.",
        )
    return boolop("Or" if name == "any" else "And", tuple(operands), region_info)


def _is_float_type(value_type: ir.Type) -> bool:
    return isinstance(value_type, (ir.F16Type, ir.F32Type, ir.F64Type, ir.BF16Type))


def _is_integer_type(value_type: ir.Type) -> bool:
    return isinstance(value_type, (ir.IntegerType, ir.IndexType))


def _is_semantically_unsigned(value: object) -> bool:
    if bool(getattr(value, "unsigned", False)):
        return True
    value_type = getattr(value, "type", None)
    return isinstance(value_type, ir.IntegerType) and value_type.is_unsigned


def _rebuild_scalar(template: object, result: ir.Value) -> object:
    if isinstance(template, ir.Value) and type(template) is not ir.Value:
        return type(template)(result)
    return result


def _dynamic_minmax(name: str, lhs: object, rhs: object) -> object:
    lhs_dynamic = _is_dynamic(lhs)
    rhs_dynamic = _is_dynamic(rhs)
    if lhs_dynamic:
        lhs_value = to_mlir_value(lhs, context=f"{name} operand")
        rhs_value = (
            to_mlir_value(rhs, context=f"{name} operand")
            if rhs_dynamic
            else materialize_literal(
                rhs,
                lhs_value.type,
                semantic_unsigned=bool(getattr(lhs, "unsigned", False)),
            )
        )
        template = lhs
    else:
        rhs_value = to_mlir_value(rhs, context=f"{name} operand")
        lhs_value = materialize_literal(
            lhs,
            rhs_value.type,
            semantic_unsigned=bool(getattr(rhs, "unsigned", False)),
        )
        template = rhs
    if lhs_value.type != rhs_value.type:
        raise TypeError(
            f"{name}() operands type mismatch: {lhs_value.type} versus "
            f"{rhs_value.type}. Cast explicitly before calling {name}()."
        )
    if _is_integer_type(lhs_value.type):
        if isinstance(lhs_value.type, ir.IntegerType) and lhs_value.type.width == 1:
            raise TypeError(f"builtin {name}() does not accept dynamic Boolean values")
        lhs_unsigned = _is_semantically_unsigned(lhs)
        rhs_unsigned = _is_semantically_unsigned(rhs)
        if lhs_dynamic and rhs_dynamic and lhs_unsigned != rhs_unsigned:
            raise TypeError(f"{name}() operands have different resolved signedness; cast one operand explicitly")
        unsigned = lhs_unsigned if lhs_dynamic else rhs_unsigned
        if name == "min":
            result = arith.minui(lhs_value, rhs_value) if unsigned else arith.minsi(lhs_value, rhs_value)
        else:
            result = arith.maxui(lhs_value, rhs_value) if unsigned else arith.maxsi(lhs_value, rhs_value)
    elif _is_float_type(lhs_value.type):
        result = arith.minnumf(lhs_value, rhs_value) if name == "min" else arith.maxnumf(lhs_value, rhs_value)
    else:
        raise TypeError(f"builtin {name}() only supports scalar integer/index/float values, got {lhs_value.type}")
    return _rebuild_scalar(template, result)


def minmax(name: str, *args: object, **kwargs: object) -> object:
    if name not in {"min", "max"}:
        raise ValueError(f"Unsupported minmax builtin {name!r}")
    values: list[object]
    if len(args) == 1 and isinstance(args[0], Iterable) and not _is_dynamic(args[0]):
        values = list(args[0])
    else:
        values = list(args)
    if kwargs:
        if any(_is_dynamic(value) for value in values):
            raise ValueError(f"builtin {name}() keyword arguments are not supported for dynamic DSL values")
        return getattr(builtins, name)(*args, **kwargs)
    if not values:
        raise ValueError(f"{name}() arg is an empty sequence")

    result = values[0]
    for candidate in values[1:]:
        if _is_dynamic(result) or _is_dynamic(candidate):
            result = _dynamic_minmax(name, result, candidate)
        elif name == "min":
            result = candidate if candidate < result else result
        else:
            result = candidate if candidate > result else result
    return result


def dynamic_getitem(container: object, key: object) -> object:
    if not _is_dynamic(key):
        return container[key]
    if isinstance(container, (tuple, list)):
        from cannbotdsl.tensor import tensor_select

        return tensor_select(container, key)
    return container[key]


def select(
    predicate: object,
    true_value: object,
    false_value: object,
    *,
    loc=None,
    ip=None,
) -> object:
    """Eagerly select matching ValueTrees with a DSL Boolean/i1 predicate."""

    if isinstance(predicate, bool):
        raise FrontendError(
            FE402_STATE_TYPE_MISMATCH,
            "select predicate must be a DSL Boolean/i1, got Python bool.",
            hint="Use ordinary Python control flow for a compile-time predicate.",
        )
    pred = to_mlir_value(predicate, context="select predicate")
    if not isinstance(pred.type, ir.IntegerType) or pred.type.width != 1:
        raise FrontendError(
            FE402_STATE_TYPE_MISMATCH,
            f"select predicate must be a DSL Boolean/i1, got {pred.type}.",
            hint="Compare DSL values first to produce an i1 predicate.",
        )
    layout, true_values = ValueTreeLayout.capture_with_values(true_value)
    false_values = layout.flatten(
        false_value,
        context="select false value",
    )
    selected = tuple(arith.select(pred, lhs, rhs, loc=loc, ip=ip) for lhs, rhs in zip(true_values, false_values))
    return layout.rebuild(selected)


__all__ = [
    "any_all",
    "bool_cast",
    "boolop",
    "comparison",
    "dynamic_getitem",
    "if_expression",
    "logical_not",
    "minmax",
    "select",
]
