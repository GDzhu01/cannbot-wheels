# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Structured definite-assignment and liveness for outlined regions."""

from __future__ import annotations

import ast
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Iterable

from cannbotdsl.core.frontend.diagnostics import (
    FE201_UNBOUND_REGION_STATE,
    FE202_REGION_VALUE_ESCAPE,
    FrontendError,
)
from cannbotdsl.core.frontend.source import SourceUnit
from cannbotdsl.core.frontend.symbols import MarkerKind, SafeSymbolResolver

_TARGET_CACHE: ContextVar[dict[int, set[str]] | None] = ContextVar(
    "cannbotdsl_dataflow_target_cache",
    default=None,
)
_NAME_CACHE: ContextVar[
    dict[tuple[str, tuple[int, ...]], "_NameCollector"] | None
] = ContextVar("cannbotdsl_dataflow_name_cache", default=None)
_EXPRESSION_CACHE: ContextVar[dict[int, set[str]] | None] = ContextVar(
    "cannbotdsl_dataflow_expression_cache",
    default=None,
)
_SIMPLE_CACHE: ContextVar[
    dict[int, tuple[set[str], set[str]]] | None
] = ContextVar("cannbotdsl_dataflow_simple_cache", default=None)


def _argument_names(args: ast.arguments) -> set[str]:
    names = {
        arg.arg
        for arg in (*args.posonlyargs, *args.args, *args.kwonlyargs)
    }
    if args.vararg is not None:
        names.add(args.vararg.arg)
    if args.kwarg is not None:
        names.add(args.kwarg.arg)
    return names


def _target_names(node: ast.AST) -> set[str]:
    cache = _TARGET_CACHE.get()
    key = id(node)
    if cache is not None and key in cache:
        return cache[key]
    names = set(_names(node).stores)
    if cache is not None:
        cache[key] = names
    return names


class _NameCollector(ast.NodeVisitor):
    def __init__(self) -> None:
        self.loads: dict[str, tuple[int, int]] = {}
        self.stores: dict[str, tuple[int, int]] = {}

    @staticmethod
    def _position(node: ast.AST) -> tuple[int, int]:
        return (
            int(getattr(node, "lineno", 0)),
            int(getattr(node, "col_offset", 0)),
        )

    @staticmethod
    def _record(
        mapping: dict[str, tuple[int, int]], name: str, position: tuple[int, int]
    ) -> None:
        previous = mapping.get(name)
        if previous is None or position < previous:
            mapping[name] = position

    def visit_Name(self, node: ast.Name) -> None:
        if isinstance(node.ctx, ast.Load):
            self._record(self.loads, node.id, self._position(node))
        elif isinstance(node.ctx, (ast.Store, ast.Del)):
            self._record(self.stores, node.id, self._position(node))

    # Nested lexical scopes do not assign or load names in the outlined scope.
    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._record(self.stores, node.name, self._position(node))
        for decorator in node.decorator_list:
            self.visit(decorator)
        for default in (*node.args.defaults, *node.args.kw_defaults):
            if default is not None:
                self.visit(default)

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self._record(self.stores, node.name, self._position(node))
        for decorator in node.decorator_list:
            self.visit(decorator)
        for base in node.bases:
            self.visit(base)
        for keyword in node.keywords:
            self.visit(keyword.value)

    def visit_Lambda(self, node: ast.Lambda) -> None:
        return


def _names(node_or_nodes: ast.AST | Iterable[ast.AST]) -> _NameCollector:
    if isinstance(node_or_nodes, ast.AST):
        nodes = (node_or_nodes,)
        key = ("node", (id(node_or_nodes),))
    else:
        nodes = tuple(node_or_nodes)
        key = ("block", tuple(id(node) for node in nodes))
    cache = _NAME_CACHE.get()
    if cache is not None and key in cache:
        return cache[key]
    collector = _NameCollector()
    pending = list(nodes)
    while pending:
        node = pending.pop()
        if isinstance(node, ast.Name):
            position = collector._position(node)
            if isinstance(node.ctx, ast.Load):
                collector._record(collector.loads, node.id, position)
            elif isinstance(node.ctx, (ast.Store, ast.Del)):
                collector._record(collector.stores, node.id, position)
            continue
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            collector._record(
                collector.stores,
                node.name,
                collector._position(node),
            )
            pending.extend(node.decorator_list)
            pending.extend(
                default
                for default in (*node.args.defaults, *node.args.kw_defaults)
                if default is not None
            )
            continue
        if isinstance(node, ast.ClassDef):
            collector._record(
                collector.stores,
                node.name,
                collector._position(node),
            )
            pending.extend(node.decorator_list)
            pending.extend(node.bases)
            pending.extend(keyword.value for keyword in node.keywords)
            continue
        if isinstance(node, ast.Lambda):
            continue
        pending.extend(ast.iter_child_nodes(node))
    if cache is not None:
        cache[key] = collector
    return collector


def _expression_loads(node: ast.AST | None) -> set[str]:
    if node is None:
        return set()
    cache = _EXPRESSION_CACHE.get()
    key = id(node)
    if cache is not None and key in cache:
        return cache[key]
    loads = set(_names(node).loads)
    if cache is not None:
        cache[key] = loads
    return loads


def _simple_defs_uses(stmt: ast.stmt) -> tuple[set[str], set[str]]:
    """Return names killed/generated by a non-control-flow statement."""

    cache = _SIMPLE_CACHE.get()
    key = id(stmt)
    if cache is not None and key in cache:
        return cache[key]
    collector = _names(stmt)
    defs = set(collector.stores)
    uses = set(collector.loads)
    if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        defs = {stmt.name}
    elif isinstance(stmt, ast.AugAssign) and isinstance(
        stmt.target, ast.Name
    ):
        uses.add(stmt.target.id)
    result = (defs, uses)
    if cache is not None:
        cache[key] = result
    return result


class _Liveness:
    def __init__(self) -> None:
        self.live_out: dict[int, frozenset[str]] = {}

    def block(
        self, statements: list[ast.stmt], live_out: set[str]
    ) -> set[str]:
        live = set(live_out)
        for stmt in reversed(statements):
            self.live_out[id(stmt)] = frozenset(live)
            live = self.statement(stmt, live)
        return live

    def statement(self, stmt: ast.stmt, live_out: set[str]) -> set[str]:
        if isinstance(stmt, ast.If):
            body = self.block(stmt.body, set(live_out))
            orelse = self.block(stmt.orelse, set(live_out))
            return _expression_loads(stmt.test) | body | orelse

        if isinstance(stmt, ast.While):
            after_normal = self.block(stmt.orelse, set(live_out))
            header = after_normal | _expression_loads(stmt.test)
            while True:
                body_in = self.block(stmt.body, set(header))
                updated = (
                    after_normal | _expression_loads(stmt.test) | body_in
                )
                if updated == header:
                    return header
                header = updated

        if isinstance(stmt, (ast.For, ast.AsyncFor)):
            after_normal = self.block(stmt.orelse, set(live_out))
            target_defs = _target_names(stmt.target)
            header = after_normal | _expression_loads(stmt.iter)
            while True:
                body_in = self.block(stmt.body, set(header))
                updated = (
                    after_normal
                    | _expression_loads(stmt.iter)
                    | (body_in - target_defs)
                )
                if updated == header:
                    return header
                header = updated

        if isinstance(stmt, (ast.With, ast.AsyncWith)):
            body_in = self.block(stmt.body, set(live_out))
            defs: set[str] = set()
            uses: set[str] = set()
            for item in stmt.items:
                uses |= _expression_loads(item.context_expr)
                if item.optional_vars is not None:
                    defs |= _target_names(item.optional_vars)
            return uses | (body_in - defs)

        if isinstance(stmt, ast.Try):
            final_in = self.block(stmt.finalbody, set(live_out))
            orelse_in = self.block(stmt.orelse, set(final_in))
            paths = [self.block(stmt.body, set(orelse_in))]
            paths.extend(
                self.block(handler.body, set(final_in))
                | _expression_loads(handler.type)
                for handler in stmt.handlers
            )
            merged = set(final_in)
            for path in paths:
                merged |= path
            return merged

        if isinstance(stmt, ast.Assign):
            uses = _expression_loads(stmt.value)
            defs = _target_names(stmt.value)
            for target in stmt.targets:
                defs |= _target_names(target)
                if not isinstance(target, ast.Name):
                    uses |= _expression_loads(target)
            return uses | (set(live_out) - defs)

        if isinstance(stmt, ast.AnnAssign):
            uses = _expression_loads(stmt.annotation)
            uses |= _expression_loads(stmt.value)
            defs = (
                _target_names(stmt.value)
                if stmt.value is not None
                else set()
            )
            defs |= _target_names(stmt.target)
            if not isinstance(stmt.target, ast.Name):
                uses |= _expression_loads(stmt.target)
            return uses | (set(live_out) - defs)

        if isinstance(stmt, ast.AugAssign):
            uses = _expression_loads(stmt.value)
            defs = _target_names(stmt.value) | _target_names(stmt.target)
            if isinstance(stmt.target, ast.Name):
                uses.add(stmt.target.id)
            else:
                uses |= _expression_loads(stmt.target)
            return uses | (set(live_out) - defs)

        defs, uses = _simple_defs_uses(stmt)
        return uses | (set(live_out) - defs)


@dataclass(frozen=True, slots=True)
class _GuardDependency:
    root: str
    path: tuple[str, ...] = ()

    def contains(self, other: "_GuardDependency") -> bool:
        """Return whether writing self invalidates the other dependency."""

        return (
            self.root == other.root
            and len(self.path) <= len(other.path)
            and other.path[: len(self.path)] == self.path
        )


@dataclass(frozen=True, slots=True)
class _GuardBase:
    marker: MarkerKind
    argument: str
    dependencies: tuple[_GuardDependency, ...]


@dataclass(frozen=True, slots=True)
class _GuardAtom:
    base: _GuardBase
    dependency_versions: tuple[tuple[_GuardDependency, int], ...]
    polarity: bool

    def opposite(self) -> "_GuardAtom":
        return _GuardAtom(
            self.base,
            self.dependency_versions,
            not self.polarity,
        )


_GuardConjunction = frozenset[_GuardAtom]


def _has_guard_contradiction(guards: _GuardConjunction) -> bool:
    return any(guard.opposite() in guards for guard in guards)


def _normalize_guard_facts(
    facts: Iterable[_GuardConjunction],
) -> set[_GuardConjunction]:
    """Return a deterministic irredundant DNF for definition guards."""

    current = {
        fact for fact in facts if not _has_guard_contradiction(fact)
    }
    while True:
        absorbed = {
            fact
            for fact in current
            if not any(other < fact for other in current)
        }
        generated: set[_GuardConjunction] = set()
        ordered = sorted(
            absorbed,
            key=lambda fact: (
                len(fact),
                tuple(
                    sorted(
                        (
                            guard.base.marker.value,
                            guard.base.argument,
                            tuple(
                                (
                                    dependency.root,
                                    dependency.path,
                                    version,
                                )
                                for dependency, version in (
                                    guard.dependency_versions
                                )
                            ),
                            guard.polarity,
                        )
                        for guard in fact
                    )
                ),
            ),
        )
        for index, left in enumerate(ordered):
            for right in ordered[index + 1 :]:
                common = left & right
                left_only = left - common
                right_only = right - common
                if (
                    len(left_only) == 1
                    and len(right_only) == 1
                    and next(iter(left_only)).opposite()
                    == next(iter(right_only))
                ):
                    generated.add(frozenset(common))
        updated = {
            fact
            for fact in absorbed | generated
            if not any(
                other < fact for other in absorbed | generated
            )
        }
        if updated == current:
            return updated
        current = updated


@dataclass(slots=True)
class _DefinitionState:
    facts: dict[str, set[_GuardConjunction]]
    versions: dict[_GuardDependency, int]

    @classmethod
    def initial(cls, names: Iterable[str]) -> "_DefinitionState":
        return cls(
            {name: {frozenset()} for name in names},
            {},
        )

    def copy(self) -> "_DefinitionState":
        return _DefinitionState(
            {name: set(facts) for name, facts in self.facts.items()},
            dict(self.versions),
        )

    def version(self, dependency: _GuardDependency) -> int:
        return self.versions.get(dependency, 0)

    def register(
        self, dependencies: Iterable[_GuardDependency]
    ) -> None:
        for dependency in dependencies:
            self.versions.setdefault(dependency, 0)

    def available(self, active: _GuardConjunction) -> set[str]:
        if _has_guard_contradiction(active):
            return set(self.facts)
        return {
            name
            for name, facts in self.facts.items()
            if any(fact <= active for fact in facts)
        }

    def define(
        self, names: Iterable[str], active: _GuardConjunction
    ) -> None:
        if _has_guard_contradiction(active):
            return
        for name in names:
            existing = self.facts.get(name, set())
            self.facts[name] = _normalize_guard_facts(
                (*existing, frozenset(active))
            )

    def undefine(self, names: Iterable[str]) -> None:
        for name in names:
            self.facts.pop(name, None)

    def mutate(self, writes: Iterable[_GuardDependency]) -> None:
        for write in writes:
            affected = {
                dependency
                for dependency in self.versions
                if write.contains(dependency)
            }
            affected.add(write)
            for dependency in affected:
                self.versions[dependency] = (
                    self.version(dependency) + 1
                )


def _dependency_path(node: ast.AST) -> _GuardDependency | None:
    if isinstance(node, ast.Name):
        return _GuardDependency(node.id)
    if isinstance(node, ast.Attribute):
        base = _dependency_path(node.value)
        if base is not None:
            return _GuardDependency(
                base.root,
                (*base.path, f".{node.attr}"),
            )
    if isinstance(node, ast.Subscript):
        base = _dependency_path(node.value)
        if base is not None:
            return _GuardDependency(
                base.root,
                (
                    *base.path,
                    "["
                    + ast.dump(
                        node.slice,
                        annotate_fields=True,
                        include_attributes=False,
                    )
                    + "]",
                ),
            )
    return None


def _guard_dependencies(node: ast.AST) -> tuple[_GuardDependency, ...]:
    dependencies: set[_GuardDependency] = set()

    class Visitor(ast.NodeVisitor):
        def visit_Name(self, name: ast.Name) -> None:
            if isinstance(name.ctx, ast.Load):
                dependencies.add(_GuardDependency(name.id))

        def visit_Attribute(self, attribute: ast.Attribute) -> None:
            if isinstance(attribute.ctx, ast.Load):
                dependency = _dependency_path(attribute)
                if dependency is not None:
                    dependencies.add(dependency)
            self.generic_visit(attribute)

        def visit_Subscript(self, subscript: ast.Subscript) -> None:
            if isinstance(subscript.ctx, ast.Load):
                dependency = _dependency_path(subscript)
                if dependency is not None:
                    dependencies.add(dependency)
            self.generic_visit(subscript)

    Visitor().visit(node)
    return tuple(
        sorted(
            dependencies,
            key=lambda dependency: (
                dependency.root,
                dependency.path,
            ),
        )
    )


def _mutation_dependencies(
    target: ast.AST,
) -> set[_GuardDependency]:
    """Names whose referenced objects are explicitly mutated by a target."""

    if isinstance(target, ast.Name):
        return {_GuardDependency(target.id)}
    if isinstance(target, ast.Starred):
        return _mutation_dependencies(target.value)
    if isinstance(target, (ast.Tuple, ast.List)):
        result: set[_GuardDependency] = set()
        for element in target.elts:
            result |= _mutation_dependencies(element)
        return result
    if isinstance(target, (ast.Attribute, ast.Subscript)):
        dependency = _dependency_path(target)
        return {dependency} if dependency is not None else set()
    return set()


class _DefiniteAssignment:
    _META_MARKERS = {
        MarkerKind.CONST_EXPR,
        MarkerKind.TARGET_VERSION,
    }

    def __init__(
        self,
        local_names: set[str],
        resolver: SafeSymbolResolver,
    ) -> None:
        self.local_names = local_names
        self.resolver = resolver
        self.defined_in: dict[int, frozenset[str]] = {}
        self.defined_out: dict[int, frozenset[str]] = {}
        self.unbound_reads: list[tuple[ast.Name, frozenset[str]]] = []

    def _check_expr(
        self,
        node: ast.AST | None,
        state: _DefinitionState,
        active: _GuardConjunction,
    ) -> None:
        if node is None or _has_guard_contradiction(active):
            return
        defined = state.available(active)
        unbound_names = (
            _expression_loads(node) & self.local_names
        ) - defined
        if not unbound_names:
            return

        class Visitor(ast.NodeVisitor):
            def __init__(inner_self, outer: "_DefiniteAssignment") -> None:
                inner_self.outer = outer

            def visit_Name(inner_self, name: ast.Name) -> None:
                if (
                    isinstance(name.ctx, ast.Load)
                    and name.id in unbound_names
                ):
                    inner_self.outer.unbound_reads.append(
                        (name, frozenset(defined))
                    )

            def visit_Lambda(inner_self, node: ast.Lambda) -> None:
                return

            def visit_FunctionDef(inner_self, node: ast.FunctionDef) -> None:
                for decorator in node.decorator_list:
                    inner_self.visit(decorator)
                for default in (*node.args.defaults, *node.args.kw_defaults):
                    if default is not None:
                        inner_self.visit(default)

            visit_AsyncFunctionDef = visit_FunctionDef

            def visit_ClassDef(inner_self, node: ast.ClassDef) -> None:
                for decorator in node.decorator_list:
                    inner_self.visit(decorator)
                for base in node.bases:
                    inner_self.visit(base)
                for keyword in node.keywords:
                    inner_self.visit(keyword.value)

        Visitor(self).visit(node)

    def _guard_pair(
        self,
        node: ast.AST,
        state: _DefinitionState,
    ) -> tuple[_GuardAtom, _GuardAtom] | None:
        if not isinstance(node, ast.Call):
            return None
        marker = self.resolver.marker_kind(node.func)
        if (
            marker not in self._META_MARKERS
            or len(node.args) != 1
            or node.keywords
            or isinstance(node.args[0], ast.Starred)
        ):
            return None
        argument = node.args[0]
        dependencies = _guard_dependencies(argument)
        state.register(dependencies)
        base = _GuardBase(
            marker,
            ast.dump(
                argument,
                annotate_fields=True,
                include_attributes=False,
            ),
            dependencies,
        )
        dependency_versions = tuple(
            (dependency, state.version(dependency))
            for dependency in dependencies
        )
        positive = _GuardAtom(base, dependency_versions, True)
        return positive, positive.opposite()

    @staticmethod
    def _merge_versions(
        left: _DefinitionState,
        right: _DefinitionState,
    ) -> dict[_GuardDependency, int]:
        versions: dict[_GuardDependency, int] = {}
        for dependency in left.versions.keys() | right.versions.keys():
            left_version = left.version(dependency)
            right_version = right.version(dependency)
            versions[dependency] = (
                left_version
                if left_version == right_version
                else max(left_version, right_version) + 1
            )
        return versions

    @classmethod
    def _merge_meta(
        cls,
        body: _DefinitionState,
        orelse: _DefinitionState,
        positive: _GuardAtom,
        negative: _GuardAtom,
    ) -> _DefinitionState:
        facts: dict[str, set[_GuardConjunction]] = {}
        for name in body.facts.keys() | orelse.facts.keys():
            restricted = {
                frozenset((*fact, positive))
                for fact in body.facts.get(name, set())
            }
            restricted |= {
                frozenset((*fact, negative))
                for fact in orelse.facts.get(name, set())
            }
            normalized = _normalize_guard_facts(restricted)
            if normalized:
                facts[name] = normalized
        return _DefinitionState(
            facts,
            cls._merge_versions(body, orelse),
        )

    @classmethod
    def _merge_dynamic(
        cls,
        body: _DefinitionState,
        orelse: _DefinitionState,
    ) -> _DefinitionState:
        facts: dict[str, set[_GuardConjunction]] = {}
        for name in body.facts.keys() & orelse.facts.keys():
            conjunctions = {
                frozenset(left | right)
                for left in body.facts[name]
                for right in orelse.facts[name]
            }
            normalized = _normalize_guard_facts(conjunctions)
            if normalized:
                facts[name] = normalized
        return _DefinitionState(
            facts,
            cls._merge_versions(body, orelse),
        )

    def block(
        self,
        statements: list[ast.stmt],
        state: _DefinitionState,
        active: _GuardConjunction = frozenset(),
    ) -> _DefinitionState:
        current = state
        for stmt in statements:
            self.defined_in[id(stmt)] = frozenset(
                current.available(active)
            )
            current = self.statement(stmt, current, active)
            self.defined_out[id(stmt)] = frozenset(
                current.available(active)
            )
        return current

    def statement(
        self,
        stmt: ast.stmt,
        state: _DefinitionState,
        active: _GuardConjunction,
    ) -> _DefinitionState:
        current = state.copy()
        if isinstance(stmt, ast.If):
            self._check_expr(stmt.test, current, active)
            guard_pair = self._guard_pair(stmt.test, current)
            if guard_pair is not None:
                positive, negative = guard_pair
                body_out = self.block(
                    stmt.body,
                    current.copy(),
                    frozenset((*active, positive)),
                )
                else_out = self.block(
                    stmt.orelse,
                    current.copy(),
                    frozenset((*active, negative)),
                )
                return self._merge_meta(
                    body_out,
                    else_out,
                    positive,
                    negative,
                )
            body_out = self.block(
                stmt.body, current.copy(), active
            )
            else_out = self.block(
                stmt.orelse, current.copy(), active
            )
            return self._merge_dynamic(body_out, else_out)

        if isinstance(stmt, ast.While):
            self._check_expr(stmt.test, current, active)
            guard_pair = self._guard_pair(stmt.test, current)
            if guard_pair is None:
                self.block(stmt.body, current.copy(), active)
                self.block(stmt.orelse, current.copy(), active)
            else:
                positive, negative = guard_pair
                self.block(
                    stmt.body,
                    current.copy(),
                    frozenset((*active, positive)),
                )
                self.block(
                    stmt.orelse,
                    current.copy(),
                    frozenset((*active, negative)),
                )
            return current

        if isinstance(stmt, (ast.For, ast.AsyncFor)):
            self._check_expr(stmt.iter, current, active)
            body_state = current.copy()
            target_names = _target_names(stmt.target)
            body_state.mutate(_mutation_dependencies(stmt.target))
            body_state.define(target_names, active)
            self.block(stmt.body, body_state, active)
            self.block(stmt.orelse, current.copy(), active)
            return current

        if isinstance(stmt, (ast.With, ast.AsyncWith)):
            body_state = current.copy()
            for item in stmt.items:
                self._check_expr(item.context_expr, current, active)
                if item.optional_vars is not None:
                    body_state.mutate(
                        _mutation_dependencies(item.optional_vars)
                    )
                    body_state.define(
                        _target_names(item.optional_vars), active
                    )
            return self.block(stmt.body, body_state, active)

        if isinstance(stmt, ast.Assign):
            self._check_expr(stmt.value, current, active)
            for target in stmt.targets:
                # Attribute/subscript target bases and indices are reads.
                self._check_target_reads(target, current, active)
                current.mutate(_mutation_dependencies(target))
                current.define(_target_names(target), active)
            return current

        if isinstance(stmt, ast.AnnAssign):
            self._check_expr(stmt.annotation, current, active)
            self._check_expr(stmt.value, current, active)
            self._check_target_reads(stmt.target, current, active)
            if stmt.value is not None:
                current.mutate(_mutation_dependencies(stmt.target))
                current.define(_target_names(stmt.target), active)
            return current

        if isinstance(stmt, ast.AugAssign):
            defined = current.available(active)
            if (
                isinstance(stmt.target, ast.Name)
                and stmt.target.id in self.local_names
                and stmt.target.id not in defined
            ):
                self.unbound_reads.append(
                    (stmt.target, frozenset(defined))
                )
            else:
                self._check_expr(stmt.target, current, active)
            self._check_expr(stmt.value, current, active)
            current.mutate(_mutation_dependencies(stmt.target))
            current.define(_target_names(stmt.target), active)
            return current

        if isinstance(stmt, ast.Delete):
            for target in stmt.targets:
                if isinstance(target, ast.Name):
                    defined = current.available(active)
                    if (
                        target.id in self.local_names
                        and target.id not in defined
                    ):
                        self.unbound_reads.append(
                            (target, frozenset(defined))
                        )
                else:
                    self._check_expr(target, current, active)
                current.mutate(_mutation_dependencies(target))
                current.undefine(_target_names(target))
            return current

        if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
            self._check_expr(stmt, current, active)
            current.mutate({_GuardDependency(stmt.name)})
            current.define({stmt.name}, active)
            return current

        if isinstance(stmt, ast.ClassDef):
            self._check_expr(stmt, current, active)
            current.mutate({_GuardDependency(stmt.name)})
            current.define({stmt.name}, active)
            return current

        self._check_expr(stmt, current, active)
        defs, _ = _simple_defs_uses(stmt)
        current.mutate(
            _GuardDependency(name) for name in defs
        )
        current.define(defs, active)
        return current

    def _check_target_reads(
        self,
        target: ast.AST,
        state: _DefinitionState,
        active: _GuardConjunction,
    ) -> None:
        if isinstance(target, ast.Name):
            return
        self._check_expr(target, state, active)


def _reads_before_assignment(
    statements: list[ast.stmt],
    candidates: set[str],
) -> set[str]:
    """Names whose previous-iteration value may be read before a body write."""

    found: set[str] = set()

    def expr(node: ast.AST | None, written: set[str]) -> None:
        if node is None:
            return
        found.update(
            (_expression_loads(node) & candidates) - written
        )

    def block(items: list[ast.stmt], written: set[str]) -> set[str]:
        current = set(written)
        for stmt in items:
            if isinstance(stmt, ast.If):
                expr(stmt.test, current)
                left = block(stmt.body, set(current))
                right = block(stmt.orelse, set(current))
                current = left & right
            elif isinstance(stmt, ast.While):
                expr(stmt.test, current)
                block(stmt.body, set(current))
                block(stmt.orelse, set(current))
            elif isinstance(stmt, (ast.For, ast.AsyncFor)):
                expr(stmt.iter, current)
                block(stmt.body, current | _target_names(stmt.target))
                block(stmt.orelse, set(current))
            elif isinstance(stmt, ast.Assign):
                expr(stmt.value, current)
                for target in stmt.targets:
                    if not isinstance(target, ast.Name):
                        expr(target, current)
                    current |= _target_names(target)
            elif isinstance(stmt, ast.AnnAssign):
                expr(stmt.value, current)
                if not isinstance(stmt.target, ast.Name):
                    expr(stmt.target, current)
                current |= _target_names(stmt.target)
            elif isinstance(stmt, ast.AugAssign):
                if (
                    isinstance(stmt.target, ast.Name)
                    and stmt.target.id in candidates
                    and stmt.target.id not in current
                ):
                    found.add(stmt.target.id)
                else:
                    expr(stmt.target, current)
                expr(stmt.value, current)
                current |= _target_names(stmt.target)
            else:
                defs, uses = _simple_defs_uses(stmt)
                found.update((uses & candidates) - current)
                current |= defs
        return current

    block(statements, set())
    return found


@dataclass(frozen=True, slots=True)
class RegionInput:
    id: int
    kind: str
    node: ast.If | ast.For | ast.While


@dataclass(frozen=True, slots=True)
class RegionDataflow:
    state: tuple[str, ...]
    captures: tuple[str, ...]
    locals: tuple[str, ...]
    defined_in: frozenset[str]
    live_out: frozenset[str]


def _ordered(
    names: set[str], positions: dict[str, tuple[int, int]]
) -> tuple[str, ...]:
    return tuple(
        sorted(names, key=lambda name: (*positions.get(name, (10**9, 10**9)), name))
    )


def _analyze_dataflow(
    source: SourceUnit,
    regions: tuple[RegionInput, ...],
) -> dict[int, RegionDataflow]:
    """Compute deterministic state/capture sets and reject escaping locals."""

    local_names = set(source.symbol_table.get_locals())
    parameters = _argument_names(source.target.args)
    definite = _DefiniteAssignment(
        local_names,
        SafeSymbolResolver(source),
    )
    definite.block(
        source.target.body,
        _DefinitionState.initial(parameters),
    )
    liveness = _Liveness()
    liveness.block(source.target.body, set())

    facts: dict[int, RegionDataflow] = {}
    for region in regions:
        node = region.node
        defined_in = definite.defined_in.get(id(node), frozenset(parameters))
        defined_out = definite.defined_out.get(id(node), defined_in)
        live_out = liveness.live_out.get(id(node), frozenset())
        unbound_reads: list[ast.Name] = []
        if definite.unbound_reads:
            region_node_ids = {id(child) for child in ast.walk(node)}
            unbound_reads = sorted(
                (
                    read
                    for read, _ in definite.unbound_reads
                    if id(read) in region_node_ids
                ),
                key=lambda read: (read.lineno, read.col_offset, read.id),
            )
        if unbound_reads:
            read = unbound_reads[0]
            raise source.error(
                FE201_UNBOUND_REGION_STATE,
                f"Local value {read.id!r} is not definitely assigned before "
                "it is read in a dynamic region.",
                node=read,
                hint=(
                    f"Initialize {read.id!r} on every path before entering "
                    "the dynamic region."
                ),
            )

        body_collector = _names(node.body)
        assigned = set(body_collector.stores)
        loaded = set(body_collector.loads)
        store_positions = dict(body_collector.stores)
        load_positions = dict(body_collector.loads)
        target_names: set[str] = set()
        if isinstance(node, ast.For):
            target_names = _target_names(node.target)
            assigned -= target_names
            loaded |= _expression_loads(node.iter)
        elif isinstance(node, ast.While):
            loaded |= _expression_loads(node.test)
        elif isinstance(node, ast.If):
            loaded |= _expression_loads(node.test)
            else_collector = _names(node.orelse)
            assigned |= set(else_collector.stores)
            loaded |= set(else_collector.loads)
            for name, position in else_collector.stores.items():
                previous = store_positions.get(name)
                if previous is None or position < previous:
                    store_positions[name] = position
            for name, position in else_collector.loads.items():
                previous = load_positions.get(name)
                if previous is None or position < previous:
                    load_positions[name] = position

        recurrence: set[str] = set()
        if assigned and isinstance(node, ast.If):
            recurrence = _reads_before_assignment(node.body, assigned)
            recurrence |= _reads_before_assignment(node.orelse, assigned)
        elif assigned and isinstance(node, (ast.For, ast.While)):
            recurrence = _reads_before_assignment(node.body, assigned)
            if isinstance(node, ast.While):
                recurrence |= _expression_loads(node.test) & assigned

        state_names = (
            assigned
            & set(defined_in)
            & (set(live_out) | recurrence)
        )

        escaping = assigned & set(live_out) - set(defined_in)
        for name in sorted(
            escaping,
            key=lambda item: (
                *store_positions.get(item, (10**9, 10**9)),
                item,
            ),
        ):
            if name not in defined_out:
                code = FE201_UNBOUND_REGION_STATE
                message = (
                    f"Region-local value {name!r} is not assigned on every path "
                    "before it is used outside the region."
                )
                hint = (
                    f"Initialize {name!r} before the region and keep it as DSL "
                    "loop-carried state."
                )
            else:
                code = FE202_REGION_VALUE_ESCAPE
                message = (
                    f"Region-local value {name!r} cannot escape a dynamic "
                    f"{region.kind} region."
                )
                hint = (
                    f"Initialize {name!r} before the region or consume it "
                    "entirely inside the region."
                )
            raise source.error(code, message, node=node, hint=hint)

        for target in _ordered(
            target_names & set(live_out), store_positions
        ):
            raise source.error(
                FE202_REGION_VALUE_ESCAPE,
                f"Loop induction variable {target!r} is region-local and cannot be used after the loop.",
                node=node.target if isinstance(node, ast.For) else node,
                hint="Assign the required value to an explicitly initialized DSL state variable.",
            )

        local_region_names = (assigned | target_names) - state_names
        capture_names = loaded - local_region_names - state_names
        facts[region.id] = RegionDataflow(
            state=_ordered(state_names, store_positions),
            captures=_ordered(capture_names, load_positions),
            locals=_ordered(local_region_names, store_positions),
            defined_in=frozenset(defined_in),
            live_out=frozenset(live_out),
        )

    return facts


def analyze_dataflow(
    source: SourceUnit,
    regions: tuple[RegionInput, ...],
) -> dict[int, RegionDataflow]:
    """Compute dataflow with caches scoped to this reentrant invocation."""

    target_token = _TARGET_CACHE.set({})
    name_token = _NAME_CACHE.set({})
    expression_token = _EXPRESSION_CACHE.set({})
    simple_token = _SIMPLE_CACHE.set({})
    try:
        return _analyze_dataflow(source, regions)
    finally:
        _SIMPLE_CACHE.reset(simple_token)
        _EXPRESSION_CACHE.reset(expression_token)
        _NAME_CACHE.reset(name_token)
        _TARGET_CACHE.reset(target_token)


__all__ = [
    "RegionDataflow",
    "RegionInput",
    "analyze_dataflow",
]
