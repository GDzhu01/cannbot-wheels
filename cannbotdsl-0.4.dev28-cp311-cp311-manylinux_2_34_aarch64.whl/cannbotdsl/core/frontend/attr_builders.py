# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Import-time registration of CANNBotDSL :class:`ir.AttrBuilder` entries.

Importing this module installs builders that let Python ``IntEnum`` values
(``PIPE``, ``RoundingMode``, ``RegLayout``) be used directly as ``PipeEnum`` /
``RoundingModeEnum`` / ``RegLayoutEnum`` attribute values on Pybind-generated ops, without
the call site having to call ``ir.IntegerAttr.get(...)`` explicitly.

The :func:`ir.AttrBuilder.insert` calls raise :class:`RuntimeError` when
the builder is already registered, which is fine — multiple imports of
this module are a no-op.
"""

import cannbotdsl._mlir.ir as ir


def _register_pipe_enum_builder() -> None:
    try:
        ir.AttrBuilder.insert(
            "PipeEnum",
            lambda val, context: ir.IntegerAttr.get(
                ir.IntegerType.get_signless(32, context=context), int(val)
            ),
        )
    except RuntimeError:
        pass


def _register_rounding_mode_enum_builder() -> None:
    try:
        ir.AttrBuilder.insert(
            "RoundingModeEnum",
            lambda val, context: ir.IntegerAttr.get(
                ir.IntegerType.get_signless(32, context=context), int(val)
            ),
        )
    except RuntimeError:
        pass


def _register_reg_layout_enum_builder() -> None:
    try:
        ir.AttrBuilder.insert(
            "RegLayoutEnum",
            lambda val, context: ir.IntegerAttr.get(
                ir.IntegerType.get_signless(32, context=context), int(val)
            ),
        )
    except RuntimeError:
        pass


def _register_cmp_op_enum_builder() -> None:
    try:
        ir.AttrBuilder.insert(
            "CmpOpEnum",
            lambda val, context: ir.IntegerAttr.get(
                ir.IntegerType.get_signless(32, context=context), int(val)
            ),
        )
    except RuntimeError:
        pass


def _register_nddma_padding_mode_enum_builder() -> None:
    try:
        ir.AttrBuilder.insert(
            "NDDMAPaddingModeEnum",
            lambda val, context: ir.IntegerAttr.get(
                ir.IntegerType.get_signless(32, context=context), int(val)
            ),
        )
    except RuntimeError:
        pass


def _register_cube_enum_builders() -> None:
    for name in (
        "HF32RoundModeEnum",
        "HF32ComputeModeEnum",
        "Cube8BitModeEnum",
        "MmadDirectionEnum",
        "CubeStateModeEnum",
    ):
        try:
            ir.AttrBuilder.insert(
                name,
                lambda val, context: ir.IntegerAttr.get(
                    ir.IntegerType.get_signless(32, context=context), int(val)
                ),
            )
        except RuntimeError:
            pass


_register_pipe_enum_builder()
_register_rounding_mode_enum_builder()
_register_reg_layout_enum_builder()
_register_cmp_op_enum_builder()
_register_nddma_padding_mode_enum_builder()
_register_cube_enum_builders()
