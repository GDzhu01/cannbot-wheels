# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Reversible identities for the closed compiler primitive algebra.

The codec is deliberately immutable and exact-type based.  It has no handler
registry, user callback, JSON layer, or digest helper.  Dictionary insertion
order is part of the identity and is therefore preserved by both directions.
"""

from __future__ import annotations

import math
from typing import TypeAlias


PrimitiveIdentity: TypeAlias = (
    tuple[str]
    | tuple[str, bool | int | str]
    | tuple[str, tuple["PrimitiveIdentity", ...]]
    | tuple[
        str,
        tuple[tuple["PrimitiveIdentity", "PrimitiveIdentity"], ...],
    ]
)


def encode_primitive(value: object) -> PrimitiveIdentity:
    """Encode one closed primitive value into a hashable identity."""

    value_type = type(value)
    if value is None:
        return ("none",)
    if value_type is bool:
        return ("bool", value)
    if value_type is int:
        return ("int", value)
    if value_type is float:
        if math.isnan(value):
            payload = "nan"
        elif math.isinf(value):
            payload = "+inf" if value > 0 else "-inf"
        else:
            payload = value.hex()
        return ("float", payload)
    if value_type is str:
        return ("str", value)
    if value_type is bytes:
        return ("bytes", value.hex())
    if value_type in {tuple, list}:
        return (
            "tuple" if value_type is tuple else "list",
            tuple(encode_primitive(item) for item in value),
        )
    if value_type is dict:
        return (
            "dict",
            tuple(
                (encode_primitive(key), encode_primitive(item))
                for key, item in value.items()
            ),
        )
    raise TypeError(
        "primitive identity does not support "
        f"{value_type.__module__}.{value_type.__qualname__}"
    )


def decode_primitive(identity: PrimitiveIdentity) -> object:
    """Decode an identity produced by :func:`encode_primitive`."""

    if type(identity) is not tuple or not identity or type(identity[0]) is not str:
        raise ValueError("primitive identity must be a non-empty tagged tuple")
    tag = identity[0]
    if tag == "none":
        if identity != ("none",):
            raise ValueError("none identity must not carry a payload")
        return None
    if len(identity) != 2:
        raise ValueError(f"{tag!r} identity must carry exactly one payload")
    payload = identity[1]
    if tag == "bool":
        if type(payload) is not bool:
            raise ValueError("bool identity payload must be bool")
        return payload
    if tag == "int":
        if type(payload) is not int:
            raise ValueError("int identity payload must be int")
        return payload
    if tag == "float":
        if type(payload) is not str:
            raise ValueError("float identity payload must be str")
        if payload == "nan":
            return float("nan")
        if payload == "+inf":
            return float("inf")
        if payload == "-inf":
            return float("-inf")
        try:
            value = float.fromhex(payload)
        except ValueError as exc:
            raise ValueError(f"invalid float identity {payload!r}") from exc
        if value.hex() != payload:
            raise ValueError(f"non-canonical float identity {payload!r}")
        return value
    if tag == "str":
        if type(payload) is not str:
            raise ValueError("str identity payload must be str")
        return payload
    if tag == "bytes":
        if type(payload) is not str:
            raise ValueError("bytes identity payload must be str")
        try:
            value = bytes.fromhex(payload)
        except ValueError as exc:
            raise ValueError(f"invalid bytes identity {payload!r}") from exc
        if value.hex() != payload:
            raise ValueError(f"non-canonical bytes identity {payload!r}")
        return value
    if tag in {"tuple", "list"}:
        if type(payload) is not tuple:
            raise ValueError(f"{tag} identity payload must be tuple")
        values = tuple(decode_primitive(item) for item in payload)
        return values if tag == "tuple" else list(values)
    if tag == "dict":
        if type(payload) is not tuple:
            raise ValueError("dict identity payload must be tuple")
        result = {}
        for entry in payload:
            if type(entry) is not tuple or len(entry) != 2:
                raise ValueError("dict identity entries must be key/value pairs")
            key = decode_primitive(entry[0])
            try:
                duplicate = key in result
            except TypeError as exc:
                raise ValueError("decoded dict identity key is not hashable") from exc
            if duplicate:
                raise ValueError(f"duplicate dict identity key {key!r}")
            result[key] = decode_primitive(entry[1])
        return result
    raise ValueError(f"unknown primitive identity tag {tag!r}")
