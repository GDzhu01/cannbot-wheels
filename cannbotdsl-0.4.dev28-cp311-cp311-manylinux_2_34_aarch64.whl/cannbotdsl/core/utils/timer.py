# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""JIT timing helpers.

``@timer("label")`` decorates a function so that, when
``CANNBOTDSL_JIT_TIME_PROFILING=1`` is set, its wall-clock duration is logged
at INFO in **seconds** (from :func:`time.perf_counter`).

``time_block("label")`` is a context manager for the same purpose when a
sub-step inside a function needs its own measurement.

The profiling flag is read via :func:`cannbotdsl.core.utils.env.env` on every
call, so tests / users can toggle it mid-process without re-importing.
``cannbotdsl.core.utils.logger.init_logger`` auto-enables console output at
INFO when the flag is set, so the user only needs the one env var to see
output.
"""

from contextlib import contextmanager
from functools import wraps
from time import perf_counter
import logging


_LOG = logging.getLogger("cannbotdsl.timer")


def timer(label: str | None = None):
    """Decorator: emit ``<label> | <seconds> s`` when profiling is on."""

    def decorator(fn):
        name = label or fn.__name__

        @wraps(fn)
        def wrapper(*args, **kwargs):
            from cannbotdsl.core.utils.env import env
            if not env().jit_time_profiling:
                return fn(*args, **kwargs)
            t0 = perf_counter()
            try:
                return fn(*args, **kwargs)
            finally:
                dt_s = perf_counter() - t0
                _LOG.info("%s | %.6f s", name, dt_s)

        return wrapper

    return decorator


@contextmanager
def time_block(label: str):
    """Context manager: same as ``@timer`` — logs ``<label> | <seconds> s``."""
    from cannbotdsl.core.utils.env import env
    if not env().jit_time_profiling:
        yield
        return
    t0 = perf_counter()
    try:
        yield
    finally:
        dt_s = perf_counter() - t0
        _LOG.info("%s | %.6f s", label, dt_s)
