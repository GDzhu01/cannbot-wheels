# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Atomic text dump to ``$CANNBOTDSL_DUMP_DIR``.

Used by ``core/compiler/builder.py`` to materialise ``.mlir`` / ``.asc``
artifacts when ``CANNBOTDSL_DUMP_MLIR`` / ``CANNBOTDSL_DUMP_ASCENDC`` are set.
"""

import contextlib
import os
import re
import tempfile

_FILENAME_SAFE_RE = re.compile(r"[^0-9A-Za-z_.-]+")


def safe_basename(name: str, fallback: str = "jit") -> str:
    """Sanitise ``name`` for use as a dump file basename."""
    cleaned = _FILENAME_SAFE_RE.sub("_", name).strip("._-")
    return cleaned or fallback


def dump_text(
    filename: str,
    text: str,
    *,
    dump_dir: str | None = None,
) -> str:
    """Atomically write ``text`` to ``$CANNBOTDSL_DUMP_DIR/<filename>``.

    Writes to a sibling temp file in the same directory (so ``os.replace`` is
    same-device and therefore atomic on POSIX), then renames over the final
    path. Concurrent writers (e.g. ``pytest -n auto`` workers parameterised
    over the same kernel) won't observe a partial file.
    """
    if dump_dir is None:
        from cannbotdsl.core.utils.env import env

        dump_dir = env().dump_dir
    os.makedirs(dump_dir, exist_ok=True)
    final_path = os.path.join(dump_dir, filename)
    fd, tmp_path = tempfile.mkstemp(
        prefix=f".{filename}.", suffix=".tmp", dir=dump_dir,
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp_path, final_path)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(tmp_path)
        raise
    return final_path
