# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""cannbotdsl logger initialization.

Reads ``CANNBOTDSL_LOG_*`` env vars and configures the ``cannbotdsl`` logger so that
submodule loggers (``cannbotdsl.lang.jit``, ``cannbotdsl.core.toolchain.ascendc``, ...) inherit
handlers and level. Called once from :mod:`cannbotdsl.__init__`.

Env vars
--------
- ``CANNBOTDSL_LOG_TO_CONSOLE`` (bool, default False) - add a StreamHandler.
- ``CANNBOTDSL_LOG_TO_FILE`` (bool, default False) - add a FileHandler.
- ``CANNBOTDSL_LOG_FILE`` (str, default ``"cannbotdsl.log"``) - file path for
  the FileHandler.
- ``CANNBOTDSL_LOG_LEVEL`` (int, default ``logging.WARNING``) - level applied
  to the ``cannbotdsl`` logger and its handlers.
- ``CANNBOTDSL_JIT_TIME_PROFILING`` (bool, default False) - convenience switch
  that auto-enables console output at INFO level.
- ``CANNBOTDSL_CACHE_TRACE`` (bool, default False) - enable DEBUG events only
  for ``cannbotdsl.core.compiler.cache``. If no log destination is configured,
  a console handler is added automatically.

When neither console nor file output is requested, the logger level is set
to ``CRITICAL + 1`` so that ``_LOG.info(...)`` / ``_LOG.debug(...)`` calls
become no-ops without ``logging``'s usual overhead.
"""

import logging
import os


_FORMATTER = logging.Formatter(
    '%(asctime)s - [%(name)s] [%(levelname)s] [%(filename)s:%(lineno)d] - %(message)s'
)
_INITIALIZED = False


def _get_bool(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v not in {"0", "False", "false", ""}


def _get_int(name: str, default: int) -> int:
    v = os.environ.get(name)
    if not v:
        return default
    try:
        return int(v)
    except ValueError:
        return default


def _get_cache_trace() -> tuple:
    """Return ``(enabled, invalid_raw_value)`` for CACHE_TRACE."""
    raw = os.environ.get("CANNBOTDSL_CACHE_TRACE")
    if raw is None:
        return False, None
    normalized = raw.strip().lower()
    if normalized in {"1", "true", "on", "yes"}:
        return True, None
    if normalized in {"0", "false", "off", "no", ""}:
        return False, None
    return False, raw


def init_logger() -> logging.Logger:
    """Configure the ``cannbotdsl`` logger from env vars. Idempotent."""
    global _INITIALIZED
    logger = logging.getLogger("cannbotdsl")

    if _INITIALIZED:
        return logger

    to_console = _get_bool("CANNBOTDSL_LOG_TO_CONSOLE", False)
    to_file = _get_bool("CANNBOTDSL_LOG_TO_FILE", False)
    level = _get_int("CANNBOTDSL_LOG_LEVEL", logging.WARNING)
    cache_trace, invalid_cache_trace = _get_cache_trace()

    if _get_bool("CANNBOTDSL_JIT_TIME_PROFILING", False) and not to_console:
        to_console = True
        level = min(level, logging.INFO)
    if cache_trace and not (to_console or to_file):
        to_console = True

    if not (to_console or to_file):
        # No output requested: short-circuit every _LOG.* call cheaply.
        logger.setLevel(logging.CRITICAL + 1)
    else:
        logger.setLevel(level)
    # Always leave propagation on. Tests use ``caplog`` (a root handler) and
    # rely on records flowing from ``cannbotdsl.*`` up to root; suppressing
    # propagation would silently break them. Duplicate-log risk from a
    # user-installed root handler is theoretical — Python's default root has
    # none until ``basicConfig`` is called, and pytest's caplog doesn't
    # double-print our own handler's output.
    logger.propagate = True

    for h in list(logger.handlers):
        logger.removeHandler(h)

    # A child logger with an explicit DEBUG level still has to cross the
    # parent handlers. Lower only those handler thresholds; the parent
    # logger itself keeps the configured level, so Pass/MLIR loggers do
    # not inherit cache tracing.
    handler_level = min(level, logging.DEBUG) if cache_trace else level

    if to_console:
        h = logging.StreamHandler()
        h.setFormatter(_FORMATTER)
        h.setLevel(handler_level)
        logger.addHandler(h)

    if to_file:
        path = os.environ.get("CANNBOTDSL_LOG_FILE", "cannbotdsl.log")
        h = logging.FileHandler(path)
        h.setFormatter(_FORMATTER)
        h.setLevel(handler_level)
        logger.addHandler(h)

    cache_logger = logging.getLogger("cannbotdsl.core.compiler.cache")
    cache_logger.setLevel(logging.DEBUG if cache_trace else logging.NOTSET)

    if invalid_cache_trace is not None:
        logger.warning(
            "CANNBOTDSL_CACHE_TRACE=%r is not a valid boolean; treating it as false "
            "(accepted true: 1/true/on/yes; false: 0/false/off/no/empty)",
            invalid_cache_trace,
        )

    _INITIALIZED = True
    return logger
