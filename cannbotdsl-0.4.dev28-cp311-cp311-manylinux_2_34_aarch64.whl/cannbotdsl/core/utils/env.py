# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""cannbotdsl runtime environment-variable snapshot.

A single :class:`EnvManager` dataclass owns every ``CANNBOTDSL_*`` variable
that affects the JIT path (dump/keep flags, pipeline overrides, stage
early-exit, manual intra-block matching, etc.). Call ``env()`` to read a fresh
snapshot.

This module is deliberately separate from
:mod:`cannbotdsl.core.utils.logger`:

- ``logger.py`` reads its own ``CANNBOTDSL_LOG_*`` family at package import
  time, before any JIT work happens.
- ``env.py`` reads runtime config lazily on each ``env()`` call from
  inside the JIT path.

Cross-import between the two is avoided.

``env()`` is intentionally not cached: several tests
(``test/test_matmul_cube.py``, ``test/test_struct.py``, ...) mutate
``CANNBOTDSL_CANNIR_PIPELINE`` mid-process and expect the next JIT call to
pick up the new value. The env reads + pipeline-string format are cheap
(a handful of dict lookups per JIT), so re-reading every call is fine.
"""

from dataclasses import dataclass
import os
from typing import Optional

from cannbotdsl.core.frontend.api import FrontendDumpKind


def _getenv_bool(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v not in {"0", "False", "false", ""}


def _getenv_str(name: str, default: Optional[str] = None) -> Optional[str]:
    v = os.environ.get(name)
    return v if v else default


def _getenv_binary_bool(name: str, default: bool = False) -> bool:
    value = os.environ.get(name)
    if value is None or value == "":
        return default
    if value == "0":
        return False
    if value == "1":
        return True
    raise ValueError(f"{name} must be exactly 0 or 1, got {value!r}")


def _debug_asc_sync_modes() -> tuple[bool, bool, str]:
    raw = os.environ.get("CANNBOTDSL_DEBUG_ASC_SYNC")
    if raw is None or raw == "":
        return False, False, ""

    value = raw.strip().lower()
    if value in {"0", "false", "off", "none"}:
        return False, False, value
    if value in {"1", "true", "on", "pipe"}:
        return True, False, value
    if value == "vf":
        return False, True, value
    if value in {"all", "both"}:
        return True, True, value

    tokens = {tok for tok in value.replace("+", ",").replace(";", ",").split(",") if tok}
    if tokens and tokens <= {"pipe", "vf"}:
        return "pipe" in tokens, "vf" in tokens, value

    raise ValueError("CANNBOTDSL_DEBUG_ASC_SYNC must be one of: 0, pipe, vf, all, both, or pipe,vf")


def _debug_asc_sync_pass(pipe_sync: bool, vf_sync: bool) -> str:
    if pipe_sync and not vf_sync:
        return "cannir-insert-debug-asc-sync"
    pipe = "true" if pipe_sync else "false"
    vf = "true" if vf_sync else "false"
    return f"cannir-insert-debug-asc-sync{{pipe-sync={pipe} vf-sync={vf}}}"


def _default_pipeline(
    debug_pipe_sync: bool,
    debug_vf_sync: bool,
    intrablock_match_manual: bool = False,
    auto_buffer_sync: bool = False,
) -> str:
    """The default CANNIR pass pipeline.

    This is the pipeline consumed by the in-process PassManager in
    ``core.compiler.passes._run_cannir_passes``. The returned string is
    wrapped in ``builtin.module(...)`` as required by that parser.
    """
    # The on-chip planner runs first so every allocation declaration becomes the
    # direct make_pointer + make_memref root expected by subsequent verifiers and
    # lowerings. cannir-infer-layout then handles a typed buffer/channel declared
    # at its full tile shape: when a writer's source is a smaller (tail) tile it
    # inserts local_slice tail views at affected uses so compute/DMA get the
    # runtime extent (docs/design/Layout_Inference.md). No-op for aligned accesses.
    # decompose-mem-copy runs early: it lowers cannir.mem_copy into DMA ops
    # and ub_copy/ub_format_convert. The generated ops accept TensorOrChannel
    # operands, so channel-typed mem_copy ops are decomposed too — the
    # channel value passes through to the generated op and is rebound to a
    # slot memref later by resolve-channel-operands. Running decompose first
    # ensures ub_copy/ub_format_convert exist before form-vf-regions so they
    # get pulled into cannir.vf regions and expanded by lower-ub-copy.
    prefix = (
        "func.func(cannir-plan-onchip-memory),"
        "cse,cannir-simplify-layout,func.func(cannir-infer-layout),"
        "decompose-mem-copy,"
        "func.func(cannir-validate-formatted-gm-uses),"
    )
    # cannir-resolve-channel-operands runs AFTER form-vf-regions: the channel
    # acquire/commit/wait/release primitives it inserts are side-effecting, so
    # resolving before form-vf-regions would inject barriers between vector
    # ops and split vf regions. Resolving after form-vf-regions lets the vf
    # regions form cleanly first; the pass treats each cannir.vf as an atomic
    # unit using vf_arg_effects and brackets the whole VF transaction. It still
    # precedes lower-channel, which consumes the four primitives and
    # irreversibly materializes Buffer/Tensor slots, scalar cursors, and target
    # synchronization. No later pass may observe a Channel value.
    # cannir-intra-block-sync takes its gating as pass
    # options rather than reading the environment themselves. That keeps every
    # input to what the passes emit inside this string, which the compile cache
    # keys on: a pass that read os.environ directly could behave differently
    # for two runs that hash to the same key (e.g. "1" vs "true"), and the
    # cache would then hand out an artifact built under the other setting.
    middle = (
        "cannir-form-vf-regions,"
        + "func.func(cannir-resolve-channel-operands),"
        + (
            "cannir-intra-block-sync{match-manual=true},"
            if intrablock_match_manual
            else ""
        )
        + "func.func(cannir-lower-channel),"
        + ("func.func(cannir-auto-buffer-sync)," if auto_buffer_sync else "")
        + "func.func(cannir-lower-ub-copy),"
        + "func.func(canonicalize),"
        + "convert-cannir-to-asc,"
        + "asccube-plan-state,"
        + "split-mix-kernel,"
    )
    suffix = ""
    if debug_pipe_sync or debug_vf_sync:
        suffix = _debug_asc_sync_pass(debug_pipe_sync, debug_vf_sync) + ","
    suffix += "convert-cannir-host-ops"
    return f"builtin.module({prefix}{middle}{suffix})"


@dataclass(frozen=True)
class EnvManager:
    """Immutable snapshot produced by one read of ``CANNBOTDSL_*`` variables."""

    # Dump output
    dump_dir: str
    dump_mlir: bool  # CANNBOTDSL_DUMP_MLIR
    dump_ascendc: bool  # CANNBOTDSL_DUMP_ASCENDC
    reuse_ascendc: bool  # CANNBOTDSL_REUSE_ASCENDC

    # Pipeline / stage
    intrablock_match_manual: bool  # CANNBOTDSL_INTRABLOCK_MATCH_MANUAL
    auto_buffer_sync: bool  # CANNBOTDSL_AUTO_BUFFER_SYNC
    debug_asc_sync: str  # CANNBOTDSL_DEBUG_ASC_SYNC raw normalized mode
    debug_asc_pipe_sync: bool  # CANNBOTDSL_DEBUG_ASC_SYNC includes pipe
    debug_asc_vf_sync: bool  # CANNBOTDSL_DEBUG_ASC_SYNC includes vf
    print_mlir: bool  # CANNBOTDSL_PRINT_MLIR
    print_ascendc: bool  # CANNBOTDSL_PRINT_ASCENDC
    pipe_stage: Optional[str]  # CANNBOTDSL_PIPE_STAGE: "transform"|"translate"|"compile"|None
    cannir_pipeline: str  # CANNBOTDSL_CANNIR_PIPELINE or _default_pipeline(...)

    # External compiler
    npu_arch: str  # CANNBOTDSL_NPU_ARCH > runtime SoC query > dav-3510
    barall: bool  # CANNBOTDSL_BARALL

    # Profiling
    jit_time_profiling: bool  # CANNBOTDSL_JIT_TIME_PROFILING — gates @timer emissions

    # Python AST frontend
    frontend_dumps: frozenset[FrontendDumpKind]
    frontend_line_info: bool


def env() -> EnvManager:
    """Read ``CANNBOTDSL_*`` env vars and return a fresh :class:`EnvManager`.

    Not cached — see module docstring for rationale.
    """
    # Imported here: ascendc reads ``_getenv_binary_bool`` from this module,
    # so a top-level import would be circular.
    from cannbotdsl.core.toolchain.ascendc import resolve_npu_arch

    intrablock_match_manual = _getenv_bool("CANNBOTDSL_INTRABLOCK_MATCH_MANUAL")
    auto_buffer_sync = _getenv_bool("CANNBOTDSL_AUTO_BUFFER_SYNC", default=True)
    debug_pipe_sync, debug_vf_sync, debug_asc_sync = _debug_asc_sync_modes()
    pipeline = _getenv_str("CANNBOTDSL_CANNIR_PIPELINE")
    if pipeline is None:
        pipeline = _default_pipeline(
            debug_pipe_sync, debug_vf_sync, intrablock_match_manual,
            auto_buffer_sync,
        )
    return EnvManager(
        dump_dir=_getenv_str("CANNBOTDSL_DUMP_DIR") or os.path.join(os.getcwd(), ".dump"),
        dump_mlir=_getenv_bool("CANNBOTDSL_DUMP_MLIR"),
        dump_ascendc=_getenv_bool("CANNBOTDSL_DUMP_ASCENDC"),
        reuse_ascendc=_getenv_bool("CANNBOTDSL_REUSE_ASCENDC"),
        intrablock_match_manual=intrablock_match_manual,
        auto_buffer_sync=auto_buffer_sync,
        debug_asc_sync=debug_asc_sync,
        debug_asc_pipe_sync=debug_pipe_sync,
        debug_asc_vf_sync=debug_vf_sync,
        print_mlir=_getenv_bool("CANNBOTDSL_PRINT_MLIR"),
        print_ascendc=_getenv_bool("CANNBOTDSL_PRINT_ASCENDC"),
        pipe_stage=_getenv_str("CANNBOTDSL_PIPE_STAGE"),
        cannir_pipeline=pipeline,
        npu_arch=resolve_npu_arch(),
        barall=_getenv_binary_bool("CANNBOTDSL_BARALL"),
        jit_time_profiling=_getenv_bool("CANNBOTDSL_JIT_TIME_PROFILING"),
        frontend_dumps=FrontendDumpKind.parse_many(
            _getenv_str("CANNBOTDSL_DUMP_FRONTEND")
        ),
        frontend_line_info=_getenv_binary_bool(
            "CANNBOTDSL_FRONTEND_LINE_INFO"
        ),
    )
