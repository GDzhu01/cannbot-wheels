# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Transactional nested-kernel materialization and launch emission."""

from __future__ import annotations

import hashlib
import io
import json
from collections.abc import Callable
from dataclasses import dataclass

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir, func
from cannbotdsl.ir_transport import unwrap_operand

from cannbotdsl.core.compiler.call_lowering import (
    _trace_call_plan,
)
from cannbotdsl.core.contracts.surface import SurfaceSignature
from cannbotdsl.core.contracts.surface import _StagedRole
from cannbotdsl.core.frontend.compiler import compile_function
from cannbotdsl.core.frontend.debug_print import (
    DebugPrintPlan,
    _debug_counter_memref_type,
    _debug_memref_type,
)
from cannbotdsl.core.frontend.lowering_state import _current_lowering_state
from cannbotdsl.core.scalar_conversion import coerce_scalar_value
from cannbotdsl.core.diag.diagnostics import (
    CANNBotInternalError,
    CANNBotTypeError,
    CANNBotValueError,
    IN001_COMPILER_INVARIANT,
    KM101_INVALID_BLOCK_DIM,
)


@dataclass(frozen=True, slots=True)
class _MaterializedKernelRecord:
    content_key: str
    symbol_name: str
    logical_signature: tuple[tuple[str, str], ...]
    argument_types: tuple[str, ...]
    debug_plan: DebugPrintPlan | None


def _operation_count(block) -> int:
    return sum(1 for _ in block.operations)


def _trim_operations(block, count: int) -> None:
    operations = list(block.operations)
    for operation in reversed(operations[count:]):
        _detach(operation)


def _capture_attributes(operation, names: tuple[str, ...]) -> dict[str, object]:
    return {
        name: operation.attributes[name]
        for name in names
        if name in operation.attributes
    }


def _restore_attributes(operation, names: tuple[str, ...], values) -> None:
    for name in names:
        if name in values:
            operation.attributes[name] = values[name]
        elif name in operation.attributes:
            del operation.attributes[name]


class _CompilerStateSnapshot:
    """Rollback capsule for compiler-owned nested-kernel state."""

    __slots__ = (
        "state",
        "module_operation_count",
        "host_entry",
        "host_operation_count",
        "host_argument_count",
        "host_attributes",
        "kernel_registry",
        "kernel_counter",
        "vf_group_counter",
        "debug_prints",
        "debug_plan_states",
    )

    def __init__(self, state) -> None:
        self.state = state
        self.module_operation_count = _operation_count(state.module.body)
        self.host_entry = (
            state.host_func.regions[0].blocks[0]
            if state.host_func is not None
            else None
        )
        self.host_operation_count = (
            _operation_count(self.host_entry) if self.host_entry is not None else 0
        )
        self.host_argument_count = (
            len(self.host_entry.arguments) if self.host_entry is not None else 0
        )
        self.host_attributes = (
            _capture_attributes(
                state.host_func,
                ("function_type", "arg_attrs"),
            )
            if state.host_func is not None
            else {}
        )
        self.kernel_registry = dict(state.kernel_registry)
        self.kernel_counter = state.kernel_counter
        self.vf_group_counter = state.vf_group_counter
        self.debug_prints = dict(state.debug_prints)
        self.debug_plan_states = tuple(
            (plan, dict(plan.__dict__)) for plan in state.debug_prints.values()
        )

    def restore(self) -> None:
        state = self.state
        if self.host_entry is not None:
            _trim_operations(self.host_entry, self.host_operation_count)
            while len(self.host_entry.arguments) > self.host_argument_count:
                self.host_entry.erase_argument(len(self.host_entry.arguments) - 1)
            _restore_attributes(
                state.host_func,
                ("function_type", "arg_attrs"),
                self.host_attributes,
            )
        _trim_operations(state.module.body, self.module_operation_count)
        state.kernel_registry.clear()
        state.kernel_registry.update(self.kernel_registry)
        state.kernel_counter = self.kernel_counter
        state.vf_group_counter = self.vf_group_counter
        for plan, values in self.debug_plan_states:
            plan.__dict__.clear()
            plan.__dict__.update(values)
        state.debug_prints.clear()
        state.debug_prints.update(self.debug_prints)


def _detach(operation) -> None:
    target = operation.operation if hasattr(operation, "operation") else operation
    target.detach_from_parent()


def _validate_block_dim(block_dim: object) -> int | None:
    """Return a static block dim or ``None`` for a valid dynamic wrapper."""

    hint = (
        "Use a positive Python int, or a registered non-Boolean DSL integer "
        "wrapper when the launch dimension is dynamic."
    )
    if type(block_dim) is int:
        if block_dim <= 0:
            raise CANNBotValueError(
                KM101_INVALID_BLOCK_DIM,
                f"block_dim must be greater than zero, got {block_dim}.",
                phase="kernel-materialize",
                path="block_dim",
                hint=hint,
            )
        return block_dim
    try:
        from cannbotdsl.core.contracts.elements import element_for_dsl_type
        from cannbotdsl.types.dtypes import DTypeKind

        info = element_for_dsl_type(type(block_dim))
        valid = info.dtype.kind is DTypeKind.INTEGER
        if valid and block_dim.type != info.scalar_mlir_type():
            valid = False
    except (TypeError, AttributeError):
        valid = False
    if valid:
        return None
    raise CANNBotTypeError(
        KM101_INVALID_BLOCK_DIM,
        f"block_dim has unsupported type {type(block_dim).__name__}.",
        phase="kernel-materialize",
        path="block_dim",
        hint=hint,
    )


def _canonical_debug_metadata(plan: DebugPrintPlan | None) -> tuple:
    if plan is None or not plan.has_prints:
        return ()
    records = tuple(
        (
            record.printer_id,
            record.label,
            record.source_location,
            record.dtype,
            tuple(record.shape),
            record.memloc,
            record.max_bytes,
            record.mode,
            record.view_offset_in_bytes,
            record.physical_copy_bytes,
            record.visible_payload_bytes,
            None if record.physical_shape is None else tuple(record.physical_shape),
            record.layout_kind,
            record.physical_format,
            record.is_scalar,
        )
        for record in plan.records
    )
    return (
        plan.block_dim,
        plan.subblock_dim,
        plan.payload_bytes,
        plan.counter_bytes,
        None if plan.payload_type is None else str(plan.payload_type),
        None if plan.counter_type is None else str(plan.counter_type),
        records,
    )


def _canonical_function_bytecode(kernel_func) -> bytes:
    """Serialize a candidate after temporary symbol/VF normalization."""

    operation = kernel_func.operation
    original_symbol = kernel_func.attributes["sym_name"]
    vf_attributes: list[tuple[object, object]] = []
    canonical_groups: dict[str, int] = {}

    def normalize(op):
        if "cannir.vf_group" in op.attributes:
            original = op.attributes["cannir.vf_group"]
            vf_attributes.append((op, original))
            original_integer = ir.IntegerAttr(original)
            group = canonical_groups.setdefault(
                str(original), len(canonical_groups) + 1
            )
            op.attributes["cannir.vf_group"] = ir.IntegerAttr.get(
                original_integer.type,
                group,
            )
        return ir.WalkResult.ADVANCE

    try:
        kernel_func.attributes["sym_name"] = ir.StringAttr.get(
            "__cannbotdsl_candidate__"
        )
        operation.walk(normalize, ir.WalkOrder.PRE_ORDER)
        stream = io.BytesIO()
        operation.write_bytecode(stream)
        return stream.getvalue()
    finally:
        kernel_func.attributes["sym_name"] = original_symbol
        for op, attribute in vf_attributes:
            op.attributes["cannir.vf_group"] = attribute


def _materialized_content_key(
    fn,
    source_digest: str,
    kernel_func,
    debug_plan: DebugPrintPlan | None,
    logical_signature: tuple[tuple[str, str], ...],
) -> str:
    identity = json.dumps(
        {
            "module": getattr(fn, "__module__", ""),
            "qualname": getattr(fn, "__qualname__", getattr(fn, "__name__", "")),
            "source_digest": source_digest,
            "debug": _canonical_debug_metadata(debug_plan),
            "logical_signature": logical_signature,
        },
        ensure_ascii=True,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    digest = hashlib.sha256()
    digest.update(identity)
    digest.update(b"\0")
    digest.update(_canonical_function_bytecode(kernel_func))
    return digest.hexdigest()


def _materialize_device_function(
    fn: Callable[..., object],
    call_plan,
    *,
    symbol_name: str,
    materialized_block_dim: int,
):
    state = _current_lowering_state()
    assert state is not None
    frontend_artifact = compile_function(
        fn,
        struct_ref_parameters=call_plan._struct_ref_parameter_names,
    )
    ir_builder = frontend_artifact.function
    kernel_func = None
    try:
        with ir.InsertionPoint(state.module.body):
            kernel_func = func.FuncOp(symbol_name, (list(call_plan.mlir_types), []))
            kernel_func.attributes["cannir.device"] = ir.UnitAttr.get()
            _copy_host_argument_attributes(kernel_func, call_plan, state)
            entry_block = kernel_func.add_entry_block()
            with ir.InsertionPoint(entry_block):
                from cannbotdsl.arena import (
                    ChannelArena,
                    _reset_current_channel_arena,
                    _set_current_channel_arena,
                )

                arena_token = _set_current_channel_arena(ChannelArena())
                from cannbotdsl.ops.cube import _finish_cube_trace, _start_cube_trace

                cube_trace, cube_trace_token = _start_cube_trace(kernel_func)
                state.debug_prints[symbol_name] = DebugPrintPlan(
                    kernel_name=symbol_name,
                    block_dim=materialized_block_dim,
                )
                try:
                    block_args = tuple(entry_block.arguments)
                    ir_args, ir_kwargs = call_plan.rebuild(block_args)
                    result = ir_builder(*ir_args, **ir_kwargs)
                    if result is not None:
                        from cannbotdsl.core.diag.diagnostics import (
                            CANNBotTypeError,
                            ST102_NON_VOID_ENTRY_RETURN,
                        )

                        raise CANNBotTypeError(
                            ST102_NON_VOID_ENTRY_RETURN,
                            f"Materialized kernel {fn.__qualname__!r} returned {type(result).__name__}; device entries must return None.",
                            phase="staging",
                            path=fn.__qualname__,
                            hint="Remove the returned value or make this helper an inline kernel.",
                        )
                    debug_plan = state.debug_prints[symbol_name]
                    if debug_plan.has_prints:
                        debug_plan.payload_type = _debug_memref_type(
                            debug_plan.payload_bytes, ctx=ir.Context.current
                        )
                        debug_plan.counter_type = _debug_counter_memref_type(
                            debug_plan.counter_bytes, ctx=ir.Context.current
                        )
                        entry = kernel_func.regions[0].blocks[0]
                        debug_plan.payload_arg = unwrap_operand(
                            entry.add_argument(
                                debug_plan.payload_type, kernel_func.location
                            )
                        )
                        debug_plan.counter_arg = unwrap_operand(
                            entry.add_argument(
                                debug_plan.counter_type, kernel_func.location
                            )
                        )
                        existing_arg_attrs = list(
                            kernel_func.attributes["arg_attrs"]
                        )
                        existing_arg_attrs.extend(
                            (ir.DictAttr.get({}), ir.DictAttr.get({}))
                        )
                        kernel_func.attributes["arg_attrs"] = (
                            ir.ArrayAttr.get(existing_arg_attrs)
                        )
                        for record in debug_plan.records:
                            if record.op is None:
                                continue
                            operand_count = len(record.op.operation.operands)
                            record.op.operation.operands[operand_count - 2] = (
                                debug_plan.payload_arg
                            )
                            record.op.operation.operands[operand_count - 1] = (
                                debug_plan.counter_arg
                            )
                        kernel_func.attributes["function_type"] = ir.TypeAttr.get(
                            ir.FunctionType.get(
                                [
                                    unwrap_operand(argument).type
                                    for argument in entry.arguments
                                ],
                                [],
                            )
                        )
                    func.ReturnOp([])
                except BaseException:
                    _finish_cube_trace(
                        cube_trace, cube_trace_token, finalize=False
                    )
                    raise
                else:
                    _finish_cube_trace(
                        cube_trace, cube_trace_token, finalize=True
                    )
                finally:
                    _reset_current_channel_arena(arena_token)
        debug_plan = state.debug_prints.get(symbol_name)
        if debug_plan is not None and not debug_plan.has_prints:
            state.debug_prints.pop(symbol_name, None)
            debug_plan = None
        kernel_func.operation.verify()
        return kernel_func, debug_plan, frontend_artifact.source_digest
    except BaseException:
        state.debug_prints.pop(symbol_name, None)
        if kernel_func is not None:
            _detach(kernel_func)
        raise


def _emit_launch(symbol_name: str, block_dim: object, call_plan, profile_attr) -> None:
    operands = list(call_plan._operands)
    operand_types = tuple(operand.type for operand in operands)
    if operand_types != call_plan.mlir_types:
        raise RuntimeError(
            "kernel launch operands do not match the captured device signature: "
            f"{operand_types!s} versus {call_plan.mlir_types!s}"
        )
    callee = ir.FlatSymbolRefAttr.get(symbol_name)
    block_dim_value = coerce_scalar_value(
        block_dim, ir.IntegerType.get_signless(64)
    )
    state = _current_lowering_state()
    assert state is not None
    debug_plan = state.debug_prints.get(symbol_name)
    if debug_plan is not None:
        if isinstance(block_dim, int):
            debug_plan.block_dim = int(block_dim)
        if debug_plan.host_payload_arg is None or debug_plan.host_counter_arg is None:
            if state.host_func is None:
                raise RuntimeError("debug print requires an active host function")
            host_entry = state.host_func.regions[0].blocks[0]
            debug_plan.host_payload_arg = unwrap_operand(
                host_entry.add_argument(
                    debug_plan.payload_type, state.host_func.location
                )
            )
            debug_plan.host_counter_arg = unwrap_operand(
                host_entry.add_argument(
                    debug_plan.counter_type, state.host_func.location
                )
            )
            state.host_func.attributes["function_type"] = ir.TypeAttr.get(
                ir.FunctionType.get(
                    [
                        unwrap_operand(argument).type
                        for argument in host_entry.arguments
                    ],
                    [],
                )
            )
            if "arg_attrs" in state.host_func.attributes:
                existing_arg_attrs = list(
                    state.host_func.attributes["arg_attrs"]
                )
            else:
                existing_arg_attrs = [
                    ir.DictAttr.get({})
                    for _ in range(len(host_entry.arguments) - 2)
                ]
            existing_arg_attrs.extend(
                (ir.DictAttr.get({}), ir.DictAttr.get({}))
            )
            state.host_func.attributes["arg_attrs"] = ir.ArrayAttr.get(
                existing_arg_attrs
            )
        operands.extend(
            [debug_plan.host_payload_arg, debug_plan.host_counter_arg]
        )
    launch = cannir.KernelLaunchOp(callee, block_dim_value, operands)
    launch.attributes["cannbotdsl.profile"] = profile_attr


def _emit_kernel_call(
    fn: Callable[..., object],
    call_args: tuple[object, ...],
    call_kwargs: dict[str, object],
    *,
    block_dim: object = 1,
    surface_signature: SurfaceSignature | None = None,
    profile=None,
) -> None:
    """Trace a candidate, deduplicate by content, and emit one launch."""

    state = _current_lowering_state()
    if state is None:
        raise RuntimeError("@kernel must be called inside @jit")
    snapshot = _CompilerStateSnapshot(state)
    try:
        static_block_dim = _validate_block_dim(block_dim)
        surface = surface_signature or SurfaceSignature.from_callable(fn)
        surface.validate_void_return_annotation(
            path=getattr(fn, "__qualname__", getattr(fn, "__name__", "kernel"))
        )
        staged = surface.bind_staged(call_args, call_kwargs)
        from cannbotdsl.core.compiler.staging import validate_no_active_ssa

        for item in staged.parameters:
            if item.role not in {_StagedRole.RECEIVER, _StagedRole.CONSTEXPR}:
                continue
            value = staged.bound.arguments[item.parameter.name]
            validate_no_active_ssa(
                value,
                path=item.parameter.name,
                subject=(
                    "materialized kernel receiver"
                    if item.role is _StagedRole.RECEIVER
                    else "materialized Constexpr"
                ),
            )
        call_plan = _trace_call_plan(
            fn,
            staged.bound.arguments,
            surface_signature=surface,
            staged_binding=staged,
        )
        candidate_symbol = (
            f"__cannbotdsl_candidate_{fn.__name__}_{state.kernel_counter}"
        )
        vf_before_candidate = state.vf_group_counter
        candidate_func, candidate_debug, source_digest = (
            _materialize_device_function(
                fn,
                call_plan,
                symbol_name=candidate_symbol,
                materialized_block_dim=(
                    static_block_dim if static_block_dim is not None else 1
                ),
            )
        )
        if candidate_debug is not None and static_block_dim is None:
            raise CANNBotValueError(
                KM101_INVALID_BLOCK_DIM,
                "A debug-print kernel requires a statically known block_dim.",
                phase="kernel-materialize",
                path="block_dim",
                hint="Launch this debug kernel with a positive Python int block_dim.",
            )

        from cannbotdsl.core.compiler.profiling import launch_profile

        argument_access = ()
        if profile is None:
            from cannbotdsl._mlir._mlir_libs import _cannir

            argument_access = _cannir.infer_kernel_argument_access(candidate_func.operation)
        profile_attr = launch_profile(fn, profile, call_plan, argument_access)

        content_key = _materialized_content_key(
            fn,
            source_digest,
            candidate_func,
            candidate_debug,
            call_plan._logical_signature,
        )
        argument_types = tuple(
            str(unwrap_operand(argument).type)
            for argument in candidate_func.regions[0].blocks[0].arguments
        )
        existing = state.kernel_registry.get(content_key)
        if existing is not None:
            if not isinstance(existing, _MaterializedKernelRecord):
                raise CANNBotInternalError(
                    IN001_COMPILER_INVARIANT,
                    "Materialized kernel registry contains an invalid record.",
                    phase="compiler",
                    path=content_key,
                    hint="Report this compiler invariant failure with the generated MLIR.",
                )
            if (
                existing.logical_signature != call_plan._logical_signature
                or existing.argument_types != argument_types
            ):
                raise CANNBotInternalError(
                    IN001_COMPILER_INVARIANT,
                    "A materialized content digest matched a different device signature.",
                    phase="compiler",
                    path=content_key,
                    hint="Report this digest/signature collision with both generated functions.",
                )
            if candidate_debug is not None:
                state.debug_prints.pop(candidate_symbol, None)
            _detach(candidate_func)
            state.vf_group_counter = vf_before_candidate
            symbol_name = existing.symbol_name
        else:
            symbol_name = f"kernel_{fn.__name__}_{state.kernel_counter}"
            candidate_func.attributes["sym_name"] = ir.StringAttr.get(symbol_name)
            if candidate_debug is not None:
                state.debug_prints.pop(candidate_symbol, None)
                candidate_debug.kernel_name = symbol_name
                state.debug_prints[symbol_name] = candidate_debug
            state.kernel_registry[content_key] = _MaterializedKernelRecord(
                content_key,
                symbol_name,
                call_plan._logical_signature,
                argument_types,
                candidate_debug,
            )
            state.kernel_counter += 1

        _emit_launch(symbol_name, block_dim, call_plan, profile_attr)
    except BaseException:
        snapshot.restore()
        raise
    return None


def _copy_host_argument_attributes(kernel_func, call_plan, state) -> None:
    """Propagate allocation bounds from host roots to device arguments."""

    empty = ir.DictAttr.get({})
    if state.host_func is None:
        kernel_func.attributes["arg_attrs"] = ir.ArrayAttr.get(
            [empty for _ in call_plan._operands]
        )
        return
    if "arg_attrs" not in state.host_func.attributes:
        kernel_func.attributes["arg_attrs"] = ir.ArrayAttr.get(
            [empty for _ in call_plan._operands]
        )
        return
    host_attributes = state.host_func.attributes["arg_attrs"]
    host_arguments = tuple(state.host_func.regions[0].blocks[0].arguments)
    # DSL scalar casters overload ``Value.__eq__`` to build an SSA compare,
    # so Python equality is not an identity predicate here. MLIR Value hashes
    # are stable for wrappers around the same underlying SSA value.
    host_argument_indices = {
        hash(unwrap_operand(argument)): index
        for index, argument in enumerate(host_arguments)
    }
    copied = []
    for operand in call_plan._operands:
        source = host_argument_indices.get(
            hash(unwrap_operand(operand))
        )
        copied.append(empty if source is None else host_attributes[source])
    kernel_func.attributes["arg_attrs"] = ir.ArrayAttr.get(copied)
