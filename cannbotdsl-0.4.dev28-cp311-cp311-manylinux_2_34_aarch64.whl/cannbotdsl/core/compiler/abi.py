# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Versioning helpers for the generated AscendC host calling convention."""

import re


HOST_ABI_VERSION = 9
ASCENDC_HOST_ABI_MARKER = f"// CANNBOTDSL_HOST_ABI_VERSION={HOST_ABI_VERSION}"
_HOST_ABI_PATTERN = re.compile(
    r"^\s*//\s*CANNBOTDSL_HOST_ABI_VERSION=(\d+)\s*$",
    re.MULTILINE,
)


def validate_ascendc_host_abi(source: str, *, source_path: str) -> None:
    """Reject reused AscendC sources with an incompatible host ABI."""
    matches = _HOST_ABI_PATTERN.findall(source)
    if not matches:
        raise ValueError(
            f"CANNBOTDSL_REUSE_ASCENDC source {source_path!r} has no host ABI "
            f"marker. Regenerate it with CANNBOTDSL_DUMP_ASCENDC=1 before reuse."
        )
    versions = {int(version) for version in matches}
    if versions != {HOST_ABI_VERSION}:
        rendered = ", ".join(str(version) for version in sorted(versions))
        raise ValueError(
            f"CANNBOTDSL_REUSE_ASCENDC source {source_path!r} uses host ABI "
            f"version(s) {rendered}; this runtime requires "
            f"{HOST_ABI_VERSION}. Regenerate the AscendC dump."
        )
