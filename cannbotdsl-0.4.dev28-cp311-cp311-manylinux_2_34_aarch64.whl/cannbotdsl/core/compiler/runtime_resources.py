# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Acquire the immutable runtime resources used by the compiler pipeline."""

from __future__ import annotations

import atexit
import hashlib
import json
import os
import threading
from contextlib import ExitStack
from dataclasses import dataclass
from importlib import resources
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class RuntimeResources:
    """One process-wide, content-addressed VF template snapshot."""

    template_dir: Path
    template_digest: str


_LOCK = threading.Lock()
_RESOURCE_STACK = ExitStack()
_PACKAGED_TEMPLATE_DIR: Path | None = None
_ACQUIRED: RuntimeResources | None = None
atexit.register(_RESOURCE_STACK.close)


def _error(source: str, message: str) -> RuntimeError:
    return RuntimeError(f"CANNBotDSL VF resources selected by {source} {message}")


def _canonical_json(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _validate_and_digest(directory: Path, source: str) -> RuntimeResources:
    directory = directory.expanduser().resolve()
    if not directory.is_dir():
        raise _error(source, f"do not name an existing directory: {directory}")

    manifest_path = directory / "manifest.json"
    if not manifest_path.is_file():
        raise _error(source, f"have no manifest.json: {directory}")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise _error(source, f"contain an invalid manifest {manifest_path}: {exc}") from exc

    if not isinstance(manifest, dict) or manifest.get("version") != "1.0":
        raise _error(source, f"require manifest version 1.0: {manifest_path}")
    entries = manifest.get("entries")
    if not isinstance(entries, list) or not entries:
        raise _error(source, f"contain no manifest entries: {manifest_path}")

    normalized_entries: list[tuple[bytes, dict[str, Any]]] = []
    seen: set[bytes] = set()
    filenames: set[str] = set()
    for index, entry in enumerate(entries):
        if not isinstance(entry, dict):
            raise _error(source, f"contain a non-object entry {index}: {manifest_path}")
        signature = entry.get("signature")
        method = entry.get("method")
        filename = entry.get("mlir_file")
        function = entry.get("func_name")
        if not isinstance(signature, dict) or not isinstance(signature.get("op"), str) or not signature["op"]:
            raise _error(source, f"contain an invalid signature at entry {index}: {manifest_path}")
        if not all(isinstance(value, str) and value for value in (method, filename, function)):
            raise _error(source, f"contain an incomplete entry {index}: {manifest_path}")
        assert isinstance(filename, str)
        if Path(filename).name != filename or "/" in filename or "\\" in filename or not filename.endswith(".mlir"):
            raise _error(source, f"contain an unsafe mlir_file at entry {index}: {filename!r}")
        template_path = directory / filename
        if not template_path.is_file():
            raise _error(source, f"reference a missing template at entry {index}: {template_path}")

        encoded = _canonical_json(entry)
        if encoded in seen:
            raise _error(source, f"contain duplicate entry {index}: {manifest_path}")
        seen.add(encoded)
        normalized_entries.append((encoded, entry))
        filenames.add(filename)

    normalized_entries.sort(key=lambda item: item[0])
    normalized_manifest = {key: value for key, value in manifest.items() if key != "entries"}
    normalized_manifest["entries"] = [entry for _, entry in normalized_entries]

    digest = hashlib.sha256()
    digest.update(_canonical_json(normalized_manifest))
    for filename in sorted(filenames):
        digest.update(b"\0template\0")
        digest.update(filename.encode("utf-8"))
        digest.update(b"\0")
        try:
            digest.update((directory / filename).read_bytes())
        except OSError as exc:
            raise _error(source, f"cannot read template {directory / filename}: {exc}") from exc

    return RuntimeResources(directory, digest.hexdigest())


def _packaged_template_dir() -> Path:
    global _PACKAGED_TEMPLATE_DIR
    if _PACKAGED_TEMPLATE_DIR is None:
        traversable = resources.files("cannbotdsl").joinpath("templates", "mlir")
        try:
            extracted = _RESOURCE_STACK.enter_context(resources.as_file(traversable))
        except (OSError, TypeError) as exc:
            raise RuntimeError("failed to materialize packaged CANNBotDSL VF resources") from exc
        _PACKAGED_TEMPLATE_DIR = Path(extracted).resolve()
    return _PACKAGED_TEMPLATE_DIR


def _select_template_dir() -> tuple[Path, str]:
    explicit = os.environ.get("CANNBOTDSL_TEMPLATE_DIR")
    if explicit:
        return Path(explicit), "CANNBOTDSL_TEMPLATE_DIR"
    return _packaged_template_dir(), "the cannbotdsl package"


def _configure_native(directory: Path) -> None:
    from cannbotdsl._mlir._mlir_libs import _cannir_runtime

    try:
        _cannir_runtime._configure_vf_templates(str(directory))
    except Exception as exc:
        raise RuntimeError(f"failed to configure native VF templates from {directory}: {exc}") from exc


def acquire_runtime_resources() -> RuntimeResources:
    """Validate, configure, and return the process-wide runtime snapshot.

    The selected path and its complete content digest are rechecked on every
    call. Once native passes have observed one snapshot, changing either
    requires a new process.
    """

    global _ACQUIRED
    with _LOCK:
        directory, source = _select_template_dir()
        candidate = _validate_and_digest(directory, source)
        if _ACQUIRED is None:
            _configure_native(candidate.template_dir)
            _ACQUIRED = candidate
            return candidate
        if candidate != _ACQUIRED:
            raise RuntimeError(
                "CANNBotDSL VF runtime resources changed after initialization; "
                "restart the process to select a different path or content snapshot"
            )
        return _ACQUIRED


__all__ = ["RuntimeResources"]
