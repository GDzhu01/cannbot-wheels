# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""MLIR ``PassManager`` wrapper for the CANNIR pipeline.

The pipeline string is driven by ``CANNBOTDSL_CANNIR_PIPELINE``; failure to
parse the user override falls back to the bare ``canonicalize,cse`` pair
so the rest of the compile path still has a chance to surface a sensible
error.

Lives next to :mod:`cannbotdsl.core.compiler.builder` because the build
orchestrator is its only caller (JIT enters through builder as well).
"""

import logging

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir import passmanager as pm

from cannbotdsl.core.utils.timer import timer as _timer

_LOG = logging.getLogger(__name__)


@_timer("transform:run_ir_passes")
def _run_cannir_passes(module: ir.Module) -> None:
    """Run CANNIR/MLIR passes on the module using the MLIR Python PassManager."""
    # Allow overriding the pipeline from environment, e.g.:
    # CANNBOTDSL_CANNIR_PIPELINE='builtin.module(canonicalize,cse)'
    from cannbotdsl.core.utils.env import env
    _env = env()
    print_mlir = _env.print_mlir
    pipeline = _env.cannir_pipeline
    fallback_pipeline = "builtin.module(canonicalize,cse)"
    ir.Context.current.enable_multithreading(False)

    # Logged before parsing so caplog-based tests can inspect the pre-pass
    # module even when the pipeline parse below falls back to canonicalize/cse.
    if _LOG.isEnabledFor(logging.DEBUG):
        _LOG.debug("Original module before passes:\n%s", str(module))

    pmgr = None
    try:
        pmgr = pm.PassManager.parse(pipeline)
        if print_mlir:
            pmgr.enable_ir_printing()
    except Exception as e:
        if pipeline == fallback_pipeline:
            if _LOG.isEnabledFor(logging.DEBUG):
                _LOG.debug("Module before failed pass parse:\n%s", str(module))
            raise RuntimeError(
                f"Failed to parse pass pipeline '{pipeline}': {e}"
            ) from e
        _LOG.warning(
            "Failed to parse pass pipeline '%s': %s; falling back to '%s'.",
            pipeline,
            e,
            fallback_pipeline,
        )
        try:
            pmgr = pm.PassManager.parse(fallback_pipeline)
            if print_mlir:
                pmgr.enable_ir_printing()
            pipeline = fallback_pipeline
        except Exception as fallback_err:  # pragma: no cover - defensive
            if _LOG.isEnabledFor(logging.DEBUG):
                _LOG.debug("Module before failed fallback pass parse:\n%s", str(module))
            raise RuntimeError(
                f"Failed to parse fallback pass pipeline '{fallback_pipeline}': "
                f"{fallback_err}"
            ) from fallback_err

    try:
        pmgr.run(module.operation)
    except Exception as e:
        if _LOG.isEnabledFor(logging.DEBUG):
            _LOG.debug("Module before failed pass run:\n%s", str(module))
        raise RuntimeError(f"Failed to run pass pipeline '{pipeline}': {e}") from e

    # Snapshot string: ``module`` is mutated in place by the pipeline; logging
    # may defer ``%`` formatting until handlers run, so pass a plain string.
    if _LOG.isEnabledFor(logging.DEBUG):
        module_text = str(module)
        _LOG.debug("Original module after passes:\n%s", module_text)
        _LOG.debug("Module after pass pipeline '%s':\n%s", pipeline, module_text)
