# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Compile-time ctypes layouts for AscendC tensor descriptor slots.

The generated AscendC host function expects arguments of type
``KernelArgTensor_<dtype>_<ndim>d``, e.g.::

    struct KernelArgTensor_float_2d {
        __gm__ float* ptr;
        int64_t shape[2];
        int64_t stride[2];
    };

This module dynamically generates matching :class:`ctypes.Structure` classes.
Runtime population is owned by the native HostCallPlan's temporary DLPack
metadata snapshots.

Python/DLPack names are resolved through the canonical semantic dtype
registry.  The C++ translator independently validates its compiled backend
type set and fails closed; the end-to-end mapping tests guard that boundary.
"""

import ctypes
from typing import Dict, Type

# Cache of dynamically generated Structure classes keyed by struct name
_STRUCT_CACHE: Dict[str, Type[ctypes.Structure]] = {}


def dtype_to_elem_name(dtype_code: int, dtype_bits: int) -> str:
    """Return the AscendC C++ element type name for a DLPack dtype.

    Raises :class:`ValueError` if the dtype is not supported.
    """
    from cannbotdsl.core.contracts.elements import element_for_dlpack

    try:
        return element_for_dlpack(dtype_code, dtype_bits).cpp_name
    except TypeError as error:
        raise ValueError(str(error)) from error


def make_kernel_arg_struct(
    elem_name: str,
    ndim: int,
    *,
    encoding: str = "identity",
    physical_rank: int | None = None,
) -> Type[ctypes.Structure]:
    """Dynamically create a ctypes.Structure matching AscendC ``KernelArgTensor_<dtype>_<ndim>d``.

    The returned class is cached so the same class object is reused across calls
    with the same *elem_name* and *ndim*.
    """
    if encoding not in ("identity", "fractal_nz"):
        raise ValueError(f"unknown tensor storage encoding {encoding!r}")
    if encoding == "identity":
        if physical_rank not in (None, ndim):
            raise ValueError("identity physical rank must alias logical rank")
        physical_rank = ndim
        cls_name = f"KernelArgTensor_{elem_name}_{ndim}d"
    else:
        if physical_rank is None or physical_rank != ndim + 2:
            raise ValueError(
                "FRACTAL_NZ physical rank must equal logical rank + 2"
            )
        cls_name = (
            f"KernelArgTensor_{elem_name}_{ndim}d_nz{physical_rank}d"
        )
    if cls_name in _STRUCT_CACHE:
        return _STRUCT_CACHE[cls_name]

    fields = [
            ("ptr", ctypes.c_void_p),
            ("shape", ctypes.c_int64 * ndim),
            ("stride", ctypes.c_int64 * ndim),
        ]
    if encoding == "fractal_nz":
        fields.extend(
            (
                ("physical_shape", ctypes.c_int64 * physical_rank),
                ("physical_stride", ctypes.c_int64 * physical_rank),
            )
        )
    cls = type(cls_name, (ctypes.Structure,), {"_fields_": fields})
    _STRUCT_CACHE[cls_name] = cls
    return cls
