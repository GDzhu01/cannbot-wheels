# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""One-shot direct-JIT execution through :class:`ProviderCallable`."""

from cannbotdsl.core.compiler.function import ProviderCallable


def _build_provider_callable_for_jit(artifact, debug_plans):
    return ProviderCallable._create(
        artifact.so_path,
        artifact.symbol_name,
        artifact.contract,
        host_abi_version=artifact.host_abi_version,
        owns_so=artifact.owns_so,
        debug_plans=debug_plans,
        content_key=artifact.content_key,
        format_version_tag=artifact.format_version_tag,
    )


def _execute_bound_call(program, bound_call) -> None:
    """Execute with a fresh provider-metadata snapshot.

    ``bind_jit_call`` observes metadata to select the exact specialization.
    ``ProviderCallable`` deliberately observes it again immediately before
    invocation, so a cold compile cannot leave execution with a stale shape,
    stride, or address snapshot.  Each observation batch deduplicates repeated
    provider objects independently.
    """

    from cannbotdsl.core.utils.timer import time_block

    positional = []
    keywords = {}
    for parameter, value in zip(
        bound_call.contract.runtime_parameters,
        bound_call.runtime_values,
    ):
        if parameter.kind == "KEYWORD_ONLY":
            keywords[parameter.name] = value
        else:
            positional.append(value)
    with time_block("execute:call_host_device"):
        program(*positional, **keywords)


__all__ = ["_build_provider_callable_for_jit", "_execute_bound_call"]
