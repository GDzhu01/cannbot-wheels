# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Canonical binary-schema expectations for the packed host ABI."""

from __future__ import annotations

import hashlib
import json
import ctypes
from dataclasses import dataclass

from cannbotdsl.core.contracts.codec import _argument_to_dict
from cannbotdsl.core.contracts.elements import element_for_tag
from cannbotdsl.core.compiler.physical_abi import host_carrier, physical_argument
from cannbotdsl.core.contracts.model import (
    BinaryExpr,
    ConstantExpr,
    DimensionExpr,
    ExactLayouts,
    ScalarContract,
    StructContract,
    StructRefContract,
    TensorContract,
    TensorListContract,
    TemplateLayout,
)
from cannbotdsl.core.contracts.normalize import format_expression


SLOT_TENSOR = 1
SLOT_SCALAR = 2
SLOT_BUFFER = 3
ENCODING_IDENTITY = 0
ENCODING_FRACTAL_NZ = 1

_BINARY_EXPRESSION_KINDS = frozenset(
    {"add", "sub", "mul", "floordiv"}
)
_I64_MIN = -(1 << 63)
_I64_MAX = (1 << 63) - 1


class _ExpressionCompiler:
    """Compile one dimension scope into a deduplicated postfix DAG.

    Global call dimensions and each TensorList template have separate binding
    scopes, but their expression indexing, rendering, topological ordering,
    and structural deduplication rules must stay identical.
    """

    __slots__ = (
        "_dimension_indices",
        "_expression_indices",
        "_expressions",
    )

    def __init__(self, dimensions):
        self._dimension_indices = {
            item.name: index for index, item in enumerate(dimensions)
        }
        self._expression_indices = {}
        self._expressions = []

    def compile(self, expression) -> int:
        cached = self._expression_indices.get(expression)
        if cached is not None:
            return cached

        rendered = format_expression(expression)
        if isinstance(expression, ConstantExpr):
            step = {
                "kind": "constant",
                "value": expression.value,
                "rendered": rendered,
            }
        elif isinstance(expression, DimensionExpr):
            step = {
                "kind": "dimension",
                "dimension": self._dimension_indices[expression.name],
                "rendered": rendered,
            }
        elif isinstance(expression, BinaryExpr):
            if expression.op not in _BINARY_EXPRESSION_KINDS:
                raise TypeError(
                    f"unknown shape expression operator {expression.op!r}"
                )
            step = {
                "kind": expression.op,
                "lhs": self.compile(expression.lhs),
                "rhs": self.compile(expression.rhs),
                "rendered": rendered,
            }
        else:  # pragma: no cover - CallContract validation owns this invariant.
            raise TypeError(f"unknown shape expression {expression!r}")

        index = len(self._expressions)
        self._expressions.append(step)
        self._expression_indices[expression] = index
        return index

    @property
    def expressions(self) -> tuple[dict[str, object], ...]:
        return tuple(self._expressions)


def _canonical_argument_bytes(argument) -> bytes:
    return json.dumps(
        _argument_to_dict(argument),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def abi_type_digest(argument) -> str:
    """Return the logical type digest attached to one physical ABI slot."""

    return hashlib.sha256(_canonical_argument_bytes(argument)).hexdigest()


def _physical_slot_kind(argument) -> int:
    if isinstance(argument, (TensorContract, StructRefContract)):
        return SLOT_TENSOR
    if isinstance(argument, ScalarContract):
        return SLOT_SCALAR
    if isinstance(argument, StructContract):
        return SLOT_BUFFER
    raise TypeError(f"unknown physical ABI argument {argument!r}")


def slot_kind(argument) -> int:
    return _physical_slot_kind(physical_argument(argument))


def _physical_slot_element(argument) -> str | None:
    if isinstance(argument, StructRefContract):
        return "u8"
    if isinstance(argument, (TensorContract, ScalarContract)):
        return argument.element
    return None


def _physical_slot_dtype(argument) -> tuple[int, int, int]:
    element = _physical_slot_element(argument)
    if element is None:
        return (0, 0, 1)
    info = element_for_tag(element)
    return (info.dlpack_code, info.dlpack_bits, 1)


def slot_dtype(argument) -> tuple[int, int, int]:
    return _physical_slot_dtype(host_carrier(argument))


def _physical_slot_rank(argument) -> int:
    if isinstance(argument, StructRefContract):
        return 1
    if isinstance(argument, TensorContract):
        return argument.rank
    return 0


def slot_rank(argument) -> int:
    return _physical_slot_rank(host_carrier(argument))


def _is_tensor_descriptor(argument) -> bool:
    return isinstance(argument, (TensorContract, StructRefContract))


def _tensor_encoding(argument) -> tuple[int, int]:
    logical_rank = _physical_slot_rank(argument)
    if not isinstance(argument, TensorContract):
        return (ENCODING_IDENTITY, logical_rank)
    storage = argument.storage_encoding
    if storage is None:
        return (ENCODING_IDENTITY, logical_rank)
    if storage.encoding != "fractal_nz":
        raise TypeError(f"unknown tensor storage encoding {storage.encoding!r}")
    return (ENCODING_FRACTAL_NZ, len(storage.physical_shape))


def _checked_i64(value: int, expression) -> int:
    if value < _I64_MIN or value > _I64_MAX:
        raise ValueError(
            "FRACTAL_NZ physical upper-bound expression "
            f"{format_expression(expression)} overflowed signed int64"
        )
    return value


def _expression_interval(
    expression,
    dimensions,
) -> tuple[int, int] | None:
    """Return a conservative finite signed-i64 interval, if provable.

    ``None`` means that the expression references an unbounded dimension (or
    otherwise cannot be handled by this deliberately small interval domain).
    It is not an error by itself: metadata-only users do not require an
    allocation upper bound.
    """

    if isinstance(expression, ConstantExpr):
        value = _checked_i64(expression.value, expression)
        return (value, value)
    if isinstance(expression, DimensionExpr):
        dimension = dimensions[expression.name]
        minimum = _checked_i64(dimension.minimum, expression)
        if dimension.maximum is None:
            return None
        maximum = _checked_i64(dimension.maximum, expression)
        return (minimum, maximum)
    if not isinstance(expression, BinaryExpr):
        raise TypeError(f"unknown shape expression {expression!r}")

    lhs = _expression_interval(expression.lhs, dimensions)
    if expression.op == "floordiv":
        if not isinstance(expression.rhs, ConstantExpr):
            return None
        divisor = _checked_i64(expression.rhs.value, expression.rhs)
        if divisor <= 0:
            return None
        if lhs is None:
            return None
        return (
            _checked_i64(lhs[0] // divisor, expression),
            _checked_i64(lhs[1] // divisor, expression),
        )

    rhs = _expression_interval(expression.rhs, dimensions)
    if lhs is None or rhs is None:
        return None
    lhs_min, lhs_max = lhs
    rhs_min, rhs_max = rhs
    if expression.op == "add":
        return (
            _checked_i64(lhs_min + rhs_min, expression),
            _checked_i64(lhs_max + rhs_max, expression),
        )
    if expression.op == "sub":
        return (
            _checked_i64(lhs_min - rhs_max, expression),
            _checked_i64(lhs_max - rhs_min, expression),
        )
    if expression.op == "mul":
        endpoints = tuple(
            _checked_i64(left * right, expression)
            for left in (lhs_min, lhs_max)
            for right in (rhs_min, rhs_max)
        )
        return (min(endpoints), max(endpoints))
    raise TypeError(f"unknown shape expression operator {expression.op!r}")


def physical_shape_upper_bounds(contract) -> tuple[tuple[int, ...] | None, ...]:
    """Return one bounded physical allocation vector per ABI argument."""

    dimensions = {item.name: item for item in contract.dimensions}
    result = []
    for logical_argument in contract.abi_arguments:
        argument = physical_argument(logical_argument)
        storage = (
            argument.storage_encoding
            if isinstance(argument, TensorContract)
            else None
        )
        if storage is None:
            result.append(None)
            continue
        intervals = tuple(
            _expression_interval(item, dimensions)
            for item in storage.physical_shape
        )
        if any(interval is None for interval in intervals):
            result.append(None)
            continue
        values = tuple(interval[1] for interval in intervals)
        if any(value <= 0 for value in values):
            raise ValueError(
                "FRACTAL_NZ physical upper bound must be strictly positive"
            )
        result.append(values)
    return tuple(result)


def _physical_shape_mlir_argument_attributes(upper_bounds):
    """Build the canonical MLIR argument-attribute vector for bounds."""

    import cannbotdsl._mlir.ir as ir

    attributes = []
    for upper_bound in upper_bounds:
        values = {}
        if upper_bound is not None:
            values["cannir.physical_shape_upper_bound"] = (
                ir.DenseI64ArrayAttr.get(upper_bound)
            )
        attributes.append(ir.DictAttr.get(values))
    return ir.ArrayAttr.get(attributes)


def expected_slots(
    contract, ctypes_types=None, debug_plans=()
) -> tuple[dict[str, object], ...]:
    supplied_ctypes = ctypes_types is not None
    if supplied_ctypes:
        ctypes_types = tuple(ctypes_types)
    else:
        from cannbotdsl.core.compiler.abi_schema import ctypes_type
    if supplied_ctypes and len(ctypes_types) != len(contract.abi_arguments):
        raise RuntimeError("host ABI ctypes/contract slot count mismatch")
    slots = []
    for index, logical_argument in enumerate(contract.abi_arguments):
        argument = host_carrier(logical_argument)
        if supplied_ctypes:
            ctype = ctypes_types[index]
        else:
            ctype = ctypes_type(argument)
        slot = {
            "kind": _physical_slot_kind(argument),
            "logical_rank": _physical_slot_rank(argument),
            "type_digest": abi_type_digest(logical_argument),
            "public": True,
            "size": ctypes.sizeof(ctype),
            "alignment": ctypes.alignment(ctype),
            "pointer_offset": 0,
            "shape_offset": 0,
            "stride_offset": 0,
            "encoding": ENCODING_IDENTITY,
            "physical_rank": _physical_slot_rank(argument),
            "physical_shape_offset": 0,
            "physical_stride_offset": 0,
        }
        if _is_tensor_descriptor(argument):
            encoding, physical_rank = _tensor_encoding(argument)
            slot.update(
                pointer_offset=ctype.ptr.offset,
                shape_offset=ctype.shape.offset,
                stride_offset=ctype.stride.offset,
                encoding=encoding,
                physical_rank=physical_rank,
                physical_shape_offset=(
                    ctype.shape.offset
                    if encoding == ENCODING_IDENTITY
                    else ctype.physical_shape.offset
                ),
                physical_stride_offset=(
                    ctype.stride.offset
                    if encoding == ENCODING_IDENTITY
                    else ctype.physical_stride.offset
                ),
            )
        if _physical_slot_element(argument) is not None:
            code, bits, lanes = _physical_slot_dtype(argument)
            slot.update(
                dtype_code=code,
                dtype_bits=bits,
                dtype_lanes=lanes,
            )
        slots.append(slot)
    from cannbotdsl.core.compiler.marshalling import make_kernel_arg_struct

    debug_ctypes = {
        "payload": make_kernel_arg_struct("int8_t", 1),
        "counter": make_kernel_arg_struct("int64_t", 1),
    }
    for plan_index, plan in enumerate(debug_plans):
        for suffix, bits in (("payload", 8), ("counter", 64)):
            debug_ctype = debug_ctypes[suffix]
            slots.append(
                {
                    "kind": SLOT_TENSOR,
                    "logical_rank": 1,
                    "physical_rank": 1,
                    "encoding": ENCODING_IDENTITY,
                    "type_digest": "00" * 32,
                    "public": False,
                    "size": ctypes.sizeof(debug_ctype),
                    "alignment": ctypes.alignment(debug_ctype),
                    "pointer_offset": debug_ctype.ptr.offset,
                    "shape_offset": debug_ctype.shape.offset,
                    "stride_offset": debug_ctype.stride.offset,
                    "physical_shape_offset": debug_ctype.shape.offset,
                    "physical_stride_offset": debug_ctype.stride.offset,
                    "dtype_code": 0,
                    "dtype_bits": bits,
                    "dtype_lanes": 1,
                    "name": f"__debug_{plan_index}_{suffix}",
                }
            )
    return tuple(slots)


def host_call_plan_spec(contract, debug_plans=()) -> dict[str, object]:
    """Compile a ``CallContract`` into the native immutable binder program.

    The native extension deliberately knows nothing about Python DSL objects.
    This compact, fully primitive description is built once next to the
    ``ProgramImage`` and contains the exact expression program used by N0 calls.
    """

    dimensions = tuple(contract.dimensions)
    expression_compiler = _ExpressionCompiler(dimensions)
    compile_expression = expression_compiler.compile

    slots = []
    for parameter in contract.runtime_parameters:
        argument = parameter.argument
        if argument is None:  # pragma: no cover - contract validation owns this.
            raise AssertionError("runtime parameter has no argument contract")
        if isinstance(argument, StructRefContract):
            code, bits, lanes = slot_dtype(argument)
            slots.append(
                {
                    "kind": "tensor",
                    "name": parameter.name,
                    "public": True,
                    "dtype_code": code,
                    "dtype_bits": bits,
                    "dtype_lanes": lanes,
                    "rank": 1,
                    "encoding": "identity",
                    "physical_rank": 1,
                    "shape": (compile_expression(ConstantExpr(argument.schema.size)),),
                    "stride": (compile_expression(ConstantExpr(1)),),
                    "physical_shape": (
                        compile_expression(ConstantExpr(argument.schema.size)),
                    ),
                    "data_alignment": argument.schema.alignment,
                    "require_exact_stride": True,
                    "require_zero_byte_offset": True,
                }
            )
        elif isinstance(argument, TensorListContract):
            element_info = element_for_tag(argument.element_type)
            code, bits, lanes = (
                element_info.dlpack_code,
                element_info.dlpack_bits,
                1,
            )
            slot = {
                "kind": "tensor_list",
                "name": parameter.name,
                "public": True,
                "descriptor_version": argument.descriptor_version,
                "record_words": argument.record_words,
                "length": compile_expression(argument.length),
                "element_dtype_code": code,
                "element_dtype_bits": bits,
                "element_dtype_lanes": lanes,
                "element_rank": argument.element_rank,
                "require_exact_stride": True,
            }
            if isinstance(argument.layout, TemplateLayout):
                local_dimensions = argument.layout.element_dimensions
                local_compiler = _ExpressionCompiler(local_dimensions)

                slot.update(
                    layout_kind="template",
                    element_dimensions=tuple(
                        {
                            "name": item.name,
                            "minimum": item.minimum,
                            "maximum": item.maximum,
                            "multiple_of": item.multiple_of,
                        }
                        for item in local_dimensions
                    ),
                    element_shape=tuple(
                        local_compiler.compile(item)
                        for item in argument.layout.shape_expressions
                    ),
                    element_stride=tuple(
                        local_compiler.compile(item)
                        for item in argument.layout.stride_expressions
                    ),
                    element_expressions=local_compiler.expressions,
                )
            elif isinstance(argument.layout, ExactLayouts):
                slot.update(
                    layout_kind="exact",
                    exact_layouts=tuple(
                        {
                            "shape": item.shape,
                            "stride": item.stride,
                        }
                        for item in argument.layout.items
                    ),
                )
            else:  # pragma: no cover - validated contract.
                raise TypeError(
                    f"unknown TensorList layout {argument.layout!r}"
                )
            slots.append(slot)
        elif isinstance(argument, TensorContract):
            code, bits, lanes = slot_dtype(argument)
            # Guards describe what the caller hands over, which for a packed
            # sub-byte dtype is the int8 byte carrier, not the logical view.
            carrier = host_carrier(argument)
            storage = argument.storage_encoding
            physical_shape = (
                carrier.shape if storage is None else storage.physical_shape
            )
            slots.append(
                {
                    "kind": "tensor",
                    "name": parameter.name,
                    "public": True,
                    "dtype_code": code,
                    "dtype_bits": bits,
                    "dtype_lanes": lanes,
                    "rank": carrier.rank,
                    "encoding": (
                        "identity" if storage is None else storage.encoding
                    ),
                    "physical_rank": len(physical_shape),
                    "shape": tuple(
                        compile_expression(item) for item in carrier.shape
                    ),
                    "stride": tuple(
                        compile_expression(item) for item in carrier.stride
                    ),
                    "physical_shape": tuple(
                        compile_expression(item) for item in physical_shape
                    ),
                }
            )
        elif isinstance(argument, ScalarContract):
            info = element_for_tag(argument.element)
            slots.append(
                {
                    "kind": "scalar",
                    "name": parameter.name,
                    "public": True,
                    "scalar_kind": info.scalar_kind,
                    "bits": info.dtype.bits,
                    "signed": bool(info.dtype.signed),
                }
            )
        else:
            # Datastructs are opaque binary buffers.
            slots.append(
                {"kind": "buffer", "name": parameter.name, "public": True}
            )

    for plan_index, plan in enumerate(debug_plans):
        for suffix, bits, extent in (
            ("payload", 8, int(plan.payload_bytes)),
            ("counter", 64, int(plan.counter_bytes) // 8),
        ):
            slots.append(
                {
                    "kind": "tensor",
                    "name": f"__debug_{plan_index}_{suffix}",
                    "public": False,
                    "dtype_code": 0,
                    "dtype_bits": bits,
                    "dtype_lanes": 1,
                    "rank": 1,
                    "encoding": "identity",
                    "physical_rank": 1,
                    "shape": (compile_expression(ConstantExpr(extent)),),
                    "stride": (compile_expression(ConstantExpr(1)),),
                    "physical_shape": (
                        compile_expression(ConstantExpr(extent)),
                    ),
                }
            )

    return {
        "dimensions": tuple(
            {
                "name": item.name,
                "minimum": item.minimum,
                "maximum": item.maximum,
                "multiple_of": item.multiple_of,
            }
            for item in dimensions
        ),
        "expressions": expression_compiler.expressions,
        "slots": tuple(slots),
    }


@dataclass(frozen=True, slots=True)
class HostProgramSpec:
    """One immutable source of truth for host schema and binding semantics.

    The canonical JSON payload keeps the object deeply immutable while still
    allowing a fresh primitive dictionary to be handed to pybind or used to
    populate MLIR attributes.  The DSO exports an independent schema that the
    native loader compares against this trusted Python-generated specification.
    """

    contract_digest: str
    _canonical_json: str

    @classmethod
    def build(cls, contract, ctypes_types=None, debug_plans=()):
        from cannbotdsl.core.contracts.codec import contract_digest

        digest = contract_digest(contract)
        call_plan = host_call_plan_spec(contract, debug_plans)
        payload = {
            "contract_digest": digest,
            "expected_slots": expected_slots(
                contract, ctypes_types, debug_plans
            ),
            **call_plan,
        }
        upper_bounds = physical_shape_upper_bounds(contract)
        for slot, upper_bound in zip(payload["expected_slots"], upper_bounds):
            slot["physical_shape_upper_bound"] = upper_bound
        encoded = json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        return cls(digest, encoded)

    def to_native(self) -> dict[str, object]:
        return json.loads(self._canonical_json)

    @property
    def slots(self) -> tuple[dict[str, object], ...]:
        return tuple(self.to_native()["slots"])

    @property
    def schema_slots(self) -> tuple[dict[str, object], ...]:
        return tuple(self.to_native()["expected_slots"])

    @property
    def public_slot_count(self) -> int:
        return sum(bool(slot["public"]) for slot in self.schema_slots)

    def apply_mlir_attributes(self, func_op) -> None:
        """Populate generated-host attributes from this exact specification."""

        import cannbotdsl._mlir.ir as ir

        payload = self.to_native()
        slots = payload["expected_slots"]
        i64 = ir.IntegerType.get_signless(64)
        func_op.attributes["cannbotdsl.contract_digest"] = ir.StringAttr.get(
            self.contract_digest
        )
        func_op.attributes["cannbotdsl.public_slot_count"] = ir.IntegerAttr.get(
            i64, self.public_slot_count
        )

        def integer_array(values):
            return ir.ArrayAttr.get(
                [ir.IntegerAttr.get(i64, int(value)) for value in values]
            )

        func_op.attributes["cannbotdsl.slot_kinds"] = integer_array(
            slot["kind"] for slot in slots
        )
        func_op.attributes["cannbotdsl.slot_flags"] = integer_array(
            1 if slot["public"] else 2 for slot in slots
        )
        func_op.attributes["cannbotdsl.slot_type_digests"] = ir.ArrayAttr.get(
            [ir.StringAttr.get(slot["type_digest"]) for slot in slots]
        )
        for attribute, key, fallback in (
            ("cannbotdsl.slot_dtype_codes", "dtype_code", 0),
            ("cannbotdsl.slot_dtype_bits", "dtype_bits", 0),
            ("cannbotdsl.slot_dtype_lanes", "dtype_lanes", 1),
        ):
            func_op.attributes[attribute] = integer_array(
                slot.get(key, fallback) for slot in slots
            )

        func_op.attributes["arg_attrs"] = (
            _physical_shape_mlir_argument_attributes(
                slot.get("physical_shape_upper_bound") for slot in slots
            )
        )


def build_host_program_spec(
    contract, ctypes_types=None, debug_plans=()
) -> HostProgramSpec:
    return HostProgramSpec.build(contract, ctypes_types, debug_plans)


def apply_physical_shape_upper_bound_attributes(func_op, contract) -> None:
    """Attach bounded private allocations before nested kernels are traced."""

    func_op.attributes["arg_attrs"] = _physical_shape_mlir_argument_attributes(
        physical_shape_upper_bounds(contract)
    )


__all__ = [
    "HostProgramSpec",
    "SLOT_BUFFER",
    "SLOT_SCALAR",
    "SLOT_TENSOR",
    "ENCODING_FRACTAL_NZ",
    "ENCODING_IDENTITY",
    "abi_type_digest",
    "apply_physical_shape_upper_bound_attributes",
    "build_host_program_spec",
    "expected_slots",
    "host_call_plan_spec",
    "physical_shape_upper_bounds",
    "slot_kind",
    "slot_dtype",
    "slot_rank",
]
