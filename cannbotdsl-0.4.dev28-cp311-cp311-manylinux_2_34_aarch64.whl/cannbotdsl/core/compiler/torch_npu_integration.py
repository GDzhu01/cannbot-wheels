# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Optional, pure-Python TorchNPU runtime integration."""

from __future__ import annotations

import ctypes
from dataclasses import dataclass

from cannbotdsl.types._storage_format import (
    FRACTAL_NZ_ELEMENT_TAGS,
    fractal_nz_c0,
)
from cannbotdsl.core.contracts.model import ConstantExpr, StorageEncodingContract
from cannbotdsl.core.contracts.storage import constant_values


_INT64_MAX = (1 << 63) - 1


def _checked_nonnegative_int(value, *, path: str) -> int:
    if type(value) is not int:
        raise RuntimeError(f"{path} must be an integer, got {value!r}")
    if value < 0:
        raise ValueError(f"{path} must be non-negative, got {value}")
    if value > _INT64_MAX:
        raise OverflowError(f"{path} exceeds signed int64")
    return value


def _checked_vector(value, *, path: str, positive: bool = False) -> tuple[int, ...]:
    if not isinstance(value, (tuple, list)):
        raise RuntimeError(f"{path} must be a vector of integers")
    result = tuple(
        _checked_nonnegative_int(item, path=f"{path}[{index}]")
        for index, item in enumerate(value)
    )
    if positive and any(item <= 0 for item in result):
        raise BufferError(f"{path} entries must be positive, got {result}")
    return result


def _checked_product(values: tuple[int, ...], *, path: str) -> int:
    product = 1
    for index, value in enumerate(values):
        if value and product > _INT64_MAX // value:
            raise OverflowError(f"{path} overflows signed int64 at axis {index}")
        product *= value
    return product


def _checked_ceildiv(value: int, divisor: int, *, path: str) -> int:
    """Compute ceildiv for a positive int64 without an overflowing add."""

    if value <= 0:
        raise ValueError(f"{path} must be positive, got {value}")
    result = (value - 1) // divisor + 1
    if result > _INT64_MAX:  # Defensive if this helper is ever generalized.
        raise OverflowError(f"{path} ceildiv exceeds signed int64")
    return result


def _compact_runtime_stride(shape: tuple[int, ...]) -> tuple[int, ...]:
    if not shape:
        return ()
    stride = [1] * len(shape)
    for index in range(len(shape) - 2, -1, -1):
        stride[index] = _checked_product(
            (shape[index + 1], stride[index + 1]),
            path="FRACTAL_NZ physical compact stride",
        )
    return tuple(stride)


def _safe_formats(torch_npu):
    """Return public formats whose logical DLPack layout describes storage."""

    try:
        format_type = getattr(torch_npu, "Format")
    except Exception as error:
        raise RuntimeError("the installed torch_npu does not expose Format") from error
    if format_type is None:
        raise RuntimeError("the installed torch_npu does not expose Format")
    formats = tuple(
        getattr(format_type, name)
        for name in (
            "NCHW",
            "NHWC",
            "ND",
            "HWCN",
            "NDHWC",
            "NCDHW",
            "NC",
            "NCL",
        )
        if hasattr(format_type, name)
    )
    if not formats:
        raise RuntimeError(
            "the installed torch_npu Format enum has no ND-compatible formats"
        )
    return formats


def _required_attribute(owner, name: str, *, path: str):
    try:
        return getattr(owner, name)
    except Exception as error:
        raise RuntimeError(f"{path} requires readable {name}") from error


def _required_call(owner, name: str, *, path: str):
    method = _required_attribute(owner, name, path=path)
    if not callable(method):
        raise RuntimeError(f"{path} requires callable {name}()")
    try:
        return method()
    except Exception as error:
        raise RuntimeError(f"{path} failed while calling {name}()") from error


@dataclass(frozen=True, slots=True)
class RuntimePhysicalLayout:
    """Provider-neutral, per-call private layout snapshot."""

    encoding: str
    physical_shape: tuple[int, ...]
    physical_stride: tuple[int, ...]

    def to_contract(self) -> StorageEncodingContract:
        return StorageEncodingContract(
            self.encoding,
            tuple(ConstantExpr(item) for item in self.physical_shape),
        )

    def to_native(self) -> dict[str, object]:
        return {
            "encoding": self.encoding,
            "physical_shape": self.physical_shape,
            "physical_stride": self.physical_stride,
        }


@dataclass(frozen=True, slots=True)
class DebugResult:
    payload: bytes
    counters: tuple[int, ...]


class TorchNPUDebugSession:
    __slots__ = (
        "_torch",
        "_torch_npu",
        "_device_id",
        "_specs",
        "_debug_tensors",
        "_tensors",
        "_closed",
    )

    def __init__(self, torch, torch_npu, device_id: int, specs) -> None:
        self._torch = torch
        self._torch_npu = torch_npu
        self._device_id = int(device_id)
        self._specs = tuple(specs)
        self._debug_tensors = []
        tensors = []
        self._closed = False
        device = f"npu:{self._device_id}"
        with torch.npu.device(self._device_id):
            for spec in self._specs:
                payload = torch.empty(
                    int(spec.payload_bytes), dtype=torch.int8, device=device
                )
                counter_bytes = int(spec.counter_bytes)
                if counter_bytes % 8:
                    raise ValueError("debug counter byte size must be a multiple of 8")
                counter = torch.zeros(
                    counter_bytes // 8, dtype=torch.int64, device=device
                )
                tensors.extend((payload, counter))
                self._debug_tensors.append((spec, payload, counter))
        self._tensors = tuple(tensors)

    @property
    def tensors(self) -> tuple[object, ...]:
        return self._tensors

    def before_invoke(self, effective_stream_handle: int) -> None:
        if self._closed:
            raise RuntimeError("TorchNPU debug session is closed")
        accessor = getattr(
            getattr(self._torch_npu, "_C", None),
            "_npu_getCurrentRawStream",
            None,
        )
        if not callable(accessor):
            raise RuntimeError(
                "the installed torch_npu does not expose the task-queue-aware "
                "raw stream accessor required by debug calls"
            )
        with self._torch.npu.device(self._device_id):
            actual = _as_stream_handle(accessor(self._device_id))
        if actual == 0 or actual != int(effective_stream_handle):
            raise RuntimeError("the current torch_npu stream changed during debug allocation")

    def finish(self) -> tuple[DebugResult, ...]:
        if self._closed:
            raise RuntimeError("TorchNPU debug session is closed")
        synchronize = getattr(self._torch.npu, "synchronize", None)
        if not callable(synchronize):
            raise RuntimeError(
                "the installed torch_npu does not expose the synchronization required for debug readback"
            )
        with self._torch.npu.device(self._device_id):
            synchronize()
            results = []
            for _, payload, counter in self._debug_tensors:
                results.append(
                    DebugResult(
                        payload.cpu().contiguous().numpy().tobytes(),
                        tuple(
                            int(item)
                            for item in counter.cpu().contiguous().tolist()
                        ),
                    )
                )
        return tuple(results)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._tensors = ()
        self._debug_tensors = []


def _as_stream_handle(raw) -> int:
    if isinstance(raw, ctypes.c_void_p):
        raw = raw.value
    if isinstance(raw, bool):
        raise TypeError("provider stream handle must be an integer pointer")
    try:
        handle = int(raw or 0)
    except (TypeError, ValueError, OverflowError) as error:
        raise TypeError("provider stream handle must be an integer pointer") from error
    if handle < 0:
        raise ValueError("provider stream handle must be non-negative")
    return handle


class TorchNPUIntegration:
    """Exact-type TorchNPU policy using public Python metadata only."""

    def __init__(self, torch, torch_npu) -> None:
        self._torch = torch
        self._torch_npu = torch_npu

    def _format(self, tensor, *, name: str):
        checker = getattr(self._torch_npu, "get_npu_format", None)
        if not callable(checker):
            raise RuntimeError("the installed torch_npu does not expose get_npu_format")
        try:
            return checker(tensor)
        except Exception as error:
            raise RuntimeError(
                f"{name} storage validation failed while calling torch_npu.get_npu_format()"
            ) from error

    def _storage_size(self, tensor, *, name: str) -> int:
        checker = getattr(self._torch_npu, "get_storage_size", None)
        if not callable(checker):
            raise RuntimeError(
                "the installed torch_npu does not expose get_storage_size"
            )
        try:
            value = checker(tensor)
        except Exception as error:
            raise RuntimeError(
                f"{name} storage validation failed while calling "
                "torch_npu.get_storage_size()"
            ) from error
        return _checked_nonnegative_int(
            value, path=f"{name} torch_npu.get_storage_size()"
        )

    def preflight_tensor_subclasses(
        self, tensors: tuple[tuple[str, object], ...]
    ) -> None:
        """Reject private-format Tensor subclasses before DLPack callbacks."""

        accepted = _safe_formats(self._torch_npu)
        exact_type = self._torch.Tensor
        for name, tensor in tensors:
            if type(tensor) is exact_type:
                continue
            actual = self._format(tensor, name=name)
            if actual in accepted:
                continue
            actual_type = type(tensor)
            qualified_type = (
                f"{actual_type.__module__}.{actual_type.__qualname__}"
            )
            raise BufferError(
                f"{name} is {qualified_type} using torch_npu private storage "
                f"format {actual!r}; private-format Tensor subclasses cannot "
                "cross the DLPack Exchange boundary. Pass an allocation-root "
                f"exact torch.Tensor, for example {name}.detach()"
            )

    def validate_storage(self, tensors: tuple[tuple[str, object], ...]) -> None:
        accepted = _safe_formats(self._torch_npu)
        for name, tensor in tensors:
            actual = self._format(tensor, name=name)
            if actual not in accepted:
                raise BufferError(
                    f"{name} uses torch_npu private storage format {actual}; "
                    "the compiled contract requires ND storage"
                )

    def inspect_storage(
        self,
        tensors: tuple[tuple[str, object], ...],
        snapshots=None,
        expected_contracts=None,
    ) -> tuple[RuntimePhysicalLayout | None, ...]:
        """Validate storage and derive canonical FRACTAL_NZ physical layouts."""

        from cannbotdsl.core.contracts.elements import (
            element_for_dlpack,
            element_for_tag,
            element_for_torch_dtype,
        )

        tensors = tuple(tensors)
        if snapshots is not None and len(snapshots) != len(tensors):
            raise RuntimeError("TorchNPU storage snapshot count mismatch")
        if expected_contracts is not None and len(expected_contracts) != len(tensors):
            raise RuntimeError("TorchNPU storage expectation count mismatch")

        accepted = _safe_formats(self._torch_npu)
        try:
            format_type = getattr(self._torch_npu, "Format")
            nz_format = getattr(format_type, "FRACTAL_NZ")
        except Exception as error:
            raise RuntimeError(
                "TorchNPU FRACTAL_NZ validation requires Format.FRACTAL_NZ"
            ) from error
        layouts = []
        for index, (name, tensor) in enumerate(tensors):
            expected_contract = (
                None if expected_contracts is None else expected_contracts[index]
            )
            expected = (
                None
                if expected_contract is None
                else getattr(expected_contract, "storage_encoding", None)
            )
            actual_format = self._format(tensor, name=name)
            if actual_format in accepted:
                if expected is not None:
                    raise BufferError(
                        f"{name} requires FRACTAL_NZ storage but received "
                        f"TorchNPU format {actual_format!r}"
                    )
                layouts.append(None)
                continue
            if actual_format != nz_format:
                raise BufferError(
                    f"{name} uses unsupported torch_npu private storage format "
                    f"{actual_format!r}; only FRACTAL_NZ is supported"
                )
            if expected_contracts is not None and expected is None:
                raise BufferError(
                    f"{name} uses FRACTAL_NZ storage but the compiled tensor "
                    "contract requires ND storage"
                )

            shape = _checked_vector(
                _required_attribute(tensor, "shape", path=name),
                path=f"{name} shape",
                positive=True,
            )
            stride = _checked_vector(
                _required_call(tensor, "stride", path=name),
                path=f"{name} stride",
            )
            if len(shape) not in (2, 3) or len(stride) != len(shape):
                raise BufferError(
                    f"{name} FRACTAL_NZ requires logical rank 2 or 3 with a "
                    f"matching stride, got shape rank {len(shape)} and "
                    f"stride rank {len(stride)}"
                )
            if stride != _compact_runtime_stride(shape):
                raise BufferError(
                    f"{name} FRACTAL_NZ logical stride must be compact row-major"
                )

            is_view = _required_call(tensor, "_is_view", path=name)
            if type(is_view) is not bool:
                raise RuntimeError(
                    f"{name} _is_view() must return a bool, got {is_view!r}"
                )
            if is_view:
                raise BufferError(
                    f"{name} is a Torch view of FRACTAL_NZ storage; "
                    "pass the allocation-root tensor"
                )
            storage_offset = _checked_nonnegative_int(
                _required_call(tensor, "storage_offset", path=name),
                path=f"{name} storage_offset()",
            )
            if storage_offset != 0:
                raise BufferError(
                    f"{name} FRACTAL_NZ storage_offset must be 0, got "
                    f"{storage_offset}"
                )
            data_ptr = _checked_nonnegative_int(
                _required_call(tensor, "data_ptr", path=name),
                path=f"{name} data_ptr()",
            )
            storage = _required_call(tensor, "untyped_storage", path=name)
            storage_ptr = _checked_nonnegative_int(
                _required_call(storage, "data_ptr", path=f"{name} untyped storage"),
                path=f"{name} untyped_storage().data_ptr()",
            )
            if data_ptr == 0 or data_ptr != storage_ptr:
                raise BufferError(
                    f"{name} FRACTAL_NZ data pointer does not identify the root allocation"
                )
            device = _required_attribute(tensor, "device", path=name)
            device_type = _required_attribute(
                device, "type", path=f"{name} device"
            )
            if type(device_type) is not str:
                raise RuntimeError(
                    f"{name} device.type must be a string, got {device_type!r}"
                )
            if device_type not in {"npu", "privateuseone"}:
                raise BufferError(
                    f"{name} FRACTAL_NZ tensor must be on an NPU device, "
                    f"got {device_type!r}"
                )

            dtype = _required_attribute(tensor, "dtype", path=name)
            try:
                dtype_name = str(dtype)
            except Exception as error:
                raise RuntimeError(f"{name} dtype cannot be rendered") from error
            tensor_info = element_for_torch_dtype(dtype_name)
            if tensor_info.tag not in FRACTAL_NZ_ELEMENT_TAGS:
                raise TypeError(
                    f"{name} FRACTAL_NZ dtype {tensor_info.dtype.name} is unsupported"
                )

            snapshot = None if snapshots is None else snapshots[index]
            if snapshot is not None:
                if snapshot.byte_offset != 0 or snapshot.data != data_ptr:
                    raise BufferError(
                        f"{name} DLPack metadata does not identify the root allocation"
                    )
                if snapshot.shape != shape or snapshot.stride != stride:
                    raise BufferError(
                        f"{name} DLPack logical shape/stride does not match "
                        "Torch metadata"
                    )
                snapshot_info = element_for_dlpack(
                    snapshot.dtype_code,
                    snapshot.dtype_bits,
                    snapshot.dtype_lanes,
                )
                if snapshot_info is not tensor_info:
                    raise BufferError(
                        f"{name} DLPack dtype {snapshot_info.dtype.name} does not "
                        f"match Torch dtype {tensor_info.dtype.name}"
                    )
            else:
                if expected_contract is None or expected is None:
                    raise RuntimeError(
                        f"{name} FRACTAL_NZ validation has no compiled storage expectation"
                    )
                expected_info = element_for_tag(expected_contract.element)
                if tensor_info is not expected_info:
                    raise BufferError(
                        f"{name} TorchNPU dtype {dtype_name} does not match "
                        f"compiled dtype {expected_info.torch_name}"
                    )
                expected_shape = constant_values(expected_contract.shape)
                if expected_shape is not None and expected_shape != shape:
                    raise BufferError(
                        f"{name} logical shape changed: expected {expected_shape}, "
                        f"got {shape}"
                    )
                expected_stride = constant_values(expected_contract.stride)
                if expected_stride is not None and expected_stride != stride:
                    raise BufferError(
                        f"{name} logical stride changed: expected {expected_stride}, "
                        f"got {stride}"
                    )

            c0 = fractal_nz_c0(tensor_info.tag)
            m, n = shape[-2:]
            physical_shape = shape[:-2] + (
                _checked_ceildiv(n, c0, path=f"{name} N extent"),
                _checked_ceildiv(m, 16, path=f"{name} M extent"),
                16,
                c0,
            )
            physical_stride = _compact_runtime_stride(physical_shape)
            physical_elements = _checked_product(
                physical_shape, path=f"{name} physical allocation elements"
            )
            public_storage_elements = self._storage_size(tensor, name=name)
            if physical_elements != public_storage_elements:
                raise BufferError(
                    f"{name} canonical FRACTAL_NZ layout requires "
                    f"{physical_elements} elements, which does not match "
                    f"torch_npu.get_storage_size() {public_storage_elements}"
                )
            item_size = tensor_info.dlpack_bits // 8
            required_bytes = _checked_product(
                (physical_elements, item_size),
                path=f"{name} physical allocation bytes",
            )
            allocation_bytes = _checked_nonnegative_int(
                _required_call(storage, "nbytes", path=f"{name} untyped storage"),
                path=f"{name} untyped_storage().nbytes()",
            )
            if allocation_bytes < required_bytes:
                raise BufferError(
                    f"{name} FRACTAL_NZ allocation has {allocation_bytes} bytes; "
                    f"canonical layout requires at least {required_bytes}"
                )
            if expected is not None:
                if expected.encoding != "fractal_nz":
                    raise BufferError(
                        f"{name} compiled storage encoding {expected.encoding!r} "
                        "is not FRACTAL_NZ"
                    )
                expected_values = constant_values(expected.physical_shape)
                if expected_values is not None and expected_values != physical_shape:
                    raise BufferError(
                        f"{name} FRACTAL_NZ physical shape changed: expected "
                        f"{expected_values}, got {physical_shape}"
                    )
            layouts.append(
                RuntimePhysicalLayout(
                    "fractal_nz", physical_shape, physical_stride
                )
            )
        return tuple(layouts)

    @staticmethod
    def _required_metadata_call(owner, name: str, *, path: str):
        try:
            method = getattr(owner, name)
        except Exception as error:
            raise RuntimeError(
                f"{path} exact TorchNPU StructRef validation requires callable {name}()"
            ) from error
        if not callable(method):
            raise RuntimeError(
                f"{path} exact TorchNPU StructRef validation requires callable {name}()"
            )
        try:
            return method()
        except Exception as error:
            raise RuntimeError(
                f"{path} exact TorchNPU StructRef validation failed while calling {name}()"
            ) from error

    def validate_struct_ref_storage(self, tensors) -> None:
        for name, tensor, expected_bytes in tensors:
            offset = self._required_metadata_call(tensor, "storage_offset", path=name)
            if isinstance(offset, bool) or not isinstance(offset, int):
                raise RuntimeError(f"{name} storage_offset() must return an integer")
            if offset != 0:
                raise ValueError(
                    f"{name} StructRef TorchNPU storage_offset must be 0, got {offset}"
                )
            storage = self._required_metadata_call(tensor, "untyped_storage", path=name)
            nbytes = self._required_metadata_call(storage, "nbytes", path=name)
            if isinstance(nbytes, bool) or not isinstance(nbytes, int):
                raise RuntimeError(
                    f"{name} untyped_storage().nbytes() must return an integer"
                )
            if nbytes != expected_bytes:
                raise ValueError(
                    f"{name} StructRef TorchNPU allocation size must equal "
                    f"{expected_bytes} bytes, got {nbytes}"
                )

    def resolve_null_stream(self, reference: object, device_id: int):
        del reference
        current_stream = getattr(self._torch.npu, "current_stream", None)
        raw_stream = getattr(
            getattr(self._torch_npu, "_C", None),
            "_npu_getCurrentRawStream",
            None,
        )
        if not callable(current_stream):
            raise RuntimeError("the installed torch_npu does not expose current_stream")
        if not callable(raw_stream):
            raise RuntimeError(
                "the installed torch_npu does not expose the task-queue-aware "
                "raw stream accessor required by a null provider stream"
            )
        device_id = int(device_id)
        with self._torch.npu.device(device_id):
            owner = current_stream(device_id)
            owner_handle = _as_stream_handle(getattr(owner, "npu_stream", None))
            handle = _as_stream_handle(raw_stream(device_id))
        if owner_handle == 0 or handle == 0:
            raise RuntimeError("the current torch_npu stream has a null handle")
        if handle != owner_handle:
            raise RuntimeError("torch_npu returned inconsistent current stream handles")
        return handle, owner

    def create_debug_session(self, reference: object, device_id: int, specs):
        if type(reference) is not self._torch.Tensor:
            raise TypeError("TorchNPU debug reference must be an exact torch.Tensor")
        return TorchNPUDebugSession(
            self._torch, self._torch_npu, device_id, specs
        )


__all__ = [
    "DebugResult",
    "RuntimePhysicalLayout",
    "TorchNPUIntegration",
]
