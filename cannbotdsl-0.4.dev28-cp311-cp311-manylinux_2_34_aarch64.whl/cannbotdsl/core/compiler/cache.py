# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Process-level compile cache for the CANNBotDSL pipeline.

The cache key is defined in :mod:`cannbotdsl.core.compiler.cache_key`.

Tier layout:

- **Memory** (on by default): ``OrderedDict`` LRU bounded by
  ``CANNBOTDSL_CACHE_MEM_MAX`` (default 128). It can be disabled for each
  compilation with ``CANNBOTDSL_CACHE_MEM_DISABLE``. Cold stores register a
  ``weakref.finalize`` when the source callable supports weak references;
  disk-promoted entries do not. Dropping an entry — by LRU overflow, by
  finalizer, or via :func:`clear_compile_cache` — also reclaims the .so
  when the cache owns it.

- **Disk** (opt-in): activated only when
  ``CANNBOTDSL_CACHE_DIR`` is set (and ``CANNBOTDSL_CACHE_DISK_DISABLE`` is
  false). Layout is
  ``$CANNBOTDSL_CACHE_DIR/v2/<key[:2]>/<key>.so`` plus a v14 sidecar.
  The binary is replaced first and its fsynced sidecar last; the sidecar is
  the publication marker. A crash or concurrent read between replacements
  is rejected by the binary SHA-256 check. On disk-write failure the
  in-memory entry is still installed so the process keeps working.
  There is no size budget / atime LRU — disk cleanup is the user's
  responsibility (or an external cron); the design doc spells this out.

Artifact ownership — **a process only ever ``dlopen``s a file it owns**:

- One process-scoped ``cannbotdsl_cache_*`` directory holds every .so this
  process executes, and is removed at interpreter exit. Bisheng links
  straight into it (``compile_ascendc_to_so(output_path=...)``), so a
  cached compile creates no ``cannbotdsl_aot_*`` tempdir at all, and a disk
  hit is copied in before it is used. The disk tier is publish-only: it
  is shared, so anything that rewrites an entry in place would raise
  SIGBUS in every process that mapped it directly.
- staged ``JitFunction.compile`` returns :class:`ProviderCallable` handles with
  ``owns_so=False`` when the memory tier owns the .so. When L1 is off,
  a cold compile or private L2 copy is caller-owned (``owns_so=True``)
  and ``close()`` unlinks it. Cache-bypassed compilations also use a
  private ``cannbotdsl_aot_*`` tempdir owned by their handle.
- Dropping an entry — LRU overflow, finalizer, or
  :func:`clear_compile_cache` — reclaims its .so, which is what keeps
  the process directory bounded.
  ``clear_compile_cache(clear_disk=True)`` opts into removing the
  configured disk root's ``v2/`` subtree; the root itself remains.
  ``clear_compile_cache(reap_orphans=True)`` additionally sweeps
  compile tempdirs no live process is using: ``cannbotdsl_aot_*`` left by
  older CANNBotDSL versions, and ``cannbotdsl_cache_<pid>_*`` belonging to
  processes killed by a signal that skipped their exit handler.
- Live :class:`ProviderCallable` handles backed by cleared .so files
  normally keep working on Linux because an already loaded mapping
  remains usable after the backing path is unlinked.
"""

import atexit
import contextlib
import fcntl
import itertools
import logging
import os
import shutil
import tempfile
import threading
import time
import weakref
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any, Callable, List, Optional, Tuple

from cannbotdsl.core.compiler.abi import HOST_ABI_VERSION

_LOG = logging.getLogger(__name__)


@dataclass(frozen=True)
class _CachedEntry:
    """One memoized compilation result.

    :param so_path: Absolute path to the .so on disk. The cache holds
        primary ownership.
    :param symbol_name: Exported ``extern "C"`` symbol name to resolve
        inside ``so_path``.
    Runtime validation and ctypes state are intentionally absent.  A cache hit
    is wrapped with the current request's CallContract by the builder.
    """

    so_path: str
    symbol_name: str
    host_abi_version: int


@dataclass(frozen=True)
class _CachePolicy:
    """Effective cache controls captured once for one compilation."""

    memory_enabled: bool
    memory_max_elems: Optional[int]
    memory_reason: str
    disk_enabled: bool
    disk_root: Optional[str]
    disk_reason: str


@dataclass(frozen=True)
class _CacheResult:
    """A cached artifact together with its caller ownership contract.

    The forwarding properties retain the small internal helper API used
    by tests and diagnostics while making ownership explicit to the
    builder.
    """

    entry: _CachedEntry
    owns_so: bool
    source: str

    @property
    def so_path(self) -> str:
        return self.entry.so_path

    @property
    def symbol_name(self) -> str:
        return self.entry.symbol_name

    @property
    def host_abi_version(self) -> int:
        return self.entry.host_abi_version

_TRUE_VALUES = frozenset({"1", "true", "on", "yes"})
_FALSE_VALUES = frozenset({"0", "false", "off", "no", ""})
_REPORTED_INVALID_SWITCHES: set = set()
_INVALID_SWITCH_LOCK = threading.Lock()


def _read_bool_switch(name: str) -> bool:
    """Parse a cache boolean, warning once for an invalid spelling.

    Invalid values fail open (the corresponding ``*_DISABLE`` switch is
    treated as false), so a typo cannot silently turn caching off.
    """
    raw = os.environ.get(name)
    if raw is None:
        return False
    normalized = raw.strip().lower()
    if normalized in _TRUE_VALUES:
        return True
    if normalized in _FALSE_VALUES:
        return False
    marker = (name, raw)
    with _INVALID_SWITCH_LOCK:
        first = marker not in _REPORTED_INVALID_SWITCHES
        if first:
            _REPORTED_INVALID_SWITCHES.add(marker)
    if first:
        _LOG.warning(
            "%s=%r is not a valid boolean; treating it as false "
            "(accepted true: 1/true/on/yes; false: 0/false/off/no/empty)",
            name,
            raw,
        )
    return False


def _trace(event: str, *, key: Optional[str] = None, **fields: Any) -> None:
    """Emit one stable, grep-friendly cache trace event."""
    if not _LOG.isEnabledFor(logging.DEBUG):
        return
    items = []
    if key is not None:
        items.append(f"key={key[:12]}")
    for name, value in fields.items():
        if isinstance(value, bool):
            rendered = "true" if value else "false"
        elif value is None:
            rendered = "none"
        else:
            rendered = str(value).replace("\n", "\\n")
        items.append(f"{name}={rendered}")
    suffix = f" {' '.join(items)}" if items else ""
    _LOG.debug("cache.%s%s", event, suffix)


_DEFAULT_MEM_MAX = 128


def _resolve_max_elems() -> Optional[int]:
    """Read ``CANNBOTDSL_CACHE_MEM_MAX`` at module import time.

    - unset / empty string → default 128
    - ``"none"`` / ``"None"`` / ``"0"`` is preserved: ``0`` disables
      writes, ``None`` lifts the bound

    A value that isn't a non-negative integer warns and falls back to the
    default. This runs at import, so raising would make ``import cannbotdsl``
    fail outright — a typo in a tuning knob must not cost the user their
    interpreter, especially one that only affects how much is cached.
    """
    raw = os.environ.get("CANNBOTDSL_CACHE_MEM_MAX")
    if raw is None or raw == "":
        return _DEFAULT_MEM_MAX
    if raw in ("none", "None"):
        return None
    try:
        value = int(raw)
    except ValueError:
        _LOG.warning(
            "CANNBOTDSL_CACHE_MEM_MAX=%r is not an integer; using the default of %d",
            raw,
            _DEFAULT_MEM_MAX,
        )
        return _DEFAULT_MEM_MAX
    if value < 0:
        # A negative bound would make the LRU pop from an empty dict on the
        # first store, i.e. a KeyError from deep inside an unrelated call.
        _LOG.warning(
            "CANNBOTDSL_CACHE_MEM_MAX=%r is negative; using the default of %d "
            "(use 0 to disable the memory tier, 'none' to lift the bound)",
            raw,
            _DEFAULT_MEM_MAX,
        )
        return _DEFAULT_MEM_MAX
    return value


@dataclass
class _MemorySlot:
    entry: _CachedEntry
    finalizer: Optional[weakref.finalize] = None

    def detach_finalizer(self) -> None:
        if self.finalizer is not None:
            self.finalizer.detach()
            self.finalizer = None


class _MemoryTier:
    """Thread-safe least-recently-used index for process-owned artifacts.

    ``None`` leaves the entry count unbounded, zero disables stores, and a
    positive value evicts the least recently observed key on overflow.
    Artifact reclamation runs after releasing the index lock.
    """

    def __init__(
        self,
        max_elems: Optional[int] = None,
        *,
        on_evict: Optional[Callable[[_CachedEntry], None]] = None,
    ):
        self._dict: "OrderedDict[str, _MemorySlot]" = OrderedDict()
        self._max_elems = max_elems
        self._on_evict = on_evict
        self._lock = threading.Lock()

    def _notify_evicted(self, entries: List[Tuple[str, _CachedEntry, str]]) -> None:
        """Run the reclaim hook outside the lock; must not raise."""
        for key, entry, reason in entries:
            try:
                _trace("evict", key=key, reason=reason)
            except Exception:  # pragma: no cover - interpreter shutdown
                pass
            if self._on_evict is not None:
                try:
                    self._on_evict(entry)
                except Exception:  # pragma: no cover - reclamation is best effort
                    _LOG.debug(
                        "cache eviction reclaim failed for %s",
                        entry.so_path,
                        exc_info=True,
                    )

    @staticmethod
    def _make_finalizer(
        fn_body: Optional[Callable], callback: Callable[[str], None], key: str
    ) -> Optional[weakref.finalize]:
        if fn_body is None:
            return None
        try:
            return weakref.finalize(fn_body, callback, key)
        except TypeError:
            return None

    def _remove_locked(
        self, key: str, *, detach_finalizer: bool
    ) -> Optional[_MemorySlot]:
        slot = self._dict.pop(key, None)
        if slot is not None and detach_finalizer:
            slot.detach_finalizer()
        return slot

    def get(self, key: str) -> Optional[_CachedEntry]:
        with self._lock:
            slot = self._dict.get(key)
            if slot is None:
                return None
            self._dict.move_to_end(key, last=True)
            return slot.entry

    def pop(self, key: str) -> Optional[_CachedEntry]:
        """Remove ``key`` without reclaiming its artifact.

        Used when a hit turns out to reference a path that no longer
        exists — the file is already gone, so there is nothing to
        reclaim and the entry is just stale index state.
        """
        with self._lock:
            slot = self._remove_locked(key, detach_finalizer=True)
        return None if slot is None else slot.entry

    def set(
        self,
        key: str,
        entry: _CachedEntry,
        *,
        fn_body: Optional[Callable] = None,
    ) -> bool:
        if self._max_elems == 0:
            return False
        evicted: List[Tuple[str, _CachedEntry, str]] = []
        with self._lock:
            old = self._remove_locked(key, detach_finalizer=True)
            if old is not None and old.entry.so_path != entry.so_path:
                evicted.append((key, old.entry, "overwrite"))

            self._dict[key] = _MemorySlot(
                entry=entry,
                finalizer=self._make_finalizer(
                    fn_body, self._on_fn_gc, key
                ),
            )
            self._dict.move_to_end(key, last=True)
            if self._max_elems is not None:
                while len(self._dict) > self._max_elems:
                    evicted_key, evicted_slot = self._dict.popitem(last=False)
                    evicted_slot.detach_finalizer()
                    evicted.append(
                        (evicted_key, evicted_slot.entry, "lru")
                    )
        self._notify_evicted(evicted)
        return True

    def _on_fn_gc(self, key: str) -> None:
        """Finalizer callback — must not raise (called during GC)."""
        with self._lock:
            slot = self._remove_locked(key, detach_finalizer=False)
        if slot is not None:
            self._notify_evicted([(key, slot.entry, "gc")])

    def values(self) -> List[_CachedEntry]:
        with self._lock:
            return [slot.entry for slot in self._dict.values()]

    def clear(self) -> List[Tuple[str, _CachedEntry]]:
        with self._lock:
            entries = [
                (key, slot.entry) for key, slot in self._dict.items()
            ]
            for slot in self._dict.values():
                slot.detach_finalizer()
            self._dict.clear()
        return entries

    @property
    def max_elems(self) -> Optional[int]:
        return self._max_elems

    def __len__(self) -> int:
        with self._lock:
            return len(self._dict)


_MEMORY = _MemoryTier(max_elems=_resolve_max_elems(), on_evict=lambda entry: _reclaim(entry.so_path))


def _configured_disk_root() -> Optional[str]:
    """Return the configured root without applying the disable switch."""
    root = os.environ.get("CANNBOTDSL_CACHE_DIR")
    if not root:
        return None
    return os.path.abspath(os.path.expanduser(root))


_LAST_TRACED_POLICY: Optional[_CachePolicy] = None
_POLICY_TRACE_LOCK = threading.Lock()


def _trace_policy(policy: _CachePolicy) -> None:
    """Log an effective policy only when it changes."""
    if not _LOG.isEnabledFor(logging.DEBUG):
        return
    global _LAST_TRACED_POLICY
    with _POLICY_TRACE_LOCK:
        if policy == _LAST_TRACED_POLICY:
            return
        _LAST_TRACED_POLICY = policy
    _trace(
        "policy",
        memory="enabled" if policy.memory_enabled else "disabled",
        memory_reason=policy.memory_reason,
        memory_max=policy.memory_max_elems,
        disk="enabled" if policy.disk_enabled else "disabled",
        disk_reason=policy.disk_reason,
        disk_root=policy.disk_root,
    )


def resolve_policy() -> _CachePolicy:
    """Capture the effective L1/L2 controls for one compilation.

    Runtime switches are deliberately re-read between compilations, but
    callers pass this immutable snapshot through lookup, singleflight,
    and store so an environment mutation cannot split one compilation
    across two different policies.
    """
    memory_disabled = _read_bool_switch("CANNBOTDSL_CACHE_MEM_DISABLE")
    memory_max = _MEMORY.max_elems
    if memory_disabled:
        memory_enabled = False
        memory_reason = "env_disabled"
    elif memory_max == 0:
        memory_enabled = False
        memory_reason = "capacity_zero"
    else:
        memory_enabled = True
        memory_reason = "enabled"

    disk_root = _configured_disk_root()
    disk_disabled = _read_bool_switch("CANNBOTDSL_CACHE_DISK_DISABLE")
    if disk_disabled:
        disk_enabled = False
        disk_reason = "env_disabled"
    elif disk_root is None:
        disk_enabled = False
        disk_reason = "not_configured"
    else:
        disk_enabled = True
        disk_reason = "enabled"

    policy = _CachePolicy(
        memory_enabled=memory_enabled,
        memory_max_elems=memory_max,
        memory_reason=memory_reason,
        disk_enabled=disk_enabled,
        disk_root=disk_root,
        disk_reason=disk_reason,
    )
    _trace_policy(policy)
    return policy


def bypass_reason(
    config: Any,
    *,
    policy: Optional[_CachePolicy] = None,
    has_debug_plans: bool = False,
) -> Optional[str]:
    """Return why this compilation must bypass cache, or ``None``."""
    if has_debug_plans:
        return "debug_plans"
    if config.pipe_stage is not None:
        return "pipe_stage"
    if config.dump_mlir:
        return "dump_mlir"
    if config.dump_ascendc:
        return "dump_ascendc"
    if config.print_mlir:
        return "print_mlir"
    if config.print_ascendc:
        return "print_ascendc"
    if config.reuse_ascendc:
        return "reuse_ascendc"
    effective = policy if policy is not None else resolve_policy()
    if not effective.memory_enabled and not effective.disk_enabled:
        return "all_tiers_disabled"
    return None


def trace_bypass(reason: str) -> None:
    """Emit the cache-bypass decision through the dedicated trace logger."""
    _trace("bypass", reason=reason)


def enabled_for(
    config: Any,
    *,
    policy: Optional[_CachePolicy] = None,
    has_debug_plans: bool = False,
) -> bool:
    """Whether this invocation may read or write either cache tier.

    Dumps, printed compiler output, AscendC source reuse, staged
    compilation, and runtime debug-print plans must execute the backend
    on every invocation so their observable effects cannot be hidden by
    a hot cache or contaminate a normal compilation entry.
    """
    return bypass_reason(config, policy=policy, has_debug_plans=has_debug_plans) is None


# ---------------------------------------------------------------------------
# Artifact ownership
# ---------------------------------------------------------------------------

_LEGACY_TEMPDIR_PREFIX = "cannbotdsl_aot_"
_PROCESS_DIR_PREFIX = "cannbotdsl_cache_"

_PROCESS_DIR: Optional[str] = None
_PROCESS_DIR_LOCK = threading.Lock()
_STAGING_COUNTER = itertools.count()


def _process_artifact_dir() -> str:
    """One cache-owned directory per process, removed at interpreter exit.

    Every compilation links straight into it, so a cache entry's .so is
    always either here (this process owns it) or published in the disk
    tier (the user owns it). There is no third, unowned location — which
    is what the ``cannbotdsl_aot_*`` tempdir per compile used to be.
    """
    global _PROCESS_DIR
    with _PROCESS_DIR_LOCK:
        if _PROCESS_DIR is None:
            # The pid is in the name so a crash that skips ``atexit``
            # (SIGKILL, SIGBUS, OOM) still leaves something a later
            # ``clear_compile_cache(reap_orphans=True)`` can identify as
            # dead and reclaim.
            _PROCESS_DIR = tempfile.mkdtemp(prefix=f"{_PROCESS_DIR_PREFIX}{os.getpid()}_")
            atexit.register(shutil.rmtree, _PROCESS_DIR, ignore_errors=True)
        return _PROCESS_DIR


def staging_path(key: str) -> str:
    """Where Bisheng should link the .so for ``key``.

    Handed to ``compile_ascendc_to_so(output_path=...)``, which then
    skips its private tempdir entirely. If the disk tier is on this file
    is copied out and reclaimed by :func:`store`; otherwise it *is* the
    cached artifact for the rest of the process's life. The name is pid-
    and counter-qualified so concurrent compilations never collide.
    """
    return os.path.join(_process_artifact_dir(), f"{key}.{os.getpid()}.{next(_STAGING_COUNTER)}.so")


def _owned_by_process_dir(path: str) -> bool:
    """True when ``path`` is a file this process's cache directory owns."""
    if not path or _PROCESS_DIR is None:
        return False
    return os.path.dirname(os.path.abspath(path)) == _PROCESS_DIR


def _reclaim(so_path: str) -> None:
    """Delete a .so the cache owns exclusively; no-op for anything else.

    Disk-tier paths are user persistent data and survive eviction — they
    are only removed by ``clear_compile_cache(clear_disk=True)``.
    """
    if not _owned_by_process_dir(so_path):
        return
    from cannbotdsl.core.compiler import metadata

    for path in (so_path, metadata.sidecar_path(so_path)):
        try:
            os.unlink(path)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Disk tier (opt-in)
# ---------------------------------------------------------------------------


def _disk_root() -> Optional[str]:
    """Compatibility helper returning the currently effective L2 root."""
    policy = resolve_policy()
    return policy.disk_root if policy.disk_enabled else None


def _disk_so_path(root: str, key: str) -> str:
    """Storage path for ``key`` under ``root``."""
    return os.path.join(root, "v2", key[:2], f"{key}.so")


def _disk_get(
    key: str,
    policy: Optional[_CachePolicy] = None,
) -> Optional[_CachedEntry]:
    """Look ``key`` up on disk; ``None`` on miss / corruption / disabled.

    Any failure (missing file, missing sidecar, sha256 mismatch,
    content_key mismatch, JSON parse error) is treated as a miss and
    returns ``None`` — the .so is NOT unlinked. Reasons:

    - sha256 mismatch typically means the user copied a .so into the
      cache dir manually; deleting it would surprise them
    - content_key mismatch means the sidecar was written by an older
      cache layout; the on-disk file may still be referenced by other
      processes via ``cannbotdsl.load``

    Every rejection is logged. A systematic cause — a host-ABI bump, a
    sidecar-version bump — silently turns an entire shared cache cold,
    and without a log line the only symptom is "everything recompiles
    today".
    """
    effective = policy if policy is not None else resolve_policy()
    if not effective.disk_enabled or effective.disk_root is None:
        _trace(
            "lookup",
            key=key,
            tier="disk",
            result="disabled",
            reason=effective.disk_reason,
        )
        return None
    root = effective.disk_root
    so_path = _disk_so_path(root, key)
    if not os.path.exists(so_path):
        _trace("lookup", key=key, tier="disk", result="miss", reason="not_found")
        return None
    try:
        from cannbotdsl.core.compiler import metadata

        sidecar = metadata.read_sidecar(so_path)
    except (FileNotFoundError, ValueError, OSError, KeyError, TypeError, AttributeError) as e:
        _report_disk_rejection(key, so_path, e)
        return None
    if sidecar.content_key != key:
        _LOG.debug("disk cache miss for %s: sidecar content_key does not match its bucket", so_path)
        _trace(
            "lookup",
            key=key,
            tier="disk",
            result="rejected",
            reason="content_key_mismatch",
        )
        return None
    from cannbotdsl.core.compiler.cache_key import _FORMAT_VERSION_TAG

    if sidecar.format_version_tag != _FORMAT_VERSION_TAG:
        _report_disk_rejection(
            key,
            so_path,
            ValueError(
                f"unsupported cache format tag {sidecar.format_version_tag!r}; "
                f"this runtime requires {_FORMAT_VERSION_TAG!r}"
            ),
        )
        return None
    _trace("lookup", key=key, tier="disk", result="hit")
    return _CachedEntry(
        so_path=so_path,
        symbol_name=sidecar.symbol_name,
        host_abi_version=sidecar.host_abi_version,
    )


_REPORTED_REJECTIONS: set = set()
_REJECTION_REPORT_LOCK = threading.Lock()


def _report_disk_rejection(key: str, so_path: str, exc: BaseException) -> None:
    """Log a rejected disk entry; escalate systematic causes to INFO once.

    A per-entry DEBUG line is enough for a one-off corrupt file, but a
    version mismatch invalidates *every* entry, so the first one is
    surfaced at INFO with the reason attached.
    """
    _LOG.debug("disk cache miss for %s: %s", so_path, exc)
    _trace(
        "lookup",
        key=key,
        tier="disk",
        result="rejected",
        reason=type(exc).__name__,
    )
    if not isinstance(exc, ValueError):
        return
    reason = str(exc)
    if "host ABI" in reason:
        kind = "host-abi"
    elif "sidecar version" in reason:
        kind = "sidecar-version"
    elif "cache format tag" in reason:
        kind = "cache-format"
    else:
        kind = None
    if kind is None:
        return
    with _REJECTION_REPORT_LOCK:
        if kind in _REPORTED_REJECTIONS:
            return
        _REPORTED_REJECTIONS.add(kind)
    _LOG.info(
        "disk compile cache entries are being rejected and recompiled: %s "
        "Every entry written by the previous runtime is affected; "
        "clear_compile_cache(clear_disk=True) reclaims the space.",
        reason,
    )


def _disk_set(
    key: str,
    src_so_path: str,
    symbol_name: str,
    contract,
    host_abi_version: int,
    *,
    policy: Optional[_CachePolicy] = None,
) -> Optional[str]:
    """Publish ``src_so_path`` into the disk tier under ``key``.

    Returns the destination path on success or ``None`` if the disk
    tier is disabled or any IO step fails. The bytes are copied through
    a same-directory temporary so the final ``os.replace`` is atomic
    even under concurrent writers.

    The binary is fsynced and replaced before its sidecar.  The sidecar is
    therefore the publication marker; an interrupted replacement is rejected
    by the binary hash check and simply behaves as a cache miss.

    IO failures log a warning and continue without L2 — they're never
    raised. L1 still stores when enabled; otherwise the caller owns the
    staging artifact.
    """
    effective = policy if policy is not None else resolve_policy()
    if not effective.disk_enabled or effective.disk_root is None:
        _trace(
            "store",
            key=key,
            tier="disk",
            result="disabled",
            reason=effective.disk_reason,
        )
        return None
    root = effective.disk_root
    bucket = os.path.join(root, "v2", key[:2])
    dst_so = os.path.join(bucket, f"{key}.so")
    try:
        os.makedirs(bucket, exist_ok=True)
        from cannbotdsl.core.compiler import metadata
        from cannbotdsl.core.compiler.cache_key import _FORMAT_VERSION_TAG
        metadata.publish_artifact(
            src_so_path,
            dst_so,
            symbol_name,
            contract,
            host_abi_version=host_abi_version,
            content_key=key,
            format_version_tag=_FORMAT_VERSION_TAG,
        )
        _trace("store", key=key, tier="disk", result="stored")
        return dst_so
    except Exception as e:
        _LOG.warning(
            "disk cache write failed for key=%s: %s; continuing without L2",
            key,
            e,
        )
        _trace("store", key=key, tier="disk", result="failed", reason=type(e).__name__)
        return None


def _disk_clear(root: Optional[str] = None) -> bool:
    """Best-effort rmtree of the configured disk root's ``v2/``.

    Only fires from :func:`clear_compile_cache` when explicitly
    requested (``clear_disk=True``). The root directory itself is
    left intact in case the user mounted a dedicated filesystem
    there.
    """
    if root is None:
        root = _configured_disk_root()
    if root is None:
        return False
    v2_root = os.path.join(root, "v2")
    if os.path.exists(v2_root):
        try:
            shutil.rmtree(v2_root)
        except OSError as e:
            _LOG.warning("disk cache clear failed for %s: %s", v2_root, e)
            return False
        return not os.path.exists(v2_root)
    return False


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def _materialize_private_copy(key: str, disk_so_path: str) -> Tuple[str, bool]:
    """Copy a disk-tier .so into this process's artifact directory.

    A process only ever ``dlopen``s files it owns. The disk tier is
    shared — another process publishing a new build, an external prune,
    or an ``rsync --inplace`` can rewrite an entry at any moment, and
    rewriting the backing file of a live executable mapping raises
    SIGBUS rather than an exception. Copying costs a few hundred KB
    against the seconds of Bisheng the hit just saved.

    Falls back to the shared path if the copy fails, since a degraded
    hit still beats recompiling.
    """
    dst = os.path.join(_process_artifact_dir(), f"{key}.{os.getpid()}.{next(_STAGING_COUNTER)}.so")
    try:
        shutil.copyfile(disk_so_path, dst)
        return dst, True
    except OSError as e:
        _LOG.debug("could not privatize %s (%s); using the shared copy", disk_so_path, e)
        return disk_so_path, False


def _promote(
    key: str,
    entry: _CachedEntry,
    policy: _CachePolicy,
) -> _CacheResult:
    """Privatize a disk hit and optionally install it in memory.

    Disk-promoted entries don't carry an ``fn_body`` finalizer — they
    outlive any specific Python fn.
    """
    private_path, copied = _materialize_private_copy(key, entry.so_path)
    private = _CachedEntry(
        so_path=private_path,
        symbol_name=entry.symbol_name,
        host_abi_version=entry.host_abi_version,
    )
    if not copied:
        # Never claim ownership of a shared L2 file: close() would unlink
        # persistent cache data. The degraded fallback is still safe from
        # accidental deletion, although it lacks rewrite isolation.
        if policy.memory_enabled:
            _MEMORY.set(key, private)
        _trace("promote", key=key, result="copy_failed")
        return _CacheResult(private, owns_so=False, source="disk")

    if policy.memory_enabled and _MEMORY.set(key, private):
        _trace("promote", key=key, result="stored")
        return _CacheResult(private, owns_so=False, source="disk")

    # With L1 disabled this process-local copy belongs to the returned
    # ProviderCallable and must be unlinked by close().
    _trace("promote", key=key, result="transient")
    return _CacheResult(private, owns_so=True, source="disk")


def lookup(
    key: str,
    policy: Optional[_CachePolicy] = None,
) -> Optional[_CacheResult]:
    """Return the cached entry for ``key`` or ``None``.

    Tries the memory tier first when enabled; on miss, falls through to
    the disk tier. A disk hit is copied into this process's artifact
    directory. It is promoted when L1 is enabled and returned as a
    caller-owned transient otherwise.

    A memory hit is re-checked against the filesystem before it is
    handed out. The index can outlive its artifact — a long-lived job
    whose temp files a system reaper collected, say — and one ``stat``
    turns that into a plain miss instead of an ``OSError`` from
    ``dlopen`` several frames later.

    The caller is responsible for computing ``key`` via
    :func:`cannbotdsl.core.compiler.cache_key._compute_key` on a verified
    MLIR module.
    """
    effective = policy if policy is not None else resolve_policy()
    if effective.memory_enabled:
        entry = _MEMORY.get(key)
        if entry is not None:
            if os.path.exists(entry.so_path):
                _trace("lookup", key=key, tier="memory", result="hit")
                return _CacheResult(entry, owns_so=False, source="memory")
            _LOG.debug("cached .so for key=%s vanished from %s; treating as a miss", key, entry.so_path)
            _trace("lookup", key=key, tier="memory", result="stale")
            _MEMORY.pop(key)
        else:
            _trace("lookup", key=key, tier="memory", result="miss")
    else:
        _trace(
            "lookup",
            key=key,
            tier="memory",
            result="disabled",
            reason=effective.memory_reason,
        )

    entry = _disk_get(key, effective)
    if entry is not None:
        return _promote(key, entry, effective)
    return None


def store(
    key: str,
    so_path: str,
    symbol_name: str,
    contract,
    *,
    host_abi_version: int = HOST_ABI_VERSION,
    fn_body: Optional[Callable] = None,
    policy: Optional[_CachePolicy] = None,
) -> _CacheResult:
    """Insert (or overwrite) a cache entry.

    Writes the memory tier when enabled; additionally publishes to the
    disk tier iff ``CANNBOTDSL_CACHE_DIR`` is configured and L2 is enabled.
    The memory entry keeps pointing at this process's own copy: the disk
    copy exists for other processes and future runs, and executing a
    file the rest of the world can rewrite is how a shared cache turns
    an unlucky prune into a SIGBUS. Reclaiming the private copy is
    :func:`_reclaim`'s job. With L1 disabled, ownership instead transfers
    to the caller.

    When two threads race to compile the same key the last writer
    wins both in memory and on disk; the .so contents are equivalent
    by construction since the key is derived from the IR.

    :param fn_body: When provided, a ``weakref.finalize`` is attached
        so the memory entry is removed automatically when ``fn_body``
        is garbage-collected.
    """
    effective = policy if policy is not None else resolve_policy()
    _disk_set(
        key,
        so_path,
        symbol_name,
        contract,
        host_abi_version,
        policy=effective,
    )
    entry = _CachedEntry(
        so_path=so_path,
        symbol_name=symbol_name,
        host_abi_version=host_abi_version,
    )
    if effective.memory_enabled and _MEMORY.set(key, entry, fn_body=fn_body):
        _trace("store", key=key, tier="memory", result="stored")
        return _CacheResult(entry, owns_so=False, source="store")

    _trace(
        "store",
        key=key,
        tier="memory",
        result="disabled",
        reason=effective.memory_reason,
    )
    return _CacheResult(entry, owns_so=True, source="store")


def _pid_is_dead(name: str) -> bool:
    """True when ``cannbotdsl_cache_<pid>_xxxx`` names a pid that is gone.

    Conservative on every ambiguity: an unparseable name, or a pid that
    has been recycled by an unrelated process, reads as alive and is
    left alone.
    """
    rest = name[len(_PROCESS_DIR_PREFIX) :]
    pid_text, _, suffix = rest.partition("_")
    if not suffix or not pid_text.isdigit():
        return False
    try:
        os.kill(int(pid_text), 0)
    except ProcessLookupError:
        return True
    except OSError:
        return False
    return False


def _reap_orphan_tempdirs(min_age_seconds: float) -> int:
    """Reclaim compile tempdirs no live process is using.

    Two kinds:

    - ``cannbotdsl_aot_*`` — before the artifact-ownership fix every
      cache-enabled compilation left one behind, so an established
      checkout can be sitting on thousands of them.
    - ``cannbotdsl_cache_<pid>_*`` — a process directory whose owner died
      from a signal that skipped its ``atexit`` handler.

    The age guard keeps the sweep from touching a directory a
    concurrently running compilation still needs; the pid check is a
    second, independent gate for the process dirs.

    Returns the number of directories removed.
    """
    live = {os.path.dirname(entry.so_path) for entry in _MEMORY.values()}
    if _PROCESS_DIR is not None:
        live.add(_PROCESS_DIR)
    cutoff = time.time() - min_age_seconds
    removed = 0
    root = tempfile.gettempdir()
    try:
        names = os.listdir(root)
    except OSError:
        return 0
    for name in names:
        if name.startswith(_LEGACY_TEMPDIR_PREFIX):
            pass
        elif name.startswith(_PROCESS_DIR_PREFIX) and _pid_is_dead(name):
            pass
        else:
            continue
        path = os.path.join(root, name)
        if path in live or not os.path.isdir(path):
            continue
        try:
            if os.stat(path).st_mtime > cutoff:
                continue
        except OSError:
            continue
        shutil.rmtree(path, ignore_errors=True)
        removed += 1
    if removed:
        _LOG.info("reclaimed %d orphaned CANNBotDSL compile tempdir(s) under %s", removed, root)
    return removed


def clear_compile_cache(
    *,
    clear_disk: bool = False,
    reap_orphans: bool = False,
    orphan_min_age_seconds: float = 3600.0,
) -> None:
    """Drop every cached compilation in the memory tier.

    The .so behind each dropped entry is reclaimed when the cache owns
    it exclusively (the per-process artifact directory). Disk-tier paths
    under ``$CANNBOTDSL_CACHE_DIR`` are left alone — they are the user's
    persistent data — as are paths the user copied elsewhere via
    :meth:`ProviderCallable.save`.

    Live :class:`ProviderCallable` handles backed by the dropped .so
    files normally keep working on Linux because their already loaded
    mappings remain usable after the backing paths are unlinked.

    :param clear_disk: When True, also rm-rf the configured disk
        root's ``v2/`` directory. Default False — the disk tier is
        the user's persistent data and must be opted into explicitly
        for destruction.
    :param reap_orphans: When True, also sweep compile tempdirs no live
        process is using — ``cannbotdsl_aot_*`` left by CANNBotDSL versions
        that did not reclaim them, and ``cannbotdsl_cache_<pid>_*`` whose
        owning process died without running its exit handler.
    :param orphan_min_age_seconds: Age below which a tempdir is assumed
        to belong to a running compilation and is skipped.
    """
    entries = _MEMORY.clear()
    for key, entry in entries:
        _trace("evict", key=key, reason="clear")
        _reclaim(entry.so_path)
        parent = os.path.dirname(entry.so_path)
        if parent and os.path.basename(parent).startswith(_LEGACY_TEMPDIR_PREFIX):
            shutil.rmtree(parent, ignore_errors=True)
    if reap_orphans:
        _reap_orphan_tempdirs(orphan_min_age_seconds)
    disk_removed = _disk_clear(_configured_disk_root()) if clear_disk else False
    _trace(
        "clear",
        memory_entries=len(entries),
        disk="removed" if disk_removed else "kept",
    )


# ---------------------------------------------------------------------------
# Singleflight
# ---------------------------------------------------------------------------

# One lock per key, so unrelated kernels still compile concurrently. The
# registry grows with the number of distinct kernels a process compiles
# (a ``Lock`` each), which is bounded by the program, not by the loop.
_KEY_LOCKS: dict = {}
_KEY_LOCKS_GUARD = threading.Lock()


def _thread_lock_for(key: str) -> threading.Lock:
    with _KEY_LOCKS_GUARD:
        lock = _KEY_LOCKS.get(key)
        if lock is None:
            lock = threading.Lock()
            _KEY_LOCKS[key] = lock
        return lock


@contextlib.contextmanager
def _file_lock(
    key: str,
    policy: Optional[_CachePolicy] = None,
):
    """Hold an exclusive flock for ``key``, or proceed unlocked.

    Only meaningful when the disk tier is on — without it there is no
    shared state between processes to protect. A lock that cannot be
    taken (read-only cache root, NFS without a working lock manager)
    degrades to no lock at all: the worst case is the pre-fix behaviour
    of two workers compiling the same key, which is far better than
    failing the compile.
    """
    effective = policy if policy is not None else resolve_policy()
    if not effective.disk_enabled or effective.disk_root is None:
        yield
        return
    root = effective.disk_root
    bucket = os.path.join(root, "v2", key[:2])
    fd = None
    try:
        os.makedirs(bucket, exist_ok=True)
        fd = os.open(os.path.join(bucket, f"{key}.lock"), os.O_CREAT | os.O_RDWR, 0o644)
        fcntl.flock(fd, fcntl.LOCK_EX)
    except OSError as e:
        _LOG.debug("compile cache lock unavailable for key=%s (%s); proceeding unlocked", key, e)
        if fd is not None:
            os.close(fd)
        yield
        return
    try:
        yield
    finally:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)


@contextlib.contextmanager
def singleflight(
    key: str,
    policy: Optional[_CachePolicy] = None,
):
    """Serialize backend runs for ``key`` across threads and processes.

    Yields an entry when someone else published one while this caller
    was waiting — the caller must then skip the backend and use it — or
    ``None`` when this caller is the one that should compile.

    Both waits re-check afterwards, which is the entire point: acquiring
    a lock only to run the compiler anyway would just queue up N
    identical Bisheng runs instead of racing them. Cold-start fan-out
    (``pytest -n 32``, one rank per device) is exactly the case this
    exists for.
    """
    effective = policy if policy is not None else resolve_policy()
    with _thread_lock_for(key):
        result = lookup(key, effective)
        if result is not None:
            _trace(
                "singleflight",
                key=key,
                result="reused_memory" if result.source == "memory" else "reused_disk",
            )
            yield result
            return
        with _file_lock(key, effective):
            entry = _disk_get(key, effective)
            if entry is not None:
                _trace("singleflight", key=key, result="reused_disk")
                yield _promote(key, entry, effective)
                return
            _trace("singleflight", key=key, result="owner")
            yield None


def _cache_size() -> int:
    """Number of cached compilations in the memory tier."""
    return len(_MEMORY)
