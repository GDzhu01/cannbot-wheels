# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Provider-neutral orchestration around the native packed-host runtime.

TorchNPU private storage inspection intentionally lives in
``torch_npu_integration``. This module owns only leases, streams, call-frame
snapshots, and debug-session orchestration.
"""

from __future__ import annotations

import ctypes
from dataclasses import dataclass, replace
import importlib
import os
import sys
import threading
from typing import Any

from cannbotdsl.core.compiler.torch_npu_integration import (
    DebugResult as _DebugResult,
    RuntimePhysicalLayout,
    TorchNPUIntegration,
)


_KDL_EXT_DEV = 12
_HOST_NATIVE = None
_HOST_NATIVE_IMPORT_ERROR: Exception | None = None
_TORCH_NPU_INTEGRATION = None
_TORCH_NPU_LOCK = threading.Lock()

# Private compatibility alias for internal callers; implementation is isolated.
_TorchNPUIntegration = TorchNPUIntegration


@dataclass(frozen=True, slots=True)
class _ResolvedStream:
    handle: int
    owner: object | None = None


@dataclass(frozen=True, slots=True)
class _DebugSpec:
    payload_bytes: int
    counter_bytes: int


@dataclass(frozen=True, slots=True)
class TensorMetadataSnapshot:
    data: int
    shape: tuple[int, ...]
    stride: tuple[int, ...]
    dtype_code: int
    dtype_bits: int
    dtype_lanes: int
    device_type: int
    device_id: int
    byte_offset: int
    physical_layout: RuntimePhysicalLayout | None = None


def host_native(*, required: bool = False):
    """Load the framework-independent packed host runtime lazily."""

    global _HOST_NATIVE, _HOST_NATIVE_IMPORT_ERROR
    if _HOST_NATIVE is not None:
        return _HOST_NATIVE
    if _HOST_NATIVE_IMPORT_ERROR is not None:
        if required:
            raise RuntimeError(
                "cannbotdsl._host_runtime is required; rebuild and reinstall CANNBotDSL"
            ) from _HOST_NATIVE_IMPORT_ERROR
        return None
    try:
        _HOST_NATIVE = importlib.import_module("cannbotdsl._host_runtime")
    except ImportError as error:
        _HOST_NATIVE_IMPORT_ERROR = error
        if required:
            raise RuntimeError(
                "cannbotdsl._host_runtime is required; rebuild and reinstall CANNBotDSL"
            ) from error
        return None
    return _HOST_NATIVE


def _as_stream_handle(raw: Any) -> int:
    if isinstance(raw, ctypes.c_void_p):
        raw = raw.value
    if isinstance(raw, bool):
        raise TypeError("provider stream handle must be an integer pointer")
    try:
        handle = int(raw or 0)
    except (TypeError, ValueError, OverflowError) as error:
        raise TypeError("provider stream handle must be an integer pointer") from error
    if handle < 0:
        raise ValueError("provider stream handle must be non-negative")
    return handle


def _torch_tensor_type_if_loaded():
    torch = sys.modules.get("torch")
    return None if torch is None else getattr(torch, "Tensor", None)


def _get_or_create_torch_npu_integration(torch):
    global _TORCH_NPU_INTEGRATION
    if _TORCH_NPU_INTEGRATION is not None:
        return _TORCH_NPU_INTEGRATION
    with _TORCH_NPU_LOCK:
        if _TORCH_NPU_INTEGRATION is not None:
            return _TORCH_NPU_INTEGRATION
        try:
            torch_npu = importlib.import_module("torch_npu")
        except ImportError as error:
            raise RuntimeError(
                "exact torch.Tensor runtime support requires torch_npu"
            ) from error
        _TORCH_NPU_INTEGRATION = TorchNPUIntegration(torch, torch_npu)
        return _TORCH_NPU_INTEGRATION


def _torch_device_type(value: object, value_type: type) -> str:
    try:
        device = value.device
        device_type = device.type
    except Exception as error:
        raise RuntimeError(
            f"cannot inspect {_qualified_type_name(value_type)}.device before "
            "the DLPack Exchange boundary"
        ) from error
    if type(device_type) is not str:
        raise RuntimeError(
            f"{_qualified_type_name(value_type)}.device.type must be a string"
        )
    return device_type


def _lazy_torch_npu_integration(value: object):
    torch_tensor_type = _torch_tensor_type_if_loaded()
    if torch_tensor_type is None or type(value) is not torch_tensor_type:
        return None
    if _torch_device_type(value, torch_tensor_type) not in {
        "npu",
        "privateuseone",
    }:
        return None
    return _get_or_create_torch_npu_integration(sys.modules["torch"])


def _is_npu_torch_tensor_subclass(value: object, torch_tensor_type: type) -> bool:
    value_type = type(value)
    if value_type is torch_tensor_type or not issubclass(
        value_type, torch_tensor_type
    ):
        return False
    return _torch_device_type(value, value_type) in {"npu", "privateuseone"}


def has_c_exchange(value: object) -> bool:
    if not hasattr(type(value), "__dlpack_c_exchange_api__"):
        return False
    return bool(host_native(required=True).has_c_exchange(value))


def inspect_provider_tensor(
    value: object, *, name: str = "tensor"
) -> TensorMetadataSnapshot:
    return inspect_provider_tensors(((name, value),))[0]


def _metadata_snapshot(raw) -> TensorMetadataSnapshot:
    return TensorMetadataSnapshot(
        int(raw[0]),
        tuple(int(item) for item in raw[1]),
        tuple(int(item) for item in raw[2]),
        int(raw[3]),
        int(raw[4]),
        int(raw[5]),
        int(raw[6]),
        int(raw[7]),
        int(raw[8]),
    )


def _qualified_type_name(value_type: type) -> str:
    return f"{value_type.__module__}.{value_type.__qualname__}"


def _preflight_provider_tensors(
    tensors: tuple[tuple[str, object], ...], *, require_torch_npu: bool
):
    if not tensors:
        return None

    torch_tensor_type = _torch_tensor_type_if_loaded()
    if torch_tensor_type is not None:
        subclass_tensors = tuple(
            (name, value)
            for name, value in tensors
            if _is_npu_torch_tensor_subclass(value, torch_tensor_type)
        )
        if subclass_tensors:
            torch = sys.modules["torch"]
            _get_or_create_torch_npu_integration(
                torch
            ).preflight_tensor_subclasses(subclass_tensors)

    reference_type = type(tensors[0][1])
    for name, value in tensors:
        if type(value) is not reference_type:
            raise TypeError(
                f"{name} changed DLPack provider type: expected "
                f"{_qualified_type_name(reference_type)}, got "
                f"{_qualified_type_name(type(value))}"
            )
    if not require_torch_npu:
        return None
    torch = sys.modules.get("torch")
    if torch is None or reference_type is not getattr(torch, "Tensor", None):
        name = tensors[0][0]
        raise TypeError(
            f"{name} must be an exact torch.Tensor for this callable, got "
            f"{_qualified_type_name(reference_type)}"
        )
    return _get_or_create_torch_npu_integration(torch)


def inspect_provider_tensors(
    tensors: tuple[tuple[str, object], ...], *, require_torch_npu: bool = False
) -> tuple[TensorMetadataSnapshot, ...]:
    """Take one compile-observation snapshot per unique provider object."""

    tensors = tuple(tensors)
    if not tensors:
        return ()
    required_integration = _preflight_provider_tensors(
        tensors, require_torch_npu=require_torch_npu
    )
    reference_type = type(tensors[0][1])
    raw_snapshots = host_native(required=True).inspect_tensors(
        tuple(value for _, value in tensors)
    )
    snapshots = tuple(_metadata_snapshot(raw) for raw in raw_snapshots)
    device_id = snapshots[0].device_id
    for (name, _), snapshot in zip(tensors, snapshots):
        if snapshot.device_type != _KDL_EXT_DEV:
            raise ValueError(
                f"{name} must use DLPack kDLExtDev (12), "
                f"got device_type={snapshot.device_type}"
            )
        if snapshot.device_id < 0:
            raise ValueError(f"{name} has a negative DLPack device id")
        if snapshot.device_id != device_id:
            raise ValueError(
                f"{name} changed DLPack device: expected device_id={device_id}, "
                f"got {snapshot.device_id}"
            )
    integration = (
        required_integration
        if require_torch_npu
        else _lazy_torch_npu_integration(tensors[0][1])
    )
    if integration is not None:
        inspector = getattr(integration, "inspect_storage", None)
        if callable(inspector):
            layouts = inspector(tensors, snapshots=snapshots)
            snapshots = tuple(
                replace(snapshot, physical_layout=layout)
                for snapshot, layout in zip(snapshots, layouts)
            )
        else:
            integration.validate_storage(tensors)
    return snapshots


def validate_struct_ref_provider_storage(value: object, schema, *, name: str) -> None:
    integration = _lazy_torch_npu_integration(value)
    if integration is not None:
        integration.validate_struct_ref_storage(((name, value, int(schema.size)),))


def _checked_provider_stream(value: object) -> _ResolvedStream:
    if isinstance(value, tuple) and len(value) == 2:
        value = _ResolvedStream(value[0], value[1])
    if not isinstance(value, _ResolvedStream):
        raise TypeError(
            "internal TorchNPU null-stream resolution must return (handle, owner)"
        )
    handle = _as_stream_handle(value.handle)
    if handle == 0:
        raise RuntimeError("TorchNPU returned a null fallback stream handle")
    return _ResolvedStream(handle, value.owner)


def _aligned_private_layouts(
    plan: object,
    public_values: tuple[object, ...],
    tensor_items: tuple[tuple[str, object], ...],
    layouts: tuple[RuntimePhysicalLayout | None, ...],
) -> tuple[dict[str, object] | None, ...]:
    if not any(layout is not None for layout in layouts):
        return ()
    result: list[dict[str, object] | None] = [None] * len(public_values)
    names = tuple(getattr(plan, "public_slot_names", ()))
    for (leaf_name, value), layout in zip(tensor_items, layouts):
        if layout is None:
            continue
        if names:
            public_name = leaf_name.split("[", 1)[0]
            try:
                slot_index = names.index(public_name)
            except ValueError as error:
                raise RuntimeError(
                    f"private layout leaf {leaf_name!r} has no matching public ABI slot"
                ) from error
        else:
            slot_index = next(
                (index for index, item in enumerate(public_values) if item is value),
                None,
            )
            if slot_index is None:
                raise RuntimeError(
                    f"private layout leaf {leaf_name!r} is absent from public ABI values"
                )
        native = layout.to_native()
        previous = result[slot_index]
        if previous is not None and previous != native:
            raise RuntimeError(
                f"public ABI slot {slot_index} received conflicting private layouts"
            )
        result[slot_index] = native
    return tuple(result)


def resolve_provider_call(
    plan: object,
    public_values: tuple[object, ...],
    tensor_items: tuple[tuple[str, object], ...],
    struct_ref_items: tuple[tuple[str, object, int], ...] = (),
    expected_contracts: tuple[object, ...] = (),
    *,
    require_torch_npu: bool = False,
):
    """Resolve one immutable metadata snapshot and the effective stream."""

    tensor_items = tuple(tensor_items)
    if not tensor_items:
        raise RuntimeError("provider call has no canonical tensor")
    required_integration = _preflight_provider_tensors(
        tensor_items, require_torch_npu=require_torch_npu
    )
    lease = plan.resolve_first(public_values)
    reference = tensor_items[0][1]
    integration = (
        required_integration
        if require_torch_npu
        else _lazy_torch_npu_integration(reference)
    )
    private_layouts: tuple[dict[str, object] | None, ...] = ()
    if integration is not None:
        inspector = getattr(integration, "inspect_storage", None)
        if expected_contracts and callable(inspector):
            layouts = inspector(
                tensor_items, expected_contracts=tuple(expected_contracts)
            )
            private_layouts = _aligned_private_layouts(
                plan, public_values, tensor_items, layouts
            )
        else:
            integration.validate_storage(tensor_items)
        if struct_ref_items:
            integration.validate_struct_ref_storage(struct_ref_items)
    provider_handle = int(lease.provider_stream_handle)
    if provider_handle:
        stream = _ResolvedStream(provider_handle)
    else:
        if integration is None:
            tensor_type = type(reference)
            raise RuntimeError(
                "DLPack provider returned a null work stream; null-stream fallback "
                "is supported only for exact torch.Tensor with torch_npu, not "
                f"{tensor_type.__module__}.{tensor_type.__qualname__}"
            )
        stream = _checked_provider_stream(
            integration.resolve_null_stream(reference, int(lease.device_id))
        )
    return lease, stream, integration, private_layouts


def invoke_provider_call(
    plan: object,
    public_values: tuple[object, ...],
    tensor_items: tuple[tuple[str, object], ...],
    debug_plans=(),
    *,
    struct_ref_items: tuple[tuple[str, object, int], ...] = (),
    expected_contracts: tuple[object, ...] = (),
    require_torch_npu: bool = False,
) -> None:
    lease, stream, integration, private_layouts = resolve_provider_call(
        plan,
        public_values,
        tensor_items,
        struct_ref_items,
        expected_contracts=expected_contracts,
        require_torch_npu=require_torch_npu,
    )
    reference = tensor_items[0][1]
    session = None
    specs = ()
    try:
        all_values = public_values
        call_layouts = private_layouts
        if debug_plans:
            factory = (
                None
                if integration is None
                else getattr(integration, "create_debug_session", None)
            )
            if not callable(factory):
                raise RuntimeError(
                    "debug-bearing calls support only exact torch.Tensor with torch_npu"
                )
            specs = tuple(
                _DebugSpec(int(item.payload_bytes), int(item.counter_bytes))
                for item in debug_plans
            )
            for spec in specs:
                if spec.payload_bytes < 0:
                    raise ValueError("debug payload byte size must be non-negative")
                if spec.counter_bytes < 0 or spec.counter_bytes % 8:
                    raise ValueError(
                        "debug counter byte size must be a non-negative multiple of 8"
                    )
            session = factory(reference, int(lease.device_id), specs)
            session_tensors = session.tensors
            if type(session_tensors) is not tuple:
                raise TypeError("TorchNPU debug session tensors must be a tuple")
            if len(session_tensors) != len(specs) * 2:
                raise ValueError("TorchNPU debug session tensor count mismatch")
            all_values = public_values + session_tensors
            if call_layouts:
                call_layouts += (None,) * len(session_tensors)
            session.before_invoke(stream.handle)
        if call_layouts:
            plan.invoke(lease, stream.handle, all_values, call_layouts)
        else:
            plan.invoke(lease, stream.handle, all_values)
        if session is not None:
            results = session.finish()
            if type(results) is not tuple or len(results) != len(specs):
                raise ValueError("TorchNPU debug result count mismatch")
            for index, (spec, result) in enumerate(zip(specs, results)):
                if not isinstance(result, _DebugResult):
                    raise TypeError(
                        f"TorchNPU debug result {index} must be DebugResult"
                    )
                if type(result.payload) is not bytes or len(result.payload) != spec.payload_bytes:
                    raise ValueError(
                        f"TorchNPU debug result {index} payload length mismatch"
                    )
                if (
                    type(result.counters) is not tuple
                    or any(type(item) is not int for item in result.counters)
                    or len(result.counters) != spec.counter_bytes // 8
                ):
                    raise ValueError(
                        f"TorchNPU debug result {index} counter count mismatch"
                    )
            from cannbotdsl.core.frontend.debug_print import _capture_debug_results

            _capture_debug_results(tuple(zip(debug_plans, results)))
    except Exception as primary:
        if session is not None:
            try:
                session.close()
            except Exception as close_error:
                primary.add_note(
                    "TorchNPU debug session close() also failed: "
                    f"{type(close_error).__name__}: {close_error}"
                )
        raise
    else:
        if session is not None:
            session.close()
    finally:
        _ = stream.owner


def _reset_after_fork() -> None:
    global _TORCH_NPU_INTEGRATION, _TORCH_NPU_LOCK
    native = _HOST_NATIVE
    if native is not None:
        native._reset_after_fork()
    _TORCH_NPU_INTEGRATION = None
    _TORCH_NPU_LOCK = threading.Lock()


if hasattr(os, "register_at_fork"):
    os.register_at_fork(after_in_child=_reset_after_fork)


__all__ = [
    "TensorMetadataSnapshot",
    "has_c_exchange",
    "host_native",
    "inspect_provider_tensor",
    "inspect_provider_tensors",
    "invoke_provider_call",
    "resolve_provider_call",
    "validate_struct_ref_provider_storage",
]
