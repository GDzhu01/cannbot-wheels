# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Reconstruct a :class:`ProviderCallable` from a saved artifact.

The .so and its ``<so>.meta.json`` sidecar are produced by
:meth:`ProviderCallable.save`. ``load`` reads the sidecar for
``symbol_name`` / immutable call contract and dlopens the .so. The returned handle
does not own the file: :meth:`ProviderCallable.close` releases its
``ProgramImage`` reference and prevents new calls, but never unlinks a
user-managed .so. The native runtime conservatively keeps successfully loaded
DSOs mapped when no independent stream-event retirement API is available.
"""

import os

from cannbotdsl.core.compiler import metadata
from cannbotdsl.core.compiler.function import ProviderCallable


def load(so_path: str) -> ProviderCallable:
    """Load a saved .so into a callable :class:`ProviderCallable`.

    :param so_path: Path to a .so previously written by
        :meth:`ProviderCallable.save`. A ``<so_path>.meta.json`` sidecar
        must sit next to it.
    :raises FileNotFoundError: if ``so_path`` or its sidecar is missing.
    :raises ValueError: if the sidecar version is not understood.
    """
    if not os.path.exists(so_path):
        raise FileNotFoundError(f".so not found at {so_path!r}")
    sidecar = metadata.read_sidecar(so_path)
    return ProviderCallable._create(
        so_path,
        sidecar.symbol_name,
        sidecar.contract,
        host_abi_version=sidecar.host_abi_version,
        owns_so=False,
        content_key=sidecar.content_key,
        format_version_tag=sidecar.format_version_tag,
    )
