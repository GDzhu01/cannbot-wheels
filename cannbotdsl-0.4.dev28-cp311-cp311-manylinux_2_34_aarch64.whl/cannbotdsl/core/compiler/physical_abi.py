# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Projection from logical call arguments to packed-host physical carriers."""

from __future__ import annotations

from cannbotdsl.core.contracts.model import (
    BinaryExpr,
    ConstantExpr,
    TensorContract,
    TensorListContract,
)


def _descriptor_extent(argument: TensorListContract):
    record_words = argument.record_words
    length = argument.length
    if isinstance(length, ConstantExpr):
        extent = length.value * record_words
        if extent > (1 << 63) - 1:
            raise ValueError("TensorList descriptor extent exceeds signed int64")
        return ConstantExpr(extent)
    if record_words == 1:
        return length
    return BinaryExpr("mul", ConstantExpr(record_words), length)


def _packed_carrier(argument: TensorContract):
    """Return the int8 carrier for a sub-byte tensor, or None.

    A packed dtype has no host-side spelling: torch cannot name a 4-bit
    element, so the caller hands over bytes.  The device keeps the logical
    contract; only this ABI slot is rewritten, with the innermost extent and
    every stride divided by the packing factor.
    """

    from cannbotdsl.core.contracts.elements import element_for_tag

    info = element_for_tag(argument.element)
    if info.dtype.bits >= 8:
        return None
    per_carrier = 8 // info.dtype.bits
    if not argument.shape:
        return None
    if not all(isinstance(item, ConstantExpr) for item in argument.shape):
        raise ValueError(
            f"a packed {info.dtype.name} tensor needs a static shape to derive "
            "its host carrier"
        )
    extents = [item.value for item in argument.shape]
    if extents[-1] % per_carrier != 0:
        raise ValueError(
            f"packed {info.dtype.name} innermost extent {extents[-1]} is not a "
            f"multiple of the packing factor {per_carrier}"
        )
    extents[-1] //= per_carrier
    stride = []
    running = 1
    for extent in reversed(extents):
        stride.append(running)
        running *= extent
    return TensorContract(
        element="i8",
        shape=tuple(ConstantExpr(value) for value in extents),
        stride=tuple(ConstantExpr(value) for value in reversed(stride)),
        address_space=argument.address_space,
    )


def physical_argument(argument):
    """Return the one-slot ABI carrier for a logical argument contract."""

    if isinstance(argument, TensorListContract):
        return TensorContract(
            element="u64",
            shape=(_descriptor_extent(argument),),
            stride=(ConstantExpr(1),),
            address_space="GM",
        )
    return argument


def host_carrier(argument):
    """Return the host-visible carrier for one logical argument.

    Identical to :func:`physical_argument` except that a packed sub-byte tensor
    becomes its int8 byte carrier.  The split matters: the device keeps the
    logical element type so the cube sees fp4, while the host ABI slot has to
    describe what the caller can actually hand over.
    """

    argument = physical_argument(argument)
    if isinstance(argument, TensorContract):
        packed = _packed_carrier(argument)
        if packed is not None:
            return packed
    return argument


__all__ = ["host_carrier", "physical_argument"]
