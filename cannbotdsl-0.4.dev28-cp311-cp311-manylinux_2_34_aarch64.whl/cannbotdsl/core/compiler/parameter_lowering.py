# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""One immutable projection from public parameters to packed-host slots."""

from __future__ import annotations

import ctypes
from dataclasses import dataclass, field

from cannbotdsl.core.compiler.physical_abi import physical_argument
from cannbotdsl.core.contracts.model import (
    ScalarContract,
    StructContract,
    StructRefContract,
    TensorContract,
    TensorListContract,
)


TENSOR = "tensor"
SCALAR = "scalar"
BUFFER = "buffer"


def _physical_kind(argument) -> str:
    argument = physical_argument(argument)
    if isinstance(argument, (TensorContract, StructRefContract)):
        return TENSOR
    if isinstance(argument, ScalarContract):
        return SCALAR
    if isinstance(argument, StructContract):
        return BUFFER
    raise TypeError(f"unknown physical ABI argument {argument!r}")


@dataclass(frozen=True, slots=True)
class PhysicalCallLayout:
    """Precomputed public/physical shape of one callable's runtime boundary."""

    runtime_parameter_names: tuple[str, ...]
    runtime_parameter_kinds: tuple[str, ...]
    physical_slot_names: tuple[str, ...]
    physical_slot_kinds: tuple[str, ...]
    provider_slot_indices: tuple[int, ...]
    struct_ref_indices: tuple[int, ...]
    requires_torch_npu: bool
    public_slot_count: int
    positional_identity: bool


def _readonly_ctype_bytes(ctype: type, value: object, *, name: str) -> memoryview:
    try:
        instance = value if isinstance(value, ctype) else ctype(value)
    except (TypeError, ValueError, OverflowError) as error:
        raise TypeError(
            f"{name} could not be marshaled as {ctype.__name__}"
        ) from error
    try:
        address = ctypes.addressof(instance)
    except TypeError as error:  # pragma: no cover - defensive buffer boundary
        raise TypeError(
            f"{name} marshal result is not compatible with "
            f"{ctype.__name__}"
        ) from error
    # bytes owns a stable, immutable copy for the duration of the synchronous
    # native call.  The native Buffer slot requires PyBUF_CONTIG_RO and checks
    # its length against the binary schema.
    return memoryview(ctypes.string_at(address, ctypes.sizeof(ctype)))


@dataclass(frozen=True, slots=True)
class ParameterLoweringPlan:
    contract: object
    validation: object = field(init=False, repr=False, compare=False)
    layout: PhysicalCallLayout = field(init=False)
    _host_ctypes: tuple[type, ...] = field(init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        from cannbotdsl.core.contracts.validate import ValidationPlan
        from cannbotdsl.core.compiler.abi_schema import ctypes_type

        validation = ValidationPlan(self.contract)
        runtime_parameters = validation.contract.runtime_parameters
        host_ctypes = tuple(
            ctypes_type(parameter.argument)
            for parameter in runtime_parameters
        )
        slot_names = []
        slot_kinds = []
        for parameter in runtime_parameters:
            argument = parameter.argument
            if argument is None:  # pragma: no cover - contract validation owns this.
                raise AssertionError("runtime parameter has no argument contract")
            slot_names.append(parameter.name)
            slot_kinds.append(_physical_kind(argument))
        if len(slot_names) != len(validation.contract.abi_arguments):
            raise RuntimeError(
                "runtime parameter and host ABI argument counts are inconsistent"
            )
        provider_slot_indices = tuple(
            index
            for index, parameter in enumerate(runtime_parameters)
            if isinstance(
                parameter.argument,
                (TensorContract, TensorListContract, StructRefContract),
            )
        )
        struct_ref_indices = tuple(
            index
            for index, parameter in enumerate(runtime_parameters)
            if isinstance(parameter.argument, StructRefContract)
        )
        positional_identity = (
            len(runtime_parameters) == len(slot_names)
            and all(
                isinstance(
                    parameter.argument,
                    (TensorContract, StructRefContract, ScalarContract),
                )
                for parameter in runtime_parameters
            )
            and all(
                parameter.kind
                in {"POSITIONAL_ONLY", "POSITIONAL_OR_KEYWORD"}
                for parameter in runtime_parameters
            )
        )
        object.__setattr__(self, "validation", validation)
        object.__setattr__(self, "_host_ctypes", host_ctypes)
        object.__setattr__(
            self,
            "layout",
            PhysicalCallLayout(
                runtime_parameter_names=tuple(
                    parameter.name for parameter in runtime_parameters
                ),
                runtime_parameter_kinds=tuple(
                    parameter.kind for parameter in runtime_parameters
                ),
                physical_slot_names=tuple(slot_names),
                physical_slot_kinds=tuple(slot_kinds),
                provider_slot_indices=provider_slot_indices,
                struct_ref_indices=struct_ref_indices,
                requires_torch_npu=any(
                    isinstance(parameter.argument, TensorListContract)
                    or (
                        isinstance(parameter.argument, TensorContract)
                        and parameter.argument.storage_encoding is not None
                    )
                    for parameter in runtime_parameters
                ),
                public_slot_count=len(slot_names),
                positional_identity=positional_identity,
            ),
        )

    @property
    def abi_arguments(self):
        return self.contract.abi_arguments

    @property
    def slot_count(self) -> int:
        return self.layout.public_slot_count

    @property
    def signature(self):
        return self.validation.signature

    def mlir_types(self):
        from cannbotdsl.core.compiler.contract_lowering import ContractTypeLowerer

        return tuple(
            ContractTypeLowerer.mlir_type(parameter.argument)
            for parameter in self.validation.contract.runtime_parameters
        )

    def ctypes_types(self):
        return self._host_ctypes

    def bind_physical(self, args, kwargs) -> tuple[object, ...]:
        """Bind once and return one host value per runtime parameter."""

        positional_fast_path = (
            self.layout.positional_identity
            and not kwargs
            and len(args) == len(self.layout.runtime_parameter_names)
        )
        if positional_fast_path:
            # CPython supplied the tuple in the exact native slot order.
            values = args
        else:
            bound = self.validation.bind(args, kwargs)
            values = self.validation.validate(bound)
        physical = []
        for index, (parameter, value, ctype) in enumerate(
            zip(
                self.validation.contract.runtime_parameters,
                values,
                self._host_ctypes,
            )
        ):
            argument = parameter.argument
            path = parameter.name
            expected = self.abi_arguments[index]
            if argument != expected:
                raise RuntimeError(
                    f"runtime parameter {path} does not match host slot {index}"
                )
            if isinstance(argument, ScalarContract):
                from cannbotdsl.core.contracts.elements import (
                    element_for_tag,
                    validate_host_scalar_value,
                )

                validate_host_scalar_value(
                    element_for_tag(argument.element),
                    value,
                    path=path,
                )
            if isinstance(
                argument, (TensorContract, StructRefContract, ScalarContract)
            ):
                physical.append(value)
                continue
            if isinstance(argument, TensorListContract):
                if type(value) is not list and type(value) is not tuple:
                    raise TypeError(
                        f"{path} expects an exact list or tuple of provider "
                        f"tensors, got {type(value).__name__}"
                    )
                frozen = tuple(value)
                if not frozen:
                    raise ValueError(
                        f"{path} TensorList must contain at least one tensor"
                    )
                physical.append(frozen)
                continue
            if isinstance(argument, StructContract):
                from cannbotdsl.types.datastruct import _marshal_datastruct

                marshaled = _marshal_datastruct(value, argument.schema)
            else:  # pragma: no cover - contract validation owns this.
                raise AssertionError(
                    f"runtime parameter {path!r} has no physical lowering"
                )
            physical.append(
                _readonly_ctype_bytes(ctype, marshaled, name=path)
            )
        if positional_fast_path:
            # Positional identity layouts contain Tensor/Scalar slots only,
            # so validation does not need to rewrite the caller-owned tuple.
            return args
        return tuple(physical)

    def provider_tensor_items(
        self,
        physical: tuple[object, ...],
    ) -> tuple[tuple[str, object], ...]:
        """Flatten provider leaves while retaining stable diagnostic paths."""

        items = []
        for index in self.layout.provider_slot_indices:
            name = self.layout.physical_slot_names[index]
            value = physical[index]
            argument = self.abi_arguments[index]
            if isinstance(argument, TensorListContract):
                items.extend(
                    (f"{name}[{element_index}]", element)
                    for element_index, element in enumerate(value)
                )
            else:
                items.append((name, value))
        return tuple(items)

    def provider_tensor_contract_items(
        self,
        physical: tuple[object, ...],
    ) -> tuple[object, ...]:
        """Return one expected contract per flattened provider tensor."""

        contracts = []
        for index in self.layout.provider_slot_indices:
            argument = self.abi_arguments[index]
            value = physical[index]
            if isinstance(argument, TensorListContract):
                contracts.extend(argument for _ in value)
            else:
                contracts.append(argument)
        return tuple(contracts)


__all__ = [
    "BUFFER",
    "PhysicalCallLayout",
    "ParameterLoweringPlan",
    "SCALAR",
    "TENSOR",
]
