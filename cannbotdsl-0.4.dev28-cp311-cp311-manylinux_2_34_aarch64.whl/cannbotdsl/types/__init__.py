# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""cannbotdsl.types -- dtypes, layouts, scalars and the aggregate containers.

`dtypes` is imported first: `array`, `datastruct` and `delay_line` reach back
into `cannbotdsl.types.dtypes` at module scope, so it must be resolved before
they are pulled in below.
"""

# Concrete scalar wrappers. These live in the private _numeric module but are
# public API in practice: they appear in user kernel signatures and 33 files
# under test/ and examples/ import them. Exposed here so callers have a
# supported path (`from cannbotdsl.types import Int64`) instead of reaching
# into a private module.
from cannbotdsl.types._numeric import (
    BFloat16,
    Float8E4M3FN,
    Float8E5M2,
    Float8E8M0,
    HIFloat8,
    Boolean,
    Float,
    Float16,
    Float32,
    Float64,
    Int16,
    Int32,
    Int64,
    Int8,
    Integer,
    UInt16,
    UInt32,
    UInt64,
    UInt8,
)
from cannbotdsl.types.dtypes import (
    ScalarValue,
    DTypeKind,
    DType,
    float16,
    float32,
    float64,
    bfloat16,
    float8_e4m3fn,
    float8_e5m2,
    float8_e8m0,
    hifloat8,
    fp4x2_e2m1,
    int8,
    int16,
    int32,
    int64,
    uint8,
    uint16,
    uint32,
    uint64,
    bool_,
    bool,
)
from cannbotdsl.types.layout import (
    Shape,
    Stride,
    Coord,
    Tile,
    Tiler,
    Layout,
)
from cannbotdsl.types.scalar import (
    Layout,
    Shape,
    Stride,
    ScalarValue,
    MemLoc,
    ChannelKind,
    PIPE,
    RoundingMode,
    RegLayout,
    CmpOp,
    Tensor,
)
from cannbotdsl.types.tensor_list import (
    TensorList,
)
from cannbotdsl.types.array import (
    IntArray,
    alloc_array,
)
from cannbotdsl.types.datastruct import (
    CArray,
    StructField,
    StructRef,
    StructSchema,
    datastruct,
)
from cannbotdsl.types.delay_line import (
    DelayLine,
    DelayLineGroup,
)

# The 13 layout/value types this package has always promised, plus the 19
# concrete scalar wrappers promoted out of the private _numeric module and the
# aggregate containers (array / datastruct / delay_line) that moved in here.
# Names such as DType, CmpOp, TensorList and the lowercase dtype descriptors
# stay importable from here but are advertised by cannbotdsl.types.dtypes.
__all__ = [
    "Shape",
    "Stride",
    "Coord",
    "Tile",
    "Tiler",
    "ScalarValue",
    "MemLoc",
    "ChannelKind",
    "PIPE",
    "RoundingMode",
    "RegLayout",
    "Layout",
    "Tensor",
    "BFloat16",
    "Boolean",
    "CArray",
    "DelayLine",
    "DelayLineGroup",
    "Float",
    "Float16",
    "Float32",
    "Float64",
    "Float8E4M3FN",
    "Float8E5M2",
    "Float8E8M0",
    "HIFloat8",
    "Int8",
    "Int16",
    "Int32",
    "Int64",
    "IntArray",
    "Integer",
    "StructField",
    "StructRef",
    "StructSchema",
    "UInt8",
    "UInt16",
    "UInt32",
    "UInt64",
    "alloc_array",
    "datastruct",
]
