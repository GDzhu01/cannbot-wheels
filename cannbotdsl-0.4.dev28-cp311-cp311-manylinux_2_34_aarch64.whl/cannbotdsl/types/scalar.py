# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Frontend scalar / tensor value types and the target enums.

Split out of the former flat ``cannbotdsl/types.py``. Depends on
``types.layout``; the dependency is one-way and must stay that way.
"""

from __future__ import annotations

from enum import IntEnum
from typing import TYPE_CHECKING, Any, Protocol, Tuple, Union

from cannbotdsl.types.layout import Layout, Shape, Stride

if TYPE_CHECKING:
    from cannbotdsl.types.dtypes import DType


class ScalarValue(Protocol):
    """A staged DSL scalar whose concrete dtype is chosen at a call site.

    This protocol is intentionally not runtime-checkable.  It is the public
    annotation for the scalar *value category*; CANNBotDSL recognizes its own
    scalar wrappers through a closed internal registry rather than accepting
    arbitrary duck-typed objects.
    """

    @property
    def dtype(self) -> "DType": ...

    def __add__(self, other: object, /) -> "ScalarValue": ...

    def __sub__(self, other: object, /) -> "ScalarValue": ...

    def __mul__(self, other: object, /) -> "ScalarValue": ...

    def __truediv__(self, other: object, /) -> "ScalarValue": ...

    def __floordiv__(self, other: object, /) -> "ScalarValue": ...

    def __mod__(self, other: object, /) -> "ScalarValue": ...

    def __radd__(self, other: object, /) -> "ScalarValue": ...

    def __rsub__(self, other: object, /) -> "ScalarValue": ...

    def __rmul__(self, other: object, /) -> "ScalarValue": ...

    def __rtruediv__(self, other: object, /) -> "ScalarValue": ...

    def __rfloordiv__(self, other: object, /) -> "ScalarValue": ...

    def __rmod__(self, other: object, /) -> "ScalarValue": ...

    def __neg__(self) -> "ScalarValue": ...

    def __lt__(self, other: object, /) -> "ScalarValue": ...

    def __le__(self, other: object, /) -> "ScalarValue": ...

    def __gt__(self, other: object, /) -> "ScalarValue": ...

    def __ge__(self, other: object, /) -> "ScalarValue": ...

_TensorIndex = Union[
    int,
    None,
    slice,
    ScalarValue,
    Tuple["_TensorIndex", ...],
]

class MemLoc(IntEnum):
    GM = 0
    UB = 1
    L1 = 2
    L0A = 3
    L0B = 4
    L0C = 5
    RegFile = 6
    L0A_MX = 7
    L0B_MX = 8
    BIAS = 9
    SSBUF = 10
    FBUF = 11

class ChannelKind(IntEnum):
    SameCore = 0
    CrossCore = 1

class PIPE(IntEnum):
    P_NULL = 0
    S = 1
    V = 2
    M = 3
    MTE1 = 4
    MTE2 = 5
    MTE3 = 6
    MTE4 = 7
    MTE5 = 8
    V2 = 9
    ALL = 10
    FIXPIPE = 11
    VLD = 12
    VST = 13
    LD = 14
    ST = 15
    LD_ST = 16
    VEXE = 17
    AIV_MTE2 = 18
    AIC_MTE3 = 19
    AIC_MTE1 = 20

class RoundingMode(IntEnum):
    NA = 6  # not specified: widening casts pass through (no rounding);
    # narrowing casts auto-select RN (AscendC default)
    RN = 0  # nearest even
    RNA = 1  # nearest away from zero
    RD = 2  # toward negative infinity
    RU = 3  # toward positive infinity
    RZ = 4  # toward zero
    RO = 5  # nearest odd; f32->f16 only

class RegLayout(IntEnum):
    UNKNOWN = -1
    ZERO = 0
    ONE = 1
    TWO = 2
    THREE = 3

class CmpOp(IntEnum):
    EQ = 0
    NE = 1
    GE = 2
    GT = 3
    LE = 4
    LT = 5

class Tensor:
    """Canonical trace-body tensor value.

    A Tensor owns no host allocation.  It is a composition facade around one
    CANNIR Tensor SSA value and is constructed only by the framework while a
    staged function is being traced.
    """

    __slots__ = ("_ssa_value",)

    def __init__(self, *args, **kwargs):
        del args, kwargs
        raise TypeError("Tensor values are created by CANNBotDSL while tracing")

    def __init_subclass__(cls, **kwargs):
        del cls, kwargs
        raise TypeError("Tensor is a sealed CANNBotDSL value type")

    @classmethod
    def _from_ir(cls, value):
        if type(value) is cls:
            return value
        import cannbotdsl._mlir.ir as ir
        from cannbotdsl._mlir.dialects import cannir

        if not isinstance(value, ir.Value) or not cannir.TensorType.isinstance(value.type):
            actual = getattr(value, "type", type(value).__name__)
            raise TypeError(f"Tensor requires a !cannir.tensor carrier, got {actual}")
        result = object.__new__(cls)
        object.__setattr__(result, "_ssa_value", value)
        return result

    @property
    def shape(self) -> Tuple[int, ...]:
        from cannbotdsl.tensor import _tensor_shape

        return _tensor_shape(self)

    @property
    def stride(self) -> Tuple[int, ...]:
        from cannbotdsl.tensor import _tensor_stride

        return _tensor_stride(self)

    @property
    def dtype(self) -> "DType":
        from cannbotdsl.tensor import _tensor_dtype

        return _tensor_dtype(self)

    @property
    def memloc(self) -> MemLoc:
        from cannbotdsl.tensor import _tensor_memloc

        return _tensor_memloc(self)

    @property
    def layout(self) -> Layout:
        from cannbotdsl.tensor import _tensor_layout

        return _tensor_layout(self)

    @property
    def physical_layout(self) -> Layout:
        from cannbotdsl.tensor import _tensor_physical_layout

        return _tensor_physical_layout(self)

    @property
    def physical_shape(self) -> Shape:
        return self.physical_layout.shape

    @property
    def physical_stride(self) -> Stride:
        return self.physical_layout.stride

    @property
    def logical_format(self) -> str:
        from cannbotdsl.tensor import _tensor_logical_format

        return _tensor_logical_format(self)

    @property
    def physical_format(self) -> str:
        from cannbotdsl.tensor import _tensor_physical_format

        return _tensor_physical_format(self)

    @property
    def data_format(self) -> str:
        return self.physical_format

    @property
    def rank(self) -> int:
        return len(self.shape)

    def reinterpret(self, dtype, shape=None):
        """Return a typed same-storage Tensor alias."""

        from cannbotdsl.tensor import reinterpret

        return reinterpret(self, dtype, shape)

    def view(self, *shape, size=None, dtype=None) -> "Tensor":
        """Return a programmer-guaranteed shape or dtype alias."""

        from cannbotdsl.tensor import _tensor_view_dispatch

        return _tensor_view_dispatch(self, *shape, size=size, dtype=dtype)

    @property
    def vec(self):
        """Return an AIV-affine point-access view of an SSBUF Tensor."""

        from cannbotdsl.tensor import _tensor_ssbuf_core_view

        return _tensor_ssbuf_core_view(self, "vec")

    @property
    def cube(self):
        """Return an AIC-affine point-access view of an SSBUF Tensor."""

        from cannbotdsl.tensor import _tensor_ssbuf_core_view

        return _tensor_ssbuf_core_view(self, "cube")

    def __getitem__(self, coord: _TensorIndex) -> Any:
        """Load a point or create a rank-preserving alias view.

        A point coordinate must match the complete logical shape tree.  The
        root one-dimensional form accepts either ``tensor[i]`` or
        ``tensor[(i,)]``.  Static coordinates are bounds-checked; runtime
        coordinates remain caller-managed and receive no implicit guard.

        ``None`` keeps the matching axis or complete nested shape subtree; it
        never inserts a new axis.  Use interval slices such as ``1:4``, ``:4``,
        or ``1:`` for strictly non-empty interval views.  Negative bounds are
        unsupported.  With a static parent extent, non-negative Python literal
        bounds are clipped at compile time; runtime bounds are absolute,
        caller-managed, and introduce no implicit checks or clipping.  The
        caller guarantees ``0 <= start < stop <= parent_extent`` without
        overflow.  A fully open ``:`` is not a keep marker.
        """
        from cannbotdsl.tensor import _tensor_getitem

        return _tensor_getitem(self, coord)

    def __setitem__(self, coord: _TensorIndex, value: Any) -> None:
        from cannbotdsl.tensor import _tensor_setitem

        _tensor_setitem(self, coord, value)

    def ptr(self, coord: _TensorIndex):
        """Return a typed scalar pointer to one GM element at ``coord``.

        ``coord`` follows the same complete-tree and static-bounds contract as
        a Tensor point load.

        The pointer is consumed by the DCache-bypass and atomic interfaces in
        ``cannbotdsl.ops.scalar`` (``load_bypass``/``store_bypass``/``atomic_*``).
        Creating it accesses no memory.
        """
        from cannbotdsl.ops.scalar import _tensor_ptr

        return _tensor_ptr(self, coord)


__all__ = [
    "ScalarValue",
    "MemLoc",
    "ChannelKind",
    "PIPE",
    "RoundingMode",
    "RegLayout",
    "CmpOp",
    "Tensor",
]
