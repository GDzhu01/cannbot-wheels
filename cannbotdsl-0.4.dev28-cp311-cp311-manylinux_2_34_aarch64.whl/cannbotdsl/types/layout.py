# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Layout and shape description types.

Split out of the former flat ``cannbotdsl/types.py``. This module is the
lower layer of the two: it must not import from ``types.scalar``.
"""

from __future__ import annotations

from typing import Tuple, Union


Shape = Union[int, Tuple["Shape", ...]]

Stride = Union[int, Tuple["Stride", ...]]

Coord = Union[int, None, Tuple["Coord", ...]]

Tile = Union[int, Tuple["Tile", ...]]

Tiler = Union[Shape, Tile]

class Layout:
    """Read-only semantic view of one CANNIR layout SSA value.

    Layout objects are created by CANNBotDSL.  The backend carrier is kept
    private so frontend code cannot accidentally couple itself to MLIR's
    Python value implementation.
    """

    __slots__ = ("_ssa_value",)

    def __init__(self, *args, **kwargs):
        del args, kwargs
        raise TypeError("Layout values are created by CANNBotDSL")

    def __init_subclass__(cls, **kwargs):
        del kwargs
        raise TypeError("Layout is a sealed CANNBotDSL value type")

    @classmethod
    def _from_ir(cls, value):
        if type(value) is cls:
            return value
        import cannbotdsl._mlir.ir as ir
        from cannbotdsl._mlir.dialects import cannir

        if not isinstance(value, ir.Value) or not cannir.LayoutType.isinstance(value.type):
            actual = getattr(value, "type", type(value).__name__)
            raise TypeError(f"Layout requires a !cannir.layout carrier, got {actual}")
        result = object.__new__(cls)
        object.__setattr__(result, "_ssa_value", value)
        return result

    @property
    def shape(self) -> Shape:
        from cannbotdsl.tensor import _layout_shape

        return _layout_shape(self)

    @property
    def stride(self) -> Stride:
        from cannbotdsl.tensor import _layout_stride

        return _layout_stride(self)


__all__ = [
    "Shape",
    "Stride",
    "Coord",
    "Tile",
    "Tiler",
    "Layout",
]
