# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Single capability table for supported private storage encodings."""

from __future__ import annotations


# Keys are both public ``DType.name`` values and canonical contract element
# tags.  The two spellings differ only for the integer types.
_FRACTAL_NZ_C0 = {
    "int8": 32,
    "uint8": 32,
    "float16": 16,
    "bfloat16": 16,
    "float32": 8,
    "i8": 32,
    "u8": 32,
    "f16": 16,
    "bf16": 16,
    "f32": 8,
}

FRACTAL_NZ_DTYPE_NAMES = frozenset(
    {"int8", "uint8", "float16", "bfloat16", "float32"}
)
FRACTAL_NZ_ELEMENT_TAGS = frozenset({"i8", "u8", "f16", "bf16", "f32"})


def fractal_nz_c0(dtype_name_or_tag: str) -> int:
    """Return the hardware C0 extent for one supported element spelling."""

    try:
        return _FRACTAL_NZ_C0[dtype_name_or_tag]
    except KeyError as error:
        raise TypeError(
            f"FRACTAL_NZ does not support element {dtype_name_or_tag!r}"
        ) from error


__all__ = [
    "FRACTAL_NZ_DTYPE_NAMES",
    "FRACTAL_NZ_ELEMENT_TAGS",
    "fractal_nz_c0",
]
