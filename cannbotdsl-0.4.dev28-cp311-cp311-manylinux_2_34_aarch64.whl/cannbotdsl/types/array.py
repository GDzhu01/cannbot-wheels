# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Compile-time-sized, runtime-mutable scalar stack array for CANNBotDSL kernels.

``alloc_array`` emits the IR directly. It must be called inside ``@kernel``
(where an MLIR insertion point is active). The returned SSA value is auto-cast
by MLIR's value-caster machinery to :class:`_ArrayValue`, which exposes
``__getitem__`` / ``__setitem__`` and reads ``length`` / ``element_type`` off
the type::

    @kernel
    def k():
        arr = alloc_array(8, dtype=dtypes.int32)                          # int32_t arr[8];
        tab = alloc_array(4, dtype=dtypes.int32, init=[0, 64, 128, 192])  # int32_t tab[4] = {0, 64, 128, 192};
        fp  = alloc_array(2, dtype=dtypes.float32, init=[0.0, 1.0])       # float fp[2] = {0.0f, 1.0f};
        arr[i] = arr[i] + 1
        v = tab[k]

For the common ``dtypes.int64`` case use the ``IntArray`` partial alias::

    @kernel
    def k():
        a = IntArray(8)                  # alloc_array(8, dtype=dtypes.int64)
        b = IntArray(4, init=[0, 1, 2, 3])
"""

from __future__ import annotations

from functools import partial

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir

from cannbotdsl.types import dtypes


def alloc_array(length, *, dtype, init=None):
    """Emit ``cannir.alloc_array`` at the current insertion point.

    Args:
        length: Positive int — number of elements.
        dtype: A canonical ``cannbotdsl.types.dtypes`` descriptor.
        init: Optional list/tuple of Python ints/floats; length must equal
              ``length``. When provided, codegen emits a C initializer list.

    Returns:
        ``!cannir.array<NxT>`` SSA value (auto-cast to :class:`_ArrayValue`).

    Must be called inside ``@kernel`` / ``@jit``.
    """
    _validate(length, dtype, init)
    from cannbotdsl.core.contracts.elements import mlir_type_for_dtype

    elem_ty = mlir_type_for_dtype(dtype)
    arr_ty = cannir.ArrayType.get(length, elem_ty)
    if init is None:
        return cannir.alloc_array(arr_ty)
    return cannir.alloc_array(arr_ty, init_values=_build_init_attr(elem_ty, length, init))


@ir.register_value_caster(cannir.ArrayType.get_static_typeid())
class _ArrayValue(ir.Value):
    """SSA-level Array. Constructed by :func:`alloc_array`.

    Exposes ``__getitem__`` / ``__setitem__`` for indexed access; ``length``
    and ``element_type`` properties read off the type.
    """

    def __getitem__(self, idx):
        from cannbotdsl.core.contracts.elements import wrap_produced_scalar

        value = cannir.array_load(self, _to_index(idx))
        return wrap_produced_scalar(value, storage_type=self.element_type)

    def __setitem__(self, idx, val):
        cannir.array_store(_to_elem(val, self.element_type), self, _to_index(idx))

    def __len__(self):
        return self.type.length

    @property
    def length(self):
        return self.type.length

    @property
    def element_type(self):
        return self.type.element_type


# Convenience aliases for the common integer array element types.
IntArray = partial(alloc_array, dtype=dtypes.int64)


# ---------------------------------------------------------------------------
# Validation + attribute / coercion helpers (private)
# ---------------------------------------------------------------------------


def _validate(length, dtype, init):
    from cannbotdsl.core.contracts.elements import element_for_dtype

    try:
        element_for_dtype(dtype)
    except TypeError as exc:
        raise TypeError(
            "alloc_array dtype must be a canonical DType descriptor, "
            f"got {dtype!r}"
        ) from exc
    if isinstance(length, bool) or not isinstance(length, int):
        raise TypeError(
            f"alloc_array length must be a positive int, got {type(length).__name__}"
        )
    if length <= 0:
        raise ValueError(f"alloc_array length must be a positive int, got {length!r}")
    if init is not None:
        if not isinstance(init, (list, tuple)):
            raise TypeError(
                f"alloc_array init must be list/tuple, got {type(init).__name__}"
            )
        if len(init) != length:
            raise ValueError(
                f"alloc_array init length {len(init)} != length {length}"
            )


def _build_init_attr(elem_ty, length, init):
    """Pick the most compact MLIR attribute that fits the dtype.

    Compact ``array<...>``-syntax attrs (``DenseI32 / I64 / F32 / F64ArrayAttr``)
    are preferred when available; everything else (i8/i16, f16/bf16, …) falls
    back to ``DenseElementsAttr``.
    """
    values = list(init)
    if ir.IntegerType.isinstance(elem_ty):
        iw = ir.IntegerType(elem_ty).width
        int_vals = [_coerce_int(v) for v in values]
        if iw == 32:
            return ir.DenseI32ArrayAttr.get(int_vals)
        if iw == 64:
            return ir.DenseI64ArrayAttr.get(int_vals)
        shaped = ir.RankedTensorType.get([length], elem_ty)
        return ir.DenseElementsAttr.get(shaped, int_vals)
    if ir.F32Type.isinstance(elem_ty):
        return ir.DenseF32ArrayAttr.get([float(v) for v in values])
    if ir.F64Type.isinstance(elem_ty):
        return ir.DenseF64ArrayAttr.get([float(v) for v in values])
    # f16 / bf16 / others
    shaped = ir.RankedTensorType.get([length], elem_ty)
    return ir.DenseElementsAttr.get(shaped, [float(v) for v in values])


def _coerce_int(v):
    if isinstance(v, bool) or not isinstance(v, int):
        raise TypeError(
            f"alloc_array init value for integer dtype must be Python int, got {type(v).__name__}"
        )
    return v


def _to_index(idx):
    """Coerce Python int / DSL integer SSA value to an ``index``-typed SSA value."""
    from cannbotdsl._mlir.dialects import arith

    if isinstance(idx, bool):
        raise TypeError("Array index must be int or DSL integer, not bool")
    if isinstance(idx, int):
        return arith.ConstantOp(ir.IndexType.get(), idx).result
    if isinstance(idx, ir.Value):
        if ir.IndexType.isinstance(idx.type):
            return idx
        if ir.IntegerType.isinstance(idx.type):
            return arith.index_cast(ir.IndexType.get(), idx)
    raise TypeError(
        f"Array index must be int or DSL integer, got {type(idx).__name__}"
    )


def _to_elem(val, elem_ty):
    """Coerce a canonical scalar wrapper or literal to array storage."""

    from cannbotdsl.core.contracts.elements import coerce_scalar_to_storage

    return coerce_scalar_to_storage(val, elem_ty, path="Array value")
