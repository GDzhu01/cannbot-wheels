# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""C-compatible aggregate schemas shared by tracing, codegen, and ctypes.

``@datastruct`` turns an annotation-only Python class into a dual-mode type:

* outside tracing it creates a validated host value object;
* inside an ``@kernel`` body it emits a zero-initialized CANNIR aggregate and
  typed field stores.

The recursive :class:`_DataStructSchema` is deliberately independent from a
particular Python class.  It is the stable contract persisted in AOT sidecars
and is also used to rebuild equivalent ``ctypes.Structure`` classes after
``cannbotdsl.load``.
"""

from __future__ import annotations

import ctypes
import hashlib
import inspect
import json
import keyword
import re
from dataclasses import dataclass, field as dataclass_field
from typing import Any

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import cannir

from cannbotdsl.core.contracts.elements import aggregate_element_infos
from cannbotdsl.core.mlir_context import (
    _has_current_context,
    _has_current_insertion_point,
)
from cannbotdsl.types.dtypes import DType, _resolve_dtype


_CXX_KEYWORDS = {
    "alignas",
    "alignof",
    "and",
    "and_eq",
    "asm",
    "auto",
    "bitand",
    "bitor",
    "bool",
    "break",
    "case",
    "catch",
    "char",
    "char8_t",
    "char16_t",
    "char32_t",
    "class",
    "compl",
    "concept",
    "const",
    "consteval",
    "constexpr",
    "constinit",
    "const_cast",
    "continue",
    "co_await",
    "co_return",
    "co_yield",
    "decltype",
    "default",
    "delete",
    "do",
    "double",
    "dynamic_cast",
    "else",
    "enum",
    "explicit",
    "export",
    "extern",
    "false",
    "float",
    "for",
    "friend",
    "goto",
    "if",
    "inline",
    "int",
    "long",
    "mutable",
    "namespace",
    "new",
    "noexcept",
    "not",
    "not_eq",
    "nullptr",
    "operator",
    "or",
    "or_eq",
    "private",
    "protected",
    "public",
    "register",
    "reinterpret_cast",
    "requires",
    "return",
    "short",
    "signed",
    "sizeof",
    "static",
    "static_assert",
    "static_cast",
    "struct",
    "switch",
    "template",
    "this",
    "thread_local",
    "throw",
    "true",
    "try",
    "typedef",
    "typeid",
    "typename",
    "union",
    "unsigned",
    "using",
    "virtual",
    "void",
    "volatile",
    "wchar_t",
    "while",
    "xor",
    "xor_eq",
}
_IDENTIFIER_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")


def _safe_type_name(value) -> str:
    if inspect.isclass(value):
        return type.__getattribute__(value, "__name__")
    return type.__getattribute__(type(value), "__name__")


@dataclass(frozen=True)
class _ScalarFieldType:
    tag: str


@dataclass(frozen=True)
class _ArrayFieldType:
    element: _ScalarFieldType
    length: int


@dataclass(frozen=True)
class _DataStructField:
    name: str
    type: Any
    offset: int


@dataclass(frozen=True)
class _DataStructSchema:
    c_name: str
    fields: tuple[_DataStructField, ...]
    size: int
    alignment: int
    fingerprint: str

    def field(self, name: str) -> _DataStructField:
        for field in self.fields:
            if field.name == name:
                return field
        raise AttributeError(
            f"{self.c_name} has no datastruct field {name!r}; "
            f"available fields: {', '.join(f.name for f in self.fields)}"
        )


@dataclass(frozen=True)
class _CArrayAnnotation:
    element_type: DType
    length: int

    def __repr__(self) -> str:
        return f"CArray[{self.element_type!r}, {self.length}]"


class CArray:
    """Annotation-only fixed-size array used in a :func:`datastruct` field."""

    def __class_getitem__(cls, params):
        if type(params) is not tuple or len(params) != 2:
            raise TypeError("CArray expects exactly two parameters: CArray[dtype, length]")
        element_type, length = params
        resolved = _scalar_field_for_dtype(element_type)
        if resolved is None:
            raise TypeError(
                "CArray element type must be an ABI-safe datastruct scalar "
                f"({', '.join(map(repr, _SCALAR_BY_DTYPE))}), "
                f"got {_safe_type_name(element_type)}"
            )
        canonical, _ = resolved
        if type(length) is not int:
            raise TypeError(
                "CArray length must be a positive int, got "
                f"{_safe_type_name(length)}"
            )
        if length <= 0:
            raise ValueError(f"CArray length must be a positive int, got {length}")
        return _CArrayAnnotation(canonical, length)


_SCALAR_INFOS = {info.tag: info for info in aggregate_element_infos()}
_SCALAR_BY_DTYPE = {
    info.dtype: _ScalarFieldType(tag) for tag, info in _SCALAR_INFOS.items()
}


def _scalar_field_for_dtype(value):
    try:
        canonical = _resolve_dtype(value)
    except TypeError:
        return None
    for dtype, field_type in _SCALAR_BY_DTYPE.items():
        if canonical is dtype:
            return canonical, field_type
    return None


_SCALAR_BY_MLIR_TEXT = {
    info.mlir_element_name: _ScalarFieldType(tag)
    for tag, info in _SCALAR_INFOS.items()
}
# Accept explicit-signed spellings when decoding hand-written/older IR.  The
# canonical registry spelling for signed scalars remains signless ``iN``.
for _tag, _info in _SCALAR_INFOS.items():
    if _info.dtype.kind.value == "integer" and _info.dtype.signed:
        _SCALAR_BY_MLIR_TEXT[f"si{_info.dtype.bits}"] = _ScalarFieldType(_tag)
_SCALAR_BY_MLIR_TEXT.update(
    {
        "si1": _ScalarFieldType("bool"),
        "ui1": _ScalarFieldType("bool"),
    }
)

_CTYPE_CACHE: dict[str, type[ctypes.Structure]] = {}
_IR_SCHEMA_CACHE: dict[str, _DataStructSchema] = {}


def _validate_identifier(name: str, *, what: str) -> None:
    if (
        type(name) is not str
        or not _IDENTIFIER_RE.fullmatch(name)
        or keyword.iskeyword(name)
        or name in _CXX_KEYWORDS
    ):
        raise ValueError(
            f"{what} must be a non-keyword C identifier starting with a letter, "
            f"got {_safe_type_name(name) if type(name) is not str else name!r}"
        )


def _field_type_payload(field_type) -> dict:
    if isinstance(field_type, _ScalarFieldType):
        return {"kind": "scalar", "tag": field_type.tag}
    if isinstance(field_type, _ArrayFieldType):
        return {
            "kind": "array",
            "element": _field_type_payload(field_type.element),
            "length": field_type.length,
        }
    if isinstance(field_type, _DataStructSchema):
        return {"kind": "datastruct", "schema": _schema_payload(field_type)}
    raise TypeError(f"unknown datastruct field type {field_type!r}")


def _schema_payload(schema: _DataStructSchema) -> dict:
    return {
        "c_name": schema.c_name,
        "fields": [
            {
                "name": field.name,
                "type": _field_type_payload(field.type),
                "offset": field.offset,
            }
            for field in schema.fields
        ],
        "size": schema.size,
        "alignment": schema.alignment,
    }


def _fingerprint_payload(payload: dict) -> str:
    encoded = json.dumps(
        payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _ctype_for_field(field_type):
    if isinstance(field_type, _ScalarFieldType):
        return _SCALAR_INFOS[field_type.tag].aggregate_ctype
    if isinstance(field_type, _ArrayFieldType):
        return (
            _SCALAR_INFOS[field_type.element.tag].aggregate_ctype
            * field_type.length
        )
    if isinstance(field_type, _DataStructSchema):
        return _make_ctypes_struct(field_type)
    raise TypeError(f"unknown datastruct field type {field_type!r}")


def _build_schema(
    c_name: str, fields: list[tuple[str, Any]]
) -> _DataStructSchema:
    _validate_identifier(c_name, what="datastruct c_name")
    if not fields:
        raise TypeError("datastruct must declare at least one field")
    seen: set[str] = set()
    c_fields = []
    for name, field_type in fields:
        _validate_identifier(name, what="datastruct field name")
        if name in seen:
            raise TypeError(f"duplicate datastruct field {name!r}")
        seen.add(name)
        c_fields.append((name, _ctype_for_field(field_type)))

    layout_cls = type(
        f"_CANNBOTDSLLayout_{c_name}",
        (ctypes.Structure,),
        {"_fields_": c_fields},
    )
    schema_fields = tuple(
        _DataStructField(
            name=name,
            type=field_type,
            offset=getattr(layout_cls, name).offset,
        )
        for name, field_type in fields
    )
    provisional = _DataStructSchema(
        c_name=c_name,
        fields=schema_fields,
        size=ctypes.sizeof(layout_cls),
        alignment=ctypes.alignment(layout_cls),
        fingerprint="",
    )
    schema = _DataStructSchema(
        c_name=provisional.c_name,
        fields=provisional.fields,
        size=provisional.size,
        alignment=provisional.alignment,
        fingerprint=_fingerprint_payload(_schema_payload(provisional)),
    )
    _CTYPE_CACHE.setdefault(schema.fingerprint, layout_cls)
    return schema


@dataclass(frozen=True, slots=True)
class StructField:
    """One public logical datastruct field."""

    name: str
    dtype: Any
    type: Any = dataclass_field(init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "type", self.dtype)


def _public_field_type(value, *, path: str):
    scalar = _scalar_field_for_dtype(value)
    if scalar is not None:
        return scalar[1]
    if isinstance(value, _CArrayAnnotation):
        element = _scalar_field_for_dtype(value.element_type)
        if element is None:  # pragma: no cover - CArray construction invariant
            raise TypeError(f"{path} contains an unsupported CArray dtype")
        return _ArrayFieldType(element[1], value.length)
    if isinstance(value, StructSchema):
        return value._internal_schema
    nested = _schema_for_datastruct_class(value)
    if nested is not None:
        return nested
    raise TypeError(
        f"{path} uses unsupported StructField dtype {_safe_type_name(value)}; "
        "expected an "
        "ABI-safe canonical dtype, CArray, StructSchema, or @datastruct class"
    )


def _schema_for_datastruct_class(value):
    if not inspect.isclass(value):
        return None
    for owner in type.__getattribute__(value, "__mro__"):
        namespace = type.__getattribute__(owner, "__dict__")
        if "__cannbotdsl_datastruct_schema__" in namespace:
            candidate = namespace["__cannbotdsl_datastruct_schema__"]
            if type(candidate) is _DataStructSchema:
                return candidate
    return None


@dataclass(frozen=True, slots=True)
class StructSchema:
    """Immutable logical schema usable independently of a Python value class."""

    name: str
    fields: tuple[StructField, ...]
    _internal_schema: _DataStructSchema = dataclass_field(
        init=False, repr=False, compare=True
    )

    def __post_init__(self) -> None:
        try:
            fields = tuple(self.fields)
        except TypeError as exc:
            raise TypeError("StructSchema.fields must be an iterable") from exc
        if not all(isinstance(field, StructField) for field in fields):
            raise TypeError("StructSchema.fields must contain StructField values")
        object.__setattr__(self, "fields", fields)
        internal = _build_schema(
            self.name,
            [
                (
                    field.name,
                    _public_field_type(
                        field.dtype,
                        path=f"StructSchema({self.name!r}).{field.name}",
                    ),
                )
                for field in fields
            ],
        )
        object.__setattr__(self, "_internal_schema", internal)

    @property
    def fingerprint(self) -> str:
        return self._internal_schema.fingerprint

    @property
    def c_name(self) -> str:
        return self._internal_schema.c_name

    @property
    def size(self) -> int:
        return self._internal_schema.size

    @property
    def alignment(self) -> int:
        return self._internal_schema.alignment


class StructRef:
    """Annotation/AOT descriptor for one datastruct resident in device GM.

    ``StructRef[T]`` is a schema descriptor, not a host value and not an
    allocation API.  Runtime calls pass an exact-size provider-owned NPU
    ``uint8`` tensor containing the naturally laid-out bytes for ``T``.
    """

    __slots__ = ("schema", "address_space", "access", "_display_name")

    def __new__(cls, *args, **kwargs):
        del args, kwargs
        raise TypeError(
            "StructRef is annotation-only; use StructRef[DataStructType]"
        )

    @classmethod
    def __class_getitem__(cls, parameter):
        if type(parameter) is tuple:
            raise TypeError("StructRef expects exactly one @datastruct type")
        schema = _schema_for_datastruct_class(parameter)
        if schema is None:
            raise TypeError(
                "StructRef expects an @datastruct class, got "
                f"{_safe_type_name(parameter)}"
            )
        display_name = type.__getattribute__(parameter, "__qualname__")
        return _struct_ref_from_schema(schema, display_name=display_name)

    def __setattr__(self, name, value) -> None:
        del name, value
        raise AttributeError("StructRef descriptors are immutable")

    def __hash__(self) -> int:
        return hash((self.schema.fingerprint, self.address_space, self.access))

    def __eq__(self, other) -> bool:
        return (
            type(other) is StructRef
            and self.schema.fingerprint == other.schema.fingerprint
            and self.address_space == other.address_space
            and self.access == other.access
        )

    def __repr__(self) -> str:
        return f"StructRef[{self._display_name}]"


def _struct_ref_from_schema(
    schema: _DataStructSchema,
    *,
    address_space: str = "GM",
    access: str = "readwrite",
    display_name: str | None = None,
) -> StructRef:
    if type(schema) is not _DataStructSchema:
        raise TypeError("StructRef requires an internal datastruct schema")
    if address_space != "GM":
        raise ValueError("StructRef address_space must be 'GM'")
    if access != "readwrite":
        raise ValueError("StructRef access must be 'readwrite'")
    result = object.__new__(StructRef)
    object.__setattr__(result, "schema", schema)
    object.__setattr__(result, "address_space", address_space)
    object.__setattr__(result, "access", access)
    object.__setattr__(result, "_display_name", display_name or schema.c_name)
    return result


def _schema_to_dict(schema: _DataStructSchema) -> dict:
    result = _schema_payload(schema)
    result["fingerprint"] = schema.fingerprint
    return result


def _field_type_from_dict(data: dict):
    kind = data.get("kind")
    if kind == "scalar":
        tag = data.get("tag")
        if tag not in _SCALAR_INFOS:
            raise ValueError(f"unknown datastruct scalar tag {tag!r}")
        return _ScalarFieldType(tag)
    if kind == "array":
        element = _field_type_from_dict(data.get("element", {}))
        if not isinstance(element, _ScalarFieldType):
            raise ValueError("datastruct arrays must contain scalar elements")
        length = data.get("length")
        if isinstance(length, bool) or not isinstance(length, int) or length <= 0:
            raise ValueError(f"invalid datastruct array length {length!r}")
        return _ArrayFieldType(element, length)
    if kind == "datastruct":
        return _schema_from_dict(data.get("schema", {}))
    raise ValueError(f"unknown datastruct field kind {kind!r}")


def _schema_from_dict(data: dict) -> _DataStructSchema:
    try:
        c_name = data["c_name"]
        raw_fields = data["fields"]
    except (KeyError, TypeError) as exc:
        raise ValueError("malformed datastruct schema") from exc
    if not isinstance(raw_fields, list):
        raise ValueError("datastruct schema fields must be a list")
    fields = []
    for raw_field in raw_fields:
        try:
            fields.append(
                (
                    raw_field["name"],
                    _field_type_from_dict(raw_field["type"]),
                )
            )
        except (KeyError, TypeError) as exc:
            raise ValueError("malformed datastruct field schema") from exc
    schema = _build_schema(c_name, fields)
    encoded_offsets = tuple(field.get("offset") for field in raw_fields)
    expected_offsets = tuple(field.offset for field in schema.fields)
    if encoded_offsets != expected_offsets:
        raise ValueError(
            f"datastruct {c_name} field offsets {encoded_offsets} do not match "
            f"native ABI offsets {expected_offsets}"
        )
    if data.get("size") != schema.size or data.get("alignment") != schema.alignment:
        raise ValueError(
            f"datastruct {c_name} size/alignment do not match the native ABI"
        )
    encoded_fingerprint = data.get("fingerprint")
    if encoded_fingerprint is not None and encoded_fingerprint != schema.fingerprint:
        raise ValueError(f"datastruct {c_name} schema fingerprint mismatch")
    return schema


def _make_ctypes_struct(
    schema: _DataStructSchema,
) -> type[ctypes.Structure]:
    cached = _CTYPE_CACHE.get(schema.fingerprint)
    if cached is not None:
        return cached
    cls = type(
        f"CANNBOTDSL_{schema.c_name}_{schema.fingerprint[:12]}",
        (ctypes.Structure,),
        {
            "_fields_": [
                (field.name, _ctype_for_field(field.type))
                for field in schema.fields
            ]
        },
    )
    actual_offsets = tuple(getattr(cls, field.name).offset for field in schema.fields)
    expected_offsets = tuple(field.offset for field in schema.fields)
    if (
        ctypes.sizeof(cls) != schema.size
        or ctypes.alignment(cls) != schema.alignment
        or actual_offsets != expected_offsets
    ):
        raise ValueError(
            f"ctypes layout for {schema.c_name} does not match its persisted ABI schema"
        )
    _CTYPE_CACHE[schema.fingerprint] = cls
    return cls


def _normalize_scalar(field_type: _ScalarFieldType, value, *, path: str):
    info = _SCALAR_INFOS[field_type.tag]
    if info.scalar_kind == "bool":
        if type(value) is not bool:
            raise TypeError(f"{path} expects bool, got {type(value).__name__}")
        return value
    if info.scalar_kind == "float":
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError(f"{path} expects int or float, got {type(value).__name__}")
        return float(value)
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{path} expects int, got {type(value).__name__}")
    if value < info.scalar_minimum or value > info.scalar_maximum:
        raise ValueError(
            f"{path}={value} is outside {field_type.tag} range "
            f"[{info.scalar_minimum}, {info.scalar_maximum}]"
        )
    return value


def _schema_for_value(value) -> _DataStructSchema | None:
    return _schema_for_datastruct_class(type(value))


def _normalize_host_value(field_type, value, *, path: str):
    if isinstance(field_type, _ScalarFieldType):
        return _normalize_scalar(field_type, value, path=path)
    if isinstance(field_type, _ArrayFieldType):
        if not isinstance(value, (list, tuple)):
            raise TypeError(f"{path} expects list/tuple, got {type(value).__name__}")
        if len(value) != field_type.length:
            raise ValueError(
                f"{path} length {len(value)} != declared length {field_type.length}"
            )
        return tuple(
            _normalize_scalar(field_type.element, element, path=f"{path}[{index}]")
            for index, element in enumerate(value)
        )
    if isinstance(field_type, _DataStructSchema):
        actual = _schema_for_value(value)
        if actual is None:
            raise TypeError(
                f"{path} expects a @datastruct value with schema "
                f"{field_type.c_name}, got {type(value).__name__}"
            )
        if actual.fingerprint != field_type.fingerprint:
            raise TypeError(
                f"{path} schema {actual.c_name}/{actual.fingerprint[:12]} does "
                f"not match {field_type.c_name}/{field_type.fingerprint[:12]}"
            )
        _validate_datastruct_value(value, field_type, path=path)
        return value
    raise TypeError(f"unknown datastruct field type {field_type!r}")


def _validate_datastruct_value(
    value, schema: _DataStructSchema, *, path: str = "argument"
) -> None:
    actual = _schema_for_value(value)
    if actual is None or actual.fingerprint != schema.fingerprint:
        got = (
            type(value).__name__
            if actual is None
            else f"{actual.c_name}/{actual.fingerprint[:12]}"
        )
        raise TypeError(
            f"{path} expects datastruct {schema.c_name}/"
            f"{schema.fingerprint[:12]}, got {got}"
        )
    for field in schema.fields:
        _normalize_host_value(
            field.type, getattr(value, field.name), path=f"{path}.{field.name}"
        )


def _marshal_datastruct(
    value, schema: _DataStructSchema
) -> ctypes.Structure:
    _validate_datastruct_value(value, schema)
    struct_cls = _make_ctypes_struct(schema)
    result = struct_cls()
    for field in schema.fields:
        raw = getattr(value, field.name)
        if isinstance(field.type, _DataStructSchema):
            setattr(result, field.name, _marshal_datastruct(raw, field.type))
        elif isinstance(field.type, _ArrayFieldType):
            array_cls = _ctype_for_field(field.type)
            setattr(result, field.name, array_cls(*raw))
        else:
            setattr(result, field.name, raw)
    return result


def _annotation_to_field_type(annotation, *, path: str):
    scalar = _scalar_field_for_dtype(annotation)
    if scalar is not None:
        return scalar[1]
    if isinstance(annotation, _CArrayAnnotation):
        element = _scalar_field_for_dtype(annotation.element_type)
        if element is None:  # pragma: no cover - CArray construction invariant
            raise TypeError(f"{path} contains an unsupported CArray dtype")
        return _ArrayFieldType(element[1], annotation.length)
    nested = _schema_for_datastruct_class(annotation)
    if nested is not None:
        return nested
    raise TypeError(
        f"{path} uses unsupported datastruct field annotation "
        f"{_safe_type_name(annotation)}; "
        "expected an ABI-safe scalar, CArray[scalar, N], or another "
        "@datastruct class"
    )


def _field_mlir_type(field_type):
    if isinstance(field_type, _ScalarFieldType):
        return _SCALAR_INFOS[field_type.tag].dsl_type.mlir_type()
    if isinstance(field_type, _ArrayFieldType):
        return cannir.ArrayType.get(
            field_type.length, _field_mlir_type(field_type.element)
        )
    if isinstance(field_type, _DataStructSchema):
        return _schema_mlir_type(field_type)
    raise TypeError(f"unknown datastruct field type {field_type!r}")


def _schema_mlir_type(schema: _DataStructSchema):
    result = cannir.DataStructType.get(
        schema.c_name,
        [field.name for field in schema.fields],
        [_field_mlir_type(field.type) for field in schema.fields],
        [field.offset for field in schema.fields],
        schema.size,
        schema.alignment,
    )
    _IR_SCHEMA_CACHE[str(result)] = schema
    return result


def _schema_ref_mlir_type(
    schema: _DataStructSchema,
    *,
    address_space: str = "GM",
    access: str = "readwrite",
):
    if address_space != "GM":
        raise ValueError("StructRef address_space must be 'GM'")
    if access != "readwrite":
        raise ValueError("StructRef access must be 'readwrite'")
    return cannir.DataStructRefType.get(
        _schema_mlir_type(schema),
        address_space=0,
        access=0,
    )


def _field_type_from_ir(mlir_type):
    scalar = _SCALAR_BY_MLIR_TEXT.get(str(mlir_type))
    if scalar is not None:
        return scalar
    if cannir.ArrayType.isinstance(mlir_type):
        array_type = cannir.ArrayType(mlir_type)
        element = _field_type_from_ir(array_type.element_type)
        if not isinstance(element, _ScalarFieldType):
            raise TypeError("datastruct IR arrays must contain scalar elements")
        return _ArrayFieldType(element, array_type.length)
    if cannir.DataStructType.isinstance(mlir_type):
        return _schema_from_ir_type(cannir.DataStructType(mlir_type))
    raise TypeError(f"unsupported datastruct IR field type {mlir_type}")


def _schema_from_ir_type(mlir_type) -> _DataStructSchema:
    key = str(mlir_type)
    cached = _IR_SCHEMA_CACHE.get(key)
    if cached is not None:
        return cached
    fields = [
        (name, _field_type_from_ir(field_type))
        for name, field_type in zip(mlir_type.field_names, mlir_type.field_types)
    ]
    schema = _build_schema(mlir_type.c_name, fields)
    if (
        tuple(field.offset for field in schema.fields)
        != tuple(mlir_type.field_offsets)
        or schema.size != mlir_type.size
        or schema.alignment != mlir_type.alignment
    ):
        raise TypeError(
            f"IR datastruct {mlir_type.c_name} layout does not match Python ABI"
        )
    _IR_SCHEMA_CACHE[key] = schema
    return schema


def _to_ir_scalar(field_type: _ScalarFieldType, value, *, path: str):
    from cannbotdsl.core.contracts.elements import coerce_scalar_to_storage

    target_type = _field_mlir_type(field_type)
    normalized = (
        value
        if isinstance(value, ir.Value)
        else _normalize_scalar(field_type, value, path=path)
    )
    return coerce_scalar_to_storage(normalized, target_type, path=path)


def _materialize_nested(
    value, schema: _DataStructSchema, *, path: str
) -> "_DataStructValue":
    if isinstance(value, _DataStructValue):
        actual = value.schema
        if actual.fingerprint != schema.fingerprint:
            raise TypeError(
                f"{path} expects {schema.c_name}/{schema.fingerprint[:12]}, "
                f"got {actual.c_name}/{actual.fingerprint[:12]}"
            )
        return value
    actual = _schema_for_value(value)
    if actual is None or actual.fingerprint != schema.fingerprint:
        raise TypeError(f"{path} expects a matching datastruct value")
    kwargs = {field.name: getattr(value, field.name) for field in schema.fields}
    return _construct_ir_value(schema, (), kwargs)


def _store_ir_field(
    target: "_DataStructValue", field: _DataStructField, value, *, path: str
) -> None:
    if isinstance(field.type, _ScalarFieldType):
        cannir.datastruct_set(
            _to_ir_scalar(field.type, value, path=path),
            target,
            field=field.name,
        )
        return
    if isinstance(field.type, _DataStructSchema):
        cannir.datastruct_set(
            _materialize_nested(value, field.type, path=path),
            target,
            field=field.name,
        )
        return
    if isinstance(field.type, _ArrayFieldType):
        if not isinstance(value, (list, tuple)):
            raise TypeError(f"{path} expects list/tuple, got {type(value).__name__}")
        if len(value) != field.type.length:
            raise ValueError(
                f"{path} length {len(value)} != declared length {field.type.length}"
            )
        array_view = cannir.datastruct_get(target, field=field.name)
        for index, element in enumerate(value):
            array_view[index] = element
        return
    raise TypeError(f"unknown datastruct field type {field.type!r}")


def _construct_ir_value(schema: _DataStructSchema, args, kwargs):
    _forbid_in_raw_vf("construct")
    if args:
        raise TypeError(
            f"{schema.c_name} datastruct construction is keyword-only"
        )
    expected = {field.name for field in schema.fields}
    missing = [field.name for field in schema.fields if field.name not in kwargs]
    extra = sorted(set(kwargs) - expected)
    if missing or extra:
        details = []
        if missing:
            details.append(f"missing fields: {', '.join(missing)}")
        if extra:
            details.append(f"unexpected fields: {', '.join(extra)}")
        raise TypeError(f"{schema.c_name} constructor " + "; ".join(details))
    result = cannir.datastruct_alloc(_schema_mlir_type(schema))
    for field in schema.fields:
        _store_ir_field(
            result,
            field,
            kwargs[field.name],
            path=f"{schema.c_name}.{field.name}",
        )
    return result


def _is_kernel_trace() -> bool:
    if not _has_current_context() or not _has_current_insertion_point():
        return False
    from cannbotdsl.lang.kernel import _IN_KERNEL_BODY

    return _IN_KERNEL_BODY.get()


def _is_active_ir_trace() -> bool:
    return _has_current_context() and _has_current_insertion_point()


def _require_kernel_access(action: str) -> None:
    from cannbotdsl.lang.kernel import _IN_KERNEL_BODY

    if not _IN_KERNEL_BODY.get():
        raise RuntimeError(
            f"datastruct field {action} is only supported inside an @kernel "
            "body; @jit may receive and forward datastruct values"
        )


def _forbid_in_raw_vf(action: str) -> None:
    from cannbotdsl.lang.vf import _current_vf_mode

    if _current_vf_mode() == "raw":
        raise RuntimeError(
            f"datastruct field {action} is not supported inside "
            "`with cannbotdsl.lang.vf(mode='raw'):`; extract scalar fields before "
            "entering the raw VF region"
        )


@ir.register_value_caster(cannir.DataStructType.get_static_typeid())
class _DataStructValue(ir.Value):
    def __init__(self, value):
        super().__init__(value)

    @property
    def schema(self) -> _DataStructSchema:
        return _schema_from_ir_type(cannir.DataStructType(self.type))

    def __getattr__(self, name: str):
        try:
            field = self.schema.field(name)
        except AttributeError:
            raise AttributeError(name) from None
        _require_kernel_access("read")
        _forbid_in_raw_vf("read")
        value = cannir.datastruct_get(self, field=name)
        if isinstance(field.type, _ScalarFieldType):
            from cannbotdsl.core.contracts.elements import wrap_produced_scalar

            return wrap_produced_scalar(
                value, storage_type=_field_mlir_type(field.type)
            )
        return value

    def __setattr__(self, name: str, value) -> None:
        try:
            field = self.schema.field(name)
        except AttributeError:
            try:
                return super().__setattr__(name, value)
            except AttributeError:
                raise AttributeError(name) from None
        _require_kernel_access("write")
        _forbid_in_raw_vf("write")
        _store_ir_field(
            self, field, value, path=f"{self.schema.c_name}.{field.name}"
        )


def _ref_path_attr(path: tuple[str, ...]):
    return ir.ArrayAttr.get([ir.StringAttr.get(name) for name in path])


def _load_ref_scalar(root, field_type, path, *, index=None):
    _require_kernel_access("read")
    _forbid_in_raw_vf("read")
    value = cannir.datastruct_ref_load(
        root,
        _ref_path_attr(path),
        index=index,
    )
    from cannbotdsl.core.contracts.elements import wrap_produced_scalar

    return wrap_produced_scalar(value, storage_type=_field_mlir_type(field_type))


def _store_ref_scalar(root, field_type, path, value, *, index=None):
    _require_kernel_access("write")
    _forbid_in_raw_vf("write")
    cannir.datastruct_ref_store(
        _to_ir_scalar(field_type, value, path=".".join(path)),
        root,
        _ref_path_attr(path),
        index=index,
    )


class _DataStructRefArrayPath:
    __slots__ = ("_root", "_field_type", "_path")

    def __init__(self, root, field_type, path):
        object.__setattr__(self, "_root", root)
        object.__setattr__(self, "_field_type", field_type)
        object.__setattr__(self, "_path", path)

    def _index(self, index):
        from cannbotdsl.types.array import _to_index

        if type(index) is int and not 0 <= index < self._field_type.length:
            raise IndexError(
                f"StructRef field {'.'.join(self._path)} index {index} is "
                f"outside [0, {self._field_type.length})"
            )
        return _to_index(index)

    def __getitem__(self, index):
        return _load_ref_scalar(
            self._root,
            self._field_type.element,
            self._path,
            index=self._index(index),
        )

    def __setitem__(self, index, value) -> None:
        _store_ref_scalar(
            self._root,
            self._field_type.element,
            self._path,
            value,
            index=self._index(index),
        )

    def __len__(self) -> int:
        return self._field_type.length

    def _reject_aggregate_operation(self, operation: str):
        raise TypeError(
            f"StructRef array field {'.'.join(self._path)} cannot be used in "
            f"{operation}; select a scalar array element"
        )

    def __bool__(self):
        self._reject_aggregate_operation("a boolean context")

    def __eq__(self, other):
        del other
        self._reject_aggregate_operation("an aggregate comparison")

    __ne__ = __eq__
    __lt__ = __eq__
    __le__ = __eq__
    __gt__ = __eq__
    __ge__ = __eq__


class _DataStructRefPath:
    __slots__ = ("_root", "_schema", "_path")

    def __init__(self, root, schema, path):
        object.__setattr__(self, "_root", root)
        object.__setattr__(self, "_schema", schema)
        object.__setattr__(self, "_path", path)

    def __getattr__(self, name: str):
        try:
            field = self._schema.field(name)
        except AttributeError:
            raise AttributeError(name) from None
        path = (*self._path, name)
        if isinstance(field.type, _ScalarFieldType):
            return _load_ref_scalar(self._root, field.type, path)
        if isinstance(field.type, _DataStructSchema):
            return _DataStructRefPath(self._root, field.type, path)
        if isinstance(field.type, _ArrayFieldType):
            return _DataStructRefArrayPath(self._root, field.type, path)
        raise TypeError(f"unknown datastruct field type {field.type!r}")

    def __setattr__(self, name: str, value) -> None:
        if name.startswith("_"):
            object.__setattr__(self, name, value)
            return
        try:
            field = self._schema.field(name)
        except AttributeError:
            raise AttributeError(name) from None
        path = (*self._path, name)
        if not isinstance(field.type, _ScalarFieldType):
            kind = "nested struct" if isinstance(field.type, _DataStructSchema) else "array"
            raise TypeError(
                f"StructRef whole-{kind} assignment is not supported for "
                f"{'.'.join(path)}; assign scalar fields or array elements"
            )
        _store_ref_scalar(self._root, field.type, path, value)

    def _reject_aggregate_operation(self, operation: str):
        path = ".".join(self._path) or self._schema.c_name
        raise TypeError(
            f"StructRef nested field {path} cannot be used in {operation}; "
            "select a scalar field"
        )

    def __bool__(self):
        self._reject_aggregate_operation("a boolean context")

    def __eq__(self, other):
        del other
        self._reject_aggregate_operation("an aggregate comparison")

    __ne__ = __eq__
    __lt__ = __eq__
    __le__ = __eq__
    __gt__ = __eq__
    __ge__ = __eq__


@ir.register_value_caster(cannir.DataStructRefType.get_static_typeid())
class _DataStructRefValue(ir.Value):
    def __init__(self, value):
        super().__init__(value)

    @property
    def schema(self) -> _DataStructSchema:
        ref_type = cannir.DataStructRefType(self.type)
        return _schema_from_ir_type(cannir.DataStructType(ref_type.schema))

    def __getattr__(self, name: str):
        return getattr(_DataStructRefPath(self, self.schema, ()), name)

    def __setattr__(self, name: str, value) -> None:
        try:
            self.schema.field(name)
        except (AttributeError, TypeError):
            try:
                return super().__setattr__(name, value)
            except AttributeError:
                raise AttributeError(name) from None
        setattr(_DataStructRefPath(self, self.schema, ()), name, value)


class _DataStructMeta(type):
    def __call__(cls, *args, **kwargs):
        schema = cls.__cannbotdsl_datastruct_schema__
        if _is_kernel_trace():
            return _construct_ir_value(schema, args, kwargs)
        if _is_active_ir_trace():
            raise RuntimeError(
                "datastruct IR construction is only supported inside an "
                "@kernel body; @jit may receive and forward datastruct values"
            )
        return super().__call__(*args, **kwargs)


class _DataStructHostValue(metaclass=_DataStructMeta):
    __slots__ = ()

    def __init__(self, *args, **kwargs):
        schema = type(self).__cannbotdsl_datastruct_schema__
        if args:
            raise TypeError(
                f"{schema.c_name} datastruct construction is keyword-only"
            )
        expected = {field.name for field in schema.fields}
        missing = [field.name for field in schema.fields if field.name not in kwargs]
        extra = sorted(set(kwargs) - expected)
        if missing or extra:
            details = []
            if missing:
                details.append(f"missing fields: {', '.join(missing)}")
            if extra:
                details.append(f"unexpected fields: {', '.join(extra)}")
            raise TypeError(f"{schema.c_name} constructor " + "; ".join(details))
        for field in schema.fields:
            object.__setattr__(
                self,
                field.name,
                _normalize_host_value(
                    field.type,
                    kwargs[field.name],
                    path=f"{schema.c_name}.{field.name}",
                ),
            )

    def __setattr__(self, name: str, value) -> None:
        schema = type(self).__cannbotdsl_datastruct_schema__
        field = schema.field(name)
        object.__setattr__(
            self,
            name,
            _normalize_host_value(
                field.type, value, path=f"{schema.c_name}.{field.name}"
            ),
        )

    def __repr__(self) -> str:
        schema = type(self).__cannbotdsl_datastruct_schema__
        values = ", ".join(
            f"{field.name}={getattr(self, field.name)!r}" for field in schema.fields
        )
        return f"{type(self).__name__}({values})"

    def __eq__(self, other) -> bool:
        schema = type(self).__cannbotdsl_datastruct_schema__
        other_schema = _schema_for_value(other)
        return (
            other_schema is not None
            and other_schema.fingerprint == schema.fingerprint
            and all(
                getattr(self, field.name) == getattr(other, field.name)
                for field in schema.fields
            )
        )


def _decorate_datastruct(
    cls: type,
    *,
    c_name: str | None,
    schema: StructSchema | None,
):
    # Imported lazily: ``cannbotdsl.core.contracts.surface`` imports
    # ``cannbotdsl.lang.spec``, which runs this package's ``__init__``.  A
    # module-level import here would close that cycle at import time.
    from cannbotdsl.core.contracts.surface import SurfaceTypeResolver

    if not inspect.isclass(cls):
        raise TypeError(f"@datastruct expects a class, got {_safe_type_name(cls)}")
    if type.__getattribute__(cls, "__bases__") != (object,):
        raise TypeError("@datastruct classes cannot inherit from another class")

    source_namespace = type.__getattribute__(cls, "__dict__")
    raw_annotations = source_namespace.get("__annotations__", {})
    if type(raw_annotations) is not dict:
        raise TypeError("@datastruct __annotations__ must be a plain dict")
    if not raw_annotations:
        raise TypeError("@datastruct class must declare at least one field")
    for field_name in raw_annotations:
        if field_name in source_namespace:
            raise TypeError(
                f"@datastruct field {field_name!r} cannot define a default value"
            )

    allowed = {
        "__module__",
        "__qualname__",
        "__doc__",
        "__annotations__",
        "__dict__",
        "__weakref__",
    }
    extras = sorted(name for name in source_namespace if name not in allowed)
    if extras:
        raise TypeError(
            "@datastruct class bodies may only contain field annotations and "
            f"a docstring; unsupported members: {', '.join(extras)}"
        )

    if schema is not None:
        if not isinstance(schema, StructSchema):
            raise TypeError(
                f"datastruct schema must be StructSchema, got {type(schema).__name__}"
            )
        if c_name is not None:
            raise TypeError("@datastruct cannot specify both schema= and c_name=")
        expected_names = tuple(field.name for field in schema.fields)
        annotation_names = tuple(raw_annotations)
        if annotation_names != expected_names:
            qualname = type.__getattribute__(cls, "__qualname__")
            raise TypeError(
                f"@datastruct {qualname} annotations {annotation_names!r} "
                f"do not match StructSchema fields {expected_names!r}"
            )
        resolved = dict(raw_annotations)
        internal_schema = schema._internal_schema
    else:
        localns = dict(source_namespace)
        qualname = type.__getattribute__(cls, "__qualname__")
        resolver = SurfaceTypeResolver.for_target(
            cls,
            localns=localns,
            annotations=raw_annotations,
        )
        resolved = {
            name: resolver.required_annotation(
                name,
                subject=f"datastruct field {qualname}.{name}",
            )
            for name in raw_annotations
        }

        fields = [
            (
                name,
                _annotation_to_field_type(
                    resolved[name], path=f"{qualname}.{name}"
                ),
            )
            for name in raw_annotations
        ]
        internal_schema = _build_schema(
            c_name or type.__getattribute__(cls, "__name__"), fields
        )

    namespace = {
        "__module__": type.__getattribute__(cls, "__module__"),
        "__qualname__": type.__getattribute__(cls, "__qualname__"),
        "__doc__": type.__getattribute__(cls, "__doc__"),
        "__annotations__": dict(resolved),
        "__slots__": tuple(field.name for field in internal_schema.fields),
        "__cannbotdsl_datastruct_schema__": internal_schema,
        "__cannbotdsl_struct_schema__": schema,
        "mlir_type": classmethod(
            lambda owner: _schema_mlir_type(
                owner.__cannbotdsl_datastruct_schema__
            )
        ),
    }
    generated = _DataStructMeta(
        type.__getattribute__(cls, "__name__"),
        (_DataStructHostValue,),
        namespace,
    )
    generated.__wrapped__ = cls
    return generated


def datastruct(
    cls=None,
    *,
    c_name: str | None = None,
    schema: StructSchema | None = None,
):
    """Describe a naturally-aligned C struct using Python annotations."""

    if cls is None:
        return lambda target: _decorate_datastruct(
            target, c_name=c_name, schema=schema
        )
    return _decorate_datastruct(cls, c_name=c_name, schema=schema)


__all__ = ["CArray", "StructField", "StructRef", "StructSchema", "datastruct"]
