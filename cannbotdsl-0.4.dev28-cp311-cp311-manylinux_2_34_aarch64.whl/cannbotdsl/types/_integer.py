# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Internal fixed-width DSL integer SSA wrappers.

Python integers used alongside one of these values are contextual literals.
Two already-resolved dynamic values must have exactly the same MLIR type;
public explicit conversion uses ``dtypes.int32(value)`` or
``dtypes.uint32(value)``.  Concrete wrapper constructors are implementation
details used at scalar producer and lowering boundaries.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import cannbotdsl._mlir.ir as ir
from cannbotdsl._mlir.dialects import arith
from cannbotdsl.types import dtypes as _dtypes

from cannbotdsl.core.scalar_conversion import (
    cast_value,
    materialize_literal,
    require_same_dynamic_type,
)
from cannbotdsl.core.diag.diagnostics import (
    CANNBotTypeError,
    CANNBotValueError,
    TS101_INVALID_SCALAR_LITERAL,
)

if TYPE_CHECKING:
    from cannbotdsl.types.dtypes import DType


def _is_unsigned(value: object) -> bool:
    """Return the semantic signedness of an SSA wrapper or an MLIR type.

    MLIR's ``arith`` scalar operations require signless integer operands.  The
    public UInt wrappers therefore carry signedness as frontend information;
    tensor/vector element types can still use MLIR's ``uiN`` spelling.
    """

    if bool(getattr(value, "unsigned", False)):
        return True
    value_type = getattr(value, "type", value)
    return isinstance(value_type, ir.IntegerType) and value_type.is_unsigned


@ir.register_value_caster(ir.IntegerType.static_typeid)
class Integer(ir.Value):
    """An SSA integer whose arithmetic semantics come from its MLIR type."""

    _dtype: "DType"

    def __init__(self, value, *, loc=None, ip=None):
        del loc, ip
        if not isinstance(value, ir.Value) or not isinstance(value.type, ir.IntegerType):
            actual = getattr(value, "type", type(value).__name__)
            raise TypeError(f"Integer requires an integer SSA value, got {actual}")
        super().__init__(value)

    @property
    def dtype(self) -> "DType":
        """Return the canonical semantic dtype of this concrete wrapper."""

        return type(self)._dtype

    def _require_arithmetic(self, operation: str) -> None:
        if self.type.width == 1:
            raise TypeError(
                f"Boolean/i1 does not support integer {operation}; use boolean operators or an explicit integer cast"
            )

    def _cast_literal_or_check(self, other, *, operation: str, loc=None, ip=None):
        if type(other) is int:
            return materialize_literal(
                other,
                self.type,
                semantic_unsigned=_is_unsigned(self),
                loc=loc,
                ip=ip,
            )
        if not isinstance(other, ir.Value):
            raise TypeError(f"{operation} expects an integer DSL value or int literal, got {type(other).__name__}")
        if not isinstance(other.type, ir.IntegerType):
            raise TypeError(f"{operation} expects integer operands, got {self.type} and {other.type}")
        require_same_dynamic_type(self, other, operation=operation)
        if _is_unsigned(self) != _is_unsigned(other):
            raise TypeError(f"{operation} operands have different resolved signedness; cast one operand explicitly")
        return other

    def _binary(self, other, signed_op, unsigned_op, *, operation, loc=None, ip=None):
        self._require_arithmetic(operation)
        other = self._cast_literal_or_check(other, operation=operation, loc=loc, ip=ip)
        operation_builder = unsigned_op if _is_unsigned(self) else signed_op
        result = operation_builder(self, other, loc=loc, ip=ip)
        return type(self)(result, loc=loc, ip=ip)

    def _reverse_binary(self, other, signed_op, unsigned_op, *, operation, loc=None, ip=None):
        self._require_arithmetic(operation)
        other = self._cast_literal_or_check(other, operation=operation, loc=loc, ip=ip)
        operation_builder = unsigned_op if _is_unsigned(self) else signed_op
        result = operation_builder(other, self, loc=loc, ip=ip)
        return type(self)(result, loc=loc, ip=ip)

    def __add__(self, other, *, loc=None, ip=None):
        self._require_arithmetic("addition")
        other = self._cast_literal_or_check(other, operation="addition", loc=loc, ip=ip)
        return type(self)(arith.addi(self, other, loc=loc, ip=ip), loc=loc, ip=ip)

    def __sub__(self, other, *, loc=None, ip=None):
        self._require_arithmetic("subtraction")
        other = self._cast_literal_or_check(other, operation="subtraction", loc=loc, ip=ip)
        return type(self)(arith.subi(self, other, loc=loc, ip=ip), loc=loc, ip=ip)

    def __mul__(self, other, *, loc=None, ip=None):
        self._require_arithmetic("multiplication")
        other = self._cast_literal_or_check(other, operation="multiplication", loc=loc, ip=ip)
        return type(self)(arith.muli(self, other, loc=loc, ip=ip), loc=loc, ip=ip)

    def __truediv__(self, other, *, loc=None, ip=None):
        return self._binary(
            other,
            arith.divsi,
            arith.divui,
            operation="division",
            loc=loc,
            ip=ip,
        )

    def __floordiv__(self, other, *, loc=None, ip=None):
        # Fixed-width DSL integer division truncates toward zero for signed
        # values.  ``/`` is retained as a compatibility spelling for the same
        # operation; neither spelling adopts Python's unbounded arithmetic.
        return self._binary(
            other,
            arith.divsi,
            arith.divui,
            operation="floor division",
            loc=loc,
            ip=ip,
        )

    def __mod__(self, other, *, loc=None, ip=None):
        return self._binary(
            other,
            arith.remsi,
            arith.remui,
            operation="remainder",
            loc=loc,
            ip=ip,
        )

    def __xor__(self, other, *, loc=None, ip=None):
        if self.type.width == 1:
            if type(other) is bool:
                other = materialize_literal(other, self.type, loc=loc, ip=ip)
            elif isinstance(other, ir.Value):
                require_same_dynamic_type(self, other, operation="boolean xor")
            else:
                raise TypeError("Boolean xor expects a bool literal or Boolean/i1 value")
        else:
            other = self._cast_literal_or_check(other, operation="xor", loc=loc, ip=ip)
        result = arith.xori(self, other, loc=loc, ip=ip)
        if self.type.width == 1:
            return Boolean(result, loc=loc, ip=ip)
        return type(self)(result, loc=loc, ip=ip)

    def __neg__(self, *, loc=None, ip=None):
        self._require_arithmetic("negation")
        if _is_unsigned(self):
            raise TypeError("unsigned integers do not support unary negation")
        zero = materialize_literal(0, self.type, loc=loc, ip=ip)
        return type(self)(arith.subi(zero, self, loc=loc, ip=ip), loc=loc, ip=ip)

    def __invert__(self, *, loc=None, ip=None):
        if self.type.width == 1:
            one = materialize_literal(True, self.type, loc=loc, ip=ip)
            return Boolean(arith.xori(self, one, loc=loc, ip=ip), loc=loc, ip=ip)
        all_ones = materialize_literal(
            (1 << self.type.width) - 1 if _is_unsigned(self) else -1,
            self.type,
            semantic_unsigned=_is_unsigned(self),
            loc=loc,
            ip=ip,
        )
        return type(self)(arith.xori(self, all_ones, loc=loc, ip=ip), loc=loc, ip=ip)

    def _compare(
        self,
        other,
        signed_predicate,
        unsigned_predicate,
        *,
        operation,
        loc=None,
        ip=None,
    ):
        if self.type.width == 1 and type(other) in {bool, int}:
            if type(other) is int and other not in {0, 1}:
                raise CANNBotValueError(
                    TS101_INVALID_SCALAR_LITERAL,
                    "Boolean comparison literal must be True, False, 0, or "
                    f"1; got {other}.",
                    phase="type-system",
                    path="Boolean comparison literal",
                    hint=(
                        "Compare a Boolean value only with True, False, 0, "
                        "or 1."
                    ),
                )
            other = arith.constant(self.type, int(other), loc=loc, ip=ip)
        elif self.type.width == 1 and not isinstance(other, ir.Value):
            raise CANNBotTypeError(
                TS101_INVALID_SCALAR_LITERAL,
                "Boolean comparison requires True, False, 0, 1, or another "
                f"Boolean value; got {type(other).__name__}.",
                phase="type-system",
                path="Boolean comparison literal",
                hint=(
                    "Compare a Boolean value only with True, False, 0, 1, "
                    "or a Boolean DSL value."
                ),
            )
        else:
            other = self._cast_literal_or_check(other, operation=operation, loc=loc, ip=ip)
        predicate = unsigned_predicate if _is_unsigned(self) else signed_predicate
        return Boolean(
            arith.cmpi(predicate, self, other, loc=loc, ip=ip),
            loc=loc,
            ip=ip,
        )

    def __lt__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpIPredicate.slt,
            arith.CmpIPredicate.ult,
            operation="less-than",
            loc=loc,
            ip=ip,
        )

    def __le__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpIPredicate.sle,
            arith.CmpIPredicate.ule,
            operation="less-than-or-equal",
            loc=loc,
            ip=ip,
        )

    def __gt__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpIPredicate.sgt,
            arith.CmpIPredicate.ugt,
            operation="greater-than",
            loc=loc,
            ip=ip,
        )

    def __ge__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpIPredicate.sge,
            arith.CmpIPredicate.uge,
            operation="greater-than-or-equal",
            loc=loc,
            ip=ip,
        )

    def __eq__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpIPredicate.eq,
            arith.CmpIPredicate.eq,
            operation="equality",
            loc=loc,
            ip=ip,
        )

    def __ne__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpIPredicate.ne,
            arith.CmpIPredicate.ne,
            operation="inequality",
            loc=loc,
            ip=ip,
        )

    def __radd__(self, other, *, loc=None, ip=None):
        return self.__add__(other, loc=loc, ip=ip)

    def __rsub__(self, other, *, loc=None, ip=None):
        self._require_arithmetic("subtraction")
        other = self._cast_literal_or_check(other, operation="subtraction", loc=loc, ip=ip)
        return type(self)(arith.subi(other, self, loc=loc, ip=ip), loc=loc, ip=ip)

    def __rmul__(self, other, *, loc=None, ip=None):
        return self.__mul__(other, loc=loc, ip=ip)

    def __rtruediv__(self, other, *, loc=None, ip=None):
        return self._reverse_binary(
            other,
            arith.divsi,
            arith.divui,
            operation="division",
            loc=loc,
            ip=ip,
        )

    def __rfloordiv__(self, other, *, loc=None, ip=None):
        return self._reverse_binary(
            other,
            arith.divsi,
            arith.divui,
            operation="floor division",
            loc=loc,
            ip=ip,
        )

    def __rmod__(self, other, *, loc=None, ip=None):
        return self._reverse_binary(
            other,
            arith.remsi,
            arith.remui,
            operation="remainder",
            loc=loc,
            ip=ip,
        )

    def __rxor__(self, other, *, loc=None, ip=None):
        return self.__xor__(other, loc=loc, ip=ip)

    def __hash__(self):
        return super().__hash__()

    def __bool__(self):
        raise TypeError(
            "Cannot evaluate truthiness of a dynamic DSL integer/boolean "
            f"(type={self.type}). This usually means the expression appears "
            "outside a @kernel/@jit AST frontend boundary "
            "(e.g. inside a helper method on a plain Python class, `assert`, "
            "or an explicit `bool()` call). Move the control flow into a "
            "@kernel/@jit function. Python conditional "
            "expressions are lowered lazily there; `cannbotdsl.select` is "
            "available only when eager value selection is intentional."
        )

    def __str__(self):
        return f"Integer(type={self.type}, value={super().__str__()})"

    def __repr__(self):
        return self.__str__()


class _ConcreteInteger(Integer):
    width: int
    unsigned: bool = False

    @classmethod
    def mlir_type(cls) -> ir.IntegerType:
        if cls.unsigned:
            return ir.IntegerType.get_unsigned(cls.width)
        return ir.IntegerType.get_signless(cls.width)

    @classmethod
    def scalar_mlir_type(cls) -> ir.IntegerType:
        """The signless form required by scalar ``arith`` operations."""

        return ir.IntegerType.get_signless(cls.width)

    def __init__(self, value, *, loc=None, ip=None):
        target_type = type(self).scalar_mlir_type()
        if type(value) is int:
            value = materialize_literal(
                value,
                target_type,
                semantic_unsigned=type(self).unsigned,
                loc=loc,
                ip=ip,
            )
        elif isinstance(value, ir.Value):
            value = cast_value(
                value,
                target_type,
                source_unsigned=_is_unsigned(value),
                target_unsigned=type(self).unsigned,
                loc=loc,
                ip=ip,
            )
        else:
            raise TypeError(
                f"{type(self).__name__} expects an int literal or numeric SSA value, got {type(value).__name__}"
            )
        super().__init__(value, loc=loc, ip=ip)


class Int64(_ConcreteInteger):
    width = 64
    _dtype = _dtypes.int64


class UInt64(_ConcreteInteger):
    width = 64
    unsigned = True
    _dtype = _dtypes.uint64


class Int32(_ConcreteInteger):
    width = 32
    _dtype = _dtypes.int32


class UInt32(_ConcreteInteger):
    width = 32
    unsigned = True
    _dtype = _dtypes.uint32


class Int16(_ConcreteInteger):
    width = 16
    _dtype = _dtypes.int16


class UInt16(_ConcreteInteger):
    width = 16
    unsigned = True
    _dtype = _dtypes.uint16


class Int8(_ConcreteInteger):
    width = 8
    _dtype = _dtypes.int8


class UInt8(_ConcreteInteger):
    width = 8
    unsigned = True
    _dtype = _dtypes.uint8


class Boolean(Integer):
    width = 1
    _dtype = _dtypes.bool

    def __init__(self, value, *, loc=None, ip=None):
        target_type = self.mlir_type()
        if type(value) is bool:
            value = materialize_literal(value, target_type, loc=loc, ip=ip)
        elif isinstance(value, ir.Value):
            if value.type != target_type:
                raise TypeError(
                    f"Boolean requires an i1 SSA value, got {value.type}; form a comparison or cast explicitly"
                )
        else:
            raise TypeError(f"Boolean expects a bool literal or i1 SSA value, got {type(value).__name__}")
        super().__init__(value, loc=loc, ip=ip)

    @staticmethod
    def mlir_type() -> ir.IntegerType:
        return ir.IntegerType.get_signless(1)


__all__: list[str] = []
