# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""On-chip Tensor allocation, static storage and Buffer resource binding."""

from __future__ import annotations

from functools import reduce
from operator import mul

from cannbot_dsl.core.diag.diagnostics import (
    CANNBotRuntimeError, CANNBotTypeError, CANNBotValueError, DiagnosticCode,
)

import cannbot_dsl._mlir.ir as ir
from cannbot_dsl._mlir.dialects import cannir

from cannbot_dsl.core.ir_transport import unwrap_operand
from cannbot_dsl.core.utils.type_checks import is_exact_instance
from cannbot_dsl.tensor import (
    _VALUE_VIEW_OPS,
    Layout,
    LayoutMapKind,
    MemLoc,
    Tensor,
    _tensor_type_from_layouts,
    make_layout,
)
from cannbot_dsl.types import dtypes

_BUFFER_MEM_LOCS = frozenset(
    (MemLoc.UB, MemLoc.L1, MemLoc.L0A, MemLoc.L0B, MemLoc.L0C, MemLoc.BIAS, MemLoc.SSBUF, MemLoc.FBUF, MemLoc.FBUF_ACT)
)
# Carriers that pack an exact number of logical elements into one addressable
# byte.  Derived from the dtype table's own marker rather than re-listed here:
# DType.is_packed_sub_byte is the single Python-side mirror of
# ascdtype::isPackedSubByteStorageType, and it is the place that records why bool
# is excluded (a predicate type, not tensor storage).
_PACKED_SUB_BYTE_DTYPES = frozenset(dtype.name for dtype in getattr(dtypes, "_DTYPES") if dtype.is_packed_sub_byte)


def _normalize_mem_loc(mem_loc):
    if not isinstance(mem_loc, MemLoc):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE, f"Buffer mem_loc must be a MemLoc value, got {type(mem_loc).__name__}"
        )
    if mem_loc not in _BUFFER_MEM_LOCS:
        supported = ", ".join(item.name for item in _BUFFER_MEM_LOCS)
        raise CANNBotValueError(
            DiagnosticCode.UNSUPPORTED_FEATURE, f"Buffer does not support MemLoc.{mem_loc.name}; supported: {supported}"
        )
    return mem_loc


def _normalize_dtype(dtype):
    from cannbot_dsl.core.contracts.elements import normalize_storage_dtype

    dtype = normalize_storage_dtype(dtype)
    if dtype.is_packed_sub_byte:
        return dtype
    width = getattr(dtype, "width", None)
    if not is_exact_instance(width, int) or width <= 0 or width % 8:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_TYPE,
            f"Buffer dtype must have a whole-byte storage width, or be one of the "
            f"packed sub-byte carriers {sorted(_PACKED_SUB_BYTE_DTYPES)}, "
            f"got {dtype!r} ({width!r} bits)"
        )
    return dtype


def _allocate_tensor_memory(
    dtype, mem_loc, logical_layout, physical_layout, *, data_format, alignment=None,
) -> Tensor:
    """Declare storage independently of its typed Tensor binding."""
    tensor_type = _tensor_type_from_layouts(
        dtype, mem_loc, logical_layout, physical_layout, data_format=data_format)
    size_bytes = cannir.tensor_storage_bytes(tensor_type, 0)
    minimum_alignment = cannir.tensor_storage_alignment(tensor_type)
    default_alignment = 512 if mem_loc in (MemLoc.L1, MemLoc.L0A, MemLoc.L0B, MemLoc.L0C) else minimum_alignment
    alignment = default_alignment if alignment is None else alignment
    if type(alignment) is not int or alignment < minimum_alignment or alignment & (alignment - 1):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            "Buffer alignment must be a power of two satisfying the memory-space requirement",
        )
    i64 = ir.IntegerType.get_signless(64)
    allocation = cannir.AllocTensorMemoryOp.build_generic(
        results=[cannir.AllocationType.get(int(mem_loc))], operands=[],
        attributes={"size_bytes": ir.IntegerAttr.get(i64, size_bytes),
                    "alignment": ir.IntegerAttr.get(i64, alignment)})
    pointer = cannir.make_pointer(tensor_type.pointer, allocation.results[0])
    value = cannir.make_tensor(tensor_type, pointer, unwrap_operand(logical_layout),
                              physical_layout=unwrap_operand(physical_layout) if physical_layout is not None else None,
                              map_symbols=[])
    return getattr(Tensor, "_from_ir")(unwrap_operand(value))


def _get_or_create_space_root(mem_loc, capacity):
    """Reuse the current function's entry binding without Python trace state."""
    from cannbot_dsl.tensor import make_pointer, make_tensor
    try:
        function = ir.InsertionPoint.current.block.owner.operation
        while function.name != "func.func":
            function = function.parent
            if function is None:
                raise CANNBotRuntimeError(
                    DiagnosticCode.INVALID_ARGUMENT, "on-chip space views require an enclosing function"
                )
    except (ValueError, AttributeError) as exc:
        raise CANNBotRuntimeError(
            DiagnosticCode.INVALID_ARGUMENT, "on-chip space views require an active function insertion point"
        ) from exc
    entry = function.regions[0].blocks[0]
    for operation in entry.operations:
        if operation.name == "cannir.make_tensor" and "cannir.onchip_space_root" in operation.attributes:
            value = unwrap_operand(operation.results[0])
            if cannir.TensorType(value.type).pointer.memloc == int(mem_loc):
                return getattr(Tensor, "_from_ir")(value)
    with ir.InsertionPoint.at_block_begin(entry):
        pointer = make_pointer(dtypes.uint8, 0, mem_loc)
        root = make_tensor(pointer, make_layout((capacity,)), data_format="nd")
        unwrap_operand(root).owner.attributes["cannir.onchip_space_root"] = ir.UnitAttr.get()
        return root


class Buffer:
    """Allocate and bind a Tensor with the same layout contract as make_tensor.

    The physical layout determines allocation size, including stride and
    padding. Allocation starts are aligned to 32 bytes in UB and 512 bytes in
    L1/L0. To reserve more space than a later view needs, allocate a
    one-dimensional ND Tensor and derive that view from it.
    """

    def __new__(
        cls,
        mem_loc,
        dtype,
        layout,
        *,
        physical_layout=None,
        data_format=None,
    ) -> Tensor:
        from cannbot_dsl.tensor import _MEMLOC_DEFAULT_PHYSICAL_FORMAT

        mem_loc = _normalize_mem_loc(mem_loc)
        dtype = _normalize_dtype(dtype)
        if not isinstance(layout, Layout):
            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "Buffer layout must be a Layout")
        if physical_layout is not None and not isinstance(physical_layout, Layout):
            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "Buffer physical_layout must be a Layout")
        if data_format is None:
            data_format = _MEMLOC_DEFAULT_PHYSICAL_FORMAT.get(mem_loc, "nd")
        if not isinstance(data_format, str):
            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "Buffer data_format must be 'nd' or 'nz'")
        if data_format not in ("nd", "nz"):
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT, f"Buffer data_format must be 'nd' or 'nz', got {data_format!r}"
            )
        if layout.layout_map_kind == LayoutMapKind.Composed:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT, "Buffer requires an explicit layout made with make_layout"
            )
        result = _allocate_tensor_memory(
            dtype, mem_loc, layout, physical_layout, data_format=data_format)
        if physical_layout is not None:
            unwrap_operand(result).owner.attributes["cannir.explicit_physical_layout"] = ir.UnitAttr.get()
        unwrap_operand(result).owner.verify()
        if dtype == dtypes.uint8 and len(layout.shape) == 1 and data_format == "nd":
            unwrap_operand(result).owner.attributes["cannir.byte_storage"] = ir.UnitAttr.get()
        return result

# arch_3510 capacities, matching PlanOnChipMemory. SSBUF describes the full
# MIX address space; scalar access verification enforces per-core windows.
_SPACE_CAPACITY_BYTES = {
    MemLoc.UB: 256 * 1024,
    MemLoc.L1: 512 * 1024,
    MemLoc.L0A: 64 * 1024,
    MemLoc.L0B: 64 * 1024,
    MemLoc.L0C: 256 * 1024,
    MemLoc.BIAS: 4 * 1024,
    MemLoc.SSBUF: 3 * 1024,
    MemLoc.FBUF: 4 * 1024,
    MemLoc.FBUF_ACT: 2 * 1024,
}
_STATIC_VIEW_OPS = _VALUE_VIEW_OPS | frozenset(
    {
        "cannir.reshape_view",
        "cannir.tensor_slice",
        "cannir.local_slice",
        "cannir.tile_slice",
        "cannir.reinterpret_view",
        "cannir.storage_cast",
        "cannir.dtype_view",
        "cannir.permute_view",
        "cannir.make_buf",
        "cannir.bind_buffer_logical_id",
    }
)


def _static_product(shape) -> int:
    values = []
    for dim in shape:
        if not is_exact_instance(dim, int) or dim <= 0:
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_SHAPE, "on-chip space views require a non-empty static shape of positive ints"
            )
        values.append(dim)
    if not values:
        raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, "on-chip space view shape must not be empty")
    return reduce(mul, values, 1)


def _ensure_static_view(view: Tensor) -> None:
    shape = view.shape
    stride = view.physical_layout.stride
    _static_product(shape)
    for name, values in (("stride", stride),):
        for index, value in enumerate(values):
            if not is_exact_instance(value, int) or value <= 0:
                raise CANNBotTypeError(
                    DiagnosticCode.INVALID_SHAPE, f"on-chip space view {name}[{index}] must be a positive static int"
                )


def _find_space_root(value):
    """Find the explicit on-chip root through the supported static view chain."""

    from cannbot_dsl.tensor import _raw

    current = _raw(value)
    visited = set()
    while current is not None and current not in visited:
        visited.add(current)
        owner = getattr(current, "owner", None)
        name = str(getattr(owner, "name", ""))
        if name == "cannir.make_tensor" and "cannir.onchip_space_root" in owner.attributes:
            if "cannir.onchip_space_root" in owner.attributes:
                return current
            return None
        if name not in _STATIC_VIEW_OPS:
            return None
        current = _raw(owner.operands[0])
    return None


def _has_bound_resource(value) -> bool:
    """Return whether a view chain already contains a make_buf boundary."""

    from cannbot_dsl.tensor import _raw

    current = _raw(value)
    visited = set()
    while current is not None and current not in visited:
        visited.add(current)
        owner = getattr(current, "owner", None)
        name = str(getattr(owner, "name", ""))
        if name in ("cannir.make_buf", "cannir.bind_buffer_logical_id"):
            return True
        if name not in _STATIC_VIEW_OPS:
            return False
        current = _raw(owner.operands[0])
    return False


class _OnChipSpace:
    """Function-local, full-capacity byte storage for manual placement."""

    __slots__ = ("mem_loc",)

    def __init__(self, mem_loc):
        self.mem_loc = mem_loc

    def view(self, *shape, dtype=None):
        """Return a static uint8 view of this space's complete capacity.

        Repeated calls in one kernel reuse the same root. For contiguous ND,
        take a byte slice and use Tensor.view for dtype and shape; use
        reinterpret for explicit physical layouts. Bind the typed
        view with make_buffer or make_ring_buffer before use.
        """
        if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
            shape = tuple(shape[0])
        else:
            shape = tuple(shape)
        name = self.mem_loc.name
        capacity = _SPACE_CAPACITY_BYTES[self.mem_loc]
        if dtype is not None and dtype != dtypes.uint8:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_TYPE, f"dsl.{name}.view is byte-addressed; dtype must be dtypes.uint8"
            )
        if _static_product(shape) != capacity:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE,
                f"dsl.{name}.view must cover the complete {capacity // 1024} KiB "
                f"{name} space ({capacity} uint8 elements), got shape={shape!r}"
            )
        root = _get_or_create_space_root(self.mem_loc, capacity)
        return root.view(shape)


UB, L1, L0A, L0B, L0C, BIAS, SSBUF, FBUF, FBUF_ACT = (_OnChipSpace(mem_loc) for mem_loc in _SPACE_CAPACITY_BYTES)


def make_buffer(tensor: Tensor) -> Tensor:
    """Bind a static on-chip Tensor to an opaque logical Buffer identity.

    The operation reuses the tensor's storage root and address.  It emits no
    ``alloc_tensor_memory``; only a logical declaration and binding are added.
    Hardware mutex/counter IDs are requested later from actual synchronization.
    The input dtype and layout are preserved. Use ``result.view(dtype)`` to
    reinterpret the bound Tensor's element type.
    """

    if not isinstance(tensor, Tensor):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE, f"make_buffer expects a Tensor view, got {type(tensor).__name__}"
        )
    if tensor.memloc not in _BUFFER_MEM_LOCS:
        raise CANNBotValueError(DiagnosticCode.UNSUPPORTED_FEATURE, "make_buffer supports only on-chip views")
    _ensure_static_view(tensor)

    root = _find_space_root(tensor)
    if root is None:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            f"make_buffer requires a static view derived from dsl.{tensor.memloc.name}.view()",
        )

    # A view of an already-bound Buffer keeps that resource, including dtype
    # aliases formed by the caller, without introducing a second buf-id.
    if _has_bound_resource(tensor):
        return tensor

    identity = cannir.AllocBufferLogicalIdOp.build_generic(
        results=[cannir.BufferLogicalIdType.get()], operands=[unwrap_operand(tensor)]
    ).results[0]
    marker = cannir.bind_buffer_logical_id(unwrap_operand(tensor), identity)
    marker_value = unwrap_operand(marker)
    marker_value.owner.attributes["cannir.buffer.explicit_binding"] = ir.UnitAttr.get()
    marker_value.owner.attributes["cannir.buffer.logical"] = ir.UnitAttr.get()
    result = getattr(Tensor, "_from_ir")(marker_value)
    return result


__all__ = ["Buffer", "UB", "L1", "L0A", "L0B", "L0C", "BIAS", "SSBUF", "FBUF", "FBUF_ACT", "make_buffer"]
