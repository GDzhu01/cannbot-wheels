# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""bisheng toolchain integration for AICPU kernels.

Compile chain for the CANN 9.2 baseline:

* device:  bisheng -x aicpu  (+ --cce-aicpu-launch-with-interface for the
  struct-by-value launch ABI; legacy single-pointer mode omits the flag)
* shim:    bisheng -x asc --npu-arch=<arch> (same interface flag)
* link:    bisheng -shared --npu-arch=<arch>
* x86:     system c++ (portable body cross-check, no CANN needed)

ASCEND_HOME_PATH selects the CANN installation for device, shim and link
compilation. AICPU always targets aarch64-target-linux-gnu, independently
of the build host. The installation's HCC compiler supplies its version
and sysroot.

Flag spelling matters: ``--cce-aicpu-L<dir>`` concatenates while
``--cce-aicpu-sysroot=<dir>`` uses ``=``.
"""

from __future__ import annotations

import ctypes
import os
import shutil
import subprocess

from cannbot_dsl.aicpu.types import GmFieldType


_AICPU_TARGET = "aarch64-target-linux-gnu"


def _run(cmd, *, env=None, cwd=None):
    proc = subprocess.run(cmd, capture_output=True, text=True, env=env, cwd=cwd)
    if proc.returncode != 0:
        failed = " ".join(str(c) for c in cmd)
        raise RuntimeError(
            f"command failed ({proc.returncode}):\n{failed}\nstdout:\n{proc.stdout}\nstderr:\n{proc.stderr}"
        )
    return proc


def _ascend_home():
    value = os.environ.get("ASCEND_HOME_PATH")
    if not value:
        raise RuntimeError("AICPU compilation requires ASCEND_HOME_PATH to point to the CANN installation")
    home = os.path.realpath(os.path.expanduser(value))
    if not os.path.isdir(home):
        raise RuntimeError(f"ASCEND_HOME_PATH is not a directory: {home}")
    return home


def _require_file(path, *, executable=False):
    if not os.path.isfile(path) or (executable and not os.access(path, os.X_OK)):
        kind = "executable" if executable else "file"
        raise RuntimeError(f"CANN installation selected by ASCEND_HOME_PATH is missing required {kind}: {path}")
    return os.path.realpath(path)


class AicpuToolchain:
    """Use the compiler and SDK from ASCEND_HOME_PATH for every build stage."""

    def __init__(self, npu_arch: str = "dav-3510", launch_mode: str = "interface"):
        self.npu_arch = npu_arch
        self.launch_mode = launch_mode
        self.ascend_home = home = _ascend_home()
        # Accept an explicitly supplied SDK subdirectory without querying the
        # build host or selecting a different SDK directory.
        self.toolkit = os.path.dirname(home) if os.path.basename(home) in {"x86_64-linux", "aarch64-linux"} else home
        self.bisheng = _require_file(os.path.join(self.ascend_home, "bin", "bisheng"), executable=True)
        self.api_include = os.path.join(self.ascend_home, "asc", "include", "aicpu_api")
        self.device_lib = os.path.join(self.ascend_home, "lib64", "device", "lib64")
        _require_file(os.path.join(self.api_include, "aicpu_api.h"))
        _require_file(os.path.join(self.device_lib, "libaicpu_api.a"))
        self.hcc = os.path.realpath(os.path.join(self.toolkit, "toolkit", "toolchain", "hcc"))
        hcc_cxx = _require_file(os.path.join(self.hcc, "bin", f"{_AICPU_TARGET}-g++"), executable=True)
        self._env = dict(os.environ, ASCEND_HOME_PATH=self.toolkit)
        target = _run([hcc_cxx, "-dumpmachine"], env=self._env).stdout.strip()
        version = _run([hcc_cxx, "-dumpfullversion"], env=self._env).stdout.strip()
        sysroot = _run([hcc_cxx, "-print-sysroot"], env=self._env).stdout.strip()
        if target != _AICPU_TARGET or not version or "/" in version:
            raise RuntimeError(f"invalid HCC target/version from {hcc_cxx}: {target!r}, {version!r}")
        if not os.path.isabs(sysroot) or not os.path.isdir(sysroot):
            raise RuntimeError(f"invalid HCC sysroot from {hcc_cxx}: {sysroot!r}")
        self.sysroot = os.path.realpath(sysroot)
        include = os.path.join(self.hcc, _AICPU_TARGET, "include")
        cxx_include = os.path.join(include, "c++", version)
        self.system_includes = [
            include,
            cxx_include,
            os.path.join(cxx_include, _AICPU_TARGET),
            os.path.join(cxx_include, "backward"),
        ]
        for path in self.system_includes:
            if not os.path.isdir(path):
                raise RuntimeError(f"HCC selected by ASCEND_HOME_PATH is missing required include directory: {path}")

    def aicpu_compile_flags(self):
        flags = [
            "-O2",
            "-c",
            "-std=c++17",
            "-D_GLIBCXX_USE_CXX11_ABI=0",
            f"-I{self.api_include}",
            f"--cce-aicpu-L{self.device_lib}",
            "--cce-aicpu-laicpu_api",
            f"--cce-aicpu-toolkit-path={self.hcc}/bin",
            f"--cce-aicpu-sysroot={self.sysroot}",
        ]
        for path in self.system_includes:
            flags.extend(["-isystem", path])
        if self.launch_mode == "interface":
            flags.append("--cce-aicpu-launch-with-interface")
        return flags

    def compile_kernel_obj(self, src, out):
        _run([self.bisheng, *self.aicpu_compile_flags(), "-o", out, "-x", "aicpu", src], env=self._env)

    def compile_shim_obj(self, src, out):
        # The interface flag also governs how the <<<>>> launch stub parses
        # kernel declarations in the host shim; single-pointer legacy kernels
        # launch fine under it too (verified locally and on 8P), so it is
        # always passed here.
        _run(
            [
                self.bisheng,
                "-fPIC",
                f"--npu-arch={self.npu_arch}",
                "-c",
                "-O3",
                "--cce-aicpu-launch-with-interface",
                "-x",
                "asc",
                src,
                "-o",
                out,
            ],
            env=self._env,
        )

    def link_so(self, objs, out_so):
        _run(
            [self.bisheng, "-shared", "-fPIC", f"--npu-arch={self.npu_arch}", "-o", out_so, *objs, "-lm"],
            env=self._env,
        )


def compile_x86(kernel, workdir: str) -> str:
    """Compile the portable body as a host x86 .so for golden cross-checks."""
    name = kernel.fn.__name__
    src = os.path.join(workdir, f"{name}_x86.cpp")
    out = os.path.join(workdir, f"{name}_x86.so")
    compiler = shutil.which("c++") or shutil.which("g++")
    if compiler is None:
        raise RuntimeError("no host c++/g++ found for the x86 cross-check build")
    _run([compiler, "-O2", "-shared", "-fPIC", "-o", out, src])
    return out


def compile_aicpu_kernel(
    kernel, *, workdir: str, launch_mode: str, npu_arch: str = "dav-3510", build_x86: bool = False
):
    """Generate sources, compile device+shim, link the launchable .so."""
    name = kernel.fn.__name__
    workdir = os.path.abspath(workdir)
    os.makedirs(workdir, exist_ok=True)
    files = kernel.generate_sources(name=name, launch_mode=launch_mode)
    for fname, text in files.items():
        with open(os.path.join(workdir, fname), "w", encoding="utf-8") as f:
            f.write(text)

    tc = AicpuToolchain(npu_arch=npu_arch, launch_mode=launch_mode)
    kernel_obj = os.path.join(workdir, f"{name}_kernel.o")
    shim_obj = os.path.join(workdir, f"{name}_shim.o")
    so_path = os.path.join(workdir, f"{name}.so")
    tc.compile_kernel_obj(os.path.join(workdir, f"{name}_kernel.aicpu"), kernel_obj)
    tc.compile_shim_obj(os.path.join(workdir, f"{name}_shim.asc"), shim_obj)
    tc.link_so([kernel_obj, shim_obj], so_path)
    x86_so = compile_x86(kernel, workdir) if build_x86 else None
    return CompiledAicpuKernel(so_path, kernel.spec, name=name, launch_mode=launch_mode, x86_so_path=x86_so)


class CompiledAicpuKernel:
    def __init__(self, so_path, spec, *, name, launch_mode, x86_so_path=None):
        self.so_path = so_path
        self.spec = spec
        self.name = name
        self.launch_mode = launch_mode
        self.x86_so_path = x86_so_path
        self._lib = None
        self._x86_lib = None

    def launch(self, stream_handle: int, **kwargs):
        """Launch on the given raw stream.

        interface mode: one flat argument per args field (GM fields are device
        addresses). legacy mode: a single ``param_addr`` device address that
        already holds the packed args struct bytes.
        """
        if self._lib is None:
            self._lib = ctypes.CDLL(self.so_path)
        entry = getattr(self._lib, f"{self.name}_do")
        entry.restype = None
        if self.launch_mode == "legacy":
            entry.argtypes = [ctypes.c_void_p, ctypes.c_uint64]
            entry(ctypes.c_void_p(stream_handle), ctypes.c_uint64(int(kwargs["param_addr"])))
            return 0
        entry.argtypes = [ctypes.c_void_p, *self._ctypes_fields()]
        args = []
        for fname, ann in self.spec.fields:
            v = kwargs.get(fname, 0) if isinstance(ann, GmFieldType) else kwargs[fname]
            ct = ctypes.c_uint64 if isinstance(ann, GmFieldType) else ann.ctypes_type
            args.append(ct(int(v)))
        entry(ctypes.c_void_p(stream_handle), *args)
        return 0

    def run_x86(self, **kwargs):
        """Run the portable body on host x86; GM fields are host buffers."""
        if self.x86_so_path is None:
            raise RuntimeError("kernel was not built with build_x86=True")
        if self._x86_lib is None:
            self._x86_lib = ctypes.CDLL(self.x86_so_path)
        entry = getattr(self._x86_lib, f"{self.name}_run_x86")
        entry.argtypes = self._ctypes_fields()
        entry.restype = ctypes.c_int64
        args = []
        for fname, ann in self.spec.fields:
            v = kwargs[fname]
            if isinstance(ann, GmFieldType):
                buf = (ctypes.c_char * 0).from_buffer(bytearray(0)) if False else None
                addr = getattr(v, "x86_addr", None)
                if addr is None:
                    arr = getattr(v, "x86_buffer", None)
                    if arr is None:
                        raise RuntimeError(f"x86 run needs an X86Buffer for GM field {fname!r}")
                    addr = ctypes.addressof(arr.data)
                args.append(ctypes.c_uint64(int(addr)))
            else:
                args.append(ann.ctypes_type(int(v)))
        return entry(*args)
    def _ctypes_fields(self):
        out = []
        for _, ann in self.spec.fields:
            if isinstance(ann, GmFieldType):
                out.append(ctypes.c_uint64)
            else:
                out.append(ann.ctypes_type)
        return out
