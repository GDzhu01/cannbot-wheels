# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Tensor and Layout values, layout derivation, type construction, and views."""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import IntEnum as _IntEnum
from functools import reduce
from typing import Any, Optional, Tuple, Union

import cannbot_dsl._mlir.ir as ir
from cannbot_dsl._mlir.dialects import arith, cannir
from cannbot_dsl.core.diag.diagnostics import (
    CANNBotIndexError, CANNBotNotImplementedError,
    CANNBotOverflowError, CANNBotTypeError, CANNBotValueError, DiagnosticCode, argument_span,
)
from cannbot_dsl.core.ir_transport import unwrap_operand
from cannbot_dsl.core.slice_arithmetic import build_slice_extent
from cannbot_dsl.core.scalar_conversion import (
    _constant_i64,
    _index_value,
    _int64_result,
    _render_literal,
    _validate_index_value,
)
from cannbot_dsl.core.utils.type_checks import is_exact_instance
from cannbot_dsl.types import _tensor as _tensor_values
from cannbot_dsl.types import dtypes as _dtypes
from cannbot_dsl.types._tensor import PartitionTiler
from cannbot_dsl.types.scalar import ScalarValue as _ScalarValue


class MemLoc(_IntEnum):
    GM = 0
    UB = 1
    L1 = 2
    L0A = 3
    L0B = 4
    L0C = 5
    RegFile = 6
    L0A_MX = 7
    L0B_MX = 8
    BIAS = 9
    SSBUF = 10
    FBUF = 11
    FBUF_ACT = 12


class LayoutMapKind(_IntEnum):
    Identity = 0
    ND2NZ = 1
    DN2NZ = 2
    NZ2ND = 3
    ZN2ND = 4
    Composed = 5


# Recursive Python metadata trees; integer validation is performed at use sites.
Shape = Union[int, _ScalarValue, Tuple["Shape", ...]]
Stride = Union[int, _ScalarValue, Tuple["Stride", ...]]
Coord = Union[int, None, _ScalarValue, Tuple["Coord", ...]]
Tile = Union[int, _ScalarValue, Tuple["Tile", ...]]
Tiler = Union[Shape, Tile]
_TensorIndex = Union[int, None, slice, _ScalarValue, Tuple["_TensorIndex", ...]]


class Layout:
    """Read-only semantic view of one CANNIR layout SSA value.

    Layout objects are created by CANNBotDSL.  The backend carrier is kept
    private so frontend code cannot accidentally couple itself to MLIR's
    Python value implementation.
    """

    __slots__ = ("_ssa_value", "_view_source")

    def __init__(self, *args, **kwargs):
        del args, kwargs
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "Layout values are created by CANNBotDSL")

    def __init_subclass__(cls, **kwargs):
        del kwargs
        raise TypeError("Layout is a sealed CANNBotDSL value type")

    @classmethod
    def _from_ir(cls, value, *, view_source=None):
        if is_exact_instance(value, cls):
            return value
        if not isinstance(value, ir.Value) or not cannir.LayoutType.isinstance(value.type):
            actual = getattr(value, "type", type(value).__name__)
            raise TypeError(f"Layout requires a !cannir.layout carrier, got {actual}")
        result = object.__new__(cls)
        object.__setattr__(result, "_ssa_value", value)
        if view_source is None and getattr(value.owner, "name", None) == "cannir.extract_layout":
            view_source = unwrap_operand(value.owner.operands[0])
        object.__setattr__(result, "_view_source", view_source)
        return result

    @property
    def shape(self) -> Shape:
        return _layout_shape(self)

    @property
    def stride(self) -> Stride:
        return _layout_stride(self)

    @property
    def layout_map_kind(self) -> LayoutMapKind:
        if self._view_source is None:
            return LayoutMapKind.Identity
        schema = self._view_source.type
        if cannir.RingBufferType.isinstance(schema):
            schema = cannir.RingBufferType(schema).element
        return LayoutMapKind(cannir.TensorType(schema).layout_map_kind)


_FRAMEWORK_TENSOR_SUBCLASS_TOKEN = object()


@dataclass(frozen=True)
class StorageBits:
    """A scalar expressed in the destination element's storage encoding."""

    value: object


class Tensor:
    """Canonical trace-body tensor value.

    A Tensor owns no host allocation.  It is a composition facade around one
    CANNIR Tensor SSA value and is constructed only by the framework while a
    staged function is being traced.
    """

    __slots__ = ("_ssa_value",)

    def __init__(self, *args, _framework_internal=None, **kwargs):
        if _framework_internal is not _FRAMEWORK_TENSOR_SUBCLASS_TOKEN or args or kwargs:
            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "Tensor values are created by CANNBotDSL while tracing")

    def __init_subclass__(cls, *, _framework_internal=None, **kwargs):
        if _framework_internal is not _FRAMEWORK_TENSOR_SUBCLASS_TOKEN:
            raise TypeError("Tensor is a sealed CANNBotDSL value type")
        super().__init_subclass__(**kwargs)

    @staticmethod
    def _bind_ir(instance, value):
        """Bind one validated Tensor carrier to a new framework value."""

        if not isinstance(instance, Tensor):
            raise TypeError("Tensor carrier binding requires a Tensor framework value")
        if not isinstance(value, ir.Value) or not cannir.TensorType.isinstance(value.type):
            actual = getattr(value, "type", type(value).__name__)
            raise TypeError(f"Tensor requires a !cannir.tensor carrier, got {actual}")
        object.__setattr__(instance, "_ssa_value", value)
        return instance

    @classmethod
    def _from_ir(cls, value):
        if is_exact_instance(value, cls):
            return value
        result = object.__new__(cls)
        return Tensor._bind_ir(result, value)

    @property
    def _tensor_type(self):
        return cannir.TensorType(object.__getattribute__(self, "_ssa_value").type)

    @property
    def shape(self) -> Shape:
        return _tensor_shape(self)

    @property
    def stride(self) -> Stride:
        return _tensor_stride(self)

    @property
    def dtype(self) -> _dtypes.DType:
        return _tensor_dtype(self)

    @property
    def memloc(self) -> MemLoc:
        return _tensor_memloc(self)

    @property
    def layout(self) -> Layout:
        return _tensor_layout(self)

    @property
    def physical_layout(self) -> Layout:
        return _tensor_physical_layout(self)

    @property
    def data_format(self) -> str:
        return _tensor_physical_format(self)

    @property
    def rank(self) -> int:
        return len(self.shape)

    def permute(self, *dims) -> "Tensor":
        """Reorder axes; accept separate axes or one tuple/list of axes."""

        return _permute(self, *dims)

    def expand(self, *sizes, size=None):
        """Expand singleton axes without moving data, following Tensor.expand.

        Accept separate sizes or one tuple/list. New axes are prepended;
        -1 retains an existing axis. Sizes may be integer SSA values. Runtime
        sizes must satisfy the same nonnegative and singleton constraints as
        static sizes; no runtime assertion is inserted.
        """
        if size is not None:
            if sizes:
                raise CANNBotTypeError(
                    DiagnosticCode.INVALID_ARGUMENT, "expand accepts either positional sizes or size=, not both"
                )
            sizes = (size,)
        if not sizes:
            raise CANNBotTypeError(DiagnosticCode.INVALID_ARGUMENT, "expand requires a size argument")
        if len(sizes) == 1 and isinstance(sizes[0], (tuple, list)):
            sizes = tuple(sizes[0])
        return _expand(self, sizes)

    def pad(self, pad, mode="constant", value=None):
        """Pad trailing axes, with before/after pairs starting at the last axis.

        Constant padding defaults to zero; replicate uses the nearest boundary
        element. Widths must be non-negative integers or runtime integers.
        This constructs a logical view without allocating or moving data;
        mem_copy checks the selected DMA path's layout and padding limits.
        """
        return _describe_pad(self, pad, mode, value)

    def partition(self, *, dim, part_id=None, alignment=1):
        """Describe one of two copy partitions on the full-data operand.

        GM -> UB uses the GM source; UB -> GM/L1 uses the destination.
        L0C -> UB uses the L0C source and omits part_id to route both parts.
        M partitions support alignment; N partitions use the hardware's
        32-column boundary and require alignment=1. No data moves here.
        """
        from cannbot_dsl.ops.memcpy import _partition

        return _partition(self, dim=dim, part_id=part_id, alignment=alignment)

    def flatten(self, start_dim=0, end_dim=-1):
        """Merge logical axes, preserving source addressing for the copy.

        Packed ND tensors form a regular view. GM batches and the supported
        NZ fold retain their axis mapping until mem_copy selects the DMA path.
        """
        from cannbot_dsl.ops.memcpy import _flatten

        return _flatten(self, start_dim, end_dim)

    def reshape(self, *shape):
        """Describe a reshape preserving logical order and element count."""
        return _reshape(self, *shape)

    def relu(self):
        """Describe FIXPIPE ReLU without reading or allocating storage."""
        return _expression("relu", [self])

    def convert(self, dtype, *, scale=None, offset=0, negative_scale=None, relu_limit=None):
        """Describe FIXPIPE conversion; source and scale are read at consumption.

        INT8/UINT8 scalar quantization accepts a signed 9-bit integer ``offset``
        (constant or i64 SSA). It is added after the scaled value is rounded to
        signed 9 bits. Encoded Tensor scale tables already contain their offsets.

        ``negative_scale`` selects the independent PRE coefficient for negative
        accumulators; it replaces ``scale`` on that branch, not a post-quantization
        slope. Pass f32 or a contiguous FP32[N] table in L1/FBUF_ACT. ``relu_limit``
        selects normal ReLU BEFORE scaling, then clips the quantized output from
        above. A negative scale may still yield negative output. These controls
        are mutually exclusive and default an omitted ``scale`` to 1.0.

        Numeric ``relu_limit`` is f32 constant/SSA, encoded as the output dtype:
        FP16, BF16, INT8 or UINT8. It must remain positive and finite; integer
        outputs require an integral limit. ``storage_bits(integer_or_i64)`` passes
        an output element's raw encoding (8 or 16 bits) to the clip register and
        is required for FP8/HIF8, whose scalar AIC casts are unavailable. The
        caller supplies a valid finite positive encoded threshold. FP32 output
        does not support this clipping mode.
        """
        return _convert(self, dtype, scale=scale, offset=offset,
                        negative_scale=negative_scale, relu_limit=relu_limit)

    def unflatten(self, dim, sizes):
        """Split one logical axis into explicit factors, without moving data.

        The product of sizes must equal that axis's extent. Runtime sizes
        must satisfy this shape contract. No inferred -1 factor is accepted.
        """
        from cannbot_dsl.ops.memcpy import _unflatten

        return _unflatten(self, dim, sizes)

    def view(self, *shape, dtype=None) -> "Tensor":
        """Return a programmer-guaranteed shape or dtype alias."""

        return _tensor_view_dispatch(self, *shape, dtype=dtype)

    def __getitem__(self, coord: _TensorIndex) -> Any:
        """Load a point or create a rank-preserving alias view.

        A point coordinate must match the complete logical shape tree.  The
        root one-dimensional form accepts either ``tensor[i]`` or
        ``tensor[(i,)]``.  Static coordinates are bounds-checked; runtime
        coordinates remain caller-managed and receive no implicit guard.

        ``None`` keeps the matching axis or complete nested shape subtree; it
        never inserts a new axis.  Use interval slices such as ``1:4``, ``:4``,
        or ``1:7:2`` for interval views, including empty intervals. A step may
        be a static or runtime positive integer. Negative bounds are unsupported.  With a static parent extent, non-negative Python literal
        bounds are clipped at compile time; runtime bounds are absolute,
        caller-managed, and introduce no implicit checks or clipping.  The
        caller guarantees ``0 <= start <= stop <= parent_extent`` and
        ``step > 0`` without overflow.  A fully open ``:`` is not a keep marker.
        """
        return _tensor_getitem(self, coord)

    def __setitem__(self, coord: _TensorIndex, value: Any) -> None:
        _tensor_setitem(self, coord, value)

    def ptr(self, coord: _TensorIndex) -> ir.Value:
        """Return a pointer SSA value to one GM or UB element at ``coord``.

        ``coord`` follows the same complete-tree and static-bounds contract as
        a Tensor point load.

        GM pointers are consumed by the DCache-bypass and scalar atomic
        interfaces; GM and UB pointers are consumed by ``simt.atomic_*``.
        Creating it accesses no memory. ``p.type`` is a ``cannir.PointerType``;
        ``p.dtype`` is its element MLIR Type. Pass ``p`` directly to consumers.
        """
        from cannbot_dsl.ops.scalar import _tensor_ptr

        return _tensor_ptr(self, coord)


# Layout trees, construction, and metadata.


def _is_tuple(x) -> bool:
    return isinstance(x, tuple)


def _product(a):
    """Recursive product of all leaf elements (matches pylayout.product)."""
    if _is_tuple(a):
        return reduce(lambda val, elem: val * _product(elem), a, 1)
    return _int64_result(_index_value(a)) if isinstance(a, ir.Value) else a


def _map_tree_leaves(tree, mapper):
    """Rebuild a nested tuple by applying ``mapper(index, leaf)`` in DFS order."""

    next_index = 0

    def visit(node):
        nonlocal next_index
        if isinstance(node, tuple):
            return tuple(visit(child) for child in node)
        index = next_index
        next_index += 1
        return mapper(index, node)

    return visit(tree)


def _materialize_type_tree(
    static_tree,
    source,
    *,
    materialize_static: bool = False,
    on_extract=None,
):
    """Replace selected type leaves with ``extract_dim`` SSA values."""

    carrier = unwrap_operand(source)
    dynamic = (cannir.StrideType.DYNAMIC if isinstance(carrier.type, cannir.StrideType)
               else cannir.ShapeType.DYNAMIC)

    def materialize(index, leaf):
        if not materialize_static and leaf != dynamic:
            return leaf
        value = _int64_result(cannir.extract_dim(unwrap_operand(source), index=index))
        if on_extract is not None:
            on_extract(value)
        return value

    return _map_tree_leaves(static_tree, materialize)


def _suffix_product(a, init=1):
    """
    Exclusive **suffix** product with output congruent to *a* (row-major strides).

    Same semantics as pylayout.suffix_product.
    """
    if _is_tuple(a):
        if _is_tuple(init):
            assert len(a) == len(init)
            return tuple(_suffix_product(x, i) for x, i in zip(a, init))
        r = [None] * len(a)
        cur = init
        for idx in range(len(a) - 1, -1, -1):
            r[idx] = _suffix_product(a[idx], cur)
            cur = cur * _product(a[idx])
        return tuple(r)
    if _is_tuple(init):
        raise ValueError("scalar shape with tuple init")
    return init


def _infer_contiguous_stride(shape: Shape) -> Stride:
    if isinstance(shape, int):
        if shape == cannir.ShapeType.DYNAMIC:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE, "Cannot infer stride for dynamic scalar shape (-1); pass stride=..."
            )
        if shape < 0:
            raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, f"Invalid scalar shape: {shape}; pass stride=...")
        return 1

    if not isinstance(shape, tuple) or any(isinstance(d, (list, tuple)) for d in shape):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_SHAPE,
            f"Cannot infer stride for nested shapes; pass stride=... explicitly (shape={shape!r})",
        )

    if any((not isinstance(d, int)) or d == cannir.ShapeType.DYNAMIC for d in shape):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_SHAPE,
            f"Cannot infer stride for dynamic/non-integer shapes; pass stride=... explicitly (shape={shape!r})"
        )
    if any(d < 0 for d in shape):
        raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, f"Invalid shape dimensions: {shape!r}; pass stride=...")

    if len(shape) == 0:
        return ()

    return _suffix_product(shape)  # type: ignore[return-value]


def _encode_integer_tree(
    value,
    *,
    type_class,
):
    """Replace SSA leaves with the public type's dynamic sentinel."""

    dynamic_values = []

    def visit(node):
        if isinstance(node, (list, tuple)):
            return tuple(visit(child) for child in node)
        if isinstance(node, ir.Value):
            dynamic_values.append(_index_value(node, operation=type_class.__name__))
            return type_class.DYNAMIC
        return node

    return visit(value), dynamic_values


def _coord_to_type_and_dynamic_values(val: Coord):
    return _encode_integer_tree(val, type_class=cannir.CoordType)


def _tiler_to_type_and_dynamic_values(tiler: Tiler):
    """Encode a tile tree and collect its dynamic leaves in DFS order."""

    return _encode_integer_tree(tiler, type_class=cannir.TileType)


def _shape_to_type_and_dynamic_values(shape):
    """Encode a shape tree and collect dynamic leaves in DFS order."""

    return _encode_integer_tree(shape, type_class=cannir.ShapeType)


def _stride_to_type_and_dynamic_values(stride):
    """Encode a stride tree and collect dynamic leaves in DFS order."""

    return _encode_integer_tree(stride, type_class=cannir.StrideType)


def _make_shape_value(shape):
    shape_tree, dynamic_values = _shape_to_type_and_dynamic_values(shape)
    shape_type = cannir.ShapeType.get(shape_tree)
    return cannir.make_shape(shape_type, dynamic_values)


def _make_tile_value(tiler):
    tile_tree, dynamic_values = _tiler_to_type_and_dynamic_values(tiler)
    tile_type = cannir.TileType.get(tile_tree)
    return cannir.make_tile(tile_type, dynamic_values)


def _has_dynamic_layout_leaf(tree, *, dynamic=cannir.ShapeType.DYNAMIC) -> bool:
    if isinstance(tree, tuple):
        return any(_has_dynamic_layout_leaf(child, dynamic=dynamic) for child in tree)
    return tree == dynamic


def _layout_shape(layout: Layout) -> Shape:
    carrier = unwrap_operand(layout)
    static_tree = cannir.LayoutType(carrier.type).shape
    if not _has_dynamic_layout_leaf(static_tree):
        return static_tree
    return _materialize_type_tree(static_tree, cannir.extract_shape(carrier))


def _layout_stride(layout: Layout) -> Stride:
    carrier = unwrap_operand(layout)
    if layout.layout_map_kind != LayoutMapKind.Identity:
        raise CANNBotValueError(
            DiagnosticCode.UNSUPPORTED_FEATURE,
            "View has no per-axis memory stride; use the source Tensor's physical_layout and index map",
        )
    static_tree = cannir.LayoutType(carrier.type).stride
    if not _has_dynamic_layout_leaf(static_tree, dynamic=cannir.StrideType.DYNAMIC):
        return static_tree
    return _materialize_type_tree(static_tree, cannir.extract_stride(carrier))


def make_layout(
    shape: Shape,
    *,
    stride: Union[Stride, None] = None,
) -> Layout:
    shape_tree, shape_dyn = _shape_to_type_and_dynamic_values(shape)
    if stride is None:
        if shape_dyn:
            # Build packed runtime strides from the actual shape operands,
            # never from the -1 sentinels in their type.
            stride_tree, stride_dyn = _stride_to_type_and_dynamic_values(_suffix_product(shape))
        else:
            stride_tree = _infer_contiguous_stride(shape_tree)
            stride_dyn: list = []
    else:
        stride_tree, stride_dyn = _stride_to_type_and_dynamic_values(stride)
    layout_ty = cannir.LayoutType.get(shape_tree, stride_tree)
    shape_val = cannir.make_shape(layout_ty.shape_type, shape_dyn)
    stride_val = cannir.make_stride(layout_ty.stride_type, stride_dyn)
    return cannir.make_layout(layout_ty, shape_val, stride_val)


# Layout operations, coordinates, and tilers.


def _shape_value_to_python(shape_val: ir.Value) -> Shape:
    """Convert a `!cannir.shape<...>` SSA value back to a Python Shape.

    Scalar leaves (rank-0 shape) become a single int; nested shapes preserve
    their tuple structure. Static leaves come from the type tree; dynamic
    leaves (-1 in the tree) materialize as `cannir.extract_dim` SSA values
    indexed in DFS flat order — matching Layout materialization.
    """
    static_tree = shape_val.type.as_tuple
    if not _has_dynamic_layout_leaf(static_tree):
        return static_tree
    return _materialize_type_tree(static_tree, shape_val)


def ceil_div(input: Shape, tiler: Tiler) -> Shape:
    """Element-wise ceiling division of `input` by `tiler`.

    Each leaf result is ``(a + b - 1) // b``. The **trailing** rank(tiler)
    flat leaves of *input* pair with *tiler*; leading prefix leaves pass
    through unchanged. Result preserves *input*'s nesting structure.

    *input* and *tiler* accept:
      - scalar ``int`` / ``ir.Value`` → treated as rank-0 (scalar)
      - nested int-tuple with ``int`` / ``ir.Value`` leaves

    Alignment is defined by the CANNBotDSL trailing-rank contract. The result type
    is fully determined at IR builder time; fully static inputs fold to an
    answer encoded entirely in the result type, with no runtime computation.

    Examples:
      ``ceil_div(10, 3) == 4``
      ``ceil_div((10, 6), (3, 4)) == (4, 2)``
      ``ceil_div((10, 6, 7), (3, 4)) == (10, 2, 2)``
    """
    res = cannir.ceil_div(
        _make_shape_value(input),
        _make_tile_value(tiler),
    )
    return _shape_value_to_python(res)


def _flatten_shape_tuple(shape):
    """Recursively flatten a (possibly nested) shape into leaf values.

    Leaf values are either Python ints or MLIR ir.Value instances.
    """
    if isinstance(shape, (list, tuple)):
        result = []
        for item in shape:
            result.extend(_flatten_shape_tuple(item))
        return result
    return [shape]


def _is_python_static_shape(shape) -> bool:
    """True iff *shape* is a (possibly nested) tree of plain Python ints."""
    if isinstance(shape, int):
        return True
    if isinstance(shape, (list, tuple)):
        return all(_is_python_static_shape(x) for x in shape)
    return False


def _row_major_unravel(idx: int, shape):
    """Pure-Python idx2crd over row-major (suffix-product) strides.

    The CANNBotDSL mixed-radix contract is:
    for flat shape ``(s_0, ..., s_{n-1})`` the leaf-order coordinate is
    ``coord[i] = (idx / prod(s_{i+1..n-1})) % s_i``. Nested shapes flatten
    in tree-leaf order before the formula and re-nest the result back.
    """
    if isinstance(shape, int):
        return idx % shape
    leaves = _flatten_shape_tuple(shape)
    n = len(leaves)
    strides = [1] * n
    for i in range(n - 2, -1, -1):
        strides[i] = strides[i + 1] * leaves[i + 1]
    flat_coord = [(idx // strides[i]) % leaves[i] for i in range(n)]
    it = iter(flat_coord)

    def rebuild(s):
        if isinstance(s, int):
            return next(it)
        return tuple(rebuild(x) for x in s)

    return rebuild(shape)


def idx2crd(
    idx: "int | ir.Value",
    shape: "Shape",
) -> "Coord | _tensor_values._Coord":
    """Unravel a linear index into a coordinate congruent with *shape*.

    Strides are derived internally from *shape* as the row-major suffix
    product (CANNBotDSL convention; equivalent to ``np.unravel_index(order='C')``).
    For nested *shape*, the result is a same-shaped nested coordinate.

    When *idx* is a Python int and *shape* is a Python tree of ints, the
    result is a plain Python (possibly nested) tuple computed at trace
    time — no MLIR op is emitted. Otherwise an MLIR CoordType SSA value
    is returned.

    Examples:
      ``idx2crd(11, (5, 4)) == (2, 3)``
      ``idx2crd(11, ((2, 3), 4)) == ((0, 2), 3)``
    """
    if isinstance(idx, int) and _is_python_static_shape(shape):
        return _row_major_unravel(idx, shape)

    shape_tree, shape_dyn = _shape_to_type_and_dynamic_values(shape)
    shape_ty = cannir.ShapeType.get(shape_tree)
    shape_val = cannir.make_shape(shape_ty, shape_dyn)

    idx_val = _index_value(idx, operation="idx2crd index")

    return cannir.idx2crd(idx_val, shape_val)


def _normalize_part_id(part_id):
    """Coerce a Python int or integer/index SSA value into i64."""
    return _index_value(part_id, operation="part_id")


def _make_partition_tiler(
    actual_shape: Shape,
    full_shape: tuple[int, int],
    *,
    axis: int = 0,
    parts: int = 2,
    alignment: int = 1,
    policy: str = "balanced",
) -> PartitionTiler:
    """Create the private runtime split plan used by ``mem_copy``."""
    if policy != "balanced":
        raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, f"only policy='balanced' is supported, got {policy!r}")
    if not isinstance(full_shape, (tuple, list)) or len(full_shape) != 2:
        raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, "full_shape must be a rank-2 tuple/list")
    if any(type(dim) is not int or (dim <= 0 and dim != -1) for dim in full_shape):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_SHAPE, f"full_shape dimensions must be positive integers or -1, got {full_shape!r}"
        )
    if axis not in (0, 1):
        raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, f"only axis=0 or axis=1 is supported, got {axis}")
    if parts != 2:
        raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, f"only parts=2 is supported, got {parts}")
    if not isinstance(alignment, int) or isinstance(alignment, bool) or alignment <= 0:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT, f"alignment must be a positive integer, got {alignment!r}"
        )
    if axis == 1 and alignment != 1:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            f"axis=1 requires alignment=1; hardware N alignment is modeled separately, got {alignment}",
        )

    shape_tree, shape_dynamic = _shape_to_type_and_dynamic_values(actual_shape)
    shape_type = cannir.ShapeType.get(shape_tree)
    shape_value = cannir.make_shape(shape_type, shape_dynamic)
    partition_type = cannir.PartitionTilerType.get(list(full_shape), axis=axis, parts=parts, alignment=alignment)
    return cannir.make_partition_tiler(partition_type, shape_value)


def _flatten_shape_tree(tree):
    flat = []

    def visit(node):
        if isinstance(node, tuple):
            for child in node:
                visit(child)
            return
        flat.append(node)

    visit(tree)
    return flat


def _static_declared_shape(raw) -> tuple[int, int]:
    """Return the static rank-2 declared shape of a tensor/ring_buffer carrier."""
    ty = raw.type
    if isinstance(ty, cannir.RingBufferType):
        ty = ty.element
    tensor_ty = cannir.TensorType(ty)
    shape_tree = tensor_ty.logical_layout.shape
    if not isinstance(shape_tree, tuple):
        shape_tree = (shape_tree,)
    flat = _flatten_shape_tree(shape_tree)
    if len(flat) != 2:
        raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, "copy split requires a flat rank-2 Tensor")
    return tuple(flat)


def _partition_full_shape_raw(raw) -> tuple[int, int]:
    definition = getattr(raw, "owner", None)
    if definition is not None and not hasattr(definition, "name"):
        definition = None

    if definition is not None and definition.name == "cannir.tile_slice":
        parent = unwrap_operand(definition.operands[0])
        ty = parent.type
        if isinstance(ty, cannir.RingBufferType):
            ty = ty.element
        parent_is_gm = cannir.PointerType(cannir.TensorType(ty).pointer).memloc == MemLoc.GM
        if not parent_is_gm:
            return _partition_full_shape_raw(parent)
        tile = definition.operands[1]
        if isinstance(tile, ir.Value) and isinstance(tile.type, cannir.TileType):
            nominal = _flatten_shape_tree(tile.type.as_tuple)
            if len(nominal) == 2 and all(
                isinstance(dim, int) and not isinstance(dim, bool) and dim > 0 for dim in nominal
            ):
                return tuple(nominal)
            return _partition_full_shape_raw(parent)
    if definition is not None and definition.name == "cannir.reinterpret_view":
        # A typed view declares its own element geometry. The source's
        # capacity is measured in a different dtype and cannot be reused.
        parent_type = unwrap_operand(definition.operands[0]).type
        result_type = raw.type
        if isinstance(parent_type, cannir.RingBufferType):
            parent_type = parent_type.element
        if isinstance(result_type, cannir.RingBufferType):
            result_type = result_type.element
        if cannir.TensorType(parent_type).pointer.dtype != cannir.TensorType(result_type).pointer.dtype:
            return _static_declared_shape(raw)
    if definition is not None and definition.name in (
        "cannir.local_slice",
        "cannir.reinterpret_view",
    ):
        parent_type = cannir.TensorType(unwrap_operand(definition.operands[0]).type)
        result_type = cannir.TensorType(raw.type)
        if (len(_flatten_shape_tree(parent_type.logical_layout.shape)) !=
                len(_flatten_shape_tree(result_type.logical_layout.shape)) or
                "layout_map" in definition.attributes):
            # A rank change or an explicit format re-anchor establishes a new
            # partition frame. Flat allocation capacity cannot supply its axes.
            return _static_declared_shape(raw)
        root_shape = _partition_full_shape_raw(unwrap_operand(definition.operands[0]))
        tile = definition.operands[1]
        window = None
        if isinstance(tile, ir.Value) and isinstance(tile.type, cannir.TileType):
            window = _flatten_shape_tree(tile.type.as_tuple)
        full = []
        for index, root_dim in enumerate(root_shape):
            leaf = window[index] if window and index < len(window) else None
            if isinstance(leaf, int) and not isinstance(leaf, bool) and leaf > 0:
                full.append(leaf)
            else:
                full.append(root_dim)
        return tuple(full)
    return _static_declared_shape(raw)


def _partition_full_shape(value) -> tuple[int, int]:
    """Recover a rank-2 partition frame; -1 denotes a runtime extent."""
    return _partition_full_shape_raw(_raw(value))


def _tile_alignment_list(alignment, leaf_count: int):
    """Normalize a user alignment argument to a flat positive-int list."""
    if isinstance(alignment, bool) or not isinstance(alignment, (int, tuple, list)):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"alignment must be an int or a sequence of ints, got {type(alignment).__name__}",
        )
    flat = [alignment] if isinstance(alignment, int) else list(alignment)
    for index, entry in enumerate(flat):
        if isinstance(entry, bool) or not isinstance(entry, int):
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE, f"alignment leaf {index} must be an int, got {type(entry).__name__}"
            )
        if entry <= 0:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT, f"alignment leaf {index} must be positive, got {entry}"
            )
    if len(flat) == 1 and leaf_count > 1:
        flat = flat * leaf_count
    if len(flat) != leaf_count:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_SHAPE,
            f"alignment rank ({len(flat)}) must match the flattened tile leaf count ({leaf_count})",
        )
    return flat


def _count_tree_leaves(tree) -> int:
    if isinstance(tree, (tuple, list)):
        return sum(_count_tree_leaves(child) for child in tree)
    return 1


def make_tiler(tiler: Tiler, *, alignment=None):
    """Create a reusable tile value, optionally declaring nominal leaf alignment.

    ``alignment`` is a positive integer or a flat tuple/list of positive
    integers in depth-first leaf order. A scalar or single entry broadcasts
    to every leaf. Static leaves must be divisible by their alignment;
    dynamic leaves require the caller to guarantee positive, divisible
    runtime values, without an inserted runtime check. ``None`` leaves the
    alignment undeclared, whereas ``1`` explicitly declares positivity.

    Pass the result to ``tile_slice``. Alignment
    describes the nominal tile, not the actual extent of a clipped tail.
    """
    tile_tree, dynamic_values = _tiler_to_type_and_dynamic_values(tiler)
    if alignment is None:
        tile_type = cannir.TileType.get(tile_tree)
    else:
        flat_alignment = _tile_alignment_list(alignment, _count_tree_leaves(tile_tree))
        tile_type = cannir.TileType.get(tile_tree, alignment=flat_alignment)
    return cannir.make_tile(tile_type, dynamic_values)


# Tensor construction, metadata, indexing, and SSBUF access.


_MEMLOC_DEFAULT_PHYSICAL_FORMAT = {
    MemLoc.GM: "nd",
    MemLoc.UB: "nd",
    MemLoc.L1: "nz",
    MemLoc.L0A: "nz",
    MemLoc.L0B: "nz",
    MemLoc.L0C: "nz",
    MemLoc.SSBUF: "nd",
}


def _layout_map_kind_for(logical_format: str, physical_format: str) -> LayoutMapKind:
    if logical_format == physical_format:
        return LayoutMapKind.Identity
    if logical_format == "nd" and physical_format == "nz":
        return LayoutMapKind.ND2NZ
    if logical_format == "nd" and physical_format == "zn":
        return LayoutMapKind.DN2NZ
    if logical_format == "nz" and physical_format == "nd":
        return LayoutMapKind.NZ2ND
    if logical_format == "zn" and physical_format == "nd":
        return LayoutMapKind.ZN2ND
    raise CANNBotValueError(
        DiagnosticCode.UNSUPPORTED_FEATURE,
        f"Unsupported logical/physical format mapping: {logical_format!r} -> {physical_format!r}",
    )


def _physical_format_for_map(layout_map_kind: LayoutMapKind) -> str:
    if layout_map_kind == LayoutMapKind.Composed:
        raise ValueError("Composed maps require the defining View to resolve their backing encoding")
    if layout_map_kind == LayoutMapKind.ND2NZ:
        return "nz"
    if layout_map_kind == LayoutMapKind.DN2NZ:
        return "zn"
    return "nd"


def _mapped_physical_layout(dtype, logical_shape, physical_format, n1_pad, *, mem_loc=MemLoc.L1):
    """Call the canonical C++ physical-layout implementation."""
    if mem_loc is None:
        mem_loc = MemLoc.L1
    from cannbot_dsl.core.contracts.elements import storage_mlir_type_for_dtype
    from cannbot_dsl.core.mlir_context import _has_current_context

    def derive():
        layout_map_kind = {"nz": 1, "zn": 2}[physical_format]
        logical_layout = cannir.LayoutType.get(logical_shape, _suffix_product(tuple(logical_shape)))
        pointer = cannir.PointerType.get(int(mem_loc), storage_mlir_type_for_dtype(dtype))
        physical_layout = cannir.derive_physical_layout(pointer, logical_layout, layout_map_kind, n1_pad)
        return tuple(physical_layout.shape), tuple(physical_layout.stride)

    if _has_current_context():
        return derive()
    with ir.Context():
        return derive()


def _physical_layout_spec(dtype, logical_shape, physical_format, n1_pad, *, mem_loc=None):
    """Return ``(physical_shape, physical_stride)`` for on-chip storage."""
    if mem_loc == MemLoc.SSBUF:
        if physical_format != "nd":
            raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "SSBUF buffers require data_format='nd'")
        if n1_pad:
            raise CANNBotValueError(DiagnosticCode.UNSUPPORTED_FEATURE, "n1_pad is not supported for SSBUF buffers")
        return logical_shape, None

    if mem_loc == MemLoc.BIAS:
        if physical_format != "nd" or len(logical_shape) != 1:
            raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, "BIAS buffers require rank-1 data_format='nd'")
        if dtype.width != 32:
            raise CANNBotValueError(DiagnosticCode.INVALID_TYPE, "BIAS buffers require float32 or int32 elements")
        if n1_pad:
            raise CANNBotValueError(DiagnosticCode.UNSUPPORTED_FEATURE, "n1_pad is not supported for BIAS buffers")
        n = logical_shape[0]
        if not isinstance(n, int) or n <= 0:
            raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, "BIAS buffers require a positive static N")
        # L1 -> BT writes float32/int32 data in 64-byte units.
        return (math.ceil(n / 16) * 16,), None

    if physical_format == "nz" and len(logical_shape) in (2, 3):
        return _mapped_physical_layout(dtype, logical_shape, physical_format, n1_pad, mem_loc=mem_loc)
    if physical_format == "zn" and len(logical_shape) in (2, 3):
        if n1_pad:
            raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "n1_pad only meaningful for data_format='nz'")
        return _mapped_physical_layout(dtype, logical_shape, physical_format, n1_pad, mem_loc=mem_loc)
    if n1_pad:
        raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "n1_pad only meaningful for data_format='nz'")
    return logical_shape, None


def _tensor_type_from_layouts(
    dtype,
    mem_loc: MemLoc,
    logical_layout: Layout,
    physical_layout: Layout | None,
    *,
    data_format: str,
):
    """Build a Tensor type from logical and physical layouts for storage or a view."""
    from cannbot_dsl.core.contracts.elements import storage_mlir_type_for_dtype

    pointer_type = cannir.PointerType.get(mem_loc, storage_mlir_type_for_dtype(dtype))
    logical_layout_value = unwrap_operand(logical_layout)
    layout_map_kind = _layout_map_kind_for("nd", data_format)
    physical_layout_type = (cannir.derive_physical_layout(pointer_type, logical_layout_value.type, int(layout_map_kind))
                            if physical_layout is None else unwrap_operand(physical_layout).type)
    return cannir.TensorType.get(
        pointer_type,
        logical_layout_value.type,
        physical_layout_type,
        int(layout_map_kind),
    )


def make_pointer(dtype: Any, addr: Union[int, ir.Value], mem_loc: MemLoc) -> _tensor_values._Pointer:
    """Create a typed pointer from a byte address.

    The address is always an absolute byte address in ``mem_loc``. A Python
    ``int`` supplies a non-negative compile-time-known address. A canonical
    signless ``i64`` SSA value supplies a runtime address and is accepted only
    for ``MemLoc.GM``; it is not an element index or an offset relative to any
    Tensor argument. Use ``dtypes.int64(value)`` or ``dtypes.uint64(value)``
    for an explicit frontend conversion.
    """
    from cannbot_dsl.core.contracts.elements import storage_mlir_type_for_dtype

    dtype_ty = storage_mlir_type_for_dtype(dtype)
    pointer_ty = cannir.PointerType.get(mem_loc, dtype_ty)
    if isinstance(addr, ir.Value):
        if mem_loc != MemLoc.GM:
            raise CANNBotValueError(
                DiagnosticCode.UNSUPPORTED_FEATURE,
                "make_pointer SSA addresses are supported only for "
                "MemLoc.GM; non-GM backend binding requires a Python int"
            )
        addr_type = addr.type
        if not (isinstance(addr_type, ir.IntegerType) and addr_type.width == 64 and addr_type.is_signless):
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                "make_pointer GM SSA addr must have canonical signless i64 "
                f"type, got {addr_type}; convert explicitly with "
                "dtypes.int64(value) or dtypes.uint64(value)"
            )
        return cannir.make_pointer(pointer_ty, addr)
    else:
        if not is_exact_instance(addr, int):
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                "make_pointer addr must be a non-negative Python int or a "
                "canonical signless i64 SSA value, got "
                f"{type(addr).__name__}; convert SSA values explicitly with "
                "dtypes.int64(value) or dtypes.uint64(value)"
            )
        if addr < 0:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT, f"make_pointer Python int addr must be non-negative, got {addr}"
            )
        if addr > (1 << 63) - 1:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT, f"make_pointer Python int addr must not exceed INT64_MAX, got {addr}"
            )
        addr_ty = ir.IntegerType.get_signless(64)
        addr_value = arith.ConstantOp(addr_ty, ir.IntegerAttr.get(addr_ty, addr)).result
    return cannir.make_pointer(pointer_ty, addr_value)


def make_tensor(
    pointer: _tensor_values._Pointer,
    layout: Layout,
    *,
    physical_layout: Layout | None = None,
    data_format: str | None = None,
) -> Tensor:
    """Bind a pointer to an ND or NZ tensor without moving data.

    ``data_format`` accepts only ``"nd"`` and ``"nz"``. ``None`` selects the
    memory-space default: NZ for L1/L0A/L0B/L0C and ND otherwise. The layout
    describes logical coordinates; ``physical_layout`` optionally supplies
    the backing shape and strides for the selected format.

    Express an ND-to-ZN copy with an NZ tensor and a logical transpose, e.g.
    ``dst = make_tensor(ptr, make_layout((N, M)), data_format="nz").permute(1, 0)``
    followed by ``mem_copy(dst, src)`` for an ND source of shape ``(M, N)``.
    """
    if data_format is None:
        data_format = _MEMLOC_DEFAULT_PHYSICAL_FORMAT.get(MemLoc(pointer.memloc), "nd")
    elif not isinstance(data_format, str):
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "make_tensor data_format must be 'nd' or 'nz'")
    if data_format not in ("nd", "nz"):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT, f"make_tensor data_format must be 'nd' or 'nz', got {data_format!r}"
        )
    return _bind_tensor(
        pointer,
        layout,
        physical_layout=physical_layout,
        layout_map_kind=_layout_map_kind_for("nd", data_format),
    )


def _bind_tensor(
    pointer: _tensor_values._Pointer,
    layout: Layout,
    *,
    physical_layout: Layout | None,
    layout_map_kind: LayoutMapKind,
) -> Tensor:
    """Bind a declared storage schema shared by Tensor and Buffer construction."""
    if layout.layout_map_kind == LayoutMapKind.Composed:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            "make_tensor requires an explicit binding map for a composed Layout; "
            "use the original View or declare a new layout with make_layout"
        )
    logical_layout_type = unwrap_operand(layout).type
    if physical_layout is None:
        physical_layout_type = cannir.derive_physical_layout(
            pointer.type,
            logical_layout_type,
            int(layout_map_kind),
        )
    else:
        physical_layout_type = unwrap_operand(physical_layout).type

    memref_type = cannir.TensorType.get(
        pointer.type,
        logical_layout_type,
        physical_layout_type,
        int(layout_map_kind),
    )
    result = cannir.make_tensor(
        memref_type,
        pointer,
        unwrap_operand(layout),
        physical_layout=unwrap_operand(physical_layout) if physical_layout is not None else None,
        map_symbols=[],
    )
    if physical_layout is not None:
        unwrap_operand(result).owner.attributes["cannir.explicit_physical_layout"] = ir.UnitAttr.get()
    return result


def _tensor_memref_type(tensor: Tensor):
    ty = unwrap_operand(tensor).type
    if cannir.RingBufferType.isinstance(ty):
        ty = cannir.RingBufferType(ty).element
    return cannir.TensorType(ty)


def _tensor_pointer_type(tensor: Tensor):
    return cannir.PointerType(_tensor_memref_type(tensor).pointer)


def _tensor_layout(tensor: Tensor) -> Layout:
    # Dynamic fields belong to this immutable View SSA value.
    return cannir.extract_layout(unwrap_operand(tensor))


def _tensor_physical_layout(tensor: Tensor) -> Layout:
    return cannir.extract_physical_layout(unwrap_operand(tensor))


def _tensor_shape(tensor: Tensor) -> Shape:
    return _tensor_layout(tensor).shape


def _tensor_stride(tensor: Tensor) -> Stride:
    if _tensor_layout_map_kind(tensor) == LayoutMapKind.Composed:
        raise CANNBotValueError(
            DiagnosticCode.UNSUPPORTED_FEATURE,
            "View has no per-axis memory stride; use its physical_layout and index map",
        )
    return _tensor_layout(tensor).stride


def _tensor_dtype(tensor: Tensor):
    from cannbot_dsl.core.contracts.elements import dtype_for_storage_mlir_type

    return dtype_for_storage_mlir_type(_tensor_pointer_type(tensor).dtype)


def _tensor_storage_type(tensor: Tensor):
    return _tensor_pointer_type(tensor).dtype


def _tensor_memloc(tensor: Tensor) -> MemLoc:
    return MemLoc(_tensor_pointer_type(tensor).memloc)


def _tensor_layout_map_kind(tensor: Tensor):
    return LayoutMapKind(_tensor_memref_type(tensor).layout_map_kind)


def _tensor_physical_format(tensor: Tensor) -> str:
    return _physical_format_for_map(_tensor_layout_map_kind(tensor))


_I64_MIN = -(1 << 63)
_I64_MAX = (1 << 63) - 1

_TENSOR_VIEW_MEMLOCS = frozenset(
    (
        MemLoc.GM,
        MemLoc.UB,
        MemLoc.L1,
        MemLoc.L0A,
        MemLoc.L0B,
        MemLoc.L0C,
        MemLoc.SSBUF,
        MemLoc.BIAS,
        MemLoc.FBUF,
        MemLoc.FBUF_ACT,
    )
)


def _validate_tensor_index_integer_type(value, where: str, *, bound: bool) -> None:
    """Validate only the Python/SSA type of one Tensor integer leaf."""

    noun = "slice bound" if bound else "integer coordinate"
    if isinstance(value, bool):
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"{where}: {noun} must not be bool")
    if is_exact_instance(value, int):
        return
    _validate_index_value(value, operation=f"{where}: {noun}")


def _validate_tensor_index_integer(value, where: str, *, bound: bool) -> None:
    """Validate one route-selected Tensor integer leaf."""

    _validate_tensor_index_integer_type(value, where, bound=bound)
    if not is_exact_instance(value, int):
        return
    if value < _I64_MIN or value > _I64_MAX:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            f"{where}: integer {_render_literal(value)} is outside the signed i64 range",
        )
    if value < 0:
        noun = "slice bounds" if bound else "integer Tensor coordinates"
        raise CANNBotNotImplementedError(
            DiagnosticCode.UNSUPPORTED_FEATURE, f"{where}: negative {noun} are not supported"
        )


class _TensorIndexIntent(_IntEnum):
    """Semantic route selected for one complete Tensor index tree."""

    POINT = 0
    KEEP = 1
    INTERVAL = 2


def _classify_tensor_index_intent(index, *, api_name: str) -> _TensorIndexIntent:
    """Classify and syntax-check a Tensor index in one DFS traversal.

    Tuple children are visited left-to-right so a compound invalid key reports
    its first invalid node. A list or Ellipsis is rejected at the node itself
    without inspecting any value it contains. For valid trees, interval intent
    dominates keep intent, which in turn dominates point intent.
    """

    def visit(node, where: str) -> _TensorIndexIntent:
        if isinstance(node, list):
            raise CANNBotTypeError(
                DiagnosticCode.UNSUPPORTED_FEATURE, f"{where}: Tensor list/fancy indexing is not supported; use a tuple"
            )
        if node is Ellipsis:
            raise CANNBotTypeError(
                DiagnosticCode.UNSUPPORTED_FEATURE,
                f"{where}: Tensor ellipsis indexing is not supported; explicitly cover the complete shape tree"
            )
        if isinstance(node, tuple):
            intent = _TensorIndexIntent.POINT
            for child_index, child in enumerate(node):
                child_intent = visit(child, f"{where}[{child_index}]")
                if child_intent > intent:
                    intent = child_intent
            return intent
        if node is None:
            return _TensorIndexIntent.KEEP
        if isinstance(node, slice):
            if node.start is None and node.stop is None and node.step is None:
                raise CANNBotTypeError(
                    DiagnosticCode.UNSUPPORTED_FEATURE,
                    f"{where}: fully open Tensor slice ':' is not supported; use None to keep an axis or shape subtree"
                )
            for name, bound in (("start", node.start), ("stop", node.stop), ("step", node.step)):
                if bound is not None:
                    _validate_tensor_index_integer_type(bound, f"{where}.{name}", bound=True)
            return _TensorIndexIntent.INTERVAL

        # Classification owns accepted leaf types only. Value range, sign,
        # tree congruence, and bounds are checked after the route is known.
        _validate_tensor_index_integer_type(node, where, bound=False)
        return _TensorIndexIntent.POINT

    return visit(index, f"{api_name} key")


def _validate_static_fixed_coord(shape, coord, *, where: str) -> None:
    """Validate one fixed coordinate leaf against one logical shape leaf."""

    _validate_tensor_index_integer(coord, where, bound=False)
    if isinstance(coord, ir.Value) and shape != cannir.ShapeType.DYNAMIC and shape == 0:
        raise CANNBotIndexError(DiagnosticCode.INVALID_ARGUMENT, f"{where}: dynamic coordinate is outside [0, 0)")
    if is_exact_instance(coord, int) and shape != cannir.ShapeType.DYNAMIC and coord >= shape:
        raise CANNBotIndexError(DiagnosticCode.INVALID_ARGUMENT, f"{where}: coordinate {coord} is outside [0, {shape})")


def _make_point_coord(
    tensor: Tensor,
    index,
    *,
    api_name: str,
    intent: Optional[_TensorIndexIntent] = None,
):
    """Validate and encode a complete Tensor point coordinate.

    A scalar coordinate is accepted for a root one-dimensional shape only.
    Every other coordinate must be recursively congruent with the logical
    shape tree. Runtime coordinates and dynamic extents remain caller-managed.
    """

    if intent is None:
        intent = _classify_tensor_index_intent(index, api_name=api_name)
    if intent is not _TensorIndexIntent.POINT:
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"{api_name} requires one integer coordinate per axis/logical "
            "shape leaf; slice and None coordinates are not supported"
        )

    static_shape = _logical_shape_type_tree(tensor)
    validation_shape = static_shape
    if (
        isinstance(static_shape, tuple)
        and len(static_shape) == 1
        and not isinstance(static_shape[0], tuple)
        and not isinstance(index, tuple)
    ):
        # Preserve the sole compatibility shorthand: shape ``(N,)`` accepts
        # both ``x[i]`` and the exact-tree spelling ``x[(i,)]``. Do not peel a
        # nested single-leaf subtree.
        validation_shape = static_shape[0]
    dynamic_values = []

    def normalize(shape, coordinate, *, where: str):
        if isinstance(coordinate, tuple) and not coordinate:
            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"{where}: empty tuple is not a Tensor point index")
        if isinstance(shape, tuple):
            if not isinstance(coordinate, tuple):
                raise CANNBotTypeError(
                    DiagnosticCode.INVALID_SHAPE,
                    f"{where}: point index tree must match shape subtree {shape!r} exactly",
                )
            if len(coordinate) != len(shape):
                raise CANNBotValueError(
                    DiagnosticCode.INVALID_SHAPE,
                    f"{where}: point index tree has {len(coordinate)} children but shape subtree has {len(shape)}"
                )
            return tuple(
                normalize(
                    subshape,
                    child,
                    where=f"{where}[{child_index}]",
                )
                for child_index, (subshape, child) in enumerate(zip(shape, coordinate))
            )

        if isinstance(coordinate, tuple):
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_SHAPE, f"{where}: tuple point index cannot match scalar shape leaf {shape!r}"
            )
        _validate_static_fixed_coord(shape, coordinate, where=where)
        if isinstance(coordinate, ir.Value):
            dynamic_values.append(_index_value(coordinate, operation=where))
            return cannir.CoordType.DYNAMIC
        return coordinate

    coord_tree = normalize(validation_shape, index, where=f"{api_name} coordinate")
    return cannir.make_coord(cannir.CoordType.get(coord_tree), dynamic_values)


def _validate_keep_index_tree(shape, index, where: str = "key") -> None:
    """Validate a legacy keep view without interpreting slices."""

    if index is None:
        return
    if isinstance(shape, tuple):
        if isinstance(index, slice):
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE, f"{where}: Tensor slices are not valid in a keep-only view"
            )
        if not isinstance(index, tuple):
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_SHAPE, f"{where}: keep index tree must match shape subtree {shape!r} exactly"
            )
        if len(index) != len(shape):
            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE,
                f"{where}: keep index tree has {len(index)} children but shape subtree has {len(shape)}",
            )
        for child_index, (subshape, child) in enumerate(zip(shape, index)):
            _validate_keep_index_tree(subshape, child, f"{where}[{child_index}]")
        return

    if isinstance(index, tuple):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_SHAPE, f"{where}: tuple index cannot match scalar shape leaf {shape!r}"
        )
    if isinstance(index, slice):
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"{where}: Tensor slices are not valid in a keep-only view")
    _validate_static_fixed_coord(shape, index, where=where)


def _validate_interval_index_tree(shape, index, where: str = "key") -> None:
    # None preserves every leaf in this exact shape subtree. Tuples otherwise
    # have to mirror the complete shape tree.
    if index is None:
        return
    if isinstance(shape, tuple):
        if isinstance(index, slice):
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                f"{where}: a non-trivial Tensor slice may only index a shape leaf; "
                "use None to preserve a complete subtree"
            )
        if not isinstance(index, tuple):
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_SHAPE, f"{where}: index tree must match shape subtree {shape!r} exactly"
            )
        if len(index) != len(shape):
            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE,
                f"{where}: index tree has {len(index)} children but shape subtree has {len(shape)}",
            )
        for child_index, (subshape, child) in enumerate(zip(shape, index)):
            _validate_interval_index_tree(subshape, child, f"{where}[{child_index}]")
        return

    if isinstance(index, tuple):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_SHAPE, f"{where}: tuple index cannot match scalar shape leaf {shape!r}"
        )
    if isinstance(index, slice):
        if index.start is not None:
            _validate_tensor_index_integer(index.start, f"{where}.start", bound=True)
        if index.stop is not None:
            _validate_tensor_index_integer(index.stop, f"{where}.stop", bound=True)
        if index.step is not None:
            _validate_tensor_index_integer_type(index.step, f"{where}.step", bound=True)
            step = _constant_i64(index.step)
            if step is not None and not 0 < step <= _I64_MAX:
                raise CANNBotValueError(
                    DiagnosticCode.INVALID_ARGUMENT,
                    f"{where}.step: Tensor slice step must be a positive signed i64 integer",
                )
        return
    _validate_static_fixed_coord(shape, index, where=where)


def _logical_shape_type_tree(tensor: Tensor):
    memref_type = _tensor_memref_type(tensor)
    return cannir.LayoutType(memref_type.logical_layout).shape


def _materialize_logical_shape_tree(tensor: Tensor, static_shape):
    if not _has_dynamic_layout_leaf(static_shape):
        return static_shape
    layout = tensor.layout
    return _materialize_type_tree(
        static_shape,
        cannir.extract_shape(unwrap_operand(layout)),
    )


class _SliceNormalizer:
    """Build interval starts and nonnegative extents, including empty domains.

    Only non-negative Python literals are clipped, and only when the parent
    extent is static.  SSA values are absolute caller-managed coordinates and
    never cause runtime clipping or checking IR to be emitted.
    """

    def normalize(self, bound, extent):
        if is_exact_instance(bound, int):
            if bound < 0:
                raise CANNBotNotImplementedError(
                    DiagnosticCode.UNSUPPORTED_FEATURE, "negative Tensor slice bounds are not supported"
                )
            return min(bound, extent) if is_exact_instance(extent, int) else bound
        return bound

    def interval(self, interval: slice, extent):
        start = 0 if interval.start is None else self.normalize(interval.start, extent)
        stop = extent if interval.stop is None else self.normalize(interval.stop, extent)
        step = 1 if interval.step is None else interval.step
        size, step = build_slice_extent(start, stop, step, parent_extent=extent)
        return start, size, step

    def coordinate(self, value):
        if isinstance(value, ir.Value):
            return _index_value(value, operation="slice coordinate")
        return value


def _fill_index_subtree(shape, coord_leaf, size_leaf, step_leaf):
    if isinstance(shape, tuple):
        children = [_fill_index_subtree(child, coord_leaf, size_leaf, step_leaf) for child in shape]
        return tuple(tuple(child[i] for child in children) for i in range(3))
    return coord_leaf, size_leaf, step_leaf


def _build_interval_index_trees(shape, index, normalizer: _SliceNormalizer):
    if index is None:
        return _fill_index_subtree(shape, None, 1, 1)
    if isinstance(shape, tuple):
        children = [_build_interval_index_trees(subshape, child, normalizer) for subshape, child in zip(shape, index)]
        return tuple(tuple(child[i] for child in children) for i in range(3))
    if isinstance(index, slice):
        return normalizer.interval(index, shape)
    return normalizer.coordinate(index), 1, 1


def _tensor_interval_slice(tensor: Tensor, index):
    static_shape = _logical_shape_type_tree(tensor)
    if (isinstance(index, slice) and isinstance(static_shape, tuple)
            and len(static_shape) == 1 and not isinstance(static_shape[0], tuple)):
        index = (index,)
    _validate_interval_index_tree(static_shape, index)
    shape = _materialize_logical_shape_tree(tensor, static_shape)
    coord, sizes, steps = _build_interval_index_trees(shape, index, _SliceNormalizer())
    coord_tree, coord_dynamic = _coord_to_type_and_dynamic_values(coord)
    sizes_tree, sizes_dynamic = _shape_to_type_and_dynamic_values(sizes)
    coord_value = cannir.make_coord(cannir.CoordType.get(coord_tree), coord_dynamic)
    sizes_value = cannir.make_shape(cannir.ShapeType.get(sizes_tree), sizes_dynamic)
    if all(type(s) is int and s == 1 for s in _flatten_shape_tree(steps)):
        return _transform("slice", tensor, coord_value, sizes_value)
    steps_tree, steps_dynamic = _shape_to_type_and_dynamic_values(steps)
    steps_value = cannir.make_shape(cannir.ShapeType.get(steps_tree), steps_dynamic)
    return _transform("slice", tensor, coord_value, sizes_value, steps_value)


def _tensor_getitem(tensor: Tensor, coord):
    intent = _classify_tensor_index_intent(coord, api_name="Tensor.__getitem__")
    if intent is _TensorIndexIntent.INTERVAL:
        return _tensor_interval_slice(tensor, coord)

    if intent is _TensorIndexIntent.KEEP:
        _validate_keep_index_tree(_logical_shape_type_tree(tensor), coord)
        coord_tree, coord_dyn = _coord_to_type_and_dynamic_values(coord)
        coord_value = cannir.make_coord(cannir.CoordType.get(coord_tree), coord_dyn)
        return _transform("slice", tensor, coord_value)
    if _tensor_memloc(tensor) == MemLoc.SSBUF:
        from cannbot_dsl.core.ssbuf import ssbuf_execution_core

        return _ssbuf_tensor_getitem(tensor, coord, core=ssbuf_execution_core())
    coord_value = _make_point_coord(tensor, coord, api_name="Tensor load", intent=intent)
    from cannbot_dsl.core.contracts.elements import wrap_produced_scalar
    from cannbot_dsl.lang.vf import _current_vf_mode

    value = _load(tensor, coord_value)
    if _current_vf_mode() == "simt":
        from cannbot_dsl.core.contracts.elements import wrap_produced_simt_scalar

        return wrap_produced_simt_scalar(value, storage_type=_tensor_storage_type(tensor))
    return wrap_produced_scalar(value, storage_type=_tensor_storage_type(tensor))


def _tensor_setitem(tensor: Tensor, coord, value) -> None:
    intent = _classify_tensor_index_intent(coord, api_name="Tensor.__setitem__")
    if intent is not _TensorIndexIntent.POINT:
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            "Tensor point assignment requires one integer coordinate per axis; "
            "slice and None coordinates are not supported"
        )
    if _tensor_memloc(tensor) == MemLoc.SSBUF:
        from cannbot_dsl.core.ssbuf import ssbuf_execution_core

        _ssbuf_tensor_setitem(tensor, coord, value, core=ssbuf_execution_core())
        return
    memloc = _tensor_memloc(tensor)
    from cannbot_dsl.lang.vf import _current_vf_mode

    simt_mode = _current_vf_mode() == "simt"
    if memloc == MemLoc.UB:
        if _current_vf_mode() == "simd":
            raise CANNBotNotImplementedError(
                DiagnosticCode.UNSUPPORTED_FEATURE,
                "UB point assignment is not supported inside SIMD VF; move the scalar assignment outside the VF"
            )
    elif memloc != MemLoc.GM:
        raise CANNBotNotImplementedError(
            DiagnosticCode.UNSUPPORTED_FEATURE, "Tensor point assignment currently supports only GM and UB tensors"
        )

    coord_value = _make_point_coord(
        tensor,
        coord,
        api_name="Tensor point assignment",
        intent=intent,
    )

    storage_type = _tensor_storage_type(tensor)
    if simt_mode:
        from cannbot_dsl.ops.simt import _coerce_simt_storage

        storage_value = _coerce_simt_storage(value, storage_type, path="Tensor point assignment value")
    else:
        from cannbot_dsl.core.contracts.elements import coerce_scalar_to_storage

        storage_value = coerce_scalar_to_storage(value, storage_type, path="Tensor point assignment value")
    _store(storage_value, tensor, coord_value)


def _ssbuf_point_coord(tensor: Tensor, coord, *, api_name: str):
    intent = _classify_tensor_index_intent(coord, api_name=api_name)
    if _tensor_memloc(tensor) != MemLoc.SSBUF:
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"{api_name} requires a MemLoc.SSBUF tensor")
    return _make_point_coord(tensor, coord, api_name=api_name, intent=intent)


def _ssbuf_tensor_getitem(tensor: Tensor, coord, *, core: str):
    coord_value = _ssbuf_point_coord(tensor, coord, api_name=f"SSBUF {core} load")
    value = _load(tensor, coord_value, core=core)

    from cannbot_dsl.core.contracts.elements import wrap_produced_scalar

    return wrap_produced_scalar(value, storage_type=_tensor_storage_type(tensor))


def _ssbuf_tensor_setitem(tensor: Tensor, coord, value, *, core: str) -> None:
    coord_value = _ssbuf_point_coord(tensor, coord, api_name=f"SSBUF {core} store")
    from cannbot_dsl.core.contracts.elements import coerce_scalar_to_storage

    storage_type = _tensor_storage_type(tensor)
    storage_value = coerce_scalar_to_storage(value, storage_type, path=f"SSBUF {core} store value")
    _store(storage_value, tensor, coord_value, core=core)


# Tensor views and partitioning.


def from_tensor(input, dtype=None, layout=None, *, physical_layout=None, offset: int = 0, data_format=None):
    """Bind a zero-copy Tensor view to the selected storage address.

    GM and on-chip Tensors share this interface. No data is allocated or moved.
    ``layout`` declares the logical shape and strides in target-dtype elements.
    ``physical_layout`` optionally declares the backing geometry, including
    padding and physical strides. Both accept Layout values from make_layout;
    their dimensions and strides may be runtime SSA values. When a new logical
    layout is supplied, an omitted physical layout is derived from its format.
    Omitting both layouts and the format preserves the input layout.

    ``offset`` is a non-negative byte displacement, either a Python int or an
    i64 SSA value. Capacity is not checked: the caller must ensure that every
    access through the view fits the backing storage.
    ``data_format`` defaults to the input format; an explicit format rebinds
    the same bytes, without converting or transposing data. The view retains
    the input's allocation and synchronization identity.
    """
    from cannbot_dsl.core.contracts.elements import (
        normalize_storage_dtype,
        storage_mlir_type_for_dtype,
    )

    if not isinstance(input, Tensor):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            "from_tensor expects a Tensor; select a RingBuffer slot with next_write()/next_read() first",
        )
    for name, value in (("layout", layout), ("physical_layout", physical_layout)):
        if value is not None and not isinstance(value, Layout):
            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"from_tensor {name} must be a Layout")
        if value is not None and value.layout_map_kind == LayoutMapKind.Composed:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT, f"from_tensor {name} requires an explicit layout made with make_layout"
            )
    runtime_offset = isinstance(offset, ir.Value)
    if not is_exact_instance(offset, int) and not runtime_offset:
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE, "from_tensor offset must be a compile-time int (bytes) or an i64 SSA value"
        )
    if not runtime_offset and offset < 0:
        raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "from_tensor offset must be non-negative")
    if not runtime_offset and offset > (1 << 63) - 1:
        raise CANNBotOverflowError(DiagnosticCode.INVALID_ARGUMENT, "from_tensor offset exceeds signed int64")
    dtype = input.dtype if dtype is None else normalize_storage_dtype(dtype)
    if not dtype.is_packed_sub_byte and (dtype.width <= 0 or dtype.width % 8):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_TYPE, "from_tensor dtype requires whole-byte storage or a packed sub-byte carrier"
        )
    if data_format is not None and data_format not in ("nd", "nz", "zn"):
        raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "from_tensor data_format must be 'nd', 'nz', or 'zn'")

    # Preserve the existing no-layout dtype view, including its element count.
    # Same-dtype address rebinding uses StorageCast too: LocalSlice describes
    # a window inside its parent and must not impose that bound on from_tensor.
    if (layout is None and physical_layout is None and data_format is None
            and not runtime_offset and (dtype != input.dtype or offset == 0)):
        tile_tree, tile_dyn = _tiler_to_type_and_dynamic_values(input.shape)
        tile = cannir.make_tile(cannir.TileType.get(tile_tree), tile_dyn)
        result = _transform("reinterpret", input, tile,
                            dtype=ir.TypeAttr.get(storage_mlir_type_for_dtype(dtype)),
                            offset_bytes=offset, preserve_layout=ir.UnitAttr.get())
        return result

    if layout is None:
        layout = input.layout
        if physical_layout is None and data_format is None:
            physical_layout = input.physical_layout
    data_format = input.data_format if data_format is None else data_format
    if input.memloc == MemLoc.SSBUF and data_format != "nd":
        raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "SSBUF views require data_format='nd'")
    if data_format in ("nz", "zn") and len(layout.shape) not in (2, 3):
        raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, "NZ/ZN from_tensor requires rank 2 or 3")
    result_type = _tensor_type_from_layouts(
        dtype, input.memloc, layout, physical_layout, data_format=data_format,
    )
    result = _transform(
        "storage_cast", input, schema=ir.TypeAttr.get(result_type),
        dtype=ir.TypeAttr.get(storage_mlir_type_for_dtype(dtype)),
        offset_bytes=0 if runtime_offset else offset,
        layout=unwrap_operand(layout),
        physical_layout=unwrap_operand(physical_layout) if physical_layout is not None else None,
        offset=_index_value(offset, operation="from_tensor offset") if runtime_offset else None,
    )
    if physical_layout is not None:
        unwrap_operand(result).owner.attributes["cannir.explicit_physical_layout"] = ir.UnitAttr.get()
    return result


def _flat_view_rank(memref_type, op_name: str) -> int:
    logical = cannir.LayoutType(memref_type.logical_layout).shape
    physical = cannir.LayoutType(memref_type.physical_layout).shape

    # ShapeType's recursive representation spells the empty Python tuple as
    # the scalar value 0.  No non-empty public TensorSpec uses that spelling,
    # so it is the canonical rank-zero representation here.
    if logical == 0 and physical == 0:
        return 0
    if not isinstance(logical, tuple) or not isinstance(physical, tuple):
        raise CANNBotNotImplementedError(
            DiagnosticCode.UNSUPPORTED_FEATURE, f"{op_name} currently supports only flat Tensor layouts"
        )
    if any(isinstance(dim, (tuple, list)) for dim in logical) or any(
        isinstance(dim, (tuple, list)) for dim in physical
    ):
        raise CANNBotNotImplementedError(
            DiagnosticCode.UNSUPPORTED_FEATURE, f"{op_name} currently supports only flat Tensor layouts"
        )
    if len(logical) != len(physical):
        raise CANNBotNotImplementedError(
            DiagnosticCode.UNSUPPORTED_FEATURE, f"{op_name} requires logical and physical layouts with matching rank"
        )
    return len(logical)


def _normalize_permutation(dims, rank: int) -> tuple[int, ...]:
    if not isinstance(dims, (tuple, list)):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE, "permute dims must be a compile-time tuple or list of integers"
        )
    if len(dims) != rank:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_SHAPE, f"permute dims must contain exactly {rank} axes, got {len(dims)}"
        )

    normalized = []
    for index, dim in enumerate(dims):
        if isinstance(dim, bool) or not isinstance(dim, int):
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                f"permute dims must contain only compile-time integers; dims[{index}] is {type(dim).__name__}"
            )
        if dim < 0:
            dim += rank
        if dim < 0 or dim >= rank:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE, f"permute dims[{index}] is out of range for rank {rank}"
            )
        normalized.append(dim)
    if len(set(normalized)) != rank:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_SHAPE, f"permute dims must be a complete permutation, got {tuple(normalized)!r}"
        )
    return tuple(normalized)


def _runtime_extent_carrier(dim):
    """Return the i64 SSA carrier for a runtime extent, else None.

    DSL integer wrappers (``Int64`` and friends) subclass ``ir.Value``, so one
    isinstance check covers both a raw SSA value and a wrapped one.
    """

    if not isinstance(dim, ir.Value):
        return None
    return _index_value(dim, operation="Tensor.view runtime extent")


def _checked_view_product(values, *, what: str) -> int:
    product = 1
    for value in values:
        product *= value
        if product > _I64_MAX:
            raise CANNBotOverflowError(DiagnosticCode.INVALID_SHAPE, f"{what} element count overflows int64")
    return product


def _normalize_tensor_view_shape(input: Tensor, shape) -> tuple:
    if not isinstance(shape, (tuple, list)):
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "Tensor.view shape must be a tuple/list or dimensions")
    if not shape:
        raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, "Tensor.view shape must not be empty")

    normalized = []
    inferred_axis = None
    for index, extent in enumerate(shape):
        carrier = _runtime_extent_carrier(extent)
        if carrier is not None:
            integer_type = ir.IntegerType(carrier.type)
            if not integer_type.is_signless:
                raise CANNBotTypeError(
                    DiagnosticCode.INVALID_TYPE, f"Tensor.view shape[{index}] must be a signless i64 value"
                )
            constant = _constant_i64(carrier)
            if constant is None:
                normalized.append(carrier)
                continue
            extent = constant
        if isinstance(extent, bool) or not isinstance(extent, int):
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                "Tensor.view shape entries must be Python ints or signless i64 "
                f"values; shape[{index}] is {type(extent).__name__}"
            )
        if extent == -1:
            if inferred_axis is not None:
                raise CANNBotValueError(
                    DiagnosticCode.INVALID_SHAPE, "Tensor.view permits at most one inferred -1 axis"
                )
            inferred_axis = index
        elif extent <= 0:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE, f"Tensor.view shape[{index}] = {extent} must be positive or -1"
            )
        normalized.append(extent)

    if inferred_axis is not None:
        source_type = _tensor_memref_type(input)
        source_shape = cannir.LayoutType(source_type.logical_layout).shape
        if not isinstance(source_shape, tuple) or any(
            not is_exact_instance(extent, int) or extent <= 0 for extent in source_shape
        ):
            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE,
                "Tensor.view can infer -1 only when the source shape is positive and fully static",
            )
        other = []
        for index, extent in enumerate(normalized):
            if index == inferred_axis:
                continue
            constant = _constant_i64(extent)
            if constant is None or constant <= 0:
                raise CANNBotValueError(
                    DiagnosticCode.INVALID_SHAPE,
                    "Tensor.view can infer -1 only when every other target "
                    "dimension is statically evaluable and positive"
                )
            other.append(constant)
        source_numel = _checked_view_product(source_shape, what="source shape")
        known_numel = _checked_view_product(other, what="target shape")
        if source_numel % known_numel:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE,
                "Tensor.view inferred dimension is not integral: source "
                f"numel {source_numel} is not divisible by {known_numel}"
            )
        inferred = source_numel // known_numel
        if inferred <= 0:
            raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, "Tensor.view inferred dimension must be positive")
        normalized[inferred_axis] = inferred
    return tuple(normalized)


def _shape_view(input: Tensor, target_shape) -> Tensor:
    from cannbot_dsl.ring_buffer import RingBuffer

    if isinstance(input, RingBuffer):
        raise CANNBotNotImplementedError(
            DiagnosticCode.UNSUPPORTED_FEATURE, "Tensor.view does not support RingBuffer values"
        )
    if not isinstance(input, Tensor):
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"Tensor.view expects a Tensor, got {type(input).__name__}")
    memref_type = _tensor_memref_type(input)
    if input.dtype.bits not in (8, 16, 32, 64):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_TYPE, "Tensor.view supports only canonical 8/16/32/64-bit non-bool dtypes"
        )
    if input.memloc not in _TENSOR_VIEW_MEMLOCS:
        raise CANNBotNotImplementedError(
            DiagnosticCode.UNSUPPORTED_FEATURE, f"Tensor.view does not support memory location {input.memloc.name}"
        )
    if _tensor_layout_map_kind(input) != LayoutMapKind.Identity:
        raise CANNBotNotImplementedError(
            DiagnosticCode.UNSUPPORTED_FEATURE, "Tensor.view supports only Identity/ND Tensors"
        )
    rank = _flat_view_rank(memref_type, "Tensor.view")
    if rank == 0:
        raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, "Tensor.view does not support rank-0 Tensors")

    normalized = _normalize_tensor_view_shape(input, target_shape)
    encoded = []
    dynamic_values = []
    for extent in normalized:
        carrier = _runtime_extent_carrier(extent)
        if carrier is None:
            encoded.append(extent)
        else:
            encoded.append(cannir.ShapeType.DYNAMIC)
            dynamic_values.append(carrier)
    return _transform("packed_reshape", input, *dynamic_values, new_shape=ir.DenseI64ArrayAttr.get(encoded))


def _dtype_view(input: Tensor, dtype) -> Tensor:
    from cannbot_dsl.ring_buffer import RingBuffer
    from cannbot_dsl.core.contracts.elements import normalize_storage_dtype, storage_mlir_type_for_dtype

    if isinstance(input, RingBuffer):
        raise CANNBotNotImplementedError(
            DiagnosticCode.UNSUPPORTED_FEATURE, "Tensor.view does not support RingBuffer values")
    if not isinstance(input, Tensor):
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"Tensor.view expects a Tensor, got {type(input).__name__}")
    dtype = normalize_storage_dtype(dtype)
    source_dtype = input.dtype
    if source_dtype.bits not in (8, 16, 32, 64) or dtype.bits not in (8, 16, 32, 64):
        raise CANNBotValueError(DiagnosticCode.INVALID_TYPE,
                                "Tensor.view dtype overload supports only canonical 8/16/32/64-bit non-bool dtypes")

    memref_type = _tensor_memref_type(input)
    if input.memloc not in _TENSOR_VIEW_MEMLOCS:
        raise CANNBotNotImplementedError(
            DiagnosticCode.UNSUPPORTED_FEATURE,
            f"Tensor.view dtype overload does not support memory location {input.memloc.name}")
    if _tensor_layout_map_kind(input) != LayoutMapKind.Identity:
        raise CANNBotNotImplementedError(
            DiagnosticCode.UNSUPPORTED_FEATURE, "Tensor.view dtype overload supports only Identity/ND Tensors")
    rank = _flat_view_rank(memref_type, "Tensor.view(dtype)")
    if rank == 0:
        raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, "Tensor.view dtype overload requires rank > 0")
    layout = cannir.LayoutType(memref_type.logical_layout)
    shape = layout.shape
    stride = layout.stride
    if not isinstance(shape, tuple) or not isinstance(stride, tuple):
        raise CANNBotNotImplementedError(
            DiagnosticCode.UNSUPPORTED_FEATURE, "Tensor.view dtype overload requires a flat layout")
    if len(shape) != len(stride) or stride[-1] != 1:
        raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, "Tensor.view dtype overload requires last stride == 1")
    if any(extent != cannir.ShapeType.DYNAMIC and extent <= 0 for extent in shape):
        raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, "Tensor.view dtype overload requires positive extents")

    if dtype.bits > source_dtype.bits:
        ratio = dtype.bits // source_dtype.bits
        affected = ((shape[-1], cannir.ShapeType.DYNAMIC),
                    *((step, cannir.StrideType.DYNAMIC) for step in stride[:-1]))
        if any(value != dynamic and value % ratio for value, dynamic in affected):
            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE,
                "Tensor.view dtype widening requires every affected static "
                "final extent and non-final stride to be statically divisible "
                "by the "
                f"byte-width ratio {ratio}"
            )

    if source_dtype == dtype:
        return input
    target_type = storage_mlir_type_for_dtype(dtype)
    return _transform("dtype", input, dtype=ir.TypeAttr.get(target_type))


def _tensor_view_dispatch(input: Tensor, *shape, dtype=None) -> Tensor:
    """Private overload dispatcher backing :meth:`Tensor.view`."""

    from cannbot_dsl.types.dtypes import DType

    if shape and dtype is not None:
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_ARGUMENT, "Tensor.view positional arguments and dtype= are mutually exclusive"
        )
    if dtype is not None:
        return _dtype_view(input, dtype)
    if len(shape) == 1 and is_exact_instance(shape[0], DType):
        return _dtype_view(input, shape[0])
    if not shape:
        raise CANNBotTypeError(DiagnosticCode.INVALID_ARGUMENT, "Tensor.view requires a shape or dtype")
    target = shape[0] if len(shape) == 1 and isinstance(shape[0], (tuple, list)) else shape
    return _shape_view(input, target)


def tile_slice_multi(input: Tensor, block_shape, *, repeats, step):
    """Describe repeated complete tiles for mem_copy, shaped (R, BM, BN).

    step is the nonnegative logical element distance between tile origins,
    independent of tile_slice's block-index coordinates. Source zero steps
    broadcast a block. Destination reuse is controlled by the caller. Both copy ends
    must have matching block_shape and repeats. Uses existing block DMA paths.
    """
    from cannbot_dsl.ops.memcpy import _tile_slice_multi

    return _tile_slice_multi(input, block_shape, repeats=repeats, step=step)


def tile_slice(
    input: Tensor,
    tiler: Tiler,
    coord: Coord,
) -> Tensor:
    """Create a zero-copy alias view of one logical tile.

    For an input of rank ``N`` and a ``tiler`` with ``K`` leaves, ``tiler`` and
    ``coord`` address the trailing ``K`` logical dimensions. The view origin is
    shifted by
    ``sum(coord[i] * tiler[i] * input.stride[N - K + i])``. ``coord`` is a
    tile index, not an element coordinate, and ``tiler`` is the nominal tile
    used to compute that origin.

    The result shape follows the tiler tree. A final partial tile reports its
    tail-aware actual extent while retaining the input's corresponding
    trailing strides; no data is copied or repacked. A tuple/list shape is
    shorthand for ``make_tiler(shape)``. Declare alignment by constructing
    ``make_tiler(shape, alignment=...)`` explicitly; the resulting tile value
    can be reused for multiple tensors and coordinates. Dynamic leaves require
    this declaration, for both GM and on-chip inputs. Tail
    extents need not be divisible by the nominal tile's declared alignment.

    Coordinates must be nonnegative and address arithmetic must fit the
    target pointer width. A window past the parent domain has zero extent;
    a divisible parent alone does not prove that a dynamic coordinate is in
    bounds. Empty extent queries remain valid, including far-past-end indices.
    Mapped layouts retain the parent's physical pitch and index-map phase.
    A window that cannot simplify to a standard encoding carries a composed
    map. The consuming operation checks its own instruction restrictions.

    Select a RingBuffer slot with next_write()/next_read() before taking a tile. The
    resulting view keeps the selected slot and its buffer identity.
    """
    if tiler is None or coord is None:
        raise CANNBotTypeError(DiagnosticCode.INVALID_ARGUMENT, "tile_slice requires (tiler, coord)")
    if not isinstance(input, Tensor):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            "tile_slice expects a Tensor; select a RingBuffer slot with next_write()/next_read() first",
        )

    # A view retains the selected Tensor's storage identity. Slot selection
    # already happened in the caller; creating the view never advances it.
    if isinstance(tiler, ir.Value) and isinstance(tiler.type, cannir.TileType):
        tile_value = tiler
    else:
        tile_value = make_tiler(tiler)
    coord_tree, coord_dyn = _coord_to_type_and_dynamic_values(coord)
    coord_ty = cannir.CoordType.get(coord_tree)
    coord_value = cannir.make_coord(coord_ty, coord_dyn)
    res = _transform("tile", input, tile_value, coord_value)
    return res


def _raw(value):
    return object.__getattribute__(value, "_ssa_value") if isinstance(value, (Tensor, Layout)) else value


_VALUE_VIEW_OPS = frozenset(
    {
        "cannir.nd2nz_view",
        "cannir.dn2nz_view",
        "cannir.relu_view",
        "cannir.convert_view",
        "cannir.pad_view",
        "cannir.cat_view",
        "cannir.partition_view",
        "cannir.repeat_view",
        "cannir.repeat_nd_view",
        "cannir.broadcast_view",
    }
)


def _reshape(self, *shape):
    self = _require_tensor(self)
    if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
        shape = tuple(shape[0])
    target = _normalize_tensor_view_shape(self, shape)
    source = self.shape
    if all(type(x) is int and x > 0 for x in (*source, *target)):
        if _checked_view_product(source, what="source shape") != _checked_view_product(target, what="reshape shape"):
            raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, "reshape requires equal logical element counts")
    return _expression(
        "reshape", [self], shape=target, data_format="nd"
    )


def _permute(self, *dims):
    self = _require_tensor(self)
    if len(dims) == 1 and isinstance(dims[0], (tuple, list)):
        dims = tuple(dims[0])
    source_shape = self.shape
    if source_shape == 0:
        _normalize_permutation(dims, 0)
        return self
    if any(isinstance(dim, (tuple, list)) for dim in source_shape):
        raise CANNBotNotImplementedError(DiagnosticCode.UNSUPPORTED_FEATURE, "permute requires a flat logical layout")
    dims = _normalize_permutation(dims, len(source_shape))
    shape = tuple(source_shape[d] for d in dims)
    return _expression("permute", [self], shape=shape, parameters={"dims": tuple(dims)})


def _expand(source, sizes):
    source_shape = source.shape
    scalar = type(source_shape) is int and source_shape == 0
    source_shape = () if scalar else source_shape
    if any(isinstance(dim, (tuple, list)) for dim in source_shape):
        raise CANNBotNotImplementedError(DiagnosticCode.UNSUPPORTED_FEATURE, "expand requires a flat logical layout")
    added = len(sizes) - len(source_shape)
    if added < 0:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_SHAPE, "expand requires at least as many sizes as source dimensions"
        )
    if not sizes:
        return source
    identity = source._tensor_type.layout_map_kind == LayoutMapKind.Identity
    source_stride = (() if scalar else source.stride) if identity else None
    shape, stride = [None] * len(sizes), [None] * len(sizes)
    for axis in reversed(range(len(sizes))):
        existing = axis >= added
        old = source_shape[axis - added] if existing else 1
        new = sizes[axis]
        _validate_index_value(new, operation="Tensor.expand size")
        fixed = _constant_i64(new)
        if fixed is not None and isinstance(new, ir.Value) and isinstance(new.type, ir.IntegerType):
            # IntegerAttr reads signless constants as signed. Recover the
            # wrapper's unsigned value before interpreting the -1 sentinel.
            if bool(getattr(new, "unsigned", False)) or new.type.is_unsigned:
                fixed &= (1 << new.type.width) - 1
        if fixed is not None:
            if fixed < -1 or fixed > (1 << 63) - 1:
                raise CANNBotValueError(
                    DiagnosticCode.INVALID_SHAPE, "expand sizes must be -1 or nonnegative signed int64 integers"
                )
            if fixed == -1:
                if not existing:
                    raise CANNBotValueError(
                        DiagnosticCode.INVALID_SHAPE, "expand cannot use -1 for a new leading dimension"
                    )
                new = old
            else:
                new = fixed
        else:
            new = _int64_result(_index_value(new, operation="Tensor.expand size"))
            if existing:
                keep = arith.CmpIOp(arith.CmpIPredicate.eq, _raw(new), _index_value(-1)).result
                new = _int64_result(arith.SelectOp(keep, _index_value(old), _raw(new)).result)
        if type(old) is int and type(new) is int and old not in (1, new):
            raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, "expand can expand only singleton dimensions")
        shape[axis] = new
        if not identity:
            continue
        if scalar:
            stride[axis] = 0
            continue
        pitch = source_stride[axis - added] if existing else shape[axis + 1] * stride[axis + 1]
        if fixed == -1 or (type(old) is int and old != 1):
            stride[axis] = pitch
        elif type(old) is int and type(new) is int:
            stride[axis] = pitch if old == new else 0
        else:
            same = arith.CmpIOp(arith.CmpIPredicate.eq, _index_value(old), _index_value(new)).result
            stride[axis] = _int64_result(arith.SelectOp(same, _index_value(pitch), _index_value(0)).result)
    return _expression("broadcast", [source], shape=shape, stride=stride if identity else None)


def _require_tensor(value):
    """Validate a Tensor operand without converting or wrapping its carrier."""
    if not isinstance(value, Tensor):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"expected a Tensor; select a RingBuffer slot first if applicable; got {type(value).__name__}",
        )
    return value


def _attribute(value):
    if isinstance(value, ir.Attribute):
        return value
    if isinstance(value, str):
        return ir.StringAttr.get(value)
    if isinstance(value, bool):
        return ir.BoolAttr.get(value)
    if isinstance(value, (tuple, list)):
        return ir.DenseI64ArrayAttr.get(value)
    if type(value) is int:
        return ir.IntegerAttr.get(ir.IntegerType.get_signless(64), value)
    raise TypeError(f"unsupported Tensor parameter {value!r}")


def _transform(kind, source, *controls, **parameters):
    """Build the canonical pure spatial operation, with native type inference."""
    source = _raw(_require_tensor(source))
    controls = tuple(_raw(v) for v in controls)
    if kind == "slice":
        op = cannir.TensorSliceOp(source, controls[0],
                                 sizes=controls[1] if len(controls) > 1 else None,
                                 steps=controls[2] if len(controls) > 2 else None)
    elif kind == "tile":
        op = cannir.TileSliceOp(source, *controls)
    elif kind == "packed_reshape":
        op = cannir.ReshapeViewOp(source, parameters["new_shape"], controls)
    elif kind == "dtype":
        op = cannir.DTypeViewOp(source, parameters["dtype"])
    elif kind == "reinterpret":
        op = cannir.ReinterpretViewOp(source, *controls, **parameters)
    elif kind == "local":
        op = cannir.LocalSliceOp(source, controls[0], offset=controls[1] if len(controls) > 1 else None, **parameters)
    elif kind == "storage_cast":
        schema = parameters.pop("schema")
        schema = ir.TypeAttr(schema).value if isinstance(schema, ir.TypeAttr) else schema
        op = cannir.StorageCastOp(schema, source, **parameters)
    else:
        raise ValueError(f"unknown Tensor transform {kind}")
    return Tensor._from_ir(op.res)


def _load(source, coord, *, core="generic"):
    operation = {"generic": cannir.TensorLoadOp, "vec": cannir.VecSsbufLoadOp, "cube": cannir.CubeSsbufLoadOp}[core]
    return operation(_raw(_require_tensor(source)), coord).res


def _store(value, destination, coord, *, core="generic"):
    operation = {"generic": cannir.TensorStoreOp, "vec": cannir.VecSsbufStoreOp, "cube": cannir.CubeSsbufStoreOp}[core]
    operation(value, _raw(_require_tensor(destination)), coord)


def _expression(
    kind,
    sources,
    *,
    controls=(),
    parameters=None,
    shape=None,
    dtype=None,
    data_format=None,
    stride=None,
    physical=None,
):
    from cannbot_dsl.core.contracts.elements import storage_mlir_type_for_dtype

    sources = tuple(_require_tensor(source) for source in sources)
    source = sources[0]
    shape = source.shape if shape is None else tuple(shape)
    if kind == "permute":
        return Tensor._from_ir(cannir.PermuteViewOp(_raw(source), parameters["dims"]).res)
    if kind in ("reshape", "flatten", "unflatten"):
        dynamic = [_raw(dim) for dim in shape if type(dim) is not int]
        reassociation = {}
        if kind == "flatten":
            reassociation["flatten_axes"] = parameters["axes"]
        elif kind == "unflatten":
            reassociation.update(unflatten_axis=parameters["dim"], unflatten_sizes=parameters["sizes"])
        op = cannir.ReshapeViewOp(
            _raw(source),
            tuple(dim if type(dim) is int else -1 for dim in shape),
            dynamic,
            preserve_order=True,
            **reassociation,
        )
        return Tensor._from_ir(op.res)
    dtype = dtype or source.dtype
    coordinate_view = kind in ("broadcast", "repeat", "repeat_nd")
    mapping = source._tensor_type.layout_map_kind if data_format is None else {"nd": 0, "nz": 1, "zn": 2}[data_format]
    if coordinate_view:
        if source._tensor_type.layout_map_kind == LayoutMapKind.Identity:
            parent_stride = source.stride
            if kind in ("repeat", "repeat_nd"):
                steps = parameters["step"]
                stride = tuple(
                    sum(steps[j + i] * p for i, p in enumerate(parent_stride))
                    for j in range(0, len(steps), source.rank)
                ) + tuple(parent_stride)
            mapping = LayoutMapKind.Identity
        else:
            # Coordinate transforms retain the encoded backing axes. Their
            # logical dense ordinal is not a per-axis memory stride.
            mapping = LayoutMapKind.Composed
            physical = source._tensor_type.physical_layout
    if kind in ("relu", "convert") and mapping == LayoutMapKind.Composed:
        # Numerical expressions retain the source coordinate graph. A
        # composed map has no standalone layout to derive from its shape.
        logical = source.layout
        physical = source._tensor_type.physical_layout
    elif kind == "partition":
        logical = make_layout(
            shape, stride=source.stride if mapping == LayoutMapKind.Identity else _suffix_product(shape)
        )
        physical = source._tensor_type.physical_layout
    else:
        logical = make_layout(shape, stride=_suffix_product(shape) if stride is None else stride)
    pointer = cannir.PointerType.get(int(source.memloc), storage_mlir_type_for_dtype(dtype))
    physical = physical or cannir.derive_physical_layout(pointer, _raw(logical).type, mapping, 0)
    schema = cannir.TensorType.get(pointer, _raw(logical).type, physical, mapping)
    ty = schema
    operations = {
        "relu": cannir.ReluViewOp,
        "convert": cannir.ConvertViewOp,
        "pad": cannir.PadViewOp,
        "cat": cannir.CatViewOp,
        "partition": cannir.PartitionViewOp,
        "repeat": cannir.RepeatViewOp,
        "repeat_nd": cannir.RepeatNDViewOp,
        "broadcast": cannir.BroadcastViewOp,
    }
    attributes = dict(parameters or {})
    if kind == "pad":
        attributes["storage_bits"] = attributes.pop("value_encoding", "numeric") == "bits"
        attributes["replicate"] = attributes.pop("mode") == "replicate"
    op = operations[kind].build_generic(
        results=[ty],
        operands=[[_raw(s) for s in sources], list(controls), _raw(logical)],
        attributes={key: _attribute(value) for key, value in attributes.items()},
    )
    return Tensor._from_ir(op.results[0])


def storage_bits(value):
    """Use integer bits without numeric conversion (including FP8/HIF8)."""
    return StorageBits(value)


def _view_integer(value, name, *, minimum=0):
    if type(value) is int:
        if not minimum <= value <= (1 << 63) - 1:
            raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, f"{name} must be in {minimum}..2^63-1")
        return value, arith.ConstantOp(ir.IntegerType.get_signless(64), value).result
    value = _raw(value)
    if not isinstance(value, ir.Value) or value.type != ir.IntegerType.get_signless(64):
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"{name} requires an integer or i64 SSA value")
    return value, value


def _repeat_nd(source, block_shape, *, repeats, step):
    source = _require_tensor(source)
    repeats = (repeats,) if type(repeats) is int else tuple(repeats)
    block_shape = tuple(block_shape)
    if len(repeats) == 1 and len(step) == source.rank and all(type(x) is int for x in step):
        step = (tuple(step),)
    else:
        step = tuple(tuple(x) for x in step)
    invalid_repeat_axes = not 1 <= len(repeats) <= 2 or len(step) != len(repeats)
    if invalid_repeat_axes or len(block_shape) != source.rank or any(len(s) != source.rank for s in step):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_SHAPE,
            "tile_slice_multi requires one or two repeat axes and one parent-rank step vector per axis",
        )
    if any(type(n) is not int or not 1 <= n <= (1 << 63) - 1 for n in (*repeats, *block_shape)):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            "tile_slice_multi counts and block extents require positive static integers",
        )
    if any(type(n) is not int or not 0 <= n <= (1 << 63) - 1 for row in step for n in row):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            "tile_slice_multi steps require nonnegative static integers",
            span=argument_span("step"),
        )
    for axis, extent in enumerate(source.shape):
        end = sum((r - 1) * row[axis] for r, row in zip(repeats, step)) + block_shape[axis]
        if end > (1 << 63) - 1 or (type(extent) is int and end > extent):
            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE,
                f"tile_slice_multi exceeds parent axis {axis}; "
                f"required {_render_literal(end)}, "
                f"available {_render_literal(extent) if type(extent) is int else 'dynamic'}",
            )
    return _expression(
        "repeat_nd", [source], shape=(*repeats, *block_shape),
        parameters={
            "block_shape": block_shape, "repeats": repeats,
            "step": tuple(n for row in step for n in row),
        },
    )


def _convert(src, dtype, *, scale=None, offset=0, negative_scale=None, relu_limit=None):
    from cannbot_dsl.core.contracts.elements import normalize_storage_dtype
    from cannbot_dsl.types._numeric import Float32, Int64

    dtype = normalize_storage_dtype(dtype)
    if negative_scale is not None and relu_limit is not None:
        raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "negative_scale and relu_limit are mutually exclusive")
    if (negative_scale is not None or relu_limit is not None) and scale is None:
        scale = 1.0
    sources, controls = [src], []
    has_offset = not (type(offset) is int and offset == 0)
    if has_offset:
        if dtype not in (_dtypes.int8, _dtypes.uint8):
            raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "convert offset requires INT8 or UINT8 output")
        if isinstance(scale, Tensor):
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT,
                "Tensor quantization tables already encode offset; a separate offset is unsupported",
            )
        if type(offset) is int:
            if not -256 <= offset <= 255:
                raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "convert offset must be in [-256, 255]")
            offset = Int64(offset)
        if not isinstance(offset, ir.Value) or offset.type != ir.IntegerType.get_signless(64):
            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "convert offset must be an integer or i64 SSA value")
        if scale is None:
            scale = 1.0
    if isinstance(scale, Tensor):
        sources.append(scale)
    elif scale is not None:
        if isinstance(scale, (int, float)) and not isinstance(scale, bool):
            scale = Float32(float(scale))
        if not isinstance(scale, ir.Value) or scale.type != ir.F32Type.get():
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE, "convert scale must be a scalar f32 or bound Tensor scale table"
            )
        controls.append(scale)
    if has_offset:
        controls.append(offset)
    negative_kind = 0
    if isinstance(negative_scale, Tensor):
        negative_kind = 2
        sources.append(negative_scale)
    elif negative_scale is not None:
        negative_kind = 1
        if isinstance(negative_scale, (int, float)) and not isinstance(negative_scale, bool):
            negative_scale = Float32(float(negative_scale))
        if not isinstance(negative_scale, ir.Value) or negative_scale.type != ir.F32Type.get():
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE, "negative_scale must be scalar f32 or a bound FP32 Tensor table"
            )
        controls.append(negative_scale)
    if relu_limit is not None:
        if dtype not in (_dtypes.float16, _dtypes.bfloat16, _dtypes.int8, _dtypes.uint8,
                         _dtypes.float8_e4m3fn, _dtypes.hifloat8):
            raise CANNBotValueError(
                DiagnosticCode.UNSUPPORTED_FEATURE,
                "relu_limit requires FP16/BF16/INT8/UINT8/FP8/HIF8 output; FP32 clipping is not supported",
            )
        if isinstance(relu_limit, StorageBits):
            relu_limit = relu_limit.value
            width = 16 if dtype in (_dtypes.float16, _dtypes.bfloat16) else 8
            if type(relu_limit) is int:
                if not 0 <= relu_limit < (1 << width):
                    raise CANNBotValueError(
                        DiagnosticCode.INVALID_ARGUMENT,
                        f"relu_limit storage_bits requires an unsigned {width}-bit encoding",
                    )
                relu_limit = Int64(relu_limit)
            if not isinstance(relu_limit, ir.Value) or relu_limit.type != ir.IntegerType.get_signless(64):
                raise CANNBotTypeError(
                    DiagnosticCode.INVALID_TYPE, "relu_limit storage_bits requires an integer or i64 SSA value"
                )
        else:
            if dtype in (_dtypes.float8_e4m3fn, _dtypes.hifloat8):
                raise CANNBotTypeError(
                    DiagnosticCode.INVALID_TYPE,
                    "FP8/HIF8 relu_limit requires storage_bits(encoded_limit); AIC has no scalar FP8/HIF8 conversion",
                )
            if isinstance(relu_limit, (int, float)) and not isinstance(relu_limit, bool):
                import math
                import struct
                valid = math.isfinite(relu_limit) and relu_limit > 0
                if dtype == _dtypes.float16:
                    valid = valid and relu_limit <= 65504 and struct.unpack("e", struct.pack("e", relu_limit))[0] > 0
                elif dtype == _dtypes.bfloat16:
                    valid = valid and 2.0 ** -134 < relu_limit <= float.fromhex("0x1.fep+127")
                else:
                    valid = (
                        valid
                        and relu_limit <= (127 if dtype == _dtypes.int8 else 255)
                        and float(relu_limit).is_integer()
                    )
                if not valid:
                    raise CANNBotValueError(
                        DiagnosticCode.INVALID_ARGUMENT,
                        ("relu_limit must be positive and finite in the output dtype; "
                            "integer outputs require an integral limit"),
                    )
                relu_limit = Float32(float(relu_limit))
            if not isinstance(relu_limit, ir.Value) or relu_limit.type != ir.F32Type.get():
                raise CANNBotTypeError(
                    DiagnosticCode.INVALID_TYPE, "relu_limit must be scalar f32 or storage_bits(integer/i64)"
                )
        controls.append(relu_limit)
    return _expression(
        "convert",
        sources,
        dtype=dtype,
        controls=controls,
        parameters={
            "negative_scale_kind": ir.IntegerAttr.get(ir.IntegerType.get_signless(32), negative_kind),
            "has_relu_limit": relu_limit is not None,
        },
    )


def cat(tensors, dim=0):
    """Describe concatenation, without reading or allocating storage."""
    if not isinstance(tensors, (tuple, list)) or not tensors:
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_ARGUMENT if isinstance(tensors, (tuple, list)) else DiagnosticCode.INVALID_TYPE,
            "cat requires a nonempty tuple or list; "
            f"got {len(tensors) if isinstance(tensors, (tuple, list)) else type(tensors).__name__}",
            span=argument_span("tensors"),
        )
    tensors = tuple(_require_tensor(t) for t in tensors)
    first = tensors[0]
    if type(dim) is not int or dim not in (0, -len(first.shape)):
        raise CANNBotValueError(
            DiagnosticCode.UNSUPPORTED_FEATURE if type(dim) is int else DiagnosticCode.INVALID_TYPE,
            f"cat currently supports dim=0 only; "
            f"got {_render_literal(dim) if type(dim) is int else type(dim).__name__}",
            span=argument_span("dim"),
        )
    shape = first.shape
    for source in tensors[1:]:
        other = source.shape
        if source.dtype != first.dtype or len(other) != len(shape):
            raise CANNBotValueError(
                DiagnosticCode.INVALID_TYPE if source.dtype != first.dtype else DiagnosticCode.INVALID_SHAPE,
                "cat inputs must have matching dtype and rank; "
                f"got dtype {first.dtype} / {source.dtype}, rank {len(shape)} / {len(other)}",
                span=argument_span("tensors"),
            )
        if any(type(a) is int and type(b) is int and a != b for a, b in zip(shape[1:], other[1:])):
            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE,
                f"cat non-concatenated dimensions must match; got {shape} and {other}",
                span=argument_span("tensors"),
            )
    result_shape = (sum(source.shape[0] for source in tensors), *shape[1:])
    return _expression("cat", tensors, shape=result_shape, parameters={"dim": 0})


def _describe_pad(source, widths, mode="constant", value=None):
    from cannbot_dsl.types._numeric import Int64, Float32

    source = _require_tensor(source)
    shape = list(source.shape)
    if not isinstance(widths, (tuple, list)) or not widths or len(widths) % 2 or len(widths) > 2 * len(shape):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT if isinstance(widths, (tuple, list)) else DiagnosticCode.INVALID_TYPE,
            "pad requires before/after pairs for trailing dimensions; "
            + (f"got width count {len(widths)} for tensor rank {len(shape)}"
             if isinstance(widths, (tuple, list)) else f"got {type(widths).__name__} instead of a tuple/list"),
            span=argument_span("pad"),
        )
    if mode not in ("constant", "replicate"):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            "pad mode must be constant or replicate; "
            f"got {mode if type(mode) is str else type(mode).__name__}",
            span=argument_span("mode"),
        )
    if mode == "replicate" and value is not None and not (type(value) in (int, float) and value == 0):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            "replicate pad does not take a fill value",
            span=argument_span("value"),
        )
    if mode == "constant" and value is None:
        value = 0
    controls = []
    for index, width in enumerate(widths):
        if type(width) is int:
            if not 0 <= width <= (1 << 63) - 1:
                raise CANNBotValueError(
                    DiagnosticCode.INVALID_ARGUMENT,
                    f"pad widths must be non-negative i64 values; got {_render_literal(width)} at index {index}",
                    span=argument_span("pad"),
                )
            amount = width
        elif isinstance(width, ir.Value) and (
            ir.IndexType.isinstance(width.type)
            or (ir.IntegerType.isinstance(width.type) and width.type.width in (32, 64))
        ):
            from cannbot_dsl.types import dtypes

            amount = dtypes.int64(width)
        else:
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                f"pad widths must be integers or runtime integer values; got {type(width).__name__} at index {index}",
                span=argument_span("pad"),
            )
        axis = len(shape) - 1 - index // 2
        shape[axis] = shape[axis] + amount
        if type(shape[axis]) is int and shape[axis] > (1 << 63) - 1:
            raise CANNBotOverflowError(
                DiagnosticCode.INVALID_SHAPE,
                f"padded extent exceeds signed int64; got {shape[axis]} on axis {axis}",
                span=argument_span("pad"),
            )
        controls.append(Int64(amount) if type(amount) is int else amount)
    encoding = "numeric"
    if mode == "constant":
        if isinstance(value, StorageBits):
            encoding, value = "bits", value.value
        if type(value) is int:
            value = Int64(value)
        elif type(value) is float:
            value = Float32(value)
        if not isinstance(value, ir.Value):
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                f"padding fill value must be a scalar; got {type(value).__name__}",
                span=argument_span("value"),
            )
        controls.append(value)
    parameters = {"pairs": len(widths) // 2, "mode": mode}
    if encoding == "bits":
        parameters["value_encoding"] = encoding
    return _expression("pad", [source], shape=shape, controls=controls, parameters=parameters)


__all__ = [
    "Shape",
    "Stride",
    "Coord",
    "Tile",
    "Tiler",
    "Layout",
    "Tensor",
    "PartitionTiler",
    "make_layout",
    "make_pointer",
    "make_tiler",
    "make_tensor",
    "from_tensor",
    "cat",
    "ceil_div",
    "idx2crd",
    "tile_slice",
    "tile_slice_multi",
    "storage_bits",
    "MemLoc",
    "LayoutMapKind",
]
