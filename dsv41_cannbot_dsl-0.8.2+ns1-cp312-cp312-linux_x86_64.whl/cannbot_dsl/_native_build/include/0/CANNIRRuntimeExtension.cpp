/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */
#include "CANNIR-c/Registration.h"

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wattributes"
#include "mlir/Bindings/Python/PybindAdaptors.h"
#pragma GCC diagnostic pop

namespace py = pybind11;

PYBIND11_MODULE(_cannir_runtime, m) {
  m.doc() = "CANNBotDSL MLIR runtime initialization bridge";

  cannirRegisterAllPasses();

  m.def("register_dialects", &cannirRegisterDialects, py::arg("registry"));
}
