/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef LIB_BINDINGS_PYTHON_HOSTRUNTIMEPROFILER_H_
#define LIB_BINDINGS_PYTHON_HOSTRUNTIMEPROFILER_H_

#include "cannbotdsl/Runtime/HostABI.h"
#include <memory>

namespace cannbotdsl::runtime::profiling {
class ReportingSession {
 public:
  ReportingSession();
  ~ReportingSession();
  ReportingSession(const ReportingSession&) = delete;
  ReportingSession& operator=(const ReportingSession&) = delete;
  const ProfilingCallbacksV1* callbacks() const;
  void rethrowIfFailed() const;

 private:
  struct Impl;
  std::unique_ptr<Impl> impl;
};
}  // namespace cannbotdsl::runtime::profiling
#endif  // LIB_BINDINGS_PYTHON_HOSTRUNTIMEPROFILER_H_
