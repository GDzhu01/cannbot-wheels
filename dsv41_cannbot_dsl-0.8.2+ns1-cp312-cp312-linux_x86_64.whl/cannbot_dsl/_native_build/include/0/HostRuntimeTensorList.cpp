/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include "HostRuntimeTensorList.h"

#include <dlfcn.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <cstring>
#include <exception>
#include <limits>
#include <map>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <tuple>
#include <utility>

namespace cannbotdsl::runtime::tensor_list {
namespace {

using AclError = int32_t;
using AclStream = void*;
using AclEvent = void*;

constexpr AclError kAclSuccess = 0;
constexpr int32_t kAclMemMallocHugeFirst = 0;
constexpr int32_t kAclMemcpyHostToDevice = 1;
constexpr int32_t kEventRecordedNotReady = 0;
constexpr int32_t kEventRecordedComplete = 1;
constexpr size_t kMaximumIdleBytes = 64ULL * 1024ULL * 1024ULL;
constexpr size_t kMaximumFreePerBucket = 2;

template <typename Function>
Function resolveSymbol(void* handle, const std::string& artifact, const char* name) {
  dlerror();
  void* raw = dlsym(handle, name);
  const char* detail = dlerror();
  if (!raw || detail) {
    std::ostringstream os;
    os << "TensorList artifact '" << artifact << "' is missing required ACL symbol '" << name << "'";
    if (detail) os << ": " << detail;
    throw std::runtime_error(os.str());
  }
  return reinterpret_cast<Function>(raw);
}

[[noreturn]] void throwAcl(const char* name, AclError status) {
  throw std::runtime_error(std::string(name) + " failed with ACL status " + std::to_string(status));
}

size_t capacityFor(size_t words) {
  if (words == 0) throw std::invalid_argument("TensorList descriptor must not be empty");
  size_t capacity = 1;
  while (capacity < words) {
    if (capacity > std::numeric_limits<size_t>::max() / 2)
      throw std::overflow_error("TensorList descriptor capacity overflow");
    capacity *= 2;
  }
  return capacity;
}

size_t bytesFor(size_t words) {
  if (words > std::numeric_limits<size_t>::max() / sizeof(uint64_t))
    throw std::overflow_error("TensorList descriptor byte size overflow");
  return words * sizeof(uint64_t);
}

}  // namespace

class RuntimeApi {
 public:
  using GetDevice = AclError (*)(int32_t*);
  using Malloc = AclError (*)(void**, size_t, int32_t);
  using Free = AclError (*)(void*);
  using MallocHost = AclError (*)(void**, size_t);
  using FreeHost = AclError (*)(void*);
  using MemcpyAsync = AclError (*)(void*, size_t, const void*, size_t, int32_t, AclStream);
  using CreateEvent = AclError (*)(AclEvent*);
  using RecordEvent = AclError (*)(AclEvent, AclStream);
  using QueryEventStatus = AclError (*)(AclEvent, int32_t*);
  using DestroyEvent = AclError (*)(AclEvent);
  using SynchronizeStream = AclError (*)(AclStream);

  RuntimeApi(void* handle, std::string artifact) : artifact(std::move(artifact)), processId(getpid()) {
    if (!handle) throw std::invalid_argument("TensorList ACL resolution requires a loaded artifact handle");
    getDevice = resolveSymbol<GetDevice>(handle, this->artifact, "aclrtGetDevice");
    mallocDevice = resolveSymbol<Malloc>(handle, this->artifact, "aclrtMalloc");
    freeDevice = resolveSymbol<Free>(handle, this->artifact, "aclrtFree");
    mallocHost = resolveSymbol<MallocHost>(handle, this->artifact, "aclrtMallocHost");
    freeHost = resolveSymbol<FreeHost>(handle, this->artifact, "aclrtFreeHost");
    memcpyAsync = resolveSymbol<MemcpyAsync>(handle, this->artifact, "aclrtMemcpyAsync");
    createEvent = resolveSymbol<CreateEvent>(handle, this->artifact, "aclrtCreateEvent");
    recordEvent = resolveSymbol<RecordEvent>(handle, this->artifact, "aclrtRecordEvent");
    queryEventStatus = resolveSymbol<QueryEventStatus>(handle, this->artifact, "aclrtQueryEventStatus");
    destroyEvent = resolveSymbol<DestroyEvent>(handle, this->artifact, "aclrtDestroyEvent");
    synchronizeStream = resolveSymbol<SynchronizeStream>(handle, this->artifact, "aclrtSynchronizeStream");
  }

  bool isCurrentProcess() const { return processId == getpid(); }

  std::string artifact;
  pid_t processId;
  GetDevice getDevice = nullptr;
  Malloc mallocDevice = nullptr;
  Free freeDevice = nullptr;
  MallocHost mallocHost = nullptr;
  FreeHost freeHost = nullptr;
  MemcpyAsync memcpyAsync = nullptr;
  CreateEvent createEvent = nullptr;
  RecordEvent recordEvent = nullptr;
  QueryEventStatus queryEventStatus = nullptr;
  DestroyEvent destroyEvent = nullptr;
  SynchronizeStream synchronizeStream = nullptr;
};

namespace {

struct Block {
  Block(std::shared_ptr<RuntimeApi> api, int32_t deviceId, uintptr_t ownerStream, size_t capacityWords)
      : api(std::move(api)), deviceId(deviceId), ownerStream(ownerStream), capacityWords(capacityWords) {}

  std::shared_ptr<RuntimeApi> api;
  const int32_t deviceId;
  const uintptr_t ownerStream;
  const size_t capacityWords;
  void* host = nullptr;
  void* device = nullptr;
  AclEvent event = nullptr;
  uintptr_t pendingStream = 0;
};

using BlockPtr = std::shared_ptr<Block>;

struct ArenaState {
  pid_t processId = getpid();
  std::mutex mutex;
  std::vector<BlockPtr> freeBlocks;
  std::vector<BlockPtr> pendingBlocks;
  // Quarantined blocks are deliberately retained: an ACL failure made it
  // impossible to prove that their memory is no longer in flight.
  std::vector<BlockPtr> quarantinedBlocks;
};

std::atomic<ArenaState*>& arenaStateSlot() {
  static auto* state = new std::atomic<ArenaState*>(new ArenaState());
  return *state;
}

ArenaState& arenaState() {
  auto& slot = arenaStateSlot();
  while (true) {
    ArenaState* state = slot.load(std::memory_order_acquire);
    if (state->processId == getpid()) return *state;
    auto* replacement = new ArenaState();
    if (slot.compare_exchange_strong(state, replacement, std::memory_order_acq_rel,
                                     std::memory_order_acquire)) {
      // Do not destroy the inherited arena. A parent thread may have owned
      // its mutex at fork, and its ACL blocks are not valid in this process.
      return *replacement;
    }
    delete replacement;
  }
}

using Bucket = std::tuple<const RuntimeApi*, int32_t, uintptr_t, size_t>;

Bucket bucketFor(const std::shared_ptr<RuntimeApi>& api, int32_t deviceId, uintptr_t ownerStream,
                 size_t capacityWords) {
  return Bucket(api.get(), deviceId, ownerStream, capacityWords);
}

Bucket bucketFor(const BlockPtr& block) {
  return bucketFor(block->api, block->deviceId, block->ownerStream, block->capacityWords);
}

void destroyBlock(const BlockPtr& block) {
  if (!block || !block->api || !block->api->isCurrentProcess()) return;
  AclError firstError = kAclSuccess;
  const char* firstName = nullptr;
  if (block->event) {
    const AclError status = block->api->destroyEvent(block->event);
    if (status != kAclSuccess) {
      firstError = status;
      firstName = "aclrtDestroyEvent";
    }
    block->event = nullptr;
  }
  if (block->device) {
    const AclError status = block->api->freeDevice(block->device);
    if (status != kAclSuccess && firstError == kAclSuccess) {
      firstError = status;
      firstName = "aclrtFree";
    }
    block->device = nullptr;
  }
  if (block->host) {
    const AclError status = block->api->freeHost(block->host);
    if (status != kAclSuccess && firstError == kAclSuccess) {
      firstError = status;
      firstName = "aclrtFreeHost";
    }
    block->host = nullptr;
  }
  if (firstError != kAclSuccess) throwAcl(firstName, firstError);
}

BlockPtr createBlock(const std::shared_ptr<RuntimeApi>& api, int32_t deviceId, uintptr_t ownerStream,
                     size_t capacityWords) {
  auto block = std::make_shared<Block>(api, deviceId, ownerStream, capacityWords);
  const size_t bytes = bytesFor(capacityWords);
  AclError status = api->mallocHost(&block->host, bytes);
  if (status != kAclSuccess) throwAcl("aclrtMallocHost", status);
  status = api->mallocDevice(&block->device, bytes, kAclMemMallocHugeFirst);
  if (status != kAclSuccess) {
    const AclError cleanup = api->freeHost(block->host);
    block->host = nullptr;
    if (cleanup != kAclSuccess) throwAcl("aclrtFreeHost", cleanup);
    throwAcl("aclrtMalloc", status);
  }
  status = api->createEvent(&block->event);
  if (status != kAclSuccess) {
    const AclError freeDevice = api->freeDevice(block->device);
    const AclError freeHost = api->freeHost(block->host);
    block->device = nullptr;
    block->host = nullptr;
    if (freeDevice != kAclSuccess) throwAcl("aclrtFree", freeDevice);
    if (freeHost != kAclSuccess) throwAcl("aclrtFreeHost", freeHost);
    throwAcl("aclrtCreateEvent", status);
  }
  return block;
}

std::vector<BlockPtr> trimFreeLocked(ArenaState& state) {
  std::vector<BlockPtr> victims;
  std::map<Bucket, size_t> counts;
  std::vector<BlockPtr> kept;
  kept.reserve(state.freeBlocks.size());
  for (const BlockPtr& block : state.freeBlocks) {
    const Bucket key = bucketFor(block);
    size_t& count = counts[key];
    if (count >= kMaximumFreePerBucket)
      victims.push_back(block);
    else {
      ++count;
      kept.push_back(block);
    }
  }
  state.freeBlocks.swap(kept);

  size_t idleBytes = 0;
  for (const BlockPtr& block : state.freeBlocks) {
    const size_t bytes = bytesFor(block->capacityWords);
    if (idleBytes > std::numeric_limits<size_t>::max() - bytes)
      idleBytes = std::numeric_limits<size_t>::max();
    else
      idleBytes += bytes;
  }
  while (idleBytes > kMaximumIdleBytes && !state.freeBlocks.empty()) {
    auto largest = std::max_element(
        state.freeBlocks.begin(), state.freeBlocks.end(),
        [](const BlockPtr& lhs, const BlockPtr& rhs) { return lhs->capacityWords < rhs->capacityWords; });
    const size_t bytes = bytesFor((*largest)->capacityWords);
    idleBytes = idleBytes >= bytes ? idleBytes - bytes : 0;
    victims.push_back(*largest);
    state.freeBlocks.erase(largest);
  }
  return victims;
}

void destroyVictims(std::vector<BlockPtr> victims) {
  std::exception_ptr firstError;
  for (const BlockPtr& block : victims) {
    try {
      destroyBlock(block);
    } catch (...) {
      if (!firstError) firstError = std::current_exception();
    }
  }
  if (firstError) std::rethrow_exception(firstError);
}

void pollPending() {
  ArenaState& state = arenaState();
  std::vector<BlockPtr> pending;
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    pending.swap(state.pendingBlocks);
  }
  std::vector<BlockPtr> completed;
  std::vector<BlockPtr> remaining;
  std::vector<BlockPtr> quarantined;
  for (const BlockPtr& block : pending) {
    if (!block->api->isCurrentProcess()) {
      quarantined.push_back(block);
      continue;
    }
    int32_t recorded = kEventRecordedNotReady;
    const AclError status = block->api->queryEventStatus(block->event, &recorded);
    if (status == kAclSuccess && recorded == kEventRecordedComplete) {
      block->pendingStream = 0;
      completed.push_back(block);
      continue;
    }
    if (status == kAclSuccess && recorded == kEventRecordedNotReady) {
      remaining.push_back(block);
      continue;
    }
    const AclError sync = block->api->synchronizeStream(reinterpret_cast<AclStream>(block->pendingStream));
    if (sync == kAclSuccess) {
      block->pendingStream = 0;
      completed.push_back(block);
    } else {
      quarantined.push_back(block);
    }
  }
  std::vector<BlockPtr> victims;
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    state.pendingBlocks.insert(state.pendingBlocks.end(), remaining.begin(), remaining.end());
    state.freeBlocks.insert(state.freeBlocks.end(), completed.begin(), completed.end());
    state.quarantinedBlocks.insert(state.quarantinedBlocks.end(), quarantined.begin(), quarantined.end());
    victims = trimFreeLocked(state);
  }
  destroyVictims(std::move(victims));
}

BlockPtr acquireBlock(const std::shared_ptr<RuntimeApi>& api, int32_t deviceId, uintptr_t ownerStream,
                      size_t requiredWords) {
  const size_t capacityWords = capacityFor(requiredWords);
  const Bucket requested = bucketFor(api, deviceId, ownerStream, capacityWords);
  pollPending();
  ArenaState& state = arenaState();
  BlockPtr selected;
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    for (auto it = state.freeBlocks.begin(); it != state.freeBlocks.end(); ++it) {
      const BlockPtr& candidate = *it;
      if (bucketFor(candidate) != requested) continue;
      selected = candidate;
      state.freeBlocks.erase(it);
      break;
    }
  }
  if (selected) return selected;
  return createBlock(api, deviceId, ownerStream, capacityWords);
}

void returnFree(const BlockPtr& block) {
  ArenaState& state = arenaState();
  std::vector<BlockPtr> victims;
  {
    std::lock_guard<std::mutex> lock(state.mutex);
    state.freeBlocks.push_back(block);
    victims = trimFreeLocked(state);
  }
  destroyVictims(std::move(victims));
}

void quarantine(const BlockPtr& block) noexcept {
  try {
    ArenaState& state = arenaState();
    std::lock_guard<std::mutex> lock(state.mutex);
    state.quarantinedBlocks.push_back(block);
  } catch (...) {
    // Retaining the shared_ptr owned by a leaking caller is still safer than
    // freeing memory whose asynchronous state is unknown.
  }
}

void retireBlock(const BlockPtr& block, uintptr_t streamHandle) {
  if (!block->api->isCurrentProcess()) {
    // An inherited block must not enter the child arena. Its raw ACL
    // allocations are deliberately left to process exit because neither
    // reuse nor destruction is safe after fork.
    throw std::runtime_error("TensorList staging reservation was inherited across fork");
  }
  if (streamHandle != block->ownerStream) {
    quarantine(block);
    throw std::runtime_error(
        "TensorList staging reservation stream does not match its owner "
        "stream");
  }
  const AclError status = block->api->recordEvent(block->event, reinterpret_cast<AclStream>(streamHandle));
  if (status == kAclSuccess) {
    block->pendingStream = streamHandle;
    ArenaState& state = arenaState();
    std::lock_guard<std::mutex> lock(state.mutex);
    state.pendingBlocks.push_back(block);
    return;
  }
  const AclError sync = block->api->synchronizeStream(reinterpret_cast<AclStream>(streamHandle));
  if (sync == kAclSuccess) {
    returnFree(block);
    return;
  }
  quarantine(block);
  std::ostringstream os;
  os << "aclrtRecordEvent failed with ACL status " << status
     << "; aclrtSynchronizeStream recovery failed with ACL status " << sync;
  throw std::runtime_error(os.str());
}

}  // namespace

struct Reservation::Impl {
  BlockPtr block;
  size_t usedWords = 0;
  uintptr_t streamHandle = 0;
  pid_t processId = getpid();
  bool retired = false;
};

Reservation::Reservation(std::unique_ptr<Impl> impl) : impl(std::move(impl)) {}

Reservation::~Reservation() {
  if (!impl || impl->retired || !impl->block) return;
  if (impl->processId != getpid()) {
    // Never call inherited ACL function pointers or touch a post-fork arena.
    // Dropping the C++ wrapper intentionally leaves the inherited raw ACL
    // resources to process exit; freeing memory with unknown async state is
    // less safe than this process-local remnant.
    impl->block.reset();
    impl->retired = true;
    return;
  }
  try {
    retireBlock(impl->block, impl->streamHandle);
    impl->retired = true;
  } catch (...) {
    // retireBlock accounts for the block in pending, free, or quarantine
    // before it can fail. Do not insert it into a second pool state here.
    impl->retired = true;
  }
}

uintptr_t Reservation::deviceAddress() const {
  if (!impl || !impl->block) throw std::runtime_error("TensorList reservation is empty");
  if (impl->processId != getpid())
    throw std::runtime_error("TensorList staging reservation was inherited across fork");
  return reinterpret_cast<uintptr_t>(impl->block->device);
}

size_t Reservation::usedWords() const {
  if (!impl) return 0;
  if (impl->processId != getpid())
    throw std::runtime_error("TensorList staging reservation was inherited across fork");
  return impl->usedWords;
}

void Reservation::retire() {
  if (!impl || impl->retired) return;
  if (impl->processId != getpid())
    throw std::runtime_error("TensorList staging reservation was inherited across fork");
  try {
    retireBlock(impl->block, impl->streamHandle);
    impl->retired = true;
  } catch (...) {
    // retireBlock either recovered synchronously or quarantined the block.
    // Never retry event recording from the destructor after reporting it.
    impl->retired = true;
    throw;
  }
}

std::shared_ptr<RuntimeApi> loadRuntimeApi(void* dsoHandle, const std::string& artifactPath) {
  return std::make_shared<RuntimeApi>(dsoHandle, artifactPath);
}

std::shared_ptr<Reservation> stage(const std::shared_ptr<RuntimeApi>& api, int32_t deviceId,
                                   uintptr_t streamHandle, const std::vector<uint64_t>& words) {
  if (!api) throw std::invalid_argument("TensorList staging requires RuntimeApi");
  if (!api->isCurrentProcess()) throw std::runtime_error("TensorList ACL API was inherited across fork");
  if (streamHandle == 0)
    throw std::invalid_argument("TensorList staging requires a non-null effective stream");
  if (words.empty()) throw std::invalid_argument("TensorList descriptor words must be non-empty");

  int32_t activeDevice = -1;
  AclError status = api->getDevice(&activeDevice);
  if (status != kAclSuccess) throwAcl("aclrtGetDevice", status);
  if (activeDevice != deviceId) {
    std::ostringstream os;
    os << "TensorList active ACL device mismatch: expected " << deviceId << ", got " << activeDevice;
    throw std::invalid_argument(os.str());
  }

  BlockPtr block = acquireBlock(api, deviceId, streamHandle, words.size());
  const size_t usedBytes = bytesFor(words.size());
  const size_t capacityBytes = bytesFor(block->capacityWords);
  std::memcpy(block->host, words.data(), usedBytes);
  status = api->memcpyAsync(block->device, capacityBytes, block->host, usedBytes, kAclMemcpyHostToDevice,
                            reinterpret_cast<AclStream>(streamHandle));
  if (status != kAclSuccess) {
    const AclError sync = api->synchronizeStream(reinterpret_cast<AclStream>(streamHandle));
    if (sync == kAclSuccess)
      returnFree(block);
    else
      quarantine(block);
    if (sync != kAclSuccess) {
      std::ostringstream os;
      os << "aclrtMemcpyAsync failed with ACL status " << status
         << "; aclrtSynchronizeStream recovery failed with ACL status " << sync;
      throw std::runtime_error(os.str());
    }
    throwAcl("aclrtMemcpyAsync", status);
  }

  std::unique_ptr<Reservation::Impl> impl;
  Reservation* reservation = nullptr;
  try {
    impl = std::make_unique<Reservation::Impl>();
    impl->block = block;
    impl->usedWords = words.size();
    impl->streamHandle = streamHandle;
    reservation = new Reservation(std::move(impl));
  } catch (...) {
    // The async copy may already be in flight. Preserve both allocations if
    // reservation construction itself runs out of host memory.
    quarantine(block);
    throw;
  }
  // Keep shared_ptr control-block allocation outside the catch above. If it
  // fails, shared_ptr deletes reservation, whose destructor safely retires
  // the block; quarantining it as well would put one block in two arena lists.
  return std::shared_ptr<Reservation>(reservation);
}

}  // namespace cannbotdsl::runtime::tensor_list
