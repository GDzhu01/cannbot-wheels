/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include "HostRuntimeProfiler.h"
#include <algorithm>
#include <cstddef>
#include <dlfcn.h>
#include <exception>
#include <limits>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>
#include <sys/syscall.h>
#include <unistd.h>

namespace cannbotdsl::runtime::profiling {
namespace {
// aprof_pub.h: MSPROF_ERROR_UNINITIALIZE. Reporting is harmless when a
// collector has not been started by msopprof / torch_npu.profiler.
constexpr int32_t kProfilerUninitialized = 6;

// Frozen CANN profiling ABI. Keeping the wire structs private avoids a CANN
// build/link dependency in the framework-independent host runtime extension.
struct AclTensor {
  uint32_t type, format, dataType, shapeDim;
  uint32_t shape[8];
};
// aprof_pub.h wire ABI, kept private so the host runtime builds without CANN.
constexpr uint16_t kMagic = 0x5A5A;
constexpr uint16_t kNodeLevel = 10000;
constexpr uint32_t kNodeBasicInfo = 0, kNodeTensorInfo = 1, kNodeLaunch = 5;
constexpr size_t kTensorsPerPacket = 5;
struct MsprofApi {
  uint16_t magicNumber, level;
  uint32_t type, threadId, reserve;
  uint64_t beginTime, endTime, itemId;
};
// aprof_pub.h packs NodeBasicInfo: opType starts at byte 12, not 16.
#pragma pack(push, 1)
struct MsprofNodeBasicInfo {
  uint64_t opName;
  uint32_t taskType;
  uint64_t opType;
  uint32_t blockDim, opFlag;
};
#pragma pack(pop)
struct MsprofTensorData {
  uint32_t tensorType, format, dataType, shape[8];
};
struct MsprofTensorInfo {
  uint64_t opName;
  uint32_t tensorNum;
  MsprofTensorData tensorData[kTensorsPerPacket];
};
struct MsprofCompactInfo {
  uint16_t magicNumber, level;
  uint32_t type, threadId, dataLen;
  uint64_t timeStamp;
  union {
    uint8_t info[40];
    MsprofNodeBasicInfo nodeBasicInfo;
  } data;
};
struct MsprofAdditionalInfo {
  uint16_t magicNumber, level;
  uint32_t type, threadId, dataLen;
  uint64_t timeStamp;
  MsprofTensorInfo data;
};
static_assert(sizeof(AclTensor) == 48);
static_assert(sizeof(MsprofApi) == 40);
static_assert(sizeof(MsprofNodeBasicInfo) == 28);
static_assert(offsetof(MsprofNodeBasicInfo, opType) == 12);
static_assert(offsetof(MsprofNodeBasicInfo, blockDim) == 20);
static_assert(sizeof(MsprofTensorData) == 44);
static_assert(sizeof(MsprofTensorInfo) == 232);
static_assert(sizeof(MsprofCompactInfo) == 64);
static_assert(sizeof(MsprofAdditionalInfo) == 256);
static_assert(offsetof(MsprofCompactInfo, data) == 24);
static_assert(offsetof(MsprofAdditionalInfo, data) == 24);

struct Api {
  uint64_t (*str2id)(const char*);
  uint64_t (*clock)();
  int32_t (*reportApi)(uint32_t, const MsprofApi*);
  int32_t (*reportCompact)(uint32_t, const void*, uint32_t);
  int32_t (*reportAdditional)(uint32_t, const void*, uint32_t);
  int32_t (*registerType)(uint16_t, uint32_t, const char*);

  static Api resolve(void* handle) {
    return {reinterpret_cast<decltype(str2id)>(dlsym(handle, "aclprofStr2Id")),
            reinterpret_cast<decltype(clock)>(dlsym(handle, "MsprofSysCycleTime")),
            reinterpret_cast<decltype(reportApi)>(dlsym(handle, "MsprofReportApi")),
            reinterpret_cast<decltype(reportCompact)>(dlsym(handle, "MsprofReportCompactInfo")),
            reinterpret_cast<decltype(reportAdditional)>(dlsym(handle, "MsprofReportAdditionalInfo")),
            reinterpret_cast<decltype(registerType)>(dlsym(handle, "MsprofRegTypeInfo"))};
  }
  explicit operator bool() const {
    return str2id && clock && reportApi && reportCompact && reportAdditional && registerType;
  }
};

Api loadApi() {
  Api api = Api::resolve(RTLD_DEFAULT);
  if (api) return api;
  void* handle = dlopen("libmsprofiler.so", RTLD_NOW | RTLD_LOCAL);
  if (handle) {
    api = Api::resolve(handle);
    if (api) return api;  // Keep the library alive for all in-flight ranges.
    dlclose(handle);
  }
  throw std::runtime_error(
      "Tensor profiling requires aclprofStr2Id, MsprofSysCycleTime, MsprofReportApi, "
      "MsprofReportCompactInfo, MsprofReportAdditionalInfo and MsprofRegTypeInfo "
      "from libmsprofiler.so; source a compatible CANN environment");
}

Api& runtimeApi() {
  static Api api = loadApi();
  return api;
}
}  // namespace

struct ReportingSession::Impl {
  ProfilingCallbacksV1 callbacks{1, sizeof(ProfilingCallbacksV1), this, begin, end};
  std::vector<AclTensor> tensors;
  std::exception_ptr failure;
  Api* api = nullptr;
  bool active = false;
  bool skipped = false;
  MsprofApi launch{};

  uint32_t validateLaunch(const char* name, const char* opType, uint64_t blocks,
                          uint32_t taskType, uint32_t mixRatio,
                          const ProfilingTensorV1* descriptions, uint64_t count) const {
    if (active || !name || !opType || blocks == 0 || blocks > UINT32_MAX || count > UINT32_MAX ||
        (count && !descriptions))
      throw std::runtime_error("invalid profiling launch description");
    if (!((taskType == 0 || taskType == 2) ? mixRatio == 0 :
          taskType == 4 && mixRatio == 2))
      throw std::runtime_error("invalid profiling kernel task type or MIX block ratio");
    // CANN carries the main block count in the low 16 bits and the
    // slave/main ratio in the high 16 bits for MIX task metadata.
    if (mixRatio && blocks > UINT16_MAX)
      throw std::runtime_error("profiling MIX block count exceeds uint16 range");
    return static_cast<uint32_t>(blocks) | (mixRatio << 16);
  }

  static AclTensor describeTensor(const ProfilingTensorV1& source, const char* name) {
    if (source.rank > 8 || (source.rank && !source.shape))
      throw std::runtime_error("Tensor profiling supports rank <= 8; refusing to truncate shape for " +
                               std::string(name));
    if (source.role > 1 || source.dataType == UINT32_MAX || source.format == UINT32_MAX)
      throw std::runtime_error("Tensor profiling cannot represent dtype, format, or role for " +
                               std::string(name));
    AclTensor tensor{source.role, source.format, source.dataType, source.rank, {}};
    for (uint32_t axis = 0; axis < source.rank; ++axis) {
      const int64_t size = source.shape[axis];
      if (size < 0 || static_cast<uint64_t>(size) > UINT32_MAX)
        throw std::runtime_error("Tensor profiling shape exceeds uint32 range for " + std::string(name));
      tensor.shape[axis] = static_cast<uint32_t>(size);
    }
    return tensor;
  }

  void prepareTensors(const ProfilingTensorV1* descriptions, uint64_t count, const char* name) {
    tensors.clear();
    tensors.reserve(count);
    for (uint64_t i = 0; i < count; ++i)
      tensors.push_back(describeTensor(descriptions[i], name));
  }

  void startLaunch(uint64_t opNameId) {
    // A real NODE_LAUNCH range associates the logical name with the
    // unchanged runtime kernel submission in this thread.
    launch = {};
    launch.magicNumber = kMagic;
    launch.level = kNodeLevel;
    launch.type = kNodeLaunch;
    launch.threadId = static_cast<uint32_t>(syscall(SYS_gettid));
    launch.itemId = opNameId;
    launch.beginTime = api->clock();
  }

  void registerTypes() const {
    for (const auto& type : {std::pair<uint32_t, const char*>{kNodeBasicInfo, "node_basic_info"},
                             {kNodeTensorInfo, "tensor_info"}}) {
      const int32_t status = api->registerType(kNodeLevel, type.first, type.second);
      if (status != 0 && status != kProfilerUninitialized)
        throw std::runtime_error("MsprofRegTypeInfo failed with status " + std::to_string(status));
    }
  }

  bool reportNode(uint64_t opNameId, uint64_t opTypeId, uint32_t taskType,
                  uint32_t reportedBlocks) const {
    MsprofCompactInfo node{};
    node.magicNumber = kMagic;
    node.level = kNodeLevel;
    node.type = kNodeBasicInfo;
    node.threadId = launch.threadId;
    node.dataLen = sizeof(MsprofNodeBasicInfo);
    // The parser joins descriptions strictly inside the launch interval.
    // A timestamp equal to beginTime leaves the Tensor/node info unbound.
    node.timeStamp = launch.beginTime + 1;
    node.data.nodeBasicInfo.opName = opNameId;
    node.data.nodeBasicInfo.opType = opTypeId;
    node.data.nodeBasicInfo.taskType = taskType;
    node.data.nodeBasicInfo.blockDim = reportedBlocks;
    const int32_t status = api->reportCompact(1, &node, sizeof(node));
    if (status == kProfilerUninitialized) return false;
    if (status != 0)
      throw std::runtime_error("MsprofReportCompactInfo failed with status " + std::to_string(status));
    return true;
  }

  void reportTensorPacket(size_t start, uint64_t opNameId) const {
    MsprofAdditionalInfo packet{};
    packet.magicNumber = kMagic;
    packet.level = kNodeLevel;
    packet.type = kNodeTensorInfo;
    packet.threadId = launch.threadId;
    packet.dataLen = sizeof(MsprofTensorInfo);
    packet.timeStamp = launch.beginTime + 1;
    auto* data = &packet.data;
    data->opName = opNameId;
    data->tensorNum = std::min<size_t>(kTensorsPerPacket, tensors.size() - start);
    for (size_t i = 0; i < data->tensorNum; ++i) {
      const auto& tensor = tensors[start + i];
      auto& dest = data->tensorData[i];
      dest.tensorType = tensor.type;
      dest.format = tensor.format;
      dest.dataType = tensor.dataType;
      for (size_t axis = 0; axis < tensor.shapeDim; ++axis) dest.shape[axis] = tensor.shape[axis];
    }
    const int32_t status = api->reportAdditional(1, &packet, sizeof(packet));
    if (status != 0 && status != kProfilerUninitialized)
      throw std::runtime_error("MsprofReportAdditionalInfo failed with status " + std::to_string(status));
  }

  void reportTensors(uint64_t opNameId) const {
    for (size_t start = 0; start < tensors.size(); start += kTensorsPerPacket)
      reportTensorPacket(start, opNameId);
  }

  static int32_t begin(void* context, const char* name, const char* opType, uint64_t blocks,
                       uint32_t taskType, uint32_t mixRatio, void* stream,
                       const ProfilingTensorV1* descriptions, uint64_t count) noexcept {
    auto& self = *static_cast<Impl*>(context);
    try {
      const uint32_t reportedBlocks = self.validateLaunch(name, opType, blocks, taskType, mixRatio,
                                                          descriptions, count);
      self.prepareTensors(descriptions, count, name);
      self.api = &runtimeApi();
      (void)stream;  // The enclosed runtime submission supplies stream/task identity.
      const uint64_t opNameId = self.api->str2id(name);
      const uint64_t opTypeId = self.api->str2id(opType);
      self.startLaunch(opNameId);
      self.registerTypes();
      if (!self.reportNode(opNameId, opTypeId, taskType, reportedBlocks)) {
        self.skipped = true;
        return 0;
      }
      self.reportTensors(opNameId);
      self.active = true;
      return 0;
    } catch (...) {
      self.failure = std::current_exception();
      return -1;
    }
  }

  static int32_t end(void* context) noexcept {
    auto& self = *static_cast<Impl*>(context);
    try {
      if (self.skipped) {
        self.skipped = false;
        return 0;
      }
      if (!self.active) throw std::runtime_error("profiling launch end has no matching begin");
      self.active = false;
      self.launch.endTime = std::max(self.api->clock(), self.launch.beginTime + 2);
      const int32_t status = self.api->reportApi(1, &self.launch);
      if (status != 0 && status != kProfilerUninitialized)
        throw std::runtime_error("MsprofReportApi failed with status " + std::to_string(status));
      return 0;
    } catch (...) {
      self.failure = std::current_exception();
      return -1;
    }
  }
  ~Impl() {
    if (active) end(this);
  }
};

ReportingSession::ReportingSession() : impl(std::make_unique<Impl>()) {}
ReportingSession::~ReportingSession() = default;
const ProfilingCallbacksV1* ReportingSession::callbacks() const { return &impl->callbacks; }
void ReportingSession::rethrowIfFailed() const {
  if (impl->failure) std::rethrow_exception(impl->failure);
}
}  // namespace cannbotdsl::runtime::profiling
