/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef LIB_BINDINGS_PYTHON_HOSTRUNTIMETENSORLIST_H_
#define LIB_BINDINGS_PYTHON_HOSTRUNTIMETENSORLIST_H_

#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace cannbotdsl::runtime::tensor_list {

class RuntimeApi;

class Reservation {
 public:
  ~Reservation();

  Reservation(const Reservation&) = delete;
  Reservation& operator=(const Reservation&) = delete;

  uintptr_t deviceAddress() const;
  size_t usedWords() const;

  /// Record completion after all kernels consuming this descriptor were
  /// submitted. Idempotent. Throws only when safe retirement is impossible.
  void retire();

 private:
  friend std::shared_ptr<Reservation> stage(const std::shared_ptr<RuntimeApi>&, int32_t, uintptr_t,
                                            const std::vector<uint64_t>&);

  struct Impl;
  explicit Reservation(std::unique_ptr<Impl> impl);
  std::unique_ptr<Impl> impl;
};

/// Resolve the small ACL runtime surface from an already loaded artifact and
/// its dependencies. No CANN symbol is linked into the Python extension.
std::shared_ptr<RuntimeApi> loadRuntimeApi(void* dsoHandle, const std::string& artifactPath);

/// Allocate/reuse a staging block, copy descriptor words on *streamHandle*, and
/// return a reservation that keeps both host and device memory alive.
std::shared_ptr<Reservation> stage(const std::shared_ptr<RuntimeApi>& api, int32_t deviceId,
                                   uintptr_t streamHandle, const std::vector<uint64_t>& words);

}  // namespace cannbotdsl::runtime::tensor_list

#endif  // LIB_BINDINGS_PYTHON_HOSTRUNTIMETENSORLIST_H_
