/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#include "cannbotdsl/Runtime/HostABI.h"
#include "HostRuntimeTensorList.h"
#include "HostRuntimeProfiler.h"
#include "dlpack/dlpack.h"

#include <Python.h>
#include <dlfcn.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <limits>
#include <memory>
#include <mutex>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>
#include <unistd.h>

namespace py = pybind11;
using namespace cannbotdsl::runtime;

namespace {

constexpr size_t kMaximumInspectionRank = 1024;

bool isPowerOfTwo(uint64_t value) { return value != 0 && (value & (value - 1)) == 0; }

std::array<uint8_t, 32> parseDigest(const std::string& value, const char* field) {
  if (value.size() != 64)
    throw std::invalid_argument(std::string(field) + " must be 64 lowercase hex digits");
  std::array<uint8_t, 32> result{};
  auto nibble = [&](char c) -> uint8_t {
    if (c >= '0' && c <= '9') return static_cast<uint8_t>(c - '0');
    if (c >= 'a' && c <= 'f') return static_cast<uint8_t>(c - 'a' + 10);
    throw std::invalid_argument(std::string(field) + " must be 64 lowercase hex digits");
  };
  for (size_t i = 0; i < result.size(); ++i)
    result[i] = static_cast<uint8_t>((nibble(value[i * 2]) << 4) | nibble(value[i * 2 + 1]));
  return result;
}

std::string digestHex(const uint8_t* bytes) {
  static constexpr char digits[] = "0123456789abcdef";
  std::string result(64, '0');
  for (size_t i = 0; i < 32; ++i) {
    result[i * 2] = digits[bytes[i] >> 4];
    result[i * 2 + 1] = digits[bytes[i] & 15];
  }
  return result;
}

bool hasDLPack(py::handle object) {
  return py::hasattr(object, "__dlpack__") && PyCallable_Check(object.attr("__dlpack__").ptr()) &&
         py::hasattr(object, "__dlpack_device__") && PyCallable_Check(object.attr("__dlpack_device__").ptr());
}

enum class DLPackCallMode { Full, StreamOnly };

// A consumed capsule owns its managed tensor independently of its exporter.
// Never run an inherited device deleter in a fork child.
class CapsuleLease {
 public:
  CapsuleLease(py::object exporter, py::object stream, DLPackCallMode callMode)
      : exporter(std::move(exporter)), processId(getpid()) {
    if (!hasDLPack(this->exporter))
      throw py::type_error("tensor does not expose __dlpack__ and __dlpack_device__");
    py::object method = this->exporter.attr("__dlpack__");
    py::object capsule = callMode == DLPackCallMode::StreamOnly
                             ? method(py::arg("stream") = stream)
                             : method(py::arg("stream") = stream,
                                      py::arg("max_version") = py::make_tuple(1, 0), py::arg("copy") = false);
    if (PyCapsule_IsValid(capsule.ptr(), "dltensor_versioned")) {
      auto* value =
          static_cast<DLManagedTensorVersioned*>(PyCapsule_GetPointer(capsule.ptr(), "dltensor_versioned"));
      if (PyCapsule_SetName(capsule.ptr(), "used_dltensor_versioned") != 0) throw py::error_already_set();
      versioned = value;
    } else if (PyCapsule_IsValid(capsule.ptr(), "dltensor")) {
      auto* value = static_cast<DLManagedTensor*>(PyCapsule_GetPointer(capsule.ptr(), "dltensor"));
      if (PyCapsule_SetName(capsule.ptr(), "used_dltensor") != 0) throw py::error_already_set();
      legacy = value;
    } else {
      throw py::value_error("__dlpack__ must return an unconsumed dltensor_versioned or dltensor capsule");
    }
  }
  CapsuleLease(const CapsuleLease&) = delete;
  CapsuleLease& operator=(const CapsuleLease&) = delete;
  ~CapsuleLease() {
    if (processId != getpid()) return;
    if (versioned && versioned->deleter) versioned->deleter(versioned);
    if (legacy && legacy->deleter) legacy->deleter(legacy);
  }
  const DLTensor& tensor() const {
    if (versioned) {
      // The version/deleter prefix is stable even across major versions.
      // Do not access flags or dl_tensor until the major has been checked.
      if (versioned->version.major != 1)
        throw py::value_error("unsupported DLPack major version; expected 1");
      if (versioned->flags & DLPACK_FLAG_BITMASK_IS_COPIED)
        throw py::value_error("copied DLPack tensors are unsupported");
      if (versioned->flags & DLPACK_FLAG_BITMASK_READ_ONLY)
        throw py::value_error("read-only DLPack tensors are unsupported");
      if (versioned->flags != 0) throw py::value_error("unknown DLPack flags are unsupported");
      return versioned->dl_tensor;
    }
    return legacy->dl_tensor;
  }

 private:
  py::object exporter;
  DLManagedTensorVersioned* versioned = nullptr;
  DLManagedTensor* legacy = nullptr;
  pid_t processId;
};

// These records are private, prepared by the Python integration. Identity and
// deduplication always use original, even for detach/int8 transport views.
struct TensorExport {
  py::object record;
  py::object original;
  py::object exporter;
  int32_t deviceType;
  int32_t deviceId;
  py::object layout;
  DLPackCallMode callMode;

  explicit TensorExport(py::object record)
      : record(std::move(record)),
        original(this->record.attr("original")),
        exporter(this->record.attr("exporter")),
        layout(this->record.attr("layout")) {
    auto mode = this->record.attr("dlpack_call_mode").cast<std::string>();
    if (mode == "full")
      callMode = DLPackCallMode::Full;
    else if (mode == "stream_only")
      callMode = DLPackCallMode::StreamOnly;
    else
      throw py::value_error("unknown DLPack call mode: " + mode);
    auto device = this->record.attr("device").cast<std::pair<int32_t, int32_t>>();
    deviceType = device.first;
    deviceId = device.second;
  }
};

using ExportMap = std::unordered_map<PyObject*, TensorExport>;
ExportMap parseExports(py::tuple records) {
  ExportMap result;
  PyTypeObject* type = nullptr;
  int32_t deviceType = 0, deviceId = 0;
  for (py::handle raw : records) {
    TensorExport item(py::reinterpret_borrow<py::object>(raw));
    if (!type) {
      type = Py_TYPE(item.original.ptr());
      deviceType = item.deviceType;
      deviceId = item.deviceId;
    }
    if (Py_TYPE(item.original.ptr()) != type)
      throw py::type_error("changed DLPack provider type in export records");
    if (item.deviceId < 0) throw py::value_error("negative DLPack device id");
    if (item.deviceType != deviceType || item.deviceId != deviceId)
      throw py::value_error("changed DLPack device in export records");
    PyObject* key = item.original.ptr();
    auto found = result.find(key);
    if (found != result.end()) {
      if (!found->second.record.is(item.record))
        throw py::value_error("conflicting export records for the same tensor");
    } else {
      result.emplace(key, std::move(item));
    }
  }
  return result;
}

const TensorExport& exportFor(const ExportMap& exports, PyObject* original) {
  auto found = exports.find(original);
  if (found == exports.end()) throw py::value_error("tensor is missing its DLPack export record");
  return found->second;
}

void validateTransport(const DLTensor& tensor, const std::string& name) {
  const auto dtype = tensor.dtype;
  if (dtype.bits == 0 || dtype.lanes == 0) throw py::value_error(name + " has an invalid DLPack dtype width");
  const bool integer = (dtype.code == kDLInt || dtype.code == kDLUInt) &&
                       (dtype.bits == 8 || dtype.bits == 16 || dtype.bits == 32 || dtype.bits == 64);
  const bool floating = dtype.code == kDLFloat && (dtype.bits == 16 || dtype.bits == 32 || dtype.bits == 64);
  if (dtype.lanes != 1 || !(integer || floating || (dtype.code == kDLBfloat && dtype.bits == 16) ||
                            (dtype.code == kDLBool && dtype.bits == 8)))
    throw py::value_error(name + " has an unsupported DLPack 1.0 transport dtype");
  switch (tensor.device.device_type) {
    case kDLCPU:
    case kDLCUDA:
    case kDLCUDAHost:
    case kDLOpenCL:
    case kDLVulkan:
    case kDLMetal:
    case kDLVPI:
    case kDLROCM:
    case kDLROCMHost:
    case kDLExtDev:
    case kDLCUDAManaged:
    case kDLOneAPI:
    case kDLWebGPU:
    case kDLHexagon:
      break;
    default:
      throw py::value_error(name + " has an unsupported DLPack device type");
  }
}

struct TensorMetadata {
  uintptr_t data = 0;
  uint64_t byteOffset = 0;
  int32_t deviceType = 0;
  int32_t deviceId = 0;
  uint8_t dtypeCode = 0;
  uint8_t dtypeBits = 0;
  uint16_t dtypeLanes = 0;
  int32_t rank = 0;
  std::vector<int64_t> shape;
  std::vector<int64_t> strides;
};

int64_t compactStrideAt(const DLTensor& tensor, int32_t index, const std::string& name) {
  int64_t stride = 1;
  for (int32_t i = tensor.ndim; i-- > index + 1;) {
    const int64_t extent = tensor.shape[i];
    if (extent < 0) throw std::invalid_argument(name + " has a negative DLPack extent");
    if (extent != 0 && stride > std::numeric_limits<int64_t>::max() / extent)
      throw std::invalid_argument(name + " compact DLPack stride overflows int64_t");
    stride *= extent;
  }
  return stride;
}

TensorMetadata readTensor(const DLTensor& tensor, const std::string& name, int32_t expectedRank = -1) {
  validateTransport(tensor, name);
  if (tensor.ndim < 0) throw std::invalid_argument(name + " has a negative DLPack rank");
  if (expectedRank >= 0 && tensor.ndim != expectedRank) {
    std::ostringstream os;
    os << name << " guard failed for rank: expected " << expectedRank << ", got " << tensor.ndim;
    throw std::invalid_argument(os.str());
  }
  if (expectedRank < 0 && static_cast<size_t>(tensor.ndim) > kMaximumInspectionRank)
    throw std::invalid_argument(name + " exceeds the metadata inspection rank limit 1024");
  if (tensor.ndim > 0 && !tensor.shape) throw std::invalid_argument(name + " has null DLPack shape metadata");

  TensorMetadata result;
  result.deviceType = static_cast<int32_t>(tensor.device.device_type);
  result.deviceId = tensor.device.device_id;
  result.dtypeCode = tensor.dtype.code;
  result.dtypeBits = tensor.dtype.bits;
  result.dtypeLanes = tensor.dtype.lanes;
  result.rank = tensor.ndim;
  result.shape.resize(static_cast<size_t>(tensor.ndim));
  result.strides.resize(static_cast<size_t>(tensor.ndim));
  if (result.dtypeBits == 0 || result.dtypeLanes == 0)
    throw std::invalid_argument(name + " has an invalid DLPack dtype width");
  bool empty = false;
  for (int32_t i = 0; i < tensor.ndim; ++i) {
    const int64_t extent = tensor.shape[i];
    if (extent < 0) throw std::invalid_argument(name + " has a negative DLPack extent");
    empty |= extent == 0;
    result.shape[i] = extent;
    result.strides[i] = tensor.strides ? tensor.strides[i] : compactStrideAt(tensor, i, name);
    if (result.strides[i] < 0) throw std::invalid_argument(name + " has a negative DLPack stride");
  }
  if (!tensor.data && !empty) throw std::invalid_argument(name + " has a null DLPack data pointer");
  const uintptr_t base = reinterpret_cast<uintptr_t>(tensor.data);
  if (tensor.byte_offset > std::numeric_limits<uintptr_t>::max() - base)
    throw std::invalid_argument(name + " DLPack byte_offset overflows uintptr_t");
  result.byteOffset = tensor.byte_offset;
  result.data = base + static_cast<uintptr_t>(result.byteOffset);
  if (!empty) {
    uintptr_t maximumElementOffset = 0;
    for (int32_t i = 0; i < tensor.ndim; ++i) {
      const uintptr_t extentMinusOne = static_cast<uintptr_t>(result.shape[i] - 1);
      const uintptr_t stride = static_cast<uintptr_t>(result.strides[i]);
      if (extentMinusOne != 0 && stride > std::numeric_limits<uintptr_t>::max() / extentMinusOne)
        throw std::invalid_argument(name + " DLPack stride span overflows uintptr_t");
      const uintptr_t dimensionSpan = extentMinusOne * stride;
      if (dimensionSpan > std::numeric_limits<uintptr_t>::max() - maximumElementOffset)
        throw std::invalid_argument(name + " DLPack stride span overflows uintptr_t");
      maximumElementOffset += dimensionSpan;
    }
    const uint64_t elementBits = static_cast<uint64_t>(result.dtypeBits) * result.dtypeLanes;
    const uint64_t elementBytes = (elementBits + 7U) / 8U;
    if (maximumElementOffset > std::numeric_limits<uintptr_t>::max() / elementBytes)
      throw std::invalid_argument(name + " DLPack data pointer span overflows uintptr_t");
    const uintptr_t byteSpan = maximumElementOffset * elementBytes;
    const uintptr_t lastByte = byteSpan + static_cast<uintptr_t>(elementBytes - 1);
    if (lastByte < byteSpan || lastByte > std::numeric_limits<uintptr_t>::max() - result.data)
      throw std::invalid_argument(name + " DLPack data pointer span overflows uintptr_t");
  }
  return result;
}

py::tuple metadataTuple(const TensorMetadata& metadata) {
  py::tuple shape(metadata.rank);
  py::tuple strides(metadata.rank);
  for (int32_t i = 0; i < metadata.rank; ++i) {
    shape[i] = metadata.shape[i];
    strides[i] = metadata.strides[i];
  }
  return py::make_tuple(metadata.data, shape, strides, metadata.dtypeCode, metadata.dtypeBits,
                        metadata.dtypeLanes, metadata.deviceType, metadata.deviceId, metadata.byteOffset);
}

struct ExportedTensor {
  TensorMetadata metadata;
  std::shared_ptr<CapsuleLease> capsule;
  py::object record;
};

ExportedTensor consumeTensor(const TensorExport& item, py::object stream, const std::string& name,
                             int32_t rank = -1) {
  auto capsule = std::make_shared<CapsuleLease>(item.exporter, std::move(stream), item.callMode);
  TensorMetadata metadata = readTensor(capsule->tensor(), name, rank);
  if (metadata.deviceType != item.deviceType || metadata.deviceId != item.deviceId)
    throw py::value_error(name + " DLPack device differs from __dlpack_device__");
  if (!item.layout.is_none()) {
    py::tuple layout = item.layout.cast<py::tuple>();
    const auto data = layout[0].cast<uintptr_t>();
    const auto shape = layout[1].cast<std::vector<int64_t>>();
    const auto strides = layout[2].cast<std::vector<int64_t>>();
    const auto dtype = layout[3].cast<std::array<uint32_t, 3>>();
    if (metadata.data != data || metadata.shape != shape || strides.size() != shape.size())
      throw py::value_error(name + " DLPack address/shape differs from original tensor");
    const bool fp8 = dtype[0] == 10 || dtype[0] == 12 || dtype[0] == 14;
    if (metadata.dtypeCode != (fp8 ? static_cast<uint32_t>(kDLInt) : dtype[0]) ||
        metadata.dtypeBits != dtype[1] || metadata.dtypeLanes != dtype[2] ||
        (fp8 && (dtype[1] != 8 || dtype[2] != 1)))
      throw py::value_error(name + " DLPack transport dtype differs from original tensor");
    for (size_t i = 0; i < shape.size(); ++i) {
      if (strides[i] < 0 || (shape[i] >= 2 && strides[i] != metadata.strides[i]))
        throw py::value_error(name + " DLPack stride differs on a non-singleton axis");
    }
    metadata.strides = strides;
    // Internal semantic codes are ABI v9 values, never DLPack 1.0 encodings.
    metadata.dtypeCode = dtype[0];
    metadata.dtypeBits = dtype[1];
    metadata.dtypeLanes = dtype[2];
  }
  return {std::move(metadata), std::move(capsule), item.record};
}

py::tuple inspectTensorBatch(py::tuple records, py::object stream) {
  ExportMap exports = parseExports(records);
  py::tuple result(records.size());
  std::unordered_map<PyObject*, TensorMetadata> snapshots;
  for (size_t i = 0; i < static_cast<size_t>(records.size()); ++i) {
    py::object original = records[i].attr("original");
    auto found = snapshots.find(original.ptr());
    if (found == snapshots.end()) {
      auto tensor =
          consumeTensor(exportFor(exports, original.ptr()), stream, "tensor[" + std::to_string(i) + "]");
      found = snapshots.emplace(original.ptr(), std::move(tensor.metadata)).first;
    }  // release the capsule after copying metadata
    result[i] = metadataTuple(found->second);
  }
  return result;
}

struct ExpectedSlot {
  uint32_t kind = 0;
  uint32_t logicalRank = 0;
  uint32_t physicalRank = 0;
  HostTensorEncoding encoding = HostTensorEncoding::Identity;
  uint32_t dtypeCode = 0;
  uint32_t dtypeBits = 0;
  uint32_t dtypeLanes = 0;
  bool checkDType = false;
  uint64_t size = 0;
  uint64_t alignment = 0;
  uint64_t pointerOffset = 0;
  uint64_t shapeOffset = 0;
  uint64_t strideOffset = 0;
  uint64_t physicalShapeOffset = 0;
  uint64_t physicalStrideOffset = 0;
  std::array<uint8_t, 32> typeDigest{};
  bool isPublic = true;
};

enum class PlanSlotKind { Tensor, TensorList, Scalar, Buffer };
enum class ExpressionKind { Constant, Dimension, Add, Sub, Mul, FloorDiv };
enum class TensorListLayoutKind { None, Template, Exact };

struct DimensionRule {
  std::string name;
  int64_t minimum = 0;
  int64_t maximum = 0;
  bool hasMaximum = false;
  int64_t multipleOf = 1;
};

struct ExpressionStep {
  ExpressionKind kind = ExpressionKind::Constant;
  std::string rendered;
  int64_t value = 0;
  size_t dimension = 0;
  size_t lhs = 0;
  size_t rhs = 0;
};

struct ExactElementLayout {
  std::vector<int64_t> shape;
  std::vector<int64_t> stride;
};

struct PlanSlot {
  std::string handleKind;
  PlanSlotKind kind = PlanSlotKind::Buffer;
  std::string name;
  uint8_t dtypeCode = 0;
  uint8_t dtypeBits = 0;
  uint16_t dtypeLanes = 0;
  uint32_t rank = 0;
  uint32_t physicalRank = 0;
  HostTensorEncoding encoding = HostTensorEncoding::Identity;
  std::vector<size_t> shapeExpressions;
  std::vector<size_t> strideExpressions;
  std::vector<size_t> physicalShapeExpressions;
  std::string scalarKind;
  uint32_t scalarBits = 0;
  bool scalarSigned = false;
  bool isPublic = true;
  uint64_t dataAlignment = 1;
  bool requireExactStride = false;
  bool requireZeroByteOffset = false;
  uint32_t descriptorVersion = 0;
  uint64_t recordWords = 0;
  size_t lengthExpression = 0;
  uint8_t elementDTypeCode = 0;
  uint8_t elementDTypeBits = 0;
  uint16_t elementDTypeLanes = 0;
  uint32_t elementRank = 0;
  TensorListLayoutKind tensorListLayoutKind = TensorListLayoutKind::None;
  std::vector<DimensionRule> elementDimensions;
  std::vector<ExpressionStep> elementExpressions;
  std::vector<size_t> elementShapeExpressions;
  std::vector<size_t> elementStrideExpressions;
  std::vector<ExactElementLayout> exactLayouts;
};

class HostProgramPlanData {
 public:
  HostProgramPlanData(py::dict specification, const std::vector<ExpectedSlot>& expectedSlots) {
    parseDimensions(specification["dimensions"]);
    parseExpressions(specification["expressions"]);
    parseSlots(specification["slots"], expectedSlots);
  }

  std::vector<DimensionRule> dimensions;
  std::vector<ExpressionStep> expressions;
  std::vector<PlanSlot> slots;
  size_t publicSlotCount = 0;
  size_t firstTensorIndex = std::numeric_limits<size_t>::max();

 private:
  static HostTensorEncoding tensorEncoding(const std::string& encoding) {
    if (encoding == "identity") return HostTensorEncoding::Identity;
    if (encoding == "fractal_nz") return HostTensorEncoding::FractalNZ;
    throw std::invalid_argument("HostProgramSpec has an unknown tensor encoding");
  }

  static ExpressionKind expressionKind(const std::string& kind) {
    if (kind == "constant") return ExpressionKind::Constant;
    if (kind == "dimension") return ExpressionKind::Dimension;
    if (kind == "add") return ExpressionKind::Add;
    if (kind == "sub") return ExpressionKind::Sub;
    if (kind == "mul") return ExpressionKind::Mul;
    if (kind == "floordiv") return ExpressionKind::FloorDiv;
    throw std::invalid_argument("HostProgramSpec has an unknown expression kind");
  }

  static std::vector<DimensionRule> parseDimensionRules(py::handle value) {
    std::vector<DimensionRule> result;
    for (py::handle handle : py::reinterpret_borrow<py::iterable>(value)) {
      py::dict item = py::reinterpret_borrow<py::dict>(handle);
      DimensionRule rule;
      rule.name = item["name"].cast<std::string>();
      rule.minimum = item["minimum"].cast<int64_t>();
      py::object maximum = py::reinterpret_borrow<py::object>(item["maximum"]);
      if (!maximum.is_none()) {
        rule.maximum = maximum.cast<int64_t>();
        rule.hasMaximum = true;
      }
      rule.multipleOf = item["multiple_of"].cast<int64_t>();
      if (rule.minimum < 0 || rule.multipleOf <= 0 || (rule.hasMaximum && rule.maximum < rule.minimum))
        throw std::invalid_argument("HostProgramSpec has an invalid dimension constraint");
      result.push_back(std::move(rule));
    }
    return result;
  }

  void parseDimensions(py::handle value) { dimensions = parseDimensionRules(value); }

  static std::vector<ExpressionStep> parseExpressionSteps(py::handle value, size_t dimensionCount) {
    std::vector<ExpressionStep> result;
    for (py::handle handle : py::reinterpret_borrow<py::iterable>(value)) {
      py::dict item = py::reinterpret_borrow<py::dict>(handle);
      ExpressionStep step;
      step.kind = expressionKind(item["kind"].cast<std::string>());
      step.rendered = item["rendered"].cast<std::string>();
      const size_t current = result.size();
      if (step.kind == ExpressionKind::Constant) {
        step.value = item["value"].cast<int64_t>();
      } else if (step.kind == ExpressionKind::Dimension) {
        step.dimension = item["dimension"].cast<size_t>();
        if (step.dimension >= dimensionCount)
          throw std::invalid_argument("HostProgramSpec expression references an invalid dimension");
      } else {
        step.lhs = item["lhs"].cast<size_t>();
        step.rhs = item["rhs"].cast<size_t>();
        if (step.lhs >= current || step.rhs >= current)
          throw std::invalid_argument("HostProgramSpec expression is not topologically ordered");
      }
      result.push_back(std::move(step));
    }
    return result;
  }

  void parseExpressions(py::handle value) { expressions = parseExpressionSteps(value, dimensions.size()); }

  static std::vector<size_t> parseExpressionIndices(py::handle value, const char* field,
                                                    size_t expressionCount) {
    std::vector<size_t> result;
    for (py::handle item : py::reinterpret_borrow<py::iterable>(value)) {
      const size_t index = item.cast<size_t>();
      if (index >= expressionCount)
        throw std::invalid_argument(std::string("HostProgramSpec ") + field +
                                    " references an invalid expression");
      result.push_back(index);
    }
    return result;
  }

  void parseSlots(py::handle value, const std::vector<ExpectedSlot>& expectedSlots) {
    size_t index = 0;
    for (py::handle handle : py::reinterpret_borrow<py::iterable>(value)) {
      if (index >= expectedSlots.size())
        throw std::invalid_argument("HostProgramSpec has more call slots than schema slots");
      py::dict item = py::reinterpret_borrow<py::dict>(handle);
      PlanSlot plan;
      plan.name = item["name"].cast<std::string>();
      plan.isPublic = item["public"].cast<bool>();
      const std::string kind = item["kind"].cast<std::string>();
      const ExpectedSlot& expected = expectedSlots[index];
      if (plan.isPublic != expected.isPublic)
        throw std::invalid_argument("HostProgramSpec call/schema visibility mismatch at slot " +
                                    std::to_string(index));
      if (!plan.isPublic && index < publicSlotCount)
        throw std::invalid_argument("HostProgramSpec public slots must precede internal slots");
      if (plan.isPublic) {
        if (index != publicSlotCount)
          throw std::invalid_argument("HostProgramSpec public slots must be contiguous");
        ++publicSlotCount;
      }
      if (item.contains(py::str("handle_kind"))) {
        plan.handleKind = item["handle_kind"].cast<std::string>();
        if (!plan.handleKind.empty() && plan.handleKind != "jetty" && plan.handleKind != "ubmem_peer" &&
            plan.handleKind != "urma_peer" && plan.handleKind != "ubmem_connection" && plan.handleKind != "urma_connection")
          throw std::invalid_argument("invalid communication handle kind");
      }
      if (kind == "tensor") {
        plan.kind = PlanSlotKind::Tensor;
        plan.dtypeCode = item["dtype_code"].cast<uint8_t>();
        plan.dtypeBits = item["dtype_bits"].cast<uint8_t>();
        plan.dtypeLanes = item["dtype_lanes"].cast<uint16_t>();
        plan.rank = item["rank"].cast<uint32_t>();
        plan.encoding = tensorEncoding(item["encoding"].cast<std::string>());
        plan.physicalRank = item["physical_rank"].cast<uint32_t>();
        plan.shapeExpressions = parseExpressionIndices(item["shape"], "shape", expressions.size());
        plan.strideExpressions = parseExpressionIndices(item["stride"], "stride", expressions.size());
        plan.physicalShapeExpressions =
            parseExpressionIndices(item["physical_shape"], "physical_shape", expressions.size());
        if (item.contains(py::str("data_alignment")))
          plan.dataAlignment = item["data_alignment"].cast<uint64_t>();
        if (item.contains(py::str("require_exact_stride")))
          plan.requireExactStride = item["require_exact_stride"].cast<bool>();
        if (item.contains(py::str("require_zero_byte_offset")))
          plan.requireZeroByteOffset = item["require_zero_byte_offset"].cast<bool>();
        if (plan.rank > static_cast<uint32_t>(std::numeric_limits<int32_t>::max()) ||
            plan.shapeExpressions.size() != plan.rank || plan.strideExpressions.size() != plan.rank ||
            plan.physicalShapeExpressions.size() != plan.physicalRank ||
            (plan.encoding == HostTensorEncoding::Identity && plan.physicalRank != plan.rank) ||
            (plan.encoding == HostTensorEncoding::FractalNZ &&
             (plan.rank < 2 || plan.rank > 3 || plan.physicalRank != plan.rank + 2)) ||
            expected.kind != static_cast<uint32_t>(HostSlotKind::Tensor) ||
            expected.logicalRank != plan.rank || expected.physicalRank != plan.physicalRank ||
            expected.encoding != plan.encoding || !expected.checkDType ||
            expected.dtypeCode != plan.dtypeCode || expected.dtypeBits != plan.dtypeBits ||
            expected.dtypeLanes != plan.dtypeLanes)
          throw std::invalid_argument("HostProgramSpec tensor mismatch at slot " + std::to_string(index));
        if (!isPowerOfTwo(plan.dataAlignment))
          throw std::invalid_argument(
              "HostProgramSpec tensor data_alignment must be a positive "
              "power of two at slot " +
              std::to_string(index));
        if (plan.isPublic && firstTensorIndex == std::numeric_limits<size_t>::max()) firstTensorIndex = index;
      } else if (kind == "tensor_list") {
        if (!plan.isPublic) throw std::invalid_argument("HostProgramSpec internal slots must be tensors");
        plan.kind = PlanSlotKind::TensorList;
        plan.descriptorVersion = item["descriptor_version"].cast<uint32_t>();
        plan.recordWords = item["record_words"].cast<uint64_t>();
        plan.lengthExpression = item["length"].cast<size_t>();
        plan.elementDTypeCode = item["element_dtype_code"].cast<uint8_t>();
        plan.elementDTypeBits = item["element_dtype_bits"].cast<uint8_t>();
        plan.elementDTypeLanes = item["element_dtype_lanes"].cast<uint16_t>();
        plan.elementRank = item["element_rank"].cast<uint32_t>();
        plan.requireExactStride = item["require_exact_stride"].cast<bool>();
        const std::string layoutKind = item["layout_kind"].cast<std::string>();
        if (layoutKind == "template") {
          plan.tensorListLayoutKind = TensorListLayoutKind::Template;
          plan.elementDimensions = parseDimensionRules(item["element_dimensions"]);
          plan.elementExpressions =
              parseExpressionSteps(item["element_expressions"], plan.elementDimensions.size());
          plan.elementShapeExpressions =
              parseExpressionIndices(item["element_shape"], "element_shape", plan.elementExpressions.size());
          plan.elementStrideExpressions = parseExpressionIndices(item["element_stride"], "element_stride",
                                                                 plan.elementExpressions.size());
        } else if (layoutKind == "exact") {
          plan.tensorListLayoutKind = TensorListLayoutKind::Exact;
          for (py::handle layoutHandle : py::reinterpret_borrow<py::iterable>(item["exact_layouts"])) {
            py::dict layout = py::reinterpret_borrow<py::dict>(layoutHandle);
            ExactElementLayout exact;
            exact.shape = layout["shape"].cast<std::vector<int64_t>>();
            exact.stride = layout["stride"].cast<std::vector<int64_t>>();
            if (exact.shape.size() != plan.elementRank || exact.stride.size() != plan.elementRank)
              throw std::invalid_argument("HostProgramSpec TensorList exact layout rank mismatch");
            for (int64_t value : exact.shape)
              if (value < 0)
                throw std::invalid_argument("HostProgramSpec TensorList exact shape is negative");
            for (int64_t value : exact.stride)
              if (value < 0)
                throw std::invalid_argument("HostProgramSpec TensorList exact stride is negative");
            plan.exactLayouts.push_back(std::move(exact));
          }
        } else {
          throw std::invalid_argument("HostProgramSpec TensorList has an unknown layout kind");
        }
        const uint64_t expectedRecordWords = 1U + static_cast<uint64_t>(plan.elementRank) * 2U;
        const bool invalidTemplate = plan.tensorListLayoutKind == TensorListLayoutKind::Template &&
                                     (plan.elementShapeExpressions.size() != plan.elementRank ||
                                      plan.elementStrideExpressions.size() != plan.elementRank);
        const bool invalidExact =
            plan.tensorListLayoutKind == TensorListLayoutKind::Exact &&
            (plan.lengthExpression >= expressions.size() ||
             expressions[plan.lengthExpression].kind != ExpressionKind::Constant ||
             expressions[plan.lengthExpression].value < 1 ||
             static_cast<uint64_t>(expressions[plan.lengthExpression].value) != plan.exactLayouts.size());
        if (plan.descriptorVersion != 2 || plan.recordWords != expectedRecordWords ||
            plan.lengthExpression >= expressions.size() ||
            (expressions[plan.lengthExpression].kind != ExpressionKind::Constant &&
             expressions[plan.lengthExpression].kind != ExpressionKind::Dimension) ||
            plan.elementRank > static_cast<uint32_t>(std::numeric_limits<int32_t>::max()) ||
            invalidTemplate || invalidExact || plan.elementDTypeBits == 0 || plan.elementDTypeLanes == 0 ||
            expected.kind != static_cast<uint32_t>(HostSlotKind::Tensor) || expected.logicalRank != 1 ||
            expected.physicalRank != 1 || expected.encoding != HostTensorEncoding::Identity ||
            !expected.checkDType || expected.dtypeCode != static_cast<uint32_t>(kDLUInt) ||
            expected.dtypeBits != 64 || expected.dtypeLanes != 1)
          throw std::invalid_argument("HostProgramSpec TensorList mismatch at slot " + std::to_string(index));
        if (plan.handleKind.empty() && firstTensorIndex == std::numeric_limits<size_t>::max()) firstTensorIndex = index;
      } else if (kind == "scalar") {
        if (!plan.isPublic) throw std::invalid_argument("HostProgramSpec internal slots must be tensors");
        plan.kind = PlanSlotKind::Scalar;
        plan.scalarKind = item["scalar_kind"].cast<std::string>();
        plan.scalarBits = item["bits"].cast<uint32_t>();
        plan.scalarSigned = item["signed"].cast<bool>();
        const uint64_t scalarBytes = (plan.scalarBits + 7U) / 8U;
        if ((plan.scalarKind != "bool" && plan.scalarKind != "int" && plan.scalarKind != "float") ||
            expected.kind != static_cast<uint32_t>(HostSlotKind::Scalar) || scalarBytes != expected.size ||
            (plan.scalarKind == "bool" && plan.scalarBits != 1) ||
            (plan.scalarKind == "float" && plan.scalarBits != 32 && plan.scalarBits != 64) ||
            (plan.scalarKind == "int" && plan.scalarBits != 8 && plan.scalarBits != 16 &&
             plan.scalarBits != 32 && plan.scalarBits != 64))
          throw std::invalid_argument("HostProgramSpec scalar mismatch at slot " + std::to_string(index));
      } else if (kind == "buffer") {
        if (!plan.isPublic || expected.kind != static_cast<uint32_t>(HostSlotKind::Buffer))
          throw std::invalid_argument("HostProgramSpec buffer mismatch at slot " + std::to_string(index));
        plan.kind = PlanSlotKind::Buffer;
      } else {
        throw std::invalid_argument("HostProgramSpec has an unknown slot kind");
      }
      slots.push_back(std::move(plan));
      ++index;
    }
    if (index != expectedSlots.size())
      throw std::invalid_argument("HostProgramSpec call/schema slot count mismatch");
    if (publicSlotCount == 0) throw std::invalid_argument("HostProgramSpec is missing public slots");
    if (firstTensorIndex == std::numeric_limits<size_t>::max())
      throw std::invalid_argument("HostProgramSpec requires a public canonical tensor");
  }
};

struct CallSchemaData {
  CannBotHostSchemaV2 header{};
  std::vector<CannBotHostSlotSchemaV2> slots;
  std::string contractDigest;
};

struct TensorListApiState {
  pid_t processId = getpid();
  std::mutex mutex;
  std::shared_ptr<tensor_list::RuntimeApi> api;
};

struct RetainedDSOState {
  pid_t processId = getpid();
  std::mutex mutex;
  std::vector<void*> handles;
};

std::atomic<RetainedDSOState*>& retainedDSOStateSlot() {
  static auto* state = new std::atomic<RetainedDSOState*>(new RetainedDSOState());
  return *state;
}

RetainedDSOState& retainedDSOState() {
  auto& slot = retainedDSOStateSlot();
  while (true) {
    RetainedDSOState* state = slot.load(std::memory_order_acquire);
    if (state->processId == getpid()) return *state;
    auto* replacement = new RetainedDSOState();
    if (slot.compare_exchange_strong(state, replacement, std::memory_order_acq_rel,
                                     std::memory_order_acquire))
      return *replacement;
    delete replacement;
  }
}

std::vector<void*>& retainedDSOHandles() { return retainedDSOState().handles; }

std::mutex& retainedDSOMutex() { return retainedDSOState().mutex; }

class ProgramImage : public std::enable_shared_from_this<ProgramImage> {
 public:
  ProgramImage(std::string path, std::string symbol, py::dict specification)
      : path(std::move(path)), symbol(std::move(symbol)), processId(getpid()), tensorListApiState(nullptr) {
    expectedDigest = parseDigest(specification["contract_digest"].cast<std::string>(), "contract_digest");
    for (py::handle handle : py::reinterpret_borrow<py::iterable>(specification["expected_slots"])) {
      py::dict item = py::reinterpret_borrow<py::dict>(handle);
      ExpectedSlot slot;
      slot.kind = item["kind"].cast<uint32_t>();
      slot.logicalRank = item["logical_rank"].cast<uint32_t>();
      slot.physicalRank = item["physical_rank"].cast<uint32_t>();
      const uint32_t rawEncoding = item["encoding"].cast<uint32_t>();
      if (rawEncoding > static_cast<uint32_t>(HostTensorEncoding::FractalNZ))
        throw std::invalid_argument("HostProgramSpec has an invalid expected tensor encoding");
      slot.encoding = static_cast<HostTensorEncoding>(rawEncoding);
      if (item.contains("dtype_code")) {
        slot.dtypeCode = item["dtype_code"].cast<uint32_t>();
        slot.dtypeBits = item["dtype_bits"].cast<uint32_t>();
        slot.dtypeLanes = item["dtype_lanes"].cast<uint32_t>();
        slot.checkDType = true;
      }
      slot.size = item["size"].cast<uint64_t>();
      slot.alignment = item["alignment"].cast<uint64_t>();
      slot.pointerOffset = item["pointer_offset"].cast<uint64_t>();
      slot.shapeOffset = item["shape_offset"].cast<uint64_t>();
      slot.strideOffset = item["stride_offset"].cast<uint64_t>();
      slot.physicalShapeOffset = item["physical_shape_offset"].cast<uint64_t>();
      slot.physicalStrideOffset = item["physical_stride_offset"].cast<uint64_t>();
      slot.typeDigest = parseDigest(item["type_digest"].cast<std::string>(), "type_digest");
      slot.isPublic = item["public"].cast<bool>();
      expectedSlots.push_back(slot);
    }
    // Parse and validate every trusted binding rule before dlopen.  HostCallPlan
    // only reuses this immutable native representation.
    plan = std::make_shared<HostProgramPlanData>(specification, expectedSlots);
    loadAndValidate();
  }

  ~ProgramImage() {
    // A child must not destroy an inherited state: its mutex may have been
    // owned by a vanished parent thread at fork.  The inherited allocation is
    // intentionally left behind in the child; process exit reclaims it.  A
    // state created by this process has ordinary ownership and is released.
    TensorListApiState* state = tensorListApiState.load(std::memory_order_acquire);
    if (state && state->processId == getpid()) delete state;
    // Successful DSO handles are retained conservatively by the process-wide
    // handle registry.
  }

  std::shared_ptr<const CallSchemaData> schemaData() const { return schema; }
  std::shared_ptr<const HostProgramPlanData> planData() const { return plan; }
  const std::string& pathName() const { return path; }
  const std::string& symbolName() const { return symbol; }

  HostInvokeFunctionV9 invokeFunction() {
    ensureCurrentProcess();
    return invoke;
  }

  HostProfileInvokeFunctionV1 profilingInvokeFunction() {
    ensureCurrentProcess();
    return profileInvoke;
  }

  std::shared_ptr<tensor_list::RuntimeApi> tensorListRuntime() {
    ensureCurrentProcess();
    TensorListApiState* state = tensorListApiState.load(std::memory_order_acquire);
    const pid_t current = getpid();
    while (!state || state->processId != current) {
      auto* replacement = new TensorListApiState();
      if (tensorListApiState.compare_exchange_weak(state, replacement, std::memory_order_acq_rel,
                                                   std::memory_order_acquire)) {
        state = replacement;
        break;
      }
      // compare_exchange updates state on failure.  Only this uninstalled
      // process-local temporary is safe to destroy; an inherited state must
      // never have its possibly locked mutex destructed after fork.
      delete replacement;
    }
    std::lock_guard<std::mutex> lock(state->mutex);
    if (!state->api) state->api = tensor_list::loadRuntimeApi(handle, path);
    return state->api;
  }

 private:
  void ensureCurrentProcess() {
    const pid_t current = getpid();
    pid_t observed = processId.load(std::memory_order_acquire);
    if (current == observed) return;
    while (true) {
      if (observed == current) return;
      if (observed == 0) {
        std::this_thread::yield();
        observed = processId.load(std::memory_order_acquire);
        continue;
      }
      const pid_t inherited = observed;
      if (!processId.compare_exchange_weak(observed, 0, std::memory_order_acq_rel, std::memory_order_acquire))
        continue;
      try {
        handle = nullptr;
        schemaFunction = nullptr;
        invoke = nullptr;
        loadAndValidate();
        processId.store(current, std::memory_order_release);
      } catch (...) {
        processId.store(inherited, std::memory_order_release);
        throw;
      }
      return;
    }
  }

  [[noreturn]] void symbolError(const std::string& exportName) {
    const char* detail = dlerror();
    std::ostringstream os;
    os << "artifact is missing required ABI v9 symbol '" << exportName << "'";
    if (detail) os << ": " << detail;
    throw std::runtime_error(os.str());
  }

  void validateSchema(const CannBotHostSchemaV2* binary) {
    if (!binary) throw std::runtime_error("ABI v9 schema export returned null");
    if (binary->magic != kHostSchemaMagicV2)
      throw std::runtime_error("binary host schema has an invalid magic");
    if (binary->hostAbiVersion != kHostABIVersion) {
      std::ostringstream os;
      os << "artifact uses host ABI " << binary->hostAbiVersion
         << "; runtime requires ABI 9. Recompile the artifact.";
      throw std::runtime_error(os.str());
    }
    if (binary->schemaVersion != kHostSchemaVersion)
      throw std::runtime_error("binary host schema version is not 2");
    if (binary->reserved != 0) throw std::runtime_error("binary host schema reserved field is nonzero");
    const size_t expectedCount = expectedSlots.size();
    if (binary->slotCount != expectedCount) {
      std::ostringstream os;
      os << "binary host schema slot count mismatch: expected " << expectedCount << ", got "
         << binary->slotCount;
      throw std::runtime_error(os.str());
    }
    if (std::memcmp(binary->contractDigest, expectedDigest.data(), 32) != 0)
      throw std::runtime_error("binary host schema contract digest mismatch");
    if (binary->frameBytes < sizeof(CannBotCallFrameHeaderV9) || !isPowerOfTwo(binary->frameAlignment) ||
        binary->frameAlignment < alignof(CannBotCallFrameHeaderV9))
      throw std::runtime_error("binary host schema has an invalid frame layout");
    if (binary->slotCount && !binary->slots)
      throw std::runtime_error("binary host schema has a null slot table");

    uint64_t expectedOffset = sizeof(CannBotCallFrameHeaderV9);
    uint64_t expectedFrameAlignment = alignof(CannBotCallFrameHeaderV9);
    for (size_t i = 0; i < binary->slotCount; ++i) {
      const CannBotHostSlotSchemaV2& slot = binary->slots[i];
      if (slot.kind < static_cast<uint32_t>(HostSlotKind::Tensor) ||
          slot.kind > static_cast<uint32_t>(HostSlotKind::Buffer))
        throw std::runtime_error("binary host schema has an invalid slot kind");
      if (!isPowerOfTwo(slot.alignment) || slot.size == 0 || slot.alignment > binary->frameAlignment ||
          slot.offset % slot.alignment != 0 || slot.offset < expectedOffset ||
          slot.offset > binary->frameBytes || slot.size > binary->frameBytes - slot.offset)
        throw std::runtime_error(
            "binary host schema has overlapping or "
            "out-of-range slots");
      const uint64_t padding = (slot.alignment - expectedOffset % slot.alignment) % slot.alignment;
      if (padding > std::numeric_limits<uint64_t>::max() - expectedOffset ||
          slot.offset != expectedOffset + padding)
        throw std::runtime_error("binary host schema is not a natural packed-frame layout");
      expectedOffset = slot.offset + slot.size;
      expectedFrameAlignment = std::max(expectedFrameAlignment, slot.alignment);
      const bool tensorStorage =
          slot.logicalRank != 0 || slot.kind == static_cast<uint32_t>(HostSlotKind::Tensor);
      if (tensorStorage) {
        const uint64_t logicalMetadataBytes = static_cast<uint64_t>(slot.logicalRank) * sizeof(int64_t);
        const uint64_t physicalMetadataBytes = static_cast<uint64_t>(slot.physicalRank) * sizeof(int64_t);
        if (slot.encoding > static_cast<uint32_t>(HostTensorEncoding::FractalNZ) ||
            (slot.encoding == static_cast<uint32_t>(HostTensorEncoding::Identity) &&
             (slot.logicalRank != slot.physicalRank || slot.physicalShapeOffset != slot.shapeOffset ||
              slot.physicalStrideOffset != slot.strideOffset)) ||
            (slot.encoding == static_cast<uint32_t>(HostTensorEncoding::FractalNZ) &&
             (slot.logicalRank < 2 || slot.logicalRank > 3 || slot.physicalRank != slot.logicalRank + 2)))
          throw std::runtime_error("binary tensor slot has an invalid physical encoding");
        if (slot.pointerOffset > slot.size || sizeof(void*) > slot.size - slot.pointerOffset ||
            slot.shapeOffset > slot.size || logicalMetadataBytes > slot.size - slot.shapeOffset ||
            slot.strideOffset > slot.size || logicalMetadataBytes > slot.size - slot.strideOffset ||
            slot.physicalShapeOffset > slot.size ||
            physicalMetadataBytes > slot.size - slot.physicalShapeOffset ||
            slot.physicalStrideOffset > slot.size ||
            physicalMetadataBytes > slot.size - slot.physicalStrideOffset)
          throw std::runtime_error("binary tensor slot metadata offsets are out of range");
      }
      const ExpectedSlot& expected = expectedSlots[i];
      const uint32_t expectedFlags = expected.isPublic ? HostSlotPublic : HostSlotInternalDebug;
      if (slot.kind != expected.kind || slot.logicalRank != expected.logicalRank ||
          slot.physicalRank != expected.physicalRank ||
          slot.encoding != static_cast<uint32_t>(expected.encoding) || slot.flags != expectedFlags ||
          slot.size != expected.size || slot.alignment != expected.alignment ||
          slot.pointerOffset != expected.pointerOffset || slot.shapeOffset != expected.shapeOffset ||
          slot.strideOffset != expected.strideOffset ||
          slot.physicalShapeOffset != expected.physicalShapeOffset ||
          slot.physicalStrideOffset != expected.physicalStrideOffset ||
          (expected.checkDType &&
           (slot.dtypeCode != expected.dtypeCode || slot.dtypeBits != expected.dtypeBits ||
            slot.dtypeLanes != expected.dtypeLanes)) ||
          std::memcmp(slot.abiTypeDigest, expected.typeDigest.data(), 32) != 0)
        throw std::runtime_error("binary host slot schema does not match CallContract at slot " +
                                 std::to_string(i));
    }
    const uint64_t tailPadding =
        (expectedFrameAlignment - expectedOffset % expectedFrameAlignment) % expectedFrameAlignment;
    if (tailPadding > std::numeric_limits<uint64_t>::max() - expectedOffset ||
        binary->frameAlignment != expectedFrameAlignment ||
        binary->frameBytes != expectedOffset + tailPadding)
      throw std::runtime_error("binary host schema frame tail is malformed");

    auto copied = std::make_shared<CallSchemaData>();
    copied->header = *binary;
    copied->slots.assign(binary->slots, binary->slots + binary->slotCount);
    copied->header.slots = copied->slots.data();
    copied->contractDigest = digestHex(binary->contractDigest);
    schema = std::move(copied);
  }

  void loadAndValidate() {
    void* newHandle = dlopen(path.c_str(), RTLD_NOW | RTLD_LOCAL);
    if (!newHandle) {
      const char* detail = dlerror();
      throw std::runtime_error("failed to load host artifact '" + path +
                               "': " + (detail ? detail : "unknown dlopen error"));
    }
    handle = newHandle;
    const std::string schemaExport = symbol + "__cannbot_schema_v2";
    const std::string invokeExport = symbol + "__cannbot_invoke_v9";
    dlerror();
    schemaFunction = reinterpret_cast<HostSchemaFunctionV2>(dlsym(handle, schemaExport.c_str()));
    if (!schemaFunction) {
      dlerror();
      const std::string v8SchemaExport = symbol + "__cannbot_schema_v1";
      void* v8Schema = dlsym(handle, v8SchemaExport.c_str());
      if (v8Schema) {
        dlclose(handle);
        handle = nullptr;
        throw std::runtime_error(
            "artifact uses host ABI 8; runtime requires ABI 9. Recompile "
            "the artifact.");
      }
      dlerror();
      void* legacyHostSymbol = dlsym(handle, symbol.c_str());
      dlclose(handle);
      handle = nullptr;
      if (legacyHostSymbol)
        throw std::runtime_error(
            "artifact uses a pre-v8 host ABI; runtime requires ABI 9. Recompile "
            "the artifact.");
      symbolError(schemaExport);
    }
    dlerror();
    invoke = reinterpret_cast<HostInvokeFunctionV9>(dlsym(handle, invokeExport.c_str()));
    if (!invoke) {
      dlclose(handle);
      handle = nullptr;
      symbolError(invokeExport);
    }
    try {
      validateSchema(schemaFunction());
    } catch (...) {
      dlclose(handle);
      handle = nullptr;
      schemaFunction = nullptr;
      invoke = nullptr;
      throw;
    }
    dlerror();
    profileInvoke = reinterpret_cast<HostProfileInvokeFunctionV1>(
        dlsym(handle, (symbol + "__cannbot_invoke_profile_v1").c_str()));
    dlerror();  // Profiling is optional for existing v9 artifacts.
    std::lock_guard<std::mutex> lock(retainedDSOMutex());
    retainedDSOHandles().push_back(handle);
  }

  std::string path;
  std::string symbol;
  std::array<uint8_t, 32> expectedDigest{};
  std::vector<ExpectedSlot> expectedSlots;
  std::shared_ptr<const HostProgramPlanData> plan;
  std::atomic<pid_t> processId;
  void* handle = nullptr;
  HostSchemaFunctionV2 schemaFunction = nullptr;
  HostInvokeFunctionV9 invoke = nullptr;
  HostProfileInvokeFunctionV1 profileInvoke = nullptr;
  std::shared_ptr<CallSchemaData> schema;
  std::atomic<TensorListApiState*> tensorListApiState;
};

class CallSchema {
 public:
  explicit CallSchema(std::shared_ptr<const CallSchemaData> data) : data(std::move(data)) {}

  uint64_t frameBytes() const { return data->header.frameBytes; }
  uint64_t frameAlignment() const { return data->header.frameAlignment; }
  uint32_t slotCount() const { return data->header.slotCount; }
  const std::string& contractDigest() const { return data->contractDigest; }

  py::tuple slots() const {
    py::tuple result(data->slots.size());
    for (size_t i = 0; i < data->slots.size(); ++i) {
      const auto& slot = data->slots[i];
      py::dict item;
      item["kind"] = slot.kind;
      item["flags"] = slot.flags;
      item["dtype_code"] = slot.dtypeCode;
      item["dtype_bits"] = slot.dtypeBits;
      item["dtype_lanes"] = slot.dtypeLanes;
      item["encoding"] = slot.encoding;
      item["logical_rank"] = slot.logicalRank;
      item["physical_rank"] = slot.physicalRank;
      item["offset"] = slot.offset;
      item["size"] = slot.size;
      item["alignment"] = slot.alignment;
      item["pointer_offset"] = slot.pointerOffset;
      item["shape_offset"] = slot.shapeOffset;
      item["stride_offset"] = slot.strideOffset;
      item["physical_shape_offset"] = slot.physicalShapeOffset;
      item["physical_stride_offset"] = slot.physicalStrideOffset;
      item["type_digest"] = digestHex(slot.abiTypeDigest);
      result[i] = std::move(item);
    }
    return result;
  }

 private:
  std::shared_ptr<const CallSchemaData> data;
};

class ExchangeLease {
 public:
  ExchangeLease(py::object source, ExportedTensor tensor, py::object stream)
      : source(std::move(source)),
        tensor(std::move(tensor)),
        stream(std::move(stream)),
        handle(this->stream.attr("handle").cast<uintptr_t>()),
        processId(getpid()) {}

  uintptr_t streamHandle() const { return handle; }
  int32_t deviceType() const { return tensor.metadata.deviceType; }
  int32_t deviceId() const { return tensor.metadata.deviceId; }
  PyObject* sourceObject() const { return source.ptr(); }
  PyTypeObject* sourceType() const { return Py_TYPE(source.ptr()); }
  const ExportedTensor& snapshot() const { return tensor; }
  py::object streamContext() const { return stream; }
  bool isCurrentProcess() const { return processId == getpid(); }

 private:
  py::object source;
  ExportedTensor tensor;
  py::object stream;
  uintptr_t handle;
  pid_t processId;
};

class AlignedFrame {
 public:
  explicit AlignedFrame(std::shared_ptr<const CallSchemaData> schema) : schema(std::move(schema)) {
    if (this->schema->header.frameBytes > static_cast<uint64_t>(std::numeric_limits<size_t>::max()) ||
        this->schema->header.frameAlignment > static_cast<uint64_t>(std::numeric_limits<size_t>::max()))
      throw std::runtime_error("packed host frame exceeds the process size limit");
    const size_t alignment =
        std::max<size_t>(static_cast<size_t>(this->schema->header.frameAlignment), sizeof(void*));
    const size_t bytes = static_cast<size_t>(this->schema->header.frameBytes);
    if (posix_memalign(&storage, alignment, bytes) != 0) throw std::bad_alloc();
    std::memset(storage, 0, bytes);
    auto* header = static_cast<CannBotCallFrameHeaderV9*>(storage);
    header->magic = kCallFrameMagicV9;
    header->hostAbiVersion = kHostABIVersion;
    header->schemaVersion = kHostSchemaVersion;
    header->slotCount = this->schema->header.slotCount;
    header->reserved = 0;
    header->frameBytes = this->schema->header.frameBytes;
    std::memcpy(header->contractDigest, this->schema->header.contractDigest, 32);
  }

  ~AlignedFrame() { std::free(storage); }
  AlignedFrame(const AlignedFrame&) = delete;
  AlignedFrame& operator=(const AlignedFrame&) = delete;

  void* data() const { return storage; }
  uintptr_t address() const { return reinterpret_cast<uintptr_t>(storage); }
  uint64_t bytes() const { return schema->header.frameBytes; }

  unsigned char* slotAddress(size_t index) const {
    if (index >= schema->slots.size()) throw std::out_of_range("host ABI slot index is out of range");
    return static_cast<unsigned char*>(storage) + schema->slots[index].offset;
  }

 private:
  std::shared_ptr<const CallSchemaData> schema;
  void* storage = nullptr;
};

[[noreturn]] void throwInvokeStatus(int32_t status) {
  const char* detail = "unknown failure";
  if (status == 1)
    detail = "null frame";
  else if (status == 2)
    detail = "invalid frame size, alignment, or header";
  else if (status == 3)
    detail = "frame schema or contract digest mismatch";
  throw std::runtime_error("invoke_v9 rejected packed host call (status " + std::to_string(status) +
                           "): " + detail);
}

void invokePacked(const std::shared_ptr<ProgramImage>& program, uintptr_t streamHandle,
                  const AlignedFrame& frame) {
  int32_t status = 0;
  if (const auto invoke = program->profilingInvokeFunction()) {
    profiling::ReportingSession session;
    {
      py::gil_scoped_release release;
      status =
          invoke(reinterpret_cast<void*>(streamHandle), frame.data(), frame.bytes(), session.callbacks());
    }
    session.rethrowIfFailed();
  } else {
    // Older AOT artifacts have no metadata entry point. Preserve their
    // ordinary execution; new artifacts always use the reporting path.
    py::gil_scoped_release release;
    status = program->invokeFunction()(reinterpret_cast<void*>(streamHandle), frame.data(), frame.bytes());
  }
  if (status != 0) throwInvokeStatus(status);
}

struct BoundInvocation {
  std::vector<ExportedTensor> tensors;
  py::object stream;
  py::tuple originals;
  void prepareSubmit() const { stream.attr("prepare_submit")(originals); }
  std::unique_ptr<AlignedFrame> frame;
  std::vector<std::shared_ptr<tensor_list::Reservation>> reservations;
};

struct PrivatePhysicalLayout {
  bool present = false;
  std::vector<int64_t> shape;
  std::vector<int64_t> stride;
};

class BenchmarkBoundCall {
 public:
  BenchmarkBoundCall(std::shared_ptr<ProgramImage> program, BoundInvocation bound, uintptr_t streamHandle)
      : program(std::move(program)),
        bound(std::move(bound)),
        streamHandle(streamHandle),
        processId(getpid()) {}

  uintptr_t address() const {
    ensureCurrentProcess();
    return bound.frame->address();
  }
  void invoke() {
    ensureCurrentProcess();
    bound.prepareSubmit();
    invokePacked(program, streamHandle, *bound.frame);
  }

 private:
  void ensureCurrentProcess() const {
    if (processId != getpid())
      throw std::runtime_error(
          "benchmark bound call was inherited across fork; resolve and bind "
          "again in the child process");
  }

  std::shared_ptr<ProgramImage> program;
  BoundInvocation bound;
  uintptr_t streamHandle;
  pid_t processId;
};

static uint64_t commAddress(py::handle value, const std::string &kind, bool allowNone) {
  if (value.is_none()) {
    if (allowNone) return 0;
    throw py::type_error("None is not a valid individual communication handle");
  }
  auto mod = py::module_::import("cannbot_dsl.comm");
  const char *name = kind == "jetty" ? "JettyHandle" :
      kind == "ubmem_peer" ? "UbMemPeerHandle" : kind == "urma_peer" ? "UrmaPeerHandle" :
      kind == "ubmem_connection" ? "UbMemConnection" : "UrmaConnection";
  if (!py::isinstance(value, mod.attr(name)))
    throw py::type_error("communication handle category mismatch");
  py::object address = value.attr("_address");
  if (!PyLong_CheckExact(address.ptr())) throw py::type_error("expected a Host communication handle");
  uint64_t raw = address.cast<uint64_t>();
  if (!raw) throw py::value_error("communication handle is null");
  return raw;
}

class HostCallPlan : public std::enable_shared_from_this<HostCallPlan> {
 public:
  explicit HostCallPlan(std::shared_ptr<ProgramImage> program)
      : program(std::move(program)), schema(this->program->schemaData()) {
    auto parsed = this->program->planData();
    if (!parsed) throw std::runtime_error("ProgramImage has no parsed HostProgramSpec");
    dimensions = parsed->dimensions;
    expressions = parsed->expressions;
    slots = parsed->slots;
    publicSlotCount = parsed->publicSlotCount;
    firstTensorIndex = parsed->firstTensorIndex;
    for (const PlanSlot& slot : slots)
      if (slot.kind == PlanSlotKind::TensorList) {
        hasTensorList = true;
        // Resolve the complete ACL surface at plan construction so a missing
        // runtime symbol cannot fail after provider inspection or staging.
        (void)this->program->tensorListRuntime();
        break;
      }
  }

  size_t slotCount() const { return slots.size(); }
  size_t publicSlotCountValue() const { return publicSlotCount; }
  py::tuple publicSlotNames() const {
    py::tuple result(publicSlotCount);
    for (size_t i = 0; i < publicSlotCount; ++i) result[i] = slots[i].name;
    return result;
  }

  std::shared_ptr<ExchangeLease> resolveFirst(py::tuple publicValues, py::tuple records, py::object stream) {
    if (static_cast<size_t>(publicValues.size()) != publicSlotCount) {
      std::ostringstream os;
      os << "public argument count mismatch: expected " << publicSlotCount << ", got " << publicValues.size();
      throw std::invalid_argument(os.str());
    }
    if (firstTensorIndex >= publicSlotCount)
      throw std::runtime_error("host call plan has no public canonical tensor slot");

    std::vector<ProviderLeaf> leaves = providerLeaves(publicValues, publicSlotCount);
    if (leaves.empty()) throw std::runtime_error("host call plan has no public canonical tensor leaf");
    PyObject* source = leaves.front().object.ptr();
    PyTypeObject* providerType = Py_TYPE(source);
    // Reject mixed public providers before invoking any exchange callback.
    for (const ProviderLeaf& leaf : leaves) {
      PyObject* value = leaf.object.ptr();
      if (Py_TYPE(value) != providerType) {
        std::ostringstream os;
        os << leaf.name << " changed DLPack provider type: expected " << providerType->tp_name << ", got "
           << Py_TYPE(value)->tp_name;
        throw py::type_error(os.str());
      }
    }

    ExportMap exports = parseExports(records);
    for (const auto& leaf : leaves) (void)exportFor(exports, leaf.object.ptr());
    const auto& first = exportFor(exports, source);
    if (first.deviceType != static_cast<int32_t>(kDLExtDev))
      throw py::value_error(leaves.front().name + " must use DLPack kDLExtDev (12)");
    auto handle = stream.attr("handle").cast<uintptr_t>();
    if (!handle || !PyCallable_Check(stream.attr("prepare_submit").ptr()))
      throw py::value_error("host invocation requires a non-null stream and submit callback");
    auto tensor = consumeTensor(first, py::int_(handle), leaves.front().name, leaves.front().rank);
    return std::make_shared<ExchangeLease>(py::reinterpret_borrow<py::object>(source), std::move(tensor),
                                           std::move(stream));
  }

  void invoke(std::shared_ptr<ExchangeLease> lease, py::object stream, py::tuple values, py::tuple records,
              py::object privateLayouts = py::none()) {
    checkEffectiveStream(lease, stream);
    const auto effectiveStreamHandle = lease->streamHandle();
    BoundInvocation bound = bind(std::move(lease), effectiveStreamHandle, values, records, privateLayouts);
    std::exception_ptr invocationError;
    try {
      bound.prepareSubmit();
      invokePacked(program, effectiveStreamHandle, *bound.frame);
    } catch (...) {
      invocationError = std::current_exception();
    }
    std::exception_ptr retirementError = retireAll(bound.reservations);
    if (invocationError) std::rethrow_exception(invocationError);
    if (retirementError) std::rethrow_exception(retirementError);
  }

  std::shared_ptr<BenchmarkBoundCall> benchmarkBind(std::shared_ptr<ExchangeLease> lease, py::object stream,
                                                    py::tuple values, py::tuple records,
                                                    py::object privateLayouts = py::none()) {
    checkEffectiveStream(lease, stream);
    const auto effectiveStreamHandle = lease->streamHandle();
    BoundInvocation bound = bind(std::move(lease), effectiveStreamHandle, values, records, privateLayouts);
    return std::make_shared<BenchmarkBoundCall>(program, std::move(bound), effectiveStreamHandle);
  }

 private:
  struct ProviderLeaf {
    py::object object;
    size_t slotIndex = 0;
    size_t elementIndex = 0;
    bool isTensorListElement = false;
    int32_t rank = 0;
    std::string name;
  };

  std::vector<ProviderLeaf> providerLeaves(py::tuple values, size_t slotLimit) const {
    std::vector<ProviderLeaf> result;
    for (size_t i = 0; i < slotLimit; ++i) {
      const PlanSlot& slot = slots[i];
      PyObject* value = PyTuple_GET_ITEM(values.ptr(), i);
      if (slot.kind == PlanSlotKind::Tensor) {
        result.push_back(ProviderLeaf{py::reinterpret_borrow<py::object>(value), i, 0, false,
                                      static_cast<int32_t>(slot.rank), slot.name});
        continue;
      }
      if (slot.kind != PlanSlotKind::TensorList || !slot.handleKind.empty()) continue;
      const bool isTuple = PyTuple_CheckExact(value);
      const bool isList = PyList_CheckExact(value);
      if (!isTuple && !isList)
        throw py::type_error(slot.name +
                             " expects an exact list or tuple of provider "
                             "tensors, got " +
                             Py_TYPE(value)->tp_name);
      const Py_ssize_t count = isTuple ? PyTuple_GET_SIZE(value) : PyList_GET_SIZE(value);
      if (count <= 0)
        throw std::invalid_argument(slot.name +
                                    " TensorList must contain at least one "
                                    "tensor");
      for (Py_ssize_t itemIndex = 0; itemIndex < count; ++itemIndex) {
        PyObject* item = isTuple ? PyTuple_GET_ITEM(value, itemIndex) : PyList_GET_ITEM(value, itemIndex);
        result.push_back(ProviderLeaf{
            py::reinterpret_borrow<py::object>(item), i, static_cast<size_t>(itemIndex), true,
            static_cast<int32_t>(slot.elementRank), slot.name + "[" + std::to_string(itemIndex) + "]"});
      }
    }
    return result;
  }

  static std::exception_ptr retireAll(std::vector<std::shared_ptr<tensor_list::Reservation>>& reservations) {
    std::exception_ptr firstError;
    for (const auto& reservation : reservations) {
      try {
        reservation->retire();
      } catch (...) {
        if (!firstError) firstError = std::current_exception();
      }
    }
    return firstError;
  }

  static void checkEffectiveStream(const std::shared_ptr<ExchangeLease>& lease, py::object stream) {
    if (!lease) throw std::invalid_argument("host invocation requires an exchange lease");
    if (!lease->isCurrentProcess())
      throw std::runtime_error("exchange lease was inherited across fork and cannot be reused");
    if (!stream.is(lease->streamContext()) ||
        stream.attr("handle").cast<uintptr_t>() != lease->streamHandle())
      throw py::value_error("effective stream context does not match the export stream");
  }

  static void mismatch(const std::string& name, const std::string& field, int64_t wanted, int64_t actual) {
    std::ostringstream os;
    os << name << " guard failed for " << field << ": expected " << wanted << ", got " << actual;
    throw std::invalid_argument(os.str());
  }

  static void mismatch(const PlanSlot& slot, const std::string& field, int64_t wanted, int64_t actual) {
    mismatch(slot.name, field, wanted, actual);
  }

  static void observeDimension(const std::vector<DimensionRule>& rules, size_t index, int64_t actual,
                               const std::string& site, std::vector<int64_t>& values,
                               std::vector<bool>& bound, std::vector<std::string>& sites) {
    const DimensionRule& rule = rules[index];
    if (actual < rule.minimum) {
      std::ostringstream os;
      os << site << "=" << actual << " violates " << rule.name << ": expected >= " << rule.minimum;
      throw std::invalid_argument(os.str());
    }
    if (rule.hasMaximum && actual > rule.maximum) {
      std::ostringstream os;
      os << site << "=" << actual << " violates " << rule.name << ": expected <= " << rule.maximum;
      throw std::invalid_argument(os.str());
    }
    if (actual % rule.multipleOf != 0) {
      std::ostringstream os;
      os << site << "=" << actual << " violates " << rule.name
         << ": expected multiple_of=" << rule.multipleOf;
      throw std::invalid_argument(os.str());
    }
    if (!bound[index]) {
      bound[index] = true;
      values[index] = actual;
      sites[index] = site;
    } else if (values[index] != actual) {
      std::ostringstream os;
      os << site << "=" << actual << " does not match " << sites[index] << "=" << values[index]
         << " for Dim '" << rule.name << "'";
      throw std::invalid_argument(os.str());
    }
  }

  static int64_t checkedExpressionResult(__int128 value, const std::string& rendered) {
    if (value < std::numeric_limits<int64_t>::min() || value > std::numeric_limits<int64_t>::max())
      throw std::invalid_argument("dimension expression " + rendered + " overflowed signed int64");
    return static_cast<int64_t>(value);
  }

  std::vector<int64_t> evaluateExpressions(const std::vector<ExpressionStep>& program,
                                           const std::vector<int64_t>& dimensionValues) const {
    std::vector<int64_t> result(program.size());
    for (size_t i = 0; i < program.size(); ++i) {
      const ExpressionStep& step = program[i];
      if (step.kind == ExpressionKind::Constant) {
        result[i] = step.value;
      } else if (step.kind == ExpressionKind::Dimension) {
        result[i] = dimensionValues[step.dimension];
      } else if (step.kind == ExpressionKind::Add) {
        result[i] = checkedExpressionResult(static_cast<__int128>(result[step.lhs]) + result[step.rhs],
                                            step.rendered);
      } else if (step.kind == ExpressionKind::Sub) {
        result[i] = checkedExpressionResult(static_cast<__int128>(result[step.lhs]) - result[step.rhs],
                                            step.rendered);
      } else if (step.kind == ExpressionKind::Mul) {
        result[i] = checkedExpressionResult(static_cast<__int128>(result[step.lhs]) * result[step.rhs],
                                            step.rendered);
      } else {
        const int64_t lhs = result[step.lhs];
        const int64_t rhs = result[step.rhs];
        if (rhs <= 0)
          throw std::invalid_argument("dimension expression " + step.rendered +
                                      " has a non-positive divisor");
        int64_t quotient = lhs / rhs;
        if (lhs % rhs < 0) --quotient;
        result[i] = quotient;
      }
    }
    return result;
  }

  template <typename T>
  static std::vector<unsigned char> scalarBytes(T value) {
    std::vector<unsigned char> result(sizeof(T));
    std::memcpy(result.data(), &value, sizeof(T));
    return result;
  }

  std::vector<unsigned char> convertScalar(const PlanSlot& plan, PyObject* value) const {
    if (plan.scalarKind == "bool") {
      if (!PyBool_Check(value))
        throw py::type_error(plan.name + " expects bool, got " + Py_TYPE(value)->tp_name);
      return scalarBytes(static_cast<bool>(value == Py_True));
    }
    if (plan.scalarKind == "float") {
      if (PyBool_Check(value) || !(PyFloat_Check(value) || PyLong_CheckExact(value)))
        throw py::type_error(plan.name + " expects int or float, got " + Py_TYPE(value)->tp_name);
      const double converted = PyFloat_AsDouble(value);
      if (PyErr_Occurred()) throw py::error_already_set();
      if (!std::isfinite(converted)) throw std::invalid_argument(plan.name + " must be finite");
      if (plan.scalarBits == 64) return scalarBytes(converted);
      const float narrowed = static_cast<float>(converted);
      if (!std::isfinite(narrowed)) throw std::invalid_argument(plan.name + " is outside float32 range");
      return scalarBytes(narrowed);
    }
    if (!PyLong_CheckExact(value))
      throw py::type_error(plan.name + " expects int, got " + Py_TYPE(value)->tp_name);
    if (plan.scalarSigned) {
      int overflow = 0;
      const long long converted = PyLong_AsLongLongAndOverflow(value, &overflow);
      if (PyErr_Occurred()) throw py::error_already_set();
      const int64_t minimum = plan.scalarBits == 64 ? std::numeric_limits<int64_t>::min()
                                                    : -(static_cast<int64_t>(1) << (plan.scalarBits - 1));
      const int64_t maximum = plan.scalarBits == 64 ? std::numeric_limits<int64_t>::max()
                                                    : (static_cast<int64_t>(1) << (plan.scalarBits - 1)) - 1;
      if (overflow != 0 || converted < minimum || converted > maximum)
        throw std::invalid_argument(plan.name + " is outside signed " + std::to_string(plan.scalarBits) +
                                    "-bit range");
      if (plan.scalarBits == 8) return scalarBytes(static_cast<int8_t>(converted));
      if (plan.scalarBits == 16) return scalarBytes(static_cast<int16_t>(converted));
      if (plan.scalarBits == 32) return scalarBytes(static_cast<int32_t>(converted));
      return scalarBytes(static_cast<int64_t>(converted));
    }
    const unsigned long long converted = PyLong_AsUnsignedLongLong(value);
    if (PyErr_Occurred()) {
      PyErr_Clear();
      throw std::invalid_argument(plan.name + " is outside unsigned " + std::to_string(plan.scalarBits) +
                                  "-bit range");
    }
    const uint64_t maximum = plan.scalarBits == 64 ? std::numeric_limits<uint64_t>::max()
                                                   : (static_cast<uint64_t>(1) << plan.scalarBits) - 1;
    if (converted > maximum)
      throw std::invalid_argument(plan.name + " is outside unsigned " + std::to_string(plan.scalarBits) +
                                  "-bit range");
    if (plan.scalarBits == 8) return scalarBytes(static_cast<uint8_t>(converted));
    if (plan.scalarBits == 16) return scalarBytes(static_cast<uint16_t>(converted));
    if (plan.scalarBits == 32) return scalarBytes(static_cast<uint32_t>(converted));
    return scalarBytes(static_cast<uint64_t>(converted));
  }

  std::vector<PrivatePhysicalLayout> parsePrivateLayouts(py::object raw, size_t valueCount) const {
    std::vector<PrivatePhysicalLayout> result(slots.size());
    if (raw.is_none()) {
      for (const PlanSlot& slot : slots)
        if (slot.kind == PlanSlotKind::Tensor && slot.encoding == HostTensorEncoding::FractalNZ)
          throw std::invalid_argument(slot.name + " requires a FRACTAL_NZ physical layout snapshot");
      return result;
    }
    if (!PyTuple_CheckExact(raw.ptr()))
      throw py::type_error("private_layouts must be an exact tuple or None");
    py::tuple values = py::reinterpret_borrow<py::tuple>(raw);
    if (static_cast<size_t>(values.size()) != valueCount || valueCount != slots.size())
      throw std::invalid_argument("private layout snapshot count must equal the host slot count");
    for (size_t i = 0; i < slots.size(); ++i) {
      py::handle item = values[i];
      const PlanSlot& slot = slots[i];
      if (item.is_none()) {
        if (slot.kind == PlanSlotKind::Tensor && slot.encoding == HostTensorEncoding::FractalNZ)
          throw std::invalid_argument(slot.name + " is missing its FRACTAL_NZ physical layout snapshot");
        continue;
      }
      if (slot.kind != PlanSlotKind::Tensor || slot.encoding != HostTensorEncoding::FractalNZ)
        throw std::invalid_argument(slot.name + " received a private layout for an identity slot");
      if (!PyDict_CheckExact(item.ptr()))
        throw py::type_error(slot.name + " private layout must be an exact dict");
      py::dict layout = py::reinterpret_borrow<py::dict>(item);
      if (layout["encoding"].cast<std::string>() != "fractal_nz")
        throw std::invalid_argument(slot.name + " private layout encoding must be fractal_nz");
      PrivatePhysicalLayout parsed;
      parsed.present = true;
      parsed.shape = layout["physical_shape"].cast<std::vector<int64_t>>();
      parsed.stride = layout["physical_stride"].cast<std::vector<int64_t>>();
      if (parsed.shape.size() != slot.physicalRank || parsed.stride.size() != slot.physicalRank)
        throw std::invalid_argument(slot.name + " private physical rank does not match the Host ABI");
      int64_t compact = 1;
      for (size_t axis = parsed.shape.size(); axis-- > 0;) {
        if (parsed.shape[axis] <= 0 || parsed.stride[axis] != compact)
          throw std::invalid_argument(slot.name + " private physical layout is not positive compact storage");
        if (axis != 0) {
          if (parsed.shape[axis] > std::numeric_limits<int64_t>::max() / compact)
            throw std::overflow_error(slot.name + " private physical layout size overflows int64");
          compact *= parsed.shape[axis];
        }
      }
      result[i] = std::move(parsed);
    }
    return result;
  }

  BoundInvocation bind(std::shared_ptr<ExchangeLease> lease, uintptr_t effectiveStreamHandle,
                       py::tuple values, py::tuple records, py::object privateLayouts) {
    if (!lease) throw std::invalid_argument("host invocation requires an exchange lease");
    if (!lease->isCurrentProcess())
      throw std::runtime_error("exchange lease was inherited across fork and cannot be reused");
    if (static_cast<size_t>(values.size()) != slots.size()) {
      std::ostringstream os;
      os << "host argument count mismatch: expected " << slots.size() << ", got " << values.size();
      throw std::invalid_argument(os.str());
    }
    const std::vector<PrivatePhysicalLayout> physicalLayouts =
        parsePrivateLayouts(privateLayouts, static_cast<size_t>(values.size()));
    // RuntimeApi contains DSO-resolved function pointers and is process-local.
    // Resolve it exactly once per bind so all TensorList slots share the same
    // current-process API, including when this HostCallPlan survived a fork.
    std::shared_ptr<tensor_list::RuntimeApi> tensorListRuntime;
    if (hasTensorList) tensorListRuntime = program->tensorListRuntime();
    PyTypeObject* providerType = lease->sourceType();
    ExportMap exports = parseExports(records);

    // Exact provider identity is checked for every tensor before any exchange
    // callback runs, so a mixed-provider call cannot partially inspect inputs.
    std::vector<ProviderLeaf> leaves = providerLeaves(values, slots.size());
    for (const ProviderLeaf& leaf : leaves) {
      PyObject* value = leaf.object.ptr();
      if (Py_TYPE(value) != providerType) {
        std::ostringstream os;
        os << leaf.name << " changed DLPack provider type: expected " << providerType->tp_name << ", got "
           << Py_TYPE(value)->tp_name;
        throw py::type_error(os.str());
      }
    }
    for (const auto& leaf : leaves) {
      const auto& item = exportFor(exports, leaf.object.ptr());
      if (item.deviceType != lease->deviceType() || item.deviceId != lease->deviceId())
        throw py::value_error(leaf.name + " changed DLPack device");
    }
    BoundInvocation bound;
    bound.stream = lease->streamContext();
    std::vector<TensorMetadata> metadata(slots.size());
    std::vector<std::vector<TensorMetadata>> listMetadata(slots.size());
    for (const ProviderLeaf& leaf : leaves)
      if (leaf.isTensorListElement && listMetadata[leaf.slotIndex].size() <= leaf.elementIndex)
        listMetadata[leaf.slotIndex].resize(leaf.elementIndex + 1);
    // Capture all communication lists before releasing the GIL or staging DMA.
    for (size_t i = 0; i < slots.size(); ++i) {
      const auto &slot = slots[i];
      if (slot.kind != PlanSlotKind::TensorList || slot.handleKind.empty()) continue;
      py::handle value = values[i];
      if (!PyTuple_CheckExact(value.ptr()) && !PyList_CheckExact(value.ptr()))
        throw py::type_error(slot.name + " expects a handle list");
      for (py::handle item : py::reinterpret_borrow<py::sequence>(value)) {
        TensorMetadata meta;
        meta.data = commAddress(item, slot.handleKind, slot.handleKind == "ubmem_peer" || slot.handleKind == "urma_peer");
        listMetadata[i].push_back(std::move(meta));
      }
    }
    std::unordered_map<PyObject*, TensorMetadata> metadataByObject;
    bool usedSnapshot = false;
    for (const ProviderLeaf& leaf : leaves) {
      PyObject* value = leaf.object.ptr();
      auto found = metadataByObject.find(value);
      if (found == metadataByObject.end()) {
        TensorMetadata snapshot;
        if (value == lease->sourceObject()) {
          bound.tensors.push_back(lease->snapshot());
          usedSnapshot = true;
        } else {
          bound.tensors.push_back(consumeTensor(exportFor(exports, value), py::int_(effectiveStreamHandle),
                                                leaf.name, leaf.rank));
        }
        snapshot = bound.tensors.back().metadata;
        found = metadataByObject.emplace(value, std::move(snapshot)).first;
      }
      if (leaf.isTensorListElement)
        listMetadata[leaf.slotIndex][leaf.elementIndex] = found->second;
      else
        metadata[leaf.slotIndex] = found->second;
    }
    if (!usedSnapshot)
      throw std::invalid_argument("exchange lease source tensor is not present in host arguments");

    auto validateMetadata = [&](const TensorMetadata& actual, const std::string& name, uint8_t dtypeCode,
                                uint8_t dtypeBits, uint16_t dtypeLanes, uint32_t rank, uint64_t dataAlignment,
                                bool requireZeroByteOffset) {
      if (actual.deviceType != lease->deviceType())
        mismatch(name, "device_type", lease->deviceType(), actual.deviceType);
      if (actual.deviceId != lease->deviceId())
        mismatch(name, "device_id", lease->deviceId(), actual.deviceId);
      if (actual.dtypeCode != dtypeCode) mismatch(name, "dtype.code", dtypeCode, actual.dtypeCode);
      if (actual.dtypeBits != dtypeBits) mismatch(name, "dtype.bits", dtypeBits, actual.dtypeBits);
      if (actual.dtypeLanes != dtypeLanes) mismatch(name, "dtype.lanes", dtypeLanes, actual.dtypeLanes);
      if (actual.rank != static_cast<int32_t>(rank)) mismatch(name, "rank", rank, actual.rank);
      if (requireZeroByteOffset && actual.byteOffset != 0) {
        std::ostringstream os;
        os << name << " guard failed for byte_offset: expected 0, got " << actual.byteOffset;
        throw std::invalid_argument(os.str());
      }
      if (actual.data % dataAlignment != 0) {
        std::ostringstream os;
        os << name << " guard failed for device address alignment: expected "
           << "a multiple of " << dataAlignment;
        throw std::invalid_argument(os.str());
      }
    };

    // Provider/device/dtype/rank checks for the entire call precede all
    // dimension binding.  In particular, no TensorList-local expression can
    // fail after another slot has already started descriptor staging.
    for (size_t i = 0; i < slots.size(); ++i) {
      const PlanSlot& plan = slots[i];
      if (plan.kind == PlanSlotKind::TensorList) {
        if (!plan.handleKind.empty()) continue;
        const auto& elements = listMetadata[i];
        if (elements.size() > static_cast<size_t>(std::numeric_limits<int64_t>::max()))
          throw std::invalid_argument(plan.name + " TensorList length exceeds int64");
        for (size_t elementIndex = 0; elementIndex < elements.size(); ++elementIndex) {
          const std::string name = plan.name + "[" + std::to_string(elementIndex) + "]";
          validateMetadata(elements[elementIndex], name, plan.elementDTypeCode, plan.elementDTypeBits,
                           plan.elementDTypeLanes, plan.elementRank, 1, false);
        }
        continue;
      }
      if (plan.kind != PlanSlotKind::Tensor) continue;
      const TensorMetadata& actual = metadata[i];
      validateMetadata(actual, plan.name, plan.dtypeCode, plan.dtypeBits, plan.dtypeLanes, plan.rank,
                       plan.dataAlignment, plan.requireZeroByteOffset);
    }

    // Bind only global dimensions here: ordinary Tensor layouts and
    // TensorList lengths share this scope.  Element-template dimensions are
    // handled independently for every list element below.
    std::vector<int64_t> dimensionValues(dimensions.size());
    std::vector<bool> dimensionBound(dimensions.size(), false);
    std::vector<std::string> dimensionSites(dimensions.size());
    for (size_t i = 0; i < slots.size(); ++i) {
      const PlanSlot& plan = slots[i];
      if (plan.kind == PlanSlotKind::TensorList) {
        const ExpressionStep& length = expressions[plan.lengthExpression];
        if (length.kind == ExpressionKind::Dimension)
          observeDimension(dimensions, length.dimension, static_cast<int64_t>(listMetadata[i].size()),
                           plan.name + ".length", dimensionValues, dimensionBound, dimensionSites);
        continue;
      }
      if (plan.kind != PlanSlotKind::Tensor) continue;
      const TensorMetadata& actual = metadata[i];

      for (size_t axis = 0; axis < plan.rank; ++axis) {
        const ExpressionStep& shape = expressions[plan.shapeExpressions[axis]];
        if (shape.kind == ExpressionKind::Dimension)
          observeDimension(dimensions, shape.dimension, actual.shape[axis],
                           plan.name + ".shape[" + std::to_string(axis) + "]", dimensionValues,
                           dimensionBound, dimensionSites);
        const ExpressionStep& stride = expressions[plan.strideExpressions[axis]];
        if (stride.kind == ExpressionKind::Dimension && actual.shape[axis] != 1)
          observeDimension(dimensions, stride.dimension, actual.strides[axis],
                           plan.name + ".stride[" + std::to_string(axis) + "]", dimensionValues,
                           dimensionBound, dimensionSites);
      }
    }
    // A dimension directly bound only by a unit-extent stride still needs a
    // value. It is observed as a last resort, while equivalent unit strides do
    // not constrain dimensions already established elsewhere.
    for (size_t i = 0; i < slots.size(); ++i) {
      const PlanSlot& plan = slots[i];
      if (plan.kind != PlanSlotKind::Tensor) continue;
      const TensorMetadata& actual = metadata[i];
      for (size_t axis = 0; axis < plan.rank; ++axis) {
        const ExpressionStep& stride = expressions[plan.strideExpressions[axis]];
        if (stride.kind == ExpressionKind::Dimension && !dimensionBound[stride.dimension])
          observeDimension(dimensions, stride.dimension, actual.strides[axis],
                           plan.name + ".stride[" + std::to_string(axis) + "]", dimensionValues,
                           dimensionBound, dimensionSites);
      }
    }
    for (size_t i = 0; i < dimensions.size(); ++i)
      if (!dimensionBound[i])
        throw std::runtime_error("host call plan did not bind Dim '" + dimensions[i].name + "'");

    const std::vector<int64_t> expressionValues = evaluateExpressions(expressions, dimensionValues);
    for (size_t i = 0; i < slots.size(); ++i) {
      const PlanSlot& plan = slots[i];
      if (plan.kind == PlanSlotKind::TensorList) {
        const int64_t length = expressionValues[plan.lengthExpression];
        if (length < (plan.handleKind.empty() ? 1 : 0)) throw std::invalid_argument(plan.name + " invalid list length");
        const auto& elements = listMetadata[i];
        if (static_cast<uint64_t>(length) != elements.size())
          mismatch(plan, "length", length, static_cast<int64_t>(elements.size()));
        continue;
      }
      if (plan.kind != PlanSlotKind::Tensor) continue;
      const TensorMetadata& actual = metadata[i];
      for (size_t axis = 0; axis < plan.rank; ++axis) {
        const int64_t shape = expressionValues[plan.shapeExpressions[axis]];
        const int64_t stride = expressionValues[plan.strideExpressions[axis]];
        if (shape < 0 || stride < 0)
          throw std::invalid_argument(plan.name + " contract shape/stride evaluated negative");
        if (actual.shape[axis] != shape)
          mismatch(plan, "shape[" + std::to_string(axis) + "]", shape, actual.shape[axis]);
        if ((plan.requireExactStride || actual.shape[axis] != 1) && actual.strides[axis] != stride)
          mismatch(plan, "stride[" + std::to_string(axis) + "]", stride, actual.strides[axis]);
      }
      if (plan.encoding == HostTensorEncoding::FractalNZ) {
        const PrivatePhysicalLayout& physical = physicalLayouts[i];
        if (!physical.present)
          throw std::runtime_error(plan.name + " lost its FRACTAL_NZ physical layout snapshot");
        for (size_t axis = 0; axis < plan.physicalRank; ++axis) {
          const int64_t expectedPhysical = expressionValues[plan.physicalShapeExpressions[axis]];
          if (expectedPhysical <= 0)
            throw std::invalid_argument(plan.name + " physical shape expression evaluated non-positive");
          if (physical.shape[axis] != expectedPhysical)
            mismatch(plan, "physical_shape[" + std::to_string(axis) + "]", expectedPhysical,
                     physical.shape[axis]);
        }
      }
    }

    // Validate every TensorList layout.  Template dimensions get a fresh
    // binding table per element, so M in xs[i] neither aliases xs[j] nor a
    // same-named dimension in another list/global scope.
    for (size_t i = 0; i < slots.size(); ++i) {
      const PlanSlot& plan = slots[i];
      if (plan.kind != PlanSlotKind::TensorList || !plan.handleKind.empty()) continue;
      const auto& elements = listMetadata[i];
      if (plan.tensorListLayoutKind == TensorListLayoutKind::Exact) {
        for (size_t elementIndex = 0; elementIndex < elements.size(); ++elementIndex) {
          const TensorMetadata& actual = elements[elementIndex];
          const ExactElementLayout& expected = plan.exactLayouts[elementIndex];
          const std::string name = plan.name + "[" + std::to_string(elementIndex) + "]";
          for (size_t axis = 0; axis < plan.elementRank; ++axis) {
            if (actual.shape[axis] != expected.shape[axis])
              mismatch(name, "shape[" + std::to_string(axis) + "]", expected.shape[axis], actual.shape[axis]);
            if ((plan.requireExactStride || actual.shape[axis] != 1) &&
                actual.strides[axis] != expected.stride[axis])
              mismatch(name, "stride[" + std::to_string(axis) + "]", expected.stride[axis],
                       actual.strides[axis]);
          }
        }
        continue;
      }

      for (size_t elementIndex = 0; elementIndex < elements.size(); ++elementIndex) {
        const TensorMetadata& actual = elements[elementIndex];
        const std::string name = plan.name + "[" + std::to_string(elementIndex) + "]";
        std::vector<int64_t> localValues(plan.elementDimensions.size());
        std::vector<bool> localBound(plan.elementDimensions.size(), false);
        std::vector<std::string> localSites(plan.elementDimensions.size());

        for (size_t axis = 0; axis < plan.elementRank; ++axis) {
          const ExpressionStep& shape = plan.elementExpressions[plan.elementShapeExpressions[axis]];
          if (shape.kind == ExpressionKind::Dimension)
            observeDimension(plan.elementDimensions, shape.dimension, actual.shape[axis],
                             name + ".shape[" + std::to_string(axis) + "]", localValues, localBound,
                             localSites);
          const ExpressionStep& stride = plan.elementExpressions[plan.elementStrideExpressions[axis]];
          if (stride.kind == ExpressionKind::Dimension && actual.shape[axis] != 1)
            observeDimension(plan.elementDimensions, stride.dimension, actual.strides[axis],
                             name + ".stride[" + std::to_string(axis) + "]", localValues, localBound,
                             localSites);
        }
        // A direct Dim occurring only in a unit-extent stride is a fallback
        // binding site, mirroring ordinary Tensor semantics.
        for (size_t axis = 0; axis < plan.elementRank; ++axis) {
          const ExpressionStep& stride = plan.elementExpressions[plan.elementStrideExpressions[axis]];
          if (stride.kind == ExpressionKind::Dimension && !localBound[stride.dimension])
            observeDimension(plan.elementDimensions, stride.dimension, actual.strides[axis],
                             name + ".stride[" + std::to_string(axis) + "]", localValues, localBound,
                             localSites);
        }
        for (size_t dimension = 0; dimension < plan.elementDimensions.size(); ++dimension)
          if (!localBound[dimension])
            throw std::runtime_error(name + " did not bind TensorList element Dim '" +
                                     plan.elementDimensions[dimension].name + "'");

        const std::vector<int64_t> localExpressionValues =
            evaluateExpressions(plan.elementExpressions, localValues);
        for (size_t axis = 0; axis < plan.elementRank; ++axis) {
          const int64_t shape = localExpressionValues[plan.elementShapeExpressions[axis]];
          const int64_t stride = localExpressionValues[plan.elementStrideExpressions[axis]];
          if (shape < 0)
            throw std::invalid_argument(name + ".shape[" + std::to_string(axis) +
                                        "] contract expression evaluated negative");
          if (stride < 0)
            throw std::invalid_argument(name + ".stride[" + std::to_string(axis) +
                                        "] contract expression evaluated negative");
          if (actual.shape[axis] != shape)
            mismatch(name, "shape[" + std::to_string(axis) + "]", shape, actual.shape[axis]);
          if ((plan.requireExactStride || actual.shape[axis] != 1) && actual.strides[axis] != stride)
            mismatch(name, "stride[" + std::to_string(axis) + "]", stride, actual.strides[axis]);
        }
      }
    }

    std::vector<std::vector<unsigned char>> convertedScalars(slots.size());
    std::vector<std::vector<unsigned char>> copiedBuffers(slots.size());
    for (size_t i = 0; i < slots.size(); ++i)
      if (slots[i].kind == PlanSlotKind::Scalar) {
        if (slots[i].handleKind.empty()) {
          convertedScalars[i] = convertScalar(slots[i], PyTuple_GET_ITEM(values.ptr(), i));
        } else {
          py::int_ address(commAddress(values[i], slots[i].handleKind, false));
          convertedScalars[i] = convertScalar(slots[i], address.ptr());
        }
      }
      else if (slots[i].kind == PlanSlotKind::Buffer) {
        PyObject* value = PyTuple_GET_ITEM(values.ptr(), i);
        Py_buffer view{};
        if (PyObject_GetBuffer(value, &view, PyBUF_CONTIG_RO) != 0) throw py::error_already_set();
        try {
          if (view.len < 0 || static_cast<uint64_t>(view.len) != schema->slots[i].size) {
            std::ostringstream os;
            os << slots[i].name << " buffer size mismatch: expected " << schema->slots[i].size << ", got "
               << view.len;
            throw std::invalid_argument(os.str());
          }
          const auto* begin = static_cast<const unsigned char*>(view.buf);
          copiedBuffers[i].assign(begin, begin + static_cast<size_t>(view.len));
        } catch (...) {
          PyBuffer_Release(&view);
          throw;
        }
        PyBuffer_Release(&view);
      }

    std::vector<std::shared_ptr<tensor_list::Reservation>> stagedBySlot(slots.size());
    bound.originals = py::tuple(bound.tensors.size());
    for (size_t i = 0; i < bound.tensors.size(); ++i)
      bound.originals[i] = bound.tensors[i].record.attr("original");
    for (size_t i = 0; i < slots.size(); ++i) {
      const PlanSlot& plan = slots[i];
      if (plan.kind != PlanSlotKind::TensorList) continue;
      const auto& elements = listMetadata[i];
      if (plan.recordWords > std::numeric_limits<size_t>::max() ||
          elements.size() > std::numeric_limits<size_t>::max() / static_cast<size_t>(plan.recordWords))
        throw std::overflow_error(plan.name + " TensorList descriptor size overflow");
      const size_t wordCount = elements.size() * static_cast<size_t>(plan.recordWords);
      if (wordCount > static_cast<size_t>(std::numeric_limits<int64_t>::max()))
        throw std::overflow_error(plan.name + " descriptor shape exceeds int64");
      std::vector<uint64_t> words;
      words.reserve(wordCount);
      for (const TensorMetadata& actual : elements) {
        words.push_back(static_cast<uint64_t>(actual.data));
        for (int64_t shape : actual.shape) words.push_back(static_cast<uint64_t>(shape));
        for (int64_t stride : actual.strides) words.push_back(static_cast<uint64_t>(stride));
      }
      if (words.empty() && !plan.handleKind.empty()) words.push_back(0);
      auto reservation =
          tensor_list::stage(tensorListRuntime, lease->deviceId(), effectiveStreamHandle, words);
      stagedBySlot[i] = reservation;
      bound.reservations.push_back(std::move(reservation));
    }

    bound.frame = std::make_unique<AlignedFrame>(schema);
    for (size_t i = 0; i < slots.size(); ++i) {
      const PlanSlot& plan = slots[i];
      const CannBotHostSlotSchemaV2& binary = schema->slots[i];
      unsigned char* destination = bound.frame->slotAddress(i);
      if (plan.kind == PlanSlotKind::Scalar) {
        std::memcpy(destination, convertedScalars[i].data(), convertedScalars[i].size());
        continue;
      }
      if (plan.kind == PlanSlotKind::Buffer) {
        std::memcpy(destination, copiedBuffers[i].data(), copiedBuffers[i].size());
        continue;
      }
      if (plan.kind == PlanSlotKind::TensorList) {
        const auto& reservation = stagedBySlot[i];
        void* pointer = reinterpret_cast<void*>(reservation->deviceAddress());
        const size_t usedWords = plan.handleKind.empty() ? reservation->usedWords() : listMetadata[i].size();
        if (usedWords > static_cast<size_t>(std::numeric_limits<int64_t>::max()))
          throw std::overflow_error(plan.name + " descriptor shape exceeds int64");
        const int64_t shape = static_cast<int64_t>(usedWords);
        const int64_t stride = 1;
        std::memcpy(destination + binary.pointerOffset, &pointer, sizeof(pointer));
        std::memcpy(destination + binary.shapeOffset, &shape, sizeof(shape));
        std::memcpy(destination + binary.strideOffset, &stride, sizeof(stride));
        continue;
      }
      const TensorMetadata& actual = metadata[i];
      void* pointer = reinterpret_cast<void*>(actual.data);
      std::memcpy(destination + binary.pointerOffset, &pointer, sizeof(pointer));
      for (size_t axis = 0; axis < plan.rank; ++axis) {
        const int64_t shape = expressionValues[plan.shapeExpressions[axis]];
        const int64_t stride = expressionValues[plan.strideExpressions[axis]];
        std::memcpy(destination + binary.shapeOffset + axis * sizeof(int64_t), &shape, sizeof(shape));
        std::memcpy(destination + binary.strideOffset + axis * sizeof(int64_t), &stride, sizeof(stride));
      }
      if (plan.encoding == HostTensorEncoding::FractalNZ) {
        const PrivatePhysicalLayout& physical = physicalLayouts[i];
        for (size_t axis = 0; axis < plan.physicalRank; ++axis) {
          std::memcpy(destination + binary.physicalShapeOffset + axis * sizeof(int64_t),
                      &physical.shape[axis], sizeof(int64_t));
          std::memcpy(destination + binary.physicalStrideOffset + axis * sizeof(int64_t),
                      &physical.stride[axis], sizeof(int64_t));
        }
      }
    }
    return bound;
  }

  std::shared_ptr<ProgramImage> program;
  std::shared_ptr<const CallSchemaData> schema;
  std::vector<DimensionRule> dimensions;
  std::vector<ExpressionStep> expressions;
  std::vector<PlanSlot> slots;
  size_t publicSlotCount = 0;
  size_t firstTensorIndex = std::numeric_limits<size_t>::max();
  bool hasTensorList = false;
};

}  // namespace

PYBIND11_MODULE(_host_runtime, module) {
  module.doc() = "Packed ABI v9 host runtime with DLPack 1.0 capsule exchange";

  module.attr("HOST_ABI_VERSION") = kHostABIVersion;
  module.attr("SCHEMA_VERSION") = kHostSchemaVersion;
  module.attr("FRAME_MAGIC") = kCallFrameMagicV9;

  module.def("has_dlpack", &hasDLPack);
  module.def("inspect_tensors", &inspectTensorBatch, py::arg("exports"), py::arg("stream"));

  py::class_<CallSchema>(module, "CallSchema", py::module_local())
      .def_property_readonly("frame_bytes", &CallSchema::frameBytes)
      .def_property_readonly("frame_alignment", &CallSchema::frameAlignment)
      .def_property_readonly("slot_count", &CallSchema::slotCount)
      .def_property_readonly("contract_digest", &CallSchema::contractDigest)
      .def_property_readonly("slots", &CallSchema::slots);

  py::class_<ProgramImage, std::shared_ptr<ProgramImage>>(module, "ProgramImage", py::module_local())
      .def(py::init<std::string, std::string, py::dict>(), py::arg("so_path"), py::arg("symbol_name"),
           py::arg("host_program_spec"))
      .def_property_readonly("so_path", &ProgramImage::pathName)
      .def_property_readonly("symbol_name", &ProgramImage::symbolName)
      .def_property_readonly("schema",
                             [](const ProgramImage& program) { return CallSchema(program.schemaData()); });

  py::class_<ExchangeLease, std::shared_ptr<ExchangeLease>>(module, "_ExchangeLease", py::module_local())
      .def_property_readonly("provider_stream_handle", &ExchangeLease::streamHandle)
      .def_property_readonly("device_type", &ExchangeLease::deviceType)
      .def_property_readonly("device_id", &ExchangeLease::deviceId);

  py::class_<BenchmarkBoundCall, std::shared_ptr<BenchmarkBoundCall>>(module, "_BenchmarkBoundCall", py::module_local())
      .def_property_readonly("address", &BenchmarkBoundCall::address)
      .def("invoke", &BenchmarkBoundCall::invoke);

  py::class_<HostCallPlan, std::shared_ptr<HostCallPlan>>(module, "HostCallPlan", py::module_local())
      .def(py::init<std::shared_ptr<ProgramImage>>(), py::arg("program"))
      .def_property_readonly("slot_count", &HostCallPlan::slotCount)
      .def_property_readonly("public_slot_count", &HostCallPlan::publicSlotCountValue)
      .def_property_readonly("public_slot_names", &HostCallPlan::publicSlotNames)
      .def("resolve_first", &HostCallPlan::resolveFirst, py::arg("public_values"), py::arg("exports"),
           py::arg("stream"))
      .def("invoke", &HostCallPlan::invoke, py::arg("lease"), py::arg("stream"), py::arg("all_values"),
           py::arg("exports"), py::arg("private_layouts") = py::none())
      .def("_benchmark_bind", &HostCallPlan::benchmarkBind, py::arg("lease"), py::arg("stream"),
           py::arg("all_values"), py::arg("exports"), py::arg("private_layouts") = py::none());
}
