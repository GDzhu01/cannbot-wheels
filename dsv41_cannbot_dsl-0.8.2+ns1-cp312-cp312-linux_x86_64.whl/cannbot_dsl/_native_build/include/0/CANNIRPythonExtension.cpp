/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */
#include <stdexcept>
#include <string>
#include <vector>

#include "CANNIR-c/Dialects.h"
#include "CANNIR-c/Translation.h"
#include "CANNIR-c/Analysis.h"
#include "llvm/ADT/ScopeExit.h"
#include "mlir/CAPI/IR.h"
#include "mlir/CAPI/Support.h"

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wattributes"
#include "mlir/Bindings/Python/PybindAdaptors.h"
#pragma GCC diagnostic pop

namespace py = pybind11;

struct TargetBufferSyncSnapshot {
  void* snapshot;
  py::object context;
  TargetBufferSyncSnapshot(void* snapshot, py::object context)
      : snapshot(snapshot), context(std::move(context)) {}
  ~TargetBufferSyncSnapshot() { cannirDestroyTargetBufferSync(snapshot); }
};

static py::object shape_to_tuple(MlirType type) {
  if (cannirShapeTypeGetNumElements(type) == 0) {
    return py::cast(cannirShapeTypeGetValue(type));
  }
  py::list l;
  for (intptr_t i = 0; i < cannirShapeTypeGetNumElements(type); ++i) {
    l.append(shape_to_tuple(cannirShapeTypeGetElement(type, i)));
  }
  return py::tuple(l);
}

static py::object stride_to_tuple(MlirType type) {
  if (cannirStrideTypeGetNumElements(type) == 0) {
    return py::cast(cannirStrideTypeGetValue(type));
  }
  py::list l;
  for (intptr_t i = 0; i < cannirStrideTypeGetNumElements(type); ++i) {
    l.append(stride_to_tuple(cannirStrideTypeGetElement(type, i)));
  }
  return py::tuple(l);
}

static py::object tile_to_tuple(MlirType type) {
  if (cannirTileTypeGetNumElements(type) == 0) {
    return py::cast(cannirTileTypeGetValue(type));
  }
  py::list l;
  for (intptr_t i = 0; i < cannirTileTypeGetNumElements(type); ++i) {
    l.append(tile_to_tuple(cannirTileTypeGetElement(type, i)));
  }
  return py::tuple(l);
}

static py::object coord_to_tuple(MlirType type) {
  if (cannirCoordTypeGetNumElements(type) == 0) {
    return py::cast(cannirCoordTypeGetValue(type));
  }
  py::list l;
  for (intptr_t i = 0; i < cannirCoordTypeGetNumElements(type); ++i) {
    l.append(coord_to_tuple(cannirCoordTypeGetElement(type, i)));
  }
  return py::tuple(l);
}

PYBIND11_MODULE(_cannir, m) {
  m.doc() = "CANNIR Python Extension";

  py::class_<TargetBufferSyncSnapshot>(m, "_TargetBufferSyncSnapshot");
  m.def("_capture_target_buffer_sync", [](py::object op) {
    void* snapshot = cannirCaptureTargetBufferSync(py::cast<MlirOperation>(op));
    if (!snapshot) throw py::value_error("cannot capture target Buffer synchronization");
    return std::make_unique<TargetBufferSyncSnapshot>(snapshot, op.attr("context"));
  });
  m.def("_verify_target_buffer_sync", [](const TargetBufferSyncSnapshot& snapshot, MlirOperation op) {
    if (mlirLogicalResultIsFailure(cannirVerifyTargetBufferSync(snapshot.snapshot, op)))
      throw py::value_error("target Buffer synchronization refinement failed");
  });

  m.def("infer_kernel_argument_access", [](MlirOperation op) {
    if (mlirOperationGetNumRegions(op) != 1) throw py::value_error("expected a materialized kernel function");
    MlirBlock block = mlirRegionGetFirstBlock(mlirOperationGetRegion(op, 0));
    if (mlirBlockIsNull(block)) throw py::value_error("kernel function has no entry block");
    std::vector<int32_t> access(mlirBlockGetNumArguments(block));
    if (mlirLogicalResultIsFailure(cannirInferKernelArgumentAccess(op, access.size(), access.data())))
      throw py::value_error("cannot infer kernel Tensor argument effects");
    py::list result;
    for (int32_t mask : access) result.append(mask);
    return result;
  });

  m.def(
      "translate_to_ascendc",
      [](MlirOperation op) -> std::string {
        std::string result;
        auto append = [](MlirStringRef chunk, void* userData) {
          static_cast<std::string*>(userData)->append(chunk.data, static_cast<size_t>(chunk.length));
        };
        if (mlirLogicalResultIsFailure(cannirTranslateToAscendC(op, append, &result)))
          throw std::runtime_error("Translation to AscendC failed");
        return result;
      },
      "Translate a lowered MLIR ModuleOp to AscendC C++ source code.");

  m.def(
      "translate_to_device_callable",
      [](MlirOperation op) {
        std::string source, manifest;
        auto append = [](MlirStringRef chunk, void* data) {
          static_cast<std::string*>(data)->append(chunk.data, chunk.length);
        };
        if (mlirLogicalResultIsFailure(cannirTranslateToDeviceCallable(op, append, &source, &manifest)))
          throw std::runtime_error("Device-callable translation failed; see MLIR diagnostics");
        return py::make_tuple(source, manifest);
      },
      "Export one lowered A5 device kernel/group as callable source and ABI JSON.");

  m.def("verify_device_callable_input", [](MlirOperation op) {
    if (mlirLogicalResultIsFailure(cannirVerifyDeviceCallableInput(op)))
      throw std::runtime_error("Device-callable capability check failed; see MLIR diagnostics");
  });

  m.def(
      "translate_to_source_bundle",
      [](MlirOperation op, bool hostOnly) {
        std::string source, functions;
        auto append = [](MlirStringRef chunk, void* data) {
          static_cast<std::string*>(data)->append(chunk.data, chunk.length);
        };
        if (mlirLogicalResultIsFailure(
                cannirTranslateToSourceBundle(op, append, &source, &functions, hostOnly)))
          throw std::runtime_error("Translation to source bundle failed");
        return py::make_tuple(source, functions);
      },
      py::arg("operation"), py::arg("host_only") = false,
      "Translate a lowered MLIR ModuleOp to a source bundle: (AscendC source, "
      "function metadata JSON). host_only selects Host code and signatures; "
      "otherwise emits device code and traditional kernel argument layouts.");

  m.def("cannirTypeIsAShape", &cannirTypeIsAShape);
  m.def("cannirTypeIsAStride", &cannirTypeIsAStride);
  m.def("cannirTypeIsATile", &cannirTypeIsATile);
  m.def("cannirTypeIsACoord", &cannirTypeIsACoord);
  m.def("cannirTypeIsAPartitionTiler", &cannirTypeIsAPartitionTiler);
  m.def("cannirTypeIsALayout", &cannirTypeIsALayout);
  m.def("cannirTypeIsAPointer", &cannirTypeIsAPointer);
  m.def("cannirTypeIsATensor", &cannirTypeIsATensor);
  m.def(
      "tensor_storage_bytes",
      [](MlirType type, int64_t offset) {
        auto bytes = cannirTensorTypeGetStorageBytes(type);
        if (bytes < 0) throw py::value_error("Tensor storage requires finite static shape and stride bounds");
        if (offset < 0 || offset > INT64_MAX - bytes)
          throw py::value_error("Tensor storage offset or capacity exceeds signed int64");
        return bytes + offset;
      },
      py::arg("type"), py::arg("offset_bytes") = 0);
  m.def("tensor_storage_alignment", &cannirTensorTypeGetStorageAlignment);
  m.def("mapped_extent_alignment", &cannirMappedExtentAlignment);
  m.def("infer_logical_reshape_layout", [](MlirType layout, MlirType shape) -> py::object {
    MlirType result = cannirInferLogicalReshapeLayout(layout, shape);
    if (mlirTypeIsNull(result)) return py::none();
    return py::cast(result);
  });
  m.def("cannirTypeIsACopyEngine", &cannirTypeIsACopyEngine);
  m.def("cannirTypeIsARingBuffer", &cannirTypeIsARingBuffer);
  m.def("cannirTypeIsADataStruct", &cannirTypeIsADataStruct);
  m.def("cannirTypeIsADataStructRef", &cannirTypeIsADataStructRef);
  m.def(
      "derive_physical_layout",
      [](MlirType pointer, MlirType logicalLayout, uint32_t layoutMapKind, int64_t n1Pad, MlirContext ctx) {
        MlirType type = cannirDerivePhysicalLayout(ctx, pointer, logicalLayout, layoutMapKind, n1Pad);
        if (mlirTypeIsNull(type))
          throw py::value_error("Cannot derive physical layout for the supplied Tensor contract");
        return type;
      },
      py::arg("pointer"), py::arg("logical_layout"), py::arg("layout_map_kind"), py::arg("n1_pad") = 0,
      py::arg("context") = py::none(), "Derive the canonical CANNIR physical layout in C++.");
  mlir::python::adaptors::mlir_type_subclass(m, "ShapeType", cannirTypeIsAShape, cannirShapeTypeGetTypeID)
      .def_classmethod(
          "get",
          [](py::object cls, py::list elements, int64_t value, MlirContext ctx) {
            llvm::SmallVector<MlirType> elts;
            for (auto item : elements) {
              elts.push_back(py::cast<MlirType>(item));
            }
            return cls(cannirShapeTypeGet(ctx, elts.size(), elts.data(), value));
          },
          py::arg("cls"), py::arg("elements"), py::arg("value") = 0, py::arg("context") = py::none())
      .def_property_readonly("is_scalar",
                             [](MlirType type) { return cannirShapeTypeGetNumElements(type) == 0; })
      .def_property_readonly("value", [](MlirType type) { return cannirShapeTypeGetValue(type); })
      .def_property_readonly("elements",
                             [](MlirType type) {
                               py::list l;
                               for (intptr_t i = 0; i < cannirShapeTypeGetNumElements(type); ++i)
                                 l.append(cannirShapeTypeGetElement(type, i));
                               return l;
                             })
      .def_property_readonly("as_tuple", [](MlirType type) { return shape_to_tuple(type); });

  mlir::python::adaptors::mlir_type_subclass(m, "StrideType", cannirTypeIsAStride, cannirStrideTypeGetTypeID)
      .def_classmethod(
          "get",
          [](py::object cls, py::list elements, int64_t value, MlirContext ctx) {
            llvm::SmallVector<MlirType> elts;
            for (auto item : elements) {
              elts.push_back(py::cast<MlirType>(item));
            }
            return cls(cannirStrideTypeGet(ctx, elts.size(), elts.data(), value));
          },
          py::arg("cls"), py::arg("elements"), py::arg("value") = 0, py::arg("context") = py::none())
      .def_property_readonly("is_scalar",
                             [](MlirType type) { return cannirStrideTypeGetNumElements(type) == 0; })
      .def_property_readonly("value", [](MlirType type) { return cannirStrideTypeGetValue(type); })
      .def_property_readonly("elements",
                             [](MlirType type) {
                               py::list l;
                               for (intptr_t i = 0; i < cannirStrideTypeGetNumElements(type); ++i)
                                 l.append(cannirStrideTypeGetElement(type, i));
                               return l;
                             })
      .def_property_readonly("as_tuple", [](MlirType type) { return stride_to_tuple(type); });

  mlir::python::adaptors::mlir_type_subclass(m, "TileType", cannirTypeIsATile, cannirTileTypeGetTypeID)
      .def_classmethod(
          "get",
          [](py::object cls, py::list elements, int64_t value, MlirContext ctx) {
            llvm::SmallVector<MlirType> elts;
            for (auto item : elements) {
              elts.push_back(py::cast<MlirType>(item));
            }
            return cls(cannirTileTypeGet(ctx, elts.size(), elts.data(), value));
          },
          py::arg("cls"), py::arg("elements"), py::arg("value") = 0, py::arg("context") = py::none())
      .def_classmethod(
          "get_with_alignment",
          [](py::object cls, py::list elements, int64_t value, std::vector<int64_t> alignment,
             MlirContext ctx) {
            llvm::SmallVector<MlirType> elts;
            for (auto item : elements) {
              elts.push_back(py::cast<MlirType>(item));
            }
            MlirType type = cannirTileTypeGetWithAlignment(ctx, elts.size(), elts.data(), value,
                                                           alignment.size(), alignment.data());
            if (mlirTypeIsNull(type)) {
              throw py::value_error(
                  "Failed to verify TileType alignment declaration. "
                  "See MLIR diagnostic for details.");
            }
            return cls(type);
          },
          py::arg("cls"), py::arg("elements"), py::arg("value"), py::arg("alignment"),
          py::arg("context") = py::none())
      .def_property_readonly("is_scalar",
                             [](MlirType type) { return cannirTileTypeGetNumElements(type) == 0; })
      .def_property_readonly("value", [](MlirType type) { return cannirTileTypeGetValue(type); })
      .def_property_readonly("alignment",
                             [](MlirType type) {
                               py::list l;
                               for (intptr_t i = 0; i < cannirTileTypeGetAlignmentSize(type); ++i)
                                 l.append(cannirTileTypeGetAlignmentDim(type, i));
                               return l;
                             })
      .def_property_readonly("elements",
                             [](MlirType type) {
                               py::list l;
                               for (intptr_t i = 0; i < cannirTileTypeGetNumElements(type); ++i)
                                 l.append(cannirTileTypeGetElement(type, i));
                               return l;
                             })
      .def_property_readonly("as_tuple", [](MlirType type) { return tile_to_tuple(type); });

  mlir::python::adaptors::mlir_type_subclass(m, "CoordType", cannirTypeIsACoord, cannirCoordTypeGetTypeID)
      .def_classmethod(
          "get",
          [](py::object cls, py::list elements, int64_t value, MlirContext ctx) {
            llvm::SmallVector<MlirType> elts;
            for (auto item : elements) {
              elts.push_back(py::cast<MlirType>(item));
            }
            return cls(cannirCoordTypeGet(ctx, elts.size(), elts.data(), value));
          },
          py::arg("cls"), py::arg("elements"), py::arg("value") = 0, py::arg("context") = py::none())
      .def_property_readonly("is_scalar",
                             [](MlirType type) { return cannirCoordTypeGetNumElements(type) == 0; })
      .def_property_readonly("value", [](MlirType type) { return cannirCoordTypeGetValue(type); })
      .def_property_readonly("elements",
                             [](MlirType type) {
                               py::list l;
                               for (intptr_t i = 0; i < cannirCoordTypeGetNumElements(type); ++i)
                                 l.append(cannirCoordTypeGetElement(type, i));
                               return l;
                             })
      .def_property_readonly("as_tuple", [](MlirType type) { return coord_to_tuple(type); });

  mlir::python::adaptors::mlir_type_subclass(m, "PartitionTilerType", cannirTypeIsAPartitionTiler,
                                             cannirPartitionTilerTypeGetTypeID)
      .def_classmethod(
          "get",
          [](py::object cls, std::vector<int64_t> fullShape, int64_t axis, int64_t parts, int64_t alignment,
             MlirContext ctx) {
            MlirType type =
                cannirPartitionTilerTypeGet(ctx, fullShape.size(), fullShape.data(), axis, parts, alignment);
            if (mlirTypeIsNull(type))
              throw py::value_error("Failed to verify PartitionTilerType. See MLIR diagnostic for details.");
            return cls(type);
          },
          py::arg("cls"), py::arg("full_shape"), py::arg("axis") = 0, py::arg("parts") = 2,
          py::arg("alignment") = 1, py::arg("context") = py::none())
      .def_property_readonly("full_shape",
                             [](MlirType type) {
                               py::tuple result(cannirPartitionTilerTypeGetRank(type));
                               for (intptr_t i = 0; i < cannirPartitionTilerTypeGetRank(type); ++i)
                                 result[i] = cannirPartitionTilerTypeGetFullShapeDim(type, i);
                               return result;
                             })
      .def_property_readonly("axis", [](MlirType type) { return cannirPartitionTilerTypeGetAxis(type); })
      .def_property_readonly("parts", [](MlirType type) { return cannirPartitionTilerTypeGetParts(type); })
      .def_property_readonly("alignment",
                             [](MlirType type) { return cannirPartitionTilerTypeGetAlignment(type); })
      .def_property_readonly("max_span",
                             [](MlirType type) { return cannirPartitionTilerTypeGetMaxSpan(type); });

  mlir::python::adaptors::mlir_type_subclass(m, "LayoutType", cannirTypeIsALayout, cannirLayoutTypeGetTypeID)
      .def_classmethod(
          "get",
          [](py::object cls, MlirType shape, MlirType stride, MlirContext ctx) {
            MlirType type = cannirLayoutTypeGet(ctx, shape, stride);
            if (mlirTypeIsNull(type)) {
              throw py::value_error("Failed to verify LayoutType. See MLIR diagnostic for details.");
            }
            return cls(type);
          },
          py::arg("cls"), py::arg("shape"), py::arg("stride"), py::arg("context") = py::none(),
          "Creates a LayoutType.")
      .def_classmethod(
          "get_checked",
          [](py::object cls, MlirType shape, MlirType stride, MlirContext ctx) {
            MlirType type = cannirLayoutTypeGet(ctx, shape, stride);
            if (mlirTypeIsNull(type)) {
              return py::object(py::none());
            }
            return cls(type);
          },
          py::arg("cls"), py::arg("shape"), py::arg("stride"), py::arg("context") = py::none(),
          "Creates a LayoutType or returns None if verification fails.")
      .def_property_readonly(
          "shape_type", [](MlirType type) { return cannirLayoutTypeGetShape(type); },
          "Gets the IR ShapeType embedded in this layout (used internally by make_layout).")
      .def_property_readonly(
          "stride_type", [](MlirType type) { return cannirLayoutTypeGetStride(type); },
          "Gets the IR StrideType embedded in this layout (used internally by make_layout).")
      .def_property_readonly("shape",
                             [](MlirType type) { return shape_to_tuple(cannirLayoutTypeGetShape(type)); })
      .def_property_readonly("stride",
                             [](MlirType type) { return stride_to_tuple(cannirLayoutTypeGetStride(type)); });

  mlir::python::adaptors::mlir_type_subclass(m, "BufferLogicalIdType", cannirTypeIsABufferLogicalId,
                                             cannirBufferLogicalIdTypeGetTypeID)
      .def_classmethod("get", [](py::object cls, MlirContext ctx) {
        return cls(cannirBufferLogicalIdTypeGet(ctx));
      }, py::arg("cls"), py::arg("context") = py::none());

  mlir::python::adaptors::mlir_type_subclass(m, "AllocationType", cannirTypeIsAAllocation,
                                             cannirAllocationTypeGetTypeID)
      .def_classmethod(
          "get",
          [](py::object cls, uint32_t memloc, MlirContext ctx) {
            return cls(cannirAllocationTypeGet(ctx, memloc));
          },
          py::arg("cls"), py::arg("memloc"), py::arg("context") = py::none())
      .def_property_readonly("memloc", [](MlirType type) { return cannirAllocationTypeGetMemloc(type); });

  mlir::python::adaptors::mlir_type_subclass(m, "PointerType", cannirTypeIsAPointer,
                                             cannirPointerTypeGetTypeID)
      .def_classmethod(
          "get",
          [](py::object cls, uint32_t memloc, MlirType dtype, MlirContext ctx) {
            return cls(cannirPointerTypeGet(ctx, memloc, dtype));
          },
          py::arg("cls"), py::arg("memloc"), py::arg("dtype"), py::arg("context") = py::none(),
          "Creates a PointerType.")
      .def_property_readonly(
          "memloc", [](MlirType type) { return cannirPointerTypeGetMemloc(type); },
          "Gets the memory location of the pointer.")
      .def_property_readonly(
          "dtype", [](MlirType type) { return cannirPointerTypeGetDtype(type); },
          "Gets the data type of the pointer.");

  mlir::python::adaptors::mlir_type_subclass(m, "TensorType", cannirTypeIsATensor, cannirTensorTypeGetTypeID)
      .def_classmethod(
          "get",
          [](py::object cls, MlirType pointer, MlirType logicalLayout, MlirType physicalLayout,
             uint32_t layoutMapKind, MlirContext ctx) {
            auto ir = py::module::import(MAKE_MLIR_PYTHON_QUALNAME("ir"));
            auto capsule = py::reinterpret_steal<py::object>(mlirPythonContextToCapsule(ctx));
            auto context = ir.attr("Context").attr(MLIR_PYTHON_CAPI_FACTORY_ATTR)(capsule);
            py::list diagnostics;
            MlirType type;
            {
              // Copy DiagnosticInfo while the diagnostic is live, preserving
              // its location and notes without depending on private MLIR bindings.
              auto handler = context.attr("attach_diagnostic_handler")(py::cpp_function(
                  [diagnostics, diagnosticInfo = ir.attr("DiagnosticInfo")](py::object diagnostic) mutable {
                    diagnostics.append(diagnosticInfo(diagnostic));
                    return true;
                  }));
              auto detach = llvm::make_scope_exit([&]() { handler.attr("detach")(); });
              type = cannirTensorTypeGet(ctx, pointer, logicalLayout, physicalLayout, layoutMapKind);
            }
            if (mlirTypeIsNull(type)) {
              auto error = ir.attr("MLIRError")("Failed to create TensorType", diagnostics);
              PyErr_SetObject(ir.attr("MLIRError").ptr(), error.ptr());
              throw py::error_already_set();
            }
            return cls(type);
          },
          py::arg("cls"), py::arg("pointer"), py::arg("logical_layout"), py::arg("physical_layout"),
          py::arg("layout_map_kind"), py::arg("context") = py::none(),
          "Creates a TensorType. Raises MLIRError if verification fails.")
      .def_property_readonly(
          "pointer", [](MlirType type) { return cannirTensorTypeGetPointer(type); },
          "Gets the pointer of the tensor.")
      .def_property_readonly(
          "logical_layout", [](MlirType type) { return cannirTensorTypeGetLogicalLayout(type); },
          "Gets the logical layout of the tensor.")
      .def_property_readonly(
          "physical_layout", [](MlirType type) { return cannirTensorTypeGetPhysicalLayout(type); },
          "Gets the physical layout of the tensor.")
      .def_property_readonly(
          "layout_map_kind", [](MlirType type) { return cannirTensorTypeGetLayoutMapKind(type); },
          "Gets the layout map kind.");

  mlir::python::adaptors::mlir_type_subclass(m, "CopyEngineType", cannirTypeIsACopyEngine,
                                             cannirCopyEngineTypeGetTypeID)
      .def_classmethod(
          "get",
          [](py::object cls, uint32_t kind, uint32_t channelSplit, MlirContext ctx) {
            return cls(cannirCopyEngineTypeGet(ctx, kind, channelSplit));
          },
          py::arg("cls"), py::arg("kind") = 0, py::arg("channel_split") = 0, py::arg("context") = py::none(),
          "Creates copy execution options.")
      .def_property_readonly("kind", [](MlirType type) { return cannirCopyEngineTypeGetKind(type); })
      .def_property_readonly("channel_split",
                             [](MlirType type) { return cannirCopyEngineTypeGetChannelSplit(type); });

  mlir::python::adaptors::mlir_type_subclass(m, "GroupSyncType", cannirTypeIsAGroupSync,
                                           cannirGroupSyncTypeGetTypeID)
      .def_classmethod("get", [](py::object cls, int64_t depth, int64_t producers,
                                 int64_t consumers, MlirContext ctx) {
        return cls(cannirGroupSyncTypeGet(ctx, depth, producers, consumers));
      }, py::arg("cls"), py::arg("depth"), py::arg("producers"), py::arg("consumers"),
         py::arg("context") = py::none())
      .def_property_readonly("depth", &cannirGroupSyncTypeGetDepth)
      .def_property_readonly("producers", &cannirGroupSyncTypeGetProducers)
      .def_property_readonly("consumers", &cannirGroupSyncTypeGetConsumers);
  mlir::python::adaptors::mlir_type_subclass(m, "GroupSyncTicketType", cannirTypeIsAGroupSyncTicket,
                                           cannirGroupSyncTicketTypeGetTypeID)
      .def_classmethod("get", [](py::object cls, MlirType sync, const std::string &role) {
        return cls(cannirGroupSyncTicketTypeGet(sync, mlirStringRefCreate(role.data(), role.size())));
      }, py::arg("cls"), py::arg("sync"), py::arg("role"))
      .def_property_readonly("sync_type", &cannirGroupSyncTicketTypeGetSyncType)
      .def_property_readonly("role", [](MlirType type) {
        auto role = cannirGroupSyncTicketTypeGetRole(type);
        return std::string(role.data, role.length);
      });

  mlir::python::adaptors::mlir_type_subclass(m, "RingBufferType", cannirTypeIsARingBuffer,
                                             cannirRingBufferTypeGetTypeID)
      .def_classmethod(
          "get",
          [](py::object cls, MlirType element, int64_t depth, MlirContext ctx) {
            return cls(cannirRingBufferTypeGet(ctx, element, depth));
          },
          py::arg("cls"), py::arg("element"), py::arg("depth"), py::kw_only(),
          py::arg("context") = py::none(), "Creates a RingBufferType.")
      .def_property_readonly(
          "element", [](MlirType type) { return cannirRingBufferTypeGetElement(type); },
          "Gets the element tensor type of the ringBuffer slots.")
      .def_property_readonly(
          "depth", [](MlirType type) { return cannirRingBufferTypeGetDepth(type); },
          "Gets the ring buffer depth (number of slots).");

  mlir::python::adaptors::mlir_type_subclass(m, "ArrayType", cannirTypeIsAArray, cannirArrayTypeGetTypeID)
      .def_classmethod(
          "get",
          [](py::object cls, int64_t length, MlirType element_type, MlirContext ctx) {
            return cls(cannirArrayTypeGet(ctx, length, element_type));
          },
          py::arg("cls"), py::arg("length"), py::arg("element_type"), py::arg("context") = py::none(),
          "Creates an ArrayType.")
      .def_property_readonly(
          "length", [](MlirType type) { return cannirArrayTypeGetLength(type); },
          "Gets the static array length.")
      .def_property_readonly(
          "element_type", [](MlirType type) { return cannirArrayTypeGetElementType(type); },
          "Gets the element type.");

  mlir::python::adaptors::mlir_type_subclass(m, "DataStructType", cannirTypeIsADataStruct,
                                             cannirDataStructTypeGetTypeID)
      .def_classmethod(
          "get",
          [](py::object cls, const std::string& c_name, py::list field_names, py::list field_types,
             py::list field_offsets, int64_t size, int64_t alignment, MlirContext ctx) {
            if (field_names.size() != field_types.size() || field_names.size() != field_offsets.size())
              throw py::value_error(
                  "field_names, field_types, and field_offsets must have "
                  "equal lengths");
            std::vector<std::string> name_storage;
            std::vector<MlirStringRef> names;
            std::vector<MlirType> types;
            std::vector<int64_t> offsets;
            name_storage.reserve(field_names.size());
            names.reserve(field_names.size());
            types.reserve(field_names.size());
            offsets.reserve(field_names.size());
            for (auto item : field_names) name_storage.push_back(py::cast<std::string>(item));
            for (const std::string& name : name_storage)
              names.push_back(mlirStringRefCreate(name.data(), name.size()));
            for (auto item : field_types) types.push_back(py::cast<MlirType>(item));
            for (auto item : field_offsets) offsets.push_back(py::cast<int64_t>(item));
            MlirType type =
                cannirDataStructTypeGet(ctx, mlirStringRefCreate(c_name.data(), c_name.size()), names.size(),
                                        names.data(), types.data(), offsets.data(), size, alignment);
            if (mlirTypeIsNull(type))
              throw py::value_error("Failed to verify DataStructType. See MLIR diagnostic for details.");
            return cls(type);
          },
          py::arg("cls"), py::arg("c_name"), py::arg("field_names"), py::arg("field_types"),
          py::arg("field_offsets"), py::arg("size"), py::arg("alignment"), py::arg("context") = py::none(),
          "Creates a naturally-aligned DataStructType.")
      .def_property_readonly(
          "c_name",
          [](MlirType type) {
            MlirStringRef value = cannirDataStructTypeGetCName(type);
            return py::str(value.data, value.length);
          },
          "Gets the emitted C struct name.")
      .def_property_readonly(
          "field_names",
          [](MlirType type) {
            py::list result;
            for (intptr_t i = 0; i < cannirDataStructTypeGetNumFields(type); ++i) {
              MlirStringRef value = cannirDataStructTypeGetFieldName(type, i);
              result.append(py::str(value.data, value.length));
            }
            return py::tuple(result);
          },
          "Gets field names in declaration order.")
      .def_property_readonly(
          "field_types",
          [](MlirType type) {
            py::list result;
            for (intptr_t i = 0; i < cannirDataStructTypeGetNumFields(type); ++i)
              result.append(cannirDataStructTypeGetFieldType(type, i));
            return py::tuple(result);
          },
          "Gets field MLIR types in declaration order.")
      .def_property_readonly(
          "field_offsets",
          [](MlirType type) {
            py::list result;
            for (intptr_t i = 0; i < cannirDataStructTypeGetNumFields(type); ++i)
              result.append(cannirDataStructTypeGetFieldOffset(type, i));
            return py::tuple(result);
          },
          "Gets natural-ABI field offsets.")
      .def_property_readonly(
          "size", [](MlirType type) { return cannirDataStructTypeGetSize(type); },
          "Gets sizeof for the aggregate ABI.")
      .def_property_readonly(
          "alignment", [](MlirType type) { return cannirDataStructTypeGetAlignment(type); },
          "Gets alignof for the aggregate ABI.");

  mlir::python::adaptors::mlir_type_subclass(m, "DataStructRefType", cannirTypeIsADataStructRef,
                                             cannirDataStructRefTypeGetTypeID)
      .def_classmethod(
          "get",
          [](py::object cls, MlirType schema, uint32_t address_space, uint32_t access, MlirContext ctx) {
            MlirType type = cannirDataStructRefTypeGet(ctx, schema, address_space, access);
            if (mlirTypeIsNull(type))
              throw py::value_error("Failed to verify DataStructRefType. See MLIR diagnostic for details.");
            return cls(type);
          },
          py::arg("cls"), py::arg("schema"), py::arg("address_space") = 0, py::arg("access") = 0,
          py::arg("context") = py::none(), "Creates a provider-backed GM datastruct reference type.")
      .def_property_readonly(
          "schema", [](MlirType type) { return cannirDataStructRefTypeGetSchema(type); },
          "Gets the referenced datastruct schema.")
      .def_property_readonly(
          "address_space", [](MlirType type) { return cannirDataStructRefTypeGetAddressSpace(type); },
          "Gets the reference address space enum value.")
      .def_property_readonly(
          "access", [](MlirType type) { return cannirDataStructRefTypeGetAccess(type); },
          "Gets the reference access-mode enum value.");
}
