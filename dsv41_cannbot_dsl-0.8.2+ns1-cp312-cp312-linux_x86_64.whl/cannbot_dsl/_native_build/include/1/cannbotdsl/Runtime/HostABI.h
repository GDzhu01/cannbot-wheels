/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef CANNBOTDSL_RUNTIME_HOSTABI_H_
#define CANNBOTDSL_RUNTIME_HOSTABI_H_

#include <cstddef>
#include <cstdint>

namespace cannbotdsl::runtime {

inline constexpr uint32_t kCallFrameMagicV9 = 0x43424639U;   // "CBF9"
inline constexpr uint32_t kHostSchemaMagicV2 = 0x43425332U;  // "CBS2"
inline constexpr uint16_t kHostABIVersion = 9;
inline constexpr uint16_t kHostSchemaVersion = 2;

enum class HostSlotKind : uint32_t {
  Tensor = 1,
  Scalar = 2,
  Buffer = 3,
};

enum HostSlotFlags : uint32_t {
  HostSlotPublic = 1U << 0,
  HostSlotInternalDebug = 1U << 1,
};

enum class HostTensorEncoding : uint32_t {
  Identity = 0,
  FractalNZ = 1,
};

struct CannBotCallFrameHeaderV9 {
  uint32_t magic;
  uint16_t hostAbiVersion;
  uint16_t schemaVersion;
  uint32_t slotCount;
  uint32_t reserved;
  uint64_t frameBytes;
  uint8_t contractDigest[32];
};

struct CannBotHostSlotSchemaV2 {
  uint32_t kind;
  uint32_t flags;
  uint32_t dtypeCode;
  uint32_t dtypeBits;
  uint32_t dtypeLanes;
  uint32_t encoding;
  uint32_t logicalRank;
  uint32_t physicalRank;
  uint64_t offset;
  uint64_t size;
  uint64_t alignment;
  uint64_t pointerOffset;
  uint64_t shapeOffset;
  uint64_t strideOffset;
  uint64_t physicalShapeOffset;
  uint64_t physicalStrideOffset;
  uint8_t abiTypeDigest[32];
};

struct CannBotHostSchemaV2 {
  uint32_t magic;
  uint16_t hostAbiVersion;
  uint16_t schemaVersion;
  uint32_t slotCount;
  uint32_t reserved;
  uint64_t frameBytes;
  uint64_t frameAlignment;
  uint8_t contractDigest[32];
  const CannBotHostSlotSchemaV2* slots;
};

using HostSchemaFunctionV2 = const CannBotHostSchemaV2* (*)() noexcept;
using HostInvokeFunctionV9 = int32_t (*)(void*, const void*, uint64_t) noexcept;

// Optional profiling entry point. The ordinary v9 call frame and invocation
// remain unchanged; old artifacts still run with reporting disabled.
struct ProfilingTensorV1 {
  uint32_t role;
  uint32_t dataType;  // aclDataType, UINT32_MAX when not representable
  uint32_t format;    // aclFormat
  uint32_t rank;
  const int64_t* shape;
};

struct ProfilingCallbacksV1 {
  uint32_t version;
  uint32_t size;
  void* context;
  // taskType is MsprofGeTaskType; mixRatio is the slave/main block ratio.
  int32_t (*begin)(void*, const char*, const char*, uint64_t, uint32_t, uint32_t,
                   void*, const ProfilingTensorV1*, uint64_t) noexcept;
  int32_t (*end)(void*) noexcept;
};

using HostProfileInvokeFunctionV1 = int32_t (*)(void*, const void*, uint64_t,
                                                const ProfilingCallbacksV1*) noexcept;

static_assert(sizeof(ProfilingTensorV1) == 24);
static_assert(sizeof(ProfilingCallbacksV1) == 32);

static_assert(sizeof(CannBotCallFrameHeaderV9) == 56);
static_assert(alignof(CannBotCallFrameHeaderV9) == 8);
static_assert(offsetof(CannBotCallFrameHeaderV9, contractDigest) == 24);
static_assert(sizeof(CannBotHostSlotSchemaV2) == 128);
static_assert(alignof(CannBotHostSlotSchemaV2) == 8);

}  // namespace cannbotdsl::runtime

#endif  // CANNBOTDSL_RUNTIME_HOSTABI_H_
