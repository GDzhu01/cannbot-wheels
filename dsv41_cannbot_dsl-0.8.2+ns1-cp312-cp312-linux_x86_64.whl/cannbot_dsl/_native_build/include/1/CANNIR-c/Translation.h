/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */
#ifndef CANNIR_C_TRANSLATION_H_
#define CANNIR_C_TRANSLATION_H_

#include "mlir-c/IR.h"
#include "mlir-c/Support.h"

#ifdef __cplusplus
extern "C" {
#endif

/// Translate a lowered builtin.module to AscendC and stream the result through
/// a C callback. No C++ MLIR object or std::string crosses the DSO boundary.
MLIR_CAPI_EXPORTED MlirLogicalResult cannirTranslateToAscendC(MlirOperation operation,
                                                              MlirStringCallback callback, void* userData);

/// Emit device source (hostOnly=false), or typed Host source and function
/// signatures for an external launcher (hostOnly=true). Device signatures are [].
/// The callback fires twice on success: first with the AscendC source chunk and
/// sourceData, then with the host-function signature JSON chunk and
/// functionsData.
MLIR_CAPI_EXPORTED MlirLogicalResult cannirTranslateToSourceBundle(MlirOperation operation,
                                                                   MlirStringCallback callback,
                                                                   void* sourceData, void* functionsData,
                                                                   bool hostOnly);

/// Export one lowered A5 device kernel/group, emitting source then ABI JSON.
MLIR_CAPI_EXPORTED MlirLogicalResult cannirTranslateToDeviceCallable(MlirOperation operation,
                                                                     MlirStringCallback callback,
                                                                     void* sourceData, void* manifestData);

MLIR_CAPI_EXPORTED MlirLogicalResult cannirVerifyDeviceCallableInput(MlirOperation operation);

#ifdef __cplusplus
}
#endif

#endif  // CANNIR_C_TRANSLATION_H_
