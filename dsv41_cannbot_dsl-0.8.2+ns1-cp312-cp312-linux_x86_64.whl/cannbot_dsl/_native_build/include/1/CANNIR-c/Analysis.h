/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef CANNIR_C_ANALYSIS_H_
#define CANNIR_C_ANALYSIS_H_
#include "mlir-c/IR.h"
#include "mlir-c/Support.h"
#ifdef __cplusplus
extern "C" {
#endif
// One mask per entry-block argument: bit 0 = read, bit 1 = write.
MLIR_CAPI_EXPORTED MlirLogicalResult cannirInferKernelArgumentAccess(MlirOperation function, intptr_t count,
                                                                     int32_t* access);
// Internal target-refinement checks. The caller keeps the MLIR context alive.
// Capture verifies no source synchronization: it records an already-lowered
// reference for compiler validation and mutation tests only.
MLIR_CAPI_EXPORTED void* cannirCaptureTargetBufferSync(MlirOperation module);
MLIR_CAPI_EXPORTED MlirLogicalResult cannirVerifyTargetBufferSync(void* snapshot, MlirOperation module);
MLIR_CAPI_EXPORTED void cannirDestroyTargetBufferSync(void* snapshot);
#ifdef __cplusplus
}
#endif
#endif  // CANNIR_C_ANALYSIS_H_
