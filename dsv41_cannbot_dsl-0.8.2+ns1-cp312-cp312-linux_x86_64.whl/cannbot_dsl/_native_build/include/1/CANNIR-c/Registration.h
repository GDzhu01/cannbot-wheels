/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */
#ifndef CANNIR_C_REGISTRATION_H_
#define CANNIR_C_REGISTRATION_H_

#include "mlir-c/IR.h"

#ifdef __cplusplus
extern "C" {
#endif

/// Insert every project and supporting dialect into `registry`.
MLIR_CAPI_EXPORTED void cannirRegisterDialects(MlirDialectRegistry registry);

/// Register project and canonical upstream transform passes once per process.
MLIR_CAPI_EXPORTED void cannirRegisterAllPasses(void);

#ifdef __cplusplus
}
#endif

#endif  // CANNIR_C_REGISTRATION_H_
