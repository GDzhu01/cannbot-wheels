/**
 * Copyright (c) 2026 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */
#ifndef CANNIR_C_DIALECTS_H_
#define CANNIR_C_DIALECTS_H_

#include "mlir-c/IR.h"
#include "mlir-c/Support.h"

#ifdef __cplusplus
extern "C" {
#endif

MLIR_DECLARE_CAPI_DIALECT_REGISTRATION(CANNIR, cannir);

// ShapeType
MLIR_CAPI_EXPORTED bool cannirTypeIsAShape(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirShapeTypeGet(MlirContext ctx, intptr_t numElements,
                                               MlirType const* elements, int64_t value);
MLIR_CAPI_EXPORTED intptr_t cannirShapeTypeGetNumElements(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirShapeTypeGetElement(MlirType type, intptr_t pos);
MLIR_CAPI_EXPORTED int64_t cannirShapeTypeGetValue(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirShapeTypeGetTypeID();

// StrideType
MLIR_CAPI_EXPORTED bool cannirTypeIsAStride(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirStrideTypeGet(MlirContext ctx, intptr_t numElements,
                                                MlirType const* elements, int64_t value);
MLIR_CAPI_EXPORTED intptr_t cannirStrideTypeGetNumElements(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirStrideTypeGetElement(MlirType type, intptr_t pos);
MLIR_CAPI_EXPORTED int64_t cannirStrideTypeGetValue(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirStrideTypeGetTypeID();

// TileType
MLIR_CAPI_EXPORTED bool cannirTypeIsATile(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirTileTypeGet(MlirContext ctx, intptr_t numElements, MlirType const* elements,
                                              int64_t value);
// Alignment describes nominal tile leaves in depth-first order, not clipped
// tail extents. An empty array is undeclared; dynamic values are caller guarantees.
MLIR_CAPI_EXPORTED MlirType cannirTileTypeGetWithAlignment(MlirContext ctx, intptr_t numElements,
                                                           MlirType const* elements, int64_t value,
                                                           intptr_t numAlignment, const int64_t* alignment);
MLIR_CAPI_EXPORTED intptr_t cannirTileTypeGetNumElements(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirTileTypeGetElement(MlirType type, intptr_t pos);
MLIR_CAPI_EXPORTED int64_t cannirTileTypeGetValue(MlirType type);
MLIR_CAPI_EXPORTED intptr_t cannirTileTypeGetAlignmentSize(MlirType type);
MLIR_CAPI_EXPORTED int64_t cannirTileTypeGetAlignmentDim(MlirType type, intptr_t pos);
MLIR_CAPI_EXPORTED MlirTypeID cannirTileTypeGetTypeID();

// CoordType
MLIR_CAPI_EXPORTED bool cannirTypeIsACoord(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirCoordTypeGet(MlirContext ctx, intptr_t numElements,
                                               MlirType const* elements, int64_t value);
MLIR_CAPI_EXPORTED intptr_t cannirCoordTypeGetNumElements(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirCoordTypeGetElement(MlirType type, intptr_t pos);
MLIR_CAPI_EXPORTED int64_t cannirCoordTypeGetValue(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirCoordTypeGetTypeID();

// PartitionTilerType
MLIR_CAPI_EXPORTED bool cannirTypeIsAPartitionTiler(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirPartitionTilerTypeGet(MlirContext ctx, intptr_t rank,
                                                        const int64_t* fullShape, int64_t axis, int64_t parts,
                                                        int64_t alignment);
MLIR_CAPI_EXPORTED intptr_t cannirPartitionTilerTypeGetRank(MlirType type);
MLIR_CAPI_EXPORTED int64_t cannirPartitionTilerTypeGetFullShapeDim(MlirType type, intptr_t pos);
MLIR_CAPI_EXPORTED int64_t cannirPartitionTilerTypeGetAxis(MlirType type);
MLIR_CAPI_EXPORTED int64_t cannirPartitionTilerTypeGetParts(MlirType type);
MLIR_CAPI_EXPORTED int64_t cannirPartitionTilerTypeGetAlignment(MlirType type);
MLIR_CAPI_EXPORTED int64_t cannirPartitionTilerTypeGetMaxSpan(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirPartitionTilerTypeGetTypeID();

// LayoutType
MLIR_CAPI_EXPORTED bool cannirTypeIsALayout(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirLayoutTypeGet(MlirContext ctx, MlirType shape, MlirType stride);
MLIR_CAPI_EXPORTED MlirType cannirLayoutTypeGetShape(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirLayoutTypeGetStride(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirLayoutTypeGetTypeID();
MLIR_CAPI_EXPORTED MlirType cannirDerivePhysicalLayout(MlirContext ctx, MlirType pointer,
                                                       MlirType logicalLayout, uint32_t layoutMapKind,
                                                       int64_t n1Pad);
MLIR_CAPI_EXPORTED int64_t cannirMappedExtentAlignment(MlirType pointer);

// BufferLogicalIdType
MLIR_CAPI_EXPORTED bool cannirTypeIsABufferLogicalId(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirBufferLogicalIdTypeGet(MlirContext ctx);
MLIR_CAPI_EXPORTED MlirTypeID cannirBufferLogicalIdTypeGetTypeID();

// AllocationType
MLIR_CAPI_EXPORTED bool cannirTypeIsAAllocation(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirAllocationTypeGet(MlirContext ctx, uint32_t memloc);
MLIR_CAPI_EXPORTED uint32_t cannirAllocationTypeGetMemloc(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirAllocationTypeGetTypeID();

// PointerType
MLIR_CAPI_EXPORTED bool cannirTypeIsAPointer(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirPointerTypeGet(MlirContext ctx, uint32_t memloc, MlirType dtype);
MLIR_CAPI_EXPORTED uint32_t cannirPointerTypeGetMemloc(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirPointerTypeGetDtype(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirPointerTypeGetTypeID();

// RawVRegType
MLIR_CAPI_EXPORTED bool cannirTypeIsARawVReg(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirRawVRegTypeGet(MlirContext ctx, MlirType dtype);
MLIR_CAPI_EXPORTED MlirType cannirRawVRegTypeGetDtype(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirRawVRegTypeGetTypeID();

// RawMaskType
MLIR_CAPI_EXPORTED bool cannirTypeIsARawMask(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirRawMaskTypeGet(MlirContext ctx, int32_t elemBits);
MLIR_CAPI_EXPORTED int32_t cannirRawMaskTypeGetElemBits(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirRawMaskTypeGetTypeID();

// ULoadRegType
MLIR_CAPI_EXPORTED bool cannirTypeIsAULoadReg(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirULoadRegTypeGet(MlirContext ctx);
MLIR_CAPI_EXPORTED MlirTypeID cannirULoadRegTypeGetTypeID();

// AddrRegType
MLIR_CAPI_EXPORTED bool cannirTypeIsAAddrReg(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirAddrRegTypeGet(MlirContext ctx);
MLIR_CAPI_EXPORTED MlirTypeID cannirAddrRegTypeGetTypeID();

// UStoreRegType
MLIR_CAPI_EXPORTED bool cannirTypeIsAUStoreReg(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirUStoreRegTypeGet(MlirContext ctx);
MLIR_CAPI_EXPORTED MlirTypeID cannirUStoreRegTypeGetTypeID();

// TensorType
MLIR_CAPI_EXPORTED bool cannirTypeIsATensor(MlirType type);
// Creates a verified TensorType. Invalid arguments or layouts emit a diagnostic
// in ctx and return a null type. All types must belong to ctx. A null ctx returns
// a null type without emitting a diagnostic.
MLIR_CAPI_EXPORTED MlirType cannirTensorTypeGet(MlirContext ctx, MlirType pointer, MlirType logicalLayout,
                                                MlirType physicalLayout, uint32_t layoutMapKind);
MLIR_CAPI_EXPORTED MlirType cannirTensorTypeGetPointer(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirTensorTypeGetLogicalLayout(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirTensorTypeGetPhysicalLayout(MlirType type);
MLIR_CAPI_EXPORTED uint32_t cannirTensorTypeGetLayoutMapKind(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirTensorTypeGetTypeID();
// Full physical pitch in bytes; -1 when a static bounded size is unavailable.
MLIR_CAPI_EXPORTED int64_t cannirTensorTypeGetStorageBytes(MlirType type);
MLIR_CAPI_EXPORTED int64_t cannirTensorTypeGetStorageAlignment(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirInferLogicalReshapeLayout(MlirType layout, MlirType shape);

// CopyEngineType
MLIR_CAPI_EXPORTED bool cannirTypeIsACopyEngine(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirCopyEngineTypeGet(MlirContext ctx, uint32_t kind,
                                                   uint32_t channelSplit);
MLIR_CAPI_EXPORTED uint32_t cannirCopyEngineTypeGetKind(MlirType type);
MLIR_CAPI_EXPORTED uint32_t cannirCopyEngineTypeGetChannelSplit(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirCopyEngineTypeGetTypeID();

// GroupSync types.
MLIR_CAPI_EXPORTED bool cannirTypeIsAGroupSync(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirGroupSyncTypeGetTypeID();
MLIR_CAPI_EXPORTED MlirType cannirGroupSyncTypeGet(MlirContext ctx, int64_t depth, int64_t producers, int64_t consumers);
MLIR_CAPI_EXPORTED int64_t cannirGroupSyncTypeGetDepth(MlirType type);
MLIR_CAPI_EXPORTED int64_t cannirGroupSyncTypeGetProducers(MlirType type);
MLIR_CAPI_EXPORTED int64_t cannirGroupSyncTypeGetConsumers(MlirType type);
MLIR_CAPI_EXPORTED bool cannirTypeIsAGroupSyncTicket(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirGroupSyncTicketTypeGetTypeID();
MLIR_CAPI_EXPORTED MlirType cannirGroupSyncTicketTypeGet(MlirType sync, MlirStringRef role);
MLIR_CAPI_EXPORTED MlirType cannirGroupSyncTicketTypeGetSyncType(MlirType type);
MLIR_CAPI_EXPORTED MlirStringRef cannirGroupSyncTicketTypeGetRole(MlirType type);

// RingBufferType
MLIR_CAPI_EXPORTED bool cannirTypeIsARingBuffer(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirRingBufferTypeGet(MlirContext ctx, MlirType element, int64_t depth);
MLIR_CAPI_EXPORTED MlirType cannirRingBufferTypeGetElement(MlirType type);
MLIR_CAPI_EXPORTED int64_t cannirRingBufferTypeGetDepth(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirRingBufferTypeGetTypeID();

// ArrayType
MLIR_CAPI_EXPORTED bool cannirTypeIsAArray(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirArrayTypeGet(MlirContext ctx, int64_t length, MlirType elementType);
MLIR_CAPI_EXPORTED int64_t cannirArrayTypeGetLength(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirArrayTypeGetElementType(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirArrayTypeGetTypeID();

// DataStructType
MLIR_CAPI_EXPORTED bool cannirTypeIsADataStruct(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirDataStructTypeGet(MlirContext ctx, MlirStringRef cName, intptr_t numFields,
                                                    MlirStringRef const* fieldNames,
                                                    MlirType const* fieldTypes, int64_t const* fieldOffsets,
                                                    int64_t size, int64_t alignment);
MLIR_CAPI_EXPORTED MlirStringRef cannirDataStructTypeGetCName(MlirType type);
MLIR_CAPI_EXPORTED intptr_t cannirDataStructTypeGetNumFields(MlirType type);
MLIR_CAPI_EXPORTED MlirStringRef cannirDataStructTypeGetFieldName(MlirType type, intptr_t pos);
MLIR_CAPI_EXPORTED MlirType cannirDataStructTypeGetFieldType(MlirType type, intptr_t pos);
MLIR_CAPI_EXPORTED int64_t cannirDataStructTypeGetFieldOffset(MlirType type, intptr_t pos);
MLIR_CAPI_EXPORTED int64_t cannirDataStructTypeGetSize(MlirType type);
MLIR_CAPI_EXPORTED int64_t cannirDataStructTypeGetAlignment(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirDataStructTypeGetTypeID();

// DataStructRefType
MLIR_CAPI_EXPORTED bool cannirTypeIsADataStructRef(MlirType type);
MLIR_CAPI_EXPORTED MlirType cannirDataStructRefTypeGet(MlirContext ctx, MlirType schema,
                                                       uint32_t addressSpace, uint32_t access);
MLIR_CAPI_EXPORTED MlirType cannirDataStructRefTypeGetSchema(MlirType type);
MLIR_CAPI_EXPORTED uint32_t cannirDataStructRefTypeGetAddressSpace(MlirType type);
MLIR_CAPI_EXPORTED uint32_t cannirDataStructRefTypeGetAccess(MlirType type);
MLIR_CAPI_EXPORTED MlirTypeID cannirDataStructRefTypeGetTypeID();

#ifdef __cplusplus
}
#endif

#endif  // CANNIR_C_DIALECTS_H_
