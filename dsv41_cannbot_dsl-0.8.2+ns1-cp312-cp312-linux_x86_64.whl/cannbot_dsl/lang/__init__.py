# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""cannbot_dsl.lang -- the surface syntax: entry points, specs and control flow."""

from cannbot_dsl.aot.compiler import compile
from cannbot_dsl.lang.host import host, HostFunction
from cannbot_dsl.lang.constexpr import (
    const_expr,
    range_constexpr,
)
from cannbot_dsl.lang.control_flow import (
    range,
)
from cannbot_dsl.lang.jit import (
    JitFunction,
    jit,
)
from cannbot_dsl.lang.kernel import (
    KernelLauncher,
    kernel,
)

# `kernel_class` has no decorator of its own: `@kernel` on a class dispatches
# to `_KernelClassLauncher`. Imported for that registration side effect only.
from cannbot_dsl.lang import kernel_class  # noqa: F401
from cannbot_dsl.aot.spec import (
    Constexpr,
    Dim,
    StructSpec,
    TensorListSpec,
    TensorSpec,
)
from cannbot_dsl.lang.vf import (
    vf,
)

__all__ = [
    "Constexpr",
    "Dim",
    "HostFunction",
    "JitFunction",
    "KernelLauncher",
    "StructSpec",
    "TensorListSpec",
    "TensorSpec",
    "compile",
    "const_expr",
    "host",
    "jit",
    "kernel",
    "kernel_class",
    "range",
    "range_constexpr",
    "vf",
]
