# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Host launch dimensions (x, y, z)."""

from dataclasses import dataclass

from cannbot_dsl.core.diag.diagnostics import (
    CANNBotValueError,
    DiagnosticCode,
)
from cannbot_dsl.core.utils.type_checks import is_exact_instance


@dataclass(frozen=True)
class Dim3:
    """Three positive compile-time dimensions; omitted y/z default to one."""

    x: int = 1
    y: int = 1
    z: int = 1

    def __post_init__(self):
        for axis in ("x", "y", "z"):
            value = getattr(self, axis)
            if not is_exact_instance(value, int) or not 1 <= value <= 0xFFFFFFFF:
                raise CANNBotValueError(
                    DiagnosticCode.INVALID_ARGUMENT, f"dim3.{axis} must be a positive uint32 integer"
                )

    @property
    def volume(self):
        return self.x * self.y * self.z

    def as_tuple(self):
        return (self.x, self.y, self.z)


# Backward-compatible lowercase spelling of the launch-dimensions class.
dim3 = Dim3


def parse_launch_config(config):
    """Parse the three public launch forms.

    Integer-only launches are used by SIMD and mixed kernels.  The two- and three-item
    forms are reserved for pure SIMT and therefore requires both dimensions to
    be explicit ``dim3`` values.
    """
    values = config if isinstance(config, tuple) else (config,)
    if len(values) not in (1, 2, 3):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            "kernel launch requires [block] or [dim3 block, dim3 thread, optional dyn_ub_buf]",
        )
    if len(values) == 1:
        return values[0], None, 0
    block, thread = values[:2]
    ub = values[2] if len(values) == 3 else 0
    if not isinstance(block, dim3) or not isinstance(thread, dim3):
        raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "pure SIMT launch requires dim3 block and dim3 thread")
    if not 1 <= thread.volume <= 1024:
        raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "thread must be dim3 with 1 <= x*y*z <= 1024")
    if not is_exact_instance(ub, int) or ub < 0:
        raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "dyn_ub_buf must be a non-negative integer")
    return block, thread, ub
