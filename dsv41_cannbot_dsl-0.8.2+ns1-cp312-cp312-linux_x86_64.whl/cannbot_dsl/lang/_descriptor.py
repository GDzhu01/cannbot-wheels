# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
from __future__ import annotations

from typing import Any, Callable

from cannbot_dsl.core.contracts.surface import SurfaceSignature


def initialize_function_metadata(descriptor: Any, fn: Callable[..., Any]) -> SurfaceSignature:
    descriptor.fn = fn
    descriptor.__name__ = getattr(fn, "__name__", type(descriptor).__name__)
    descriptor.__qualname__ = getattr(fn, "__qualname__", descriptor.__name__)
    descriptor.__doc__ = getattr(fn, "__doc__", None)
    descriptor.__wrapped__ = fn
    surface = SurfaceSignature.from_callable(fn)
    descriptor.__signature__ = surface.signature
    return surface
