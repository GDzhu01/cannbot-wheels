# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Rounding modes and internal parsing shared by the DSL frontends."""


__all__ = ["RoundingMode"]

from enum import IntEnum


class RoundingMode(IntEnum):
    """Shared scalar, register, SIMT and Cube rounding modes.

    Values follow AscRoundingModeEnum in include/AscEnum/IR/AscEnums.td.
    Individual operations validate their supported subset.
    """

    RN = 0
    RNA = 1
    RD = 2
    RU = 3
    RZ = 4
    RO = 5
    NA = 6
    RH = 7


def _parse_rounding(value, *, operation: str, supported=None, allow_rint=False) -> RoundingMode:
    if isinstance(value, str):
        name = value.upper()
        if allow_rint and name == "RINT":
            name = "RN"
        try:
            value = RoundingMode[name]
        except KeyError as error:
            names = supported if supported is not None else tuple(RoundingMode)
            choices = ", ".join(mode.name for mode in names)
            from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT, f"{operation}: rounding must be one of {choices}"
            ) from error
    elif not isinstance(value, RoundingMode):
        from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"{operation}: rounding must be a RoundingMode or string")
    if supported is not None and value not in supported:
        choices = ", ".join(mode.name for mode in supported)
        from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            f"{operation}: {value.name} rounding is unsupported; rounding must be one of {choices}",
        )
    return value
