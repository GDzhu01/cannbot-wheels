# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Fixed-length device scalar arrays and their single SSA value caster."""

from __future__ import annotations

import cannbot_dsl._mlir.ir as ir
from cannbot_dsl._mlir.dialects import cannir

__all__ = ["Array"]


def _check_domain(*, require_context=False):
    from cannbot_dsl.core.frontend.call_context import current_call_context
    from cannbot_dsl.lang.vf import _current_vf_mode

    context = current_call_context()
    if (require_context and context is None) or (context is not None and context.domain != "device"):
        from cannbot_dsl.core.diag.diagnostics import CANNBotRuntimeError, DiagnosticCode

        raise CANNBotRuntimeError(
            DiagnosticCode.INVALID_ARGUMENT,
            "Array requires a device scalar @kernel or inline @jit context",
        )
    if _current_vf_mode() is not None:
        from cannbot_dsl.core.diag.diagnostics import CANNBotRuntimeError, DiagnosticCode

        raise CANNBotRuntimeError(
            DiagnosticCode.INVALID_ARGUMENT,
            "Array cannot be allocated, accessed or passed in SIMD VF or SIMT",
        )


def Array(dtype, length, *, init=None):
    """Create a fixed-length scalar array in a device kernel or inline helper.

    Assignment and helper arguments share storage. ``init`` is an optional
    list/tuple of Python constants with exactly ``length`` elements. Without
    it, storage is uninitialized: write each element before reading it.
    Indices must be in [0, length); dynamic indices are not bounds checked.
    References must not escape the scope of their storage allocation.
    """
    _check_domain(require_context=True)
    return _alloc_array(length, dtype=dtype, init=init)


def _alloc_array(length, *, dtype, init=None):
    """Emit ``cannir.alloc_array`` at the current insertion point.

    Args:
        length: Positive int — number of elements.
        dtype: A canonical ``cannbot_dsl.types.dtypes`` descriptor.
        init: Optional list/tuple of Python ints/floats; length must equal
              ``length``. When provided, codegen emits a C initializer list.

    Returns:
        ``!cannir.array<NxT>`` SSA value (auto-cast to :class:`_ArrayValue`).

    Must be called inside ``@kernel`` / ``@jit``.
    """
    _validate(length, dtype, init)
    from cannbot_dsl.core.contracts.elements import mlir_type_for_dtype

    elem_ty = mlir_type_for_dtype(dtype)
    arr_ty = cannir.ArrayType.get(length, elem_ty)
    if init is None:
        return cannir.alloc_array(arr_ty)
    return cannir.alloc_array(arr_ty, init_values=_build_init_attr(elem_ty, length, init))


@ir.register_value_caster(cannir.ArrayType.get_static_typeid())
class _ArrayValue(ir.Value):
    """SSA-level Array. Constructed by :func:`_alloc_array`.

    Exposes ``__getitem__`` / ``__setitem__`` for indexed access; ``length``
    and ``element_type`` properties read off the type.
    """

    def __getitem__(self, idx):
        from cannbot_dsl.core.contracts.elements import wrap_produced_scalar

        _check_domain()
        value = cannir.array_load(self, _to_index(idx, self.length))
        return wrap_produced_scalar(value, storage_type=self.element_type)

    def __setitem__(self, idx, val):
        _check_domain()
        index = _to_index(idx, self.length)
        cannir.array_store(_to_elem(val, self.element_type), self, index)

    def __iter__(self):
        from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

        raise CANNBotTypeError(
            DiagnosticCode.UNSUPPORTED_FEATURE,
            "Array does not support direct iteration; use an explicit index loop",
        )

    def __len__(self):
        return self.type.length

    @property
    def length(self):
        return self.type.length

    @property
    def element_type(self):
        return self.type.element_type


# ---------------------------------------------------------------------------
# Validation + attribute / coercion helpers (private)
# ---------------------------------------------------------------------------


def _validate(length, dtype, init):
    from cannbot_dsl.core.contracts.elements import trace_scalar_for_dtype

    try:
        trace_scalar_for_dtype(dtype)
    except TypeError as exc:
        from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"internal array dtype must be a canonical DType descriptor with an executable scalar wrapper, got {dtype!r}"
        ) from exc
    if isinstance(length, bool) or not isinstance(length, int):
        from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"internal array length must be a positive int, got {type(length).__name__}",
        )
    if length <= 0:
        from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            f"internal array length must be a positive int, got {length!r}",
        )
    if length > (1 << 63) - 1:
        from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            "internal array length exceeds the signed 64-bit ArrayType range",
        )
    if init is not None:
        if not isinstance(init, (list, tuple)):
            from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                f"internal array init must be list/tuple, got {type(init).__name__}",
            )
        if len(init) != length:
            from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE,
                f"internal array init length {len(init)} != length {length}",
            )


def _build_init_attr(elem_ty, length, init):
    """Build tensor<Nxstorage_type> without losing signedness or literal rules."""
    from cannbot_dsl.core.scalar_conversion import validate_literal

    attrs = []
    for value in init:
        validate_literal(value, elem_ty)
        if isinstance(elem_ty, ir.IntegerType):
            bits = int(value)
            # IntegerAttr's Python binding transports an int64_t, even for ui64.
            if elem_ty.width == 64 and elem_ty.is_unsigned and bits >= 1 << 63:
                bits -= 1 << 64
            attrs.append(ir.IntegerAttr.get(elem_ty, bits))
        else:
            attrs.append(ir.FloatAttr.get(elem_ty, float(value)))
    shaped = ir.RankedTensorType.get([length], elem_ty)
    return ir.DenseElementsAttr.get(attrs, type=shaped)


def _to_index(idx, length):
    """Adapt integer indices; reject Python constant bounds before emitting IR."""
    from cannbot_dsl.core.scalar_conversion import _index_value

    if type(idx) is int and not 0 <= idx < length:
        from cannbot_dsl.core.diag.diagnostics import CANNBotIndexError, DiagnosticCode

        raise CANNBotIndexError(DiagnosticCode.INVALID_ARGUMENT, f"static array index {idx} is outside [0, {length})")
    return _index_value(idx, target_type=ir.IndexType.get(), operation="Internal array index")


def _to_elem(val, elem_ty):
    """Coerce a canonical scalar wrapper or literal to array storage."""

    from cannbot_dsl.core.contracts.elements import coerce_scalar_to_storage

    return coerce_scalar_to_storage(val, elem_ty, path="Internal array value")
