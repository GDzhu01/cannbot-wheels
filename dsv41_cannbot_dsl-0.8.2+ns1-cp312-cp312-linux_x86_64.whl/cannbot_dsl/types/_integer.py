# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Internal fixed-width DSL integer SSA wrappers.

Python integer literals are contextual outside VF; inside VF they contribute
int32 when representable, otherwise int64, to common-type selection.
Dynamic integers with the same signedness use the wider operand dtype;
public explicit conversion uses ``dtypes.int32(value)`` or
``dtypes.uint32(value)``.  Concrete wrapper constructors are implementation
details used at scalar producer and lowering boundaries.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import cannbot_dsl._mlir.ir as ir
from cannbot_dsl._mlir.dialects import arith
from cannbot_dsl.core.diag.diagnostics import (
    TS101_INVALID_SCALAR_LITERAL,
    CANNBotTypeError,
    CANNBotValueError,
)
from cannbot_dsl.core.scalar_conversion import (
    _promote_integer_operands,
    cast_value,
    materialize_literal,
    require_same_dynamic_type,
)
from cannbot_dsl.core.utils.type_checks import is_exact_instance, is_exact_instance_of
from cannbot_dsl.types import dtypes as _dtypes

if TYPE_CHECKING:
    from cannbot_dsl.types.dtypes import DType


def _is_unsigned(value: object) -> bool:
    """Return the semantic signedness of an SSA wrapper or an MLIR type.

    MLIR's ``arith`` scalar operations require signless integer operands.  The
    public UInt wrappers therefore carry signedness as frontend information;
    tensor/vector element types can still use MLIR's ``uiN`` spelling.
    """

    if bool(getattr(value, "unsigned", False)):
        return True
    value_type = getattr(value, "type", value)
    return isinstance(value_type, ir.IntegerType) and value_type.is_unsigned


@ir.register_value_caster(ir.IntegerType.static_typeid)
class Integer(ir.Value):
    """An SSA integer whose arithmetic semantics come from its MLIR type."""

    _dtype: "DType"

    def __init__(self, value, *, loc=None, ip=None):
        del loc, ip
        if not isinstance(value, ir.Value) or not isinstance(value.type, ir.IntegerType):
            actual = getattr(value, "type", type(value).__name__)
            raise TypeError(f"Integer requires an integer SSA value, got {actual}")
        super().__init__(value)

    def __add__(self, other, *, loc=None, ip=None):
        return self._binary(other, arith.addi, arith.addi, operation="addition", loc=loc, ip=ip)

    def __sub__(self, other, *, loc=None, ip=None):
        return self._binary(other, arith.subi, arith.subi, operation="subtraction", loc=loc, ip=ip)

    def __mul__(self, other, *, loc=None, ip=None):
        return self._binary(other, arith.muli, arith.muli, operation="multiplication", loc=loc, ip=ip)

    def __truediv__(self, other, *, loc=None, ip=None):
        return self._true_divide(other, loc=loc, ip=ip)

    def __floordiv__(self, other, *, loc=None, ip=None):
        return self._floor_divmod(other, remainder=False, loc=loc, ip=ip)

    def __mod__(self, other, *, loc=None, ip=None):
        return self._floor_divmod(other, remainder=True, loc=loc, ip=ip)

    def _true_divide(self, other, *, reverse=False, loc=None, ip=None):
        from cannbot_dsl.types._float import Float32

        self._require_arithmetic("division")
        lhs, rhs = self._operands(other, operation="division", loc=loc, ip=ip)
        if reverse:
            lhs, rhs = rhs, lhs
        convert = arith.uitofp if _is_unsigned(self) else arith.sitofp
        target = ir.F32Type.get()
        lhs = convert(target, lhs, loc=loc, ip=ip)
        rhs = convert(target, rhs, loc=loc, ip=ip)
        return Float32(arith.divf(lhs, rhs, loc=loc, ip=ip))

    def _floor_divmod(self, other, *, remainder, reverse=False, loc=None, ip=None):
        self._require_arithmetic("floor division/remainder")
        lhs, rhs = self._operands(other, operation="floor division/remainder", loc=loc, ip=ip)
        if reverse:
            lhs, rhs = rhs, lhs
        wrapper = type(lhs)
        if _is_unsigned(self):
            op = arith.remui if remainder else arith.divui
            return self._computed(wrapper(op(lhs, rhs, loc=loc, ip=ip)), lhs, rhs)
        zero = materialize_literal(0, lhs.type, loc=loc, ip=ip)
        one = materialize_literal(1, lhs.type, loc=loc, ip=ip)
        rem = arith.remsi(lhs, rhs, loc=loc, ip=ip)
        nonzero = arith.cmpi(arith.CmpIPredicate.ne, rem, zero, loc=loc, ip=ip)
        rem_negative = arith.cmpi(arith.CmpIPredicate.slt, rem, zero, loc=loc, ip=ip)
        rhs_negative = arith.cmpi(arith.CmpIPredicate.slt, rhs, zero, loc=loc, ip=ip)
        different_signs = arith.xori(rem_negative, rhs_negative, loc=loc, ip=ip)
        fix = arith.andi(nonzero, different_signs, loc=loc, ip=ip)
        if remainder:
            correction = arith.select(fix, rhs, zero, loc=loc, ip=ip)
            return self._computed(wrapper(arith.addi(rem, correction, loc=loc, ip=ip)), lhs, rhs)
        quotient = arith.divsi(lhs, rhs, loc=loc, ip=ip)
        correction = arith.select(fix, one, zero, loc=loc, ip=ip)
        return self._computed(wrapper(arith.subi(quotient, correction, loc=loc, ip=ip)), lhs, rhs)

    def __and__(self, other, *, loc=None, ip=None):
        return self._binary(other, arith.andi, arith.andi, operation="bitwise and", loc=loc, ip=ip)

    def __or__(self, other, *, loc=None, ip=None):
        return self._binary(other, arith.ori, arith.ori, operation="bitwise or", loc=loc, ip=ip)

    def __rand__(self, other, *, loc=None, ip=None):
        return self.__and__(other, loc=loc, ip=ip)

    def __ror__(self, other, *, loc=None, ip=None):
        return self.__or__(other, loc=loc, ip=ip)

    def _shift(self, other, signed_op, unsigned_op, *, loc=None, ip=None):
        # MLIR shift counts must be smaller than the word width. Dynamic
        # counts retain that caller precondition; do not add hidden branches.
        if type(other) is int and not 0 <= other < self.type.width:
            raise ValueError("shift count must be in [0, integer width)")
        return self._binary(other, signed_op, unsigned_op, operation="shift", loc=loc, ip=ip)

    def __lshift__(self, other, *, loc=None, ip=None):
        return self._shift(other, arith.shli, arith.shli, loc=loc, ip=ip)

    def __rshift__(self, other, *, loc=None, ip=None):
        return self._shift(other, arith.shrsi, arith.shrui, loc=loc, ip=ip)

    def __xor__(self, other, *, loc=None, ip=None):
        if self.type.width == 1:
            if is_exact_instance(other, bool):
                other = materialize_literal(other, self.type, loc=loc, ip=ip)
            elif isinstance(other, ir.Value):
                require_same_dynamic_type(self, other, operation="boolean xor")
            else:
                raise TypeError("Boolean xor expects a bool literal or Boolean/i1 value")
        else:
            return self._binary(other, arith.xori, arith.xori, operation="xor", loc=loc, ip=ip)
        result = arith.xori(self, other, loc=loc, ip=ip)
        if self.type.width == 1:
            return Boolean(result, loc=loc, ip=ip)
        return type(self)(result, loc=loc, ip=ip)

    def __neg__(self, *, loc=None, ip=None):
        from cannbot_dsl.core.frontend.runtime.integer_policy import read_integer

        self = read_integer(self)
        self._require_arithmetic("negation")
        if _is_unsigned(self):
            raise TypeError("unsigned integers do not support unary negation")
        zero = materialize_literal(0, self.type, loc=loc, ip=ip)
        return self._computed(type(self)(arith.subi(zero, self, loc=loc, ip=ip)), self)

    def __invert__(self, *, loc=None, ip=None):
        from cannbot_dsl.core.frontend.runtime.integer_policy import read_integer

        self = read_integer(self)
        if self.type.width == 1:
            one = materialize_literal(True, self.type, loc=loc, ip=ip)
            return Boolean(arith.xori(self, one, loc=loc, ip=ip), loc=loc, ip=ip)
        all_ones = materialize_literal(
            (1 << self.type.width) - 1 if _is_unsigned(self) else -1,
            self.type,
            semantic_unsigned=_is_unsigned(self),
            loc=loc,
            ip=ip,
        )
        return self._computed(type(self)(arith.xori(self, all_ones, loc=loc, ip=ip)), self)

    def __lt__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpIPredicate.slt,
            arith.CmpIPredicate.ult,
            operation="less-than",
            loc=loc,
            ip=ip,
        )

    def __le__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpIPredicate.sle,
            arith.CmpIPredicate.ule,
            operation="less-than-or-equal",
            loc=loc,
            ip=ip,
        )

    def __gt__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpIPredicate.sgt,
            arith.CmpIPredicate.ugt,
            operation="greater-than",
            loc=loc,
            ip=ip,
        )

    def __ge__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpIPredicate.sge,
            arith.CmpIPredicate.uge,
            operation="greater-than-or-equal",
            loc=loc,
            ip=ip,
        )

    def __eq__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpIPredicate.eq,
            arith.CmpIPredicate.eq,
            operation="equality",
            loc=loc,
            ip=ip,
        )

    def __ne__(self, other, *, loc=None, ip=None):
        return self._compare(
            other,
            arith.CmpIPredicate.ne,
            arith.CmpIPredicate.ne,
            operation="inequality",
            loc=loc,
            ip=ip,
        )

    def __radd__(self, other, *, loc=None, ip=None):
        return self.__add__(other, loc=loc, ip=ip)

    def __rsub__(self, other, *, loc=None, ip=None):
        return self._reverse_binary(other, arith.subi, arith.subi, operation="subtraction", loc=loc, ip=ip)

    def __rmul__(self, other, *, loc=None, ip=None):
        return self.__mul__(other, loc=loc, ip=ip)

    def __rtruediv__(self, other, *, loc=None, ip=None):
        return self._true_divide(other, reverse=True, loc=loc, ip=ip)

    def __rfloordiv__(self, other, *, loc=None, ip=None):
        return self._floor_divmod(other, remainder=False, reverse=True, loc=loc, ip=ip)

    def __rmod__(self, other, *, loc=None, ip=None):
        return self._floor_divmod(other, remainder=True, reverse=True, loc=loc, ip=ip)

    def __rxor__(self, other, *, loc=None, ip=None):
        return self.__xor__(other, loc=loc, ip=ip)

    def __hash__(self):
        return super().__hash__()

    def __bool__(self):
        raise TypeError(
            "Cannot evaluate truthiness of a dynamic DSL integer/boolean "
            f"(type={self.type}). This usually means the expression appears "
            "outside a @host/@kernel/@jit AST frontend boundary "
            "(e.g. inside a helper method on a plain Python class, `assert`, "
            "or an explicit `bool()` call). Move the control flow into a "
            "@host/@kernel/@jit function. Python conditional "
            "expressions (`x if predicate else y`) are lowered lazily there."
        )

    def __str__(self):
        return f"Integer(type={self.type}, value={super().__str__()})"

    def __repr__(self):
        return self.__str__()

    @property
    def dtype(self) -> "DType":
        """Return the canonical semantic dtype of this concrete wrapper."""

        return type(self)._dtype

    def _require_arithmetic(self, operation: str) -> None:
        if self.type.width == 1:
            raise TypeError(
                f"Boolean/i1 does not support integer {operation}; use boolean operators or an explicit integer cast"
            )

    @staticmethod
    def _computed(result, *operands):
        from cannbot_dsl.core.frontend.runtime.integer_policy import computed

        return computed(result, *operands)

    def _operands(self, other, *, operation, loc=None, ip=None):
        return _promote_integer_operands(self, other, operation=operation, loc=loc, ip=ip)

    def _binary(self, other, signed_op, unsigned_op, *, operation, loc=None, ip=None):
        self._require_arithmetic(operation)
        lhs, other = self._operands(other, operation=operation, loc=loc, ip=ip)
        operation_builder = unsigned_op if _is_unsigned(self) else signed_op
        result = operation_builder(lhs, other, loc=loc, ip=ip)
        return self._computed(type(lhs)(result, loc=loc, ip=ip), lhs, other)

    def _reverse_binary(self, other, signed_op, unsigned_op, *, operation, loc=None, ip=None):
        self._require_arithmetic(operation)
        lhs, other = self._operands(other, operation=operation, loc=loc, ip=ip)
        operation_builder = unsigned_op if _is_unsigned(self) else signed_op
        result = operation_builder(other, lhs, loc=loc, ip=ip)
        return self._computed(type(lhs)(result, loc=loc, ip=ip), lhs, other)

    def _compare(
        self,
        other,
        signed_predicate,
        unsigned_predicate,
        *,
        operation,
        loc=None,
        ip=None,
    ):
        lhs = self
        if self.type.width == 1 and is_exact_instance_of(other, (bool, int)):
            if is_exact_instance(other, int) and other not in {0, 1}:
                raise CANNBotValueError(
                    TS101_INVALID_SCALAR_LITERAL,
                    f"Boolean comparison literal must be True, False, 0, or 1; got {other}.",
                    phase="type-system",
                    path="Boolean comparison literal",
                    hint=("Compare a Boolean value only with True, False, 0, or 1."),
                )
            other = arith.constant(self.type, int(other), loc=loc, ip=ip)
        elif self.type.width == 1 and not isinstance(other, ir.Value):
            raise CANNBotTypeError(
                TS101_INVALID_SCALAR_LITERAL,
                f"Boolean comparison requires True, False, 0, 1, or another Boolean value; got {type(other).__name__}.",
                phase="type-system",
                path="Boolean comparison literal",
                hint=("Compare a Boolean value only with True, False, 0, 1, or a Boolean DSL value."),
            )
        elif self.type.width == 1:
            require_same_dynamic_type(self, other, operation=operation)
        else:
            lhs, other = self._operands(other, operation=operation, loc=loc, ip=ip)
        predicate = unsigned_predicate if _is_unsigned(self) else signed_predicate
        return Boolean(
            arith.cmpi(predicate, lhs, other, loc=loc, ip=ip),
            loc=loc,
            ip=ip,
        )


class _ConcreteInteger(Integer):
    width: int
    unsigned: bool = False

    def __init__(self, value, *, loc=None, ip=None):
        original = value
        target_type = type(self).scalar_mlir_type()
        if is_exact_instance(value, int):
            value = materialize_literal(
                value,
                target_type,
                semantic_unsigned=type(self).unsigned,
                loc=loc,
                ip=ip,
            )
        elif isinstance(value, ir.Value):
            value = cast_value(
                value,
                target_type,
                source_unsigned=_is_unsigned(value),
                target_unsigned=type(self).unsigned,
                loc=loc,
                ip=ip,
            )
        else:
            raise TypeError(
                f"{type(self).__name__} expects an int literal or numeric SSA value, got {type(value).__name__}"
            )
        super().__init__(value, loc=loc, ip=ip)
        from cannbot_dsl.core.frontend.runtime.integer_policy import copy_policy, mark

        if isinstance(original, Integer) and hasattr(original, "_integer_policy"):
            copy_policy(self, original)
        else:
            is_literal = isinstance(original, int) and not isinstance(original, bool)
            mark(
                self,
                origin="default" if isinstance(self, Int64) else "fixed",
                constant=is_literal,
                literal=original if is_literal else None,
            )

    @classmethod
    def mlir_type(cls) -> ir.IntegerType:
        if cls.unsigned:
            return ir.IntegerType.get_unsigned(cls.width)
        return ir.IntegerType.get_signless(cls.width)

    @classmethod
    def scalar_mlir_type(cls) -> ir.IntegerType:
        """The signless form required by scalar ``arith`` operations."""

        return ir.IntegerType.get_signless(cls.width)


class Int64(_ConcreteInteger):
    width = 64
    _dtype = _dtypes.int64


class UInt64(_ConcreteInteger):
    width = 64
    unsigned = True
    _dtype = _dtypes.uint64


class Int32(_ConcreteInteger):
    width = 32
    _dtype = _dtypes.int32


class UInt32(_ConcreteInteger):
    width = 32
    unsigned = True
    _dtype = _dtypes.uint32


class Int16(_ConcreteInteger):
    width = 16
    _dtype = _dtypes.int16


class UInt16(_ConcreteInteger):
    width = 16
    unsigned = True
    _dtype = _dtypes.uint16


class Int8(_ConcreteInteger):
    width = 8
    _dtype = _dtypes.int8


class UInt8(_ConcreteInteger):
    width = 8
    unsigned = True
    _dtype = _dtypes.uint8


class Boolean(Integer):
    width = 1
    _dtype = _dtypes.bool

    def __init__(self, value, *, loc=None, ip=None):
        target_type = self.mlir_type()
        if is_exact_instance(value, bool):
            value = materialize_literal(value, target_type, loc=loc, ip=ip)
        elif isinstance(value, ir.Value):
            if value.type != target_type:
                raise TypeError(
                    f"Boolean requires an i1 SSA value, got {value.type}; form a comparison or cast explicitly"
                )
        else:
            raise TypeError(f"Boolean expects a bool literal or i1 SSA value, got {type(value).__name__}")
        super().__init__(value, loc=loc, ip=ip)

    @staticmethod
    def mlir_type() -> ir.IntegerType:
        return ir.IntegerType.get_signless(1)


__all__: list[str] = []
