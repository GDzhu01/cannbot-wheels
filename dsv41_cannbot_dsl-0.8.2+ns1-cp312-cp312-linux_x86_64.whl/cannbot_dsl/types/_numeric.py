# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Fixed-format numeric SSA wrappers (internal).

Aggregates the former ``cannbotdsl/float.py`` and ``cannbotdsl/integer.py``,
both of which already described themselves as internal. They are kept as
separate source files (``_float`` / ``_integer``) purely because merging two
modules that each open with ``from __future__ import annotations`` is not
textually possible; this module is the single import point.
"""

from cannbot_dsl.types._float import (  # noqa: F401
    annotations,
    TYPE_CHECKING,
    arith,
    _dtypes,
    cast_value,
    is_float_type,
    materialize_literal,
    require_same_dynamic_type,
    Float,
    _ConcreteFloat,
    Float16,
    Float32,
    Float64,
    BFloat16,
)

from cannbot_dsl.types._integer import (  # noqa: F401
    annotations,
    TYPE_CHECKING,
    arith,
    _dtypes,
    cast_value,
    materialize_literal,
    require_same_dynamic_type,
    CANNBotTypeError,
    CANNBotValueError,
    TS101_INVALID_SCALAR_LITERAL,
    _is_unsigned,
    Integer,
    _ConcreteInteger,
    Int64,
    UInt64,
    Int32,
    UInt32,
    Int16,
    UInt16,
    Int8,
    UInt8,
    Boolean,
)

from cannbot_dsl.types._short_vector import ShortVector  # noqa: F401
