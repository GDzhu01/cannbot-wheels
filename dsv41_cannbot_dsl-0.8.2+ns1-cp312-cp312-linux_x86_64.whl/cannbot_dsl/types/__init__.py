# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Public types and the single Tensor/Layout caster initialization boundary."""

from cannbot_dsl.types.scalar import ScalarValue
from cannbot_dsl.types import dtypes
from cannbot_dsl.types.dtypes import DType
from cannbot_dsl.types.rounding import RoundingMode
from cannbot_dsl.types import _tensor

# Register wrappers and callbacks before loading aggregate containers. The two
# public classes are imported only when their callbacks run; registration does
# not require tensor definitions. Ordinary imports use Python's module cache.
class _ValueCasterRegistration:
    def _invoke_value_casters(self):
        getattr(_tensor, "_register_value_casters")()

    _register_value_casters = _invoke_value_casters

    def register(self):
        self._register_value_casters()


_ValueCasterRegistration().register()

from cannbot_dsl.types._array import Array

from cannbot_dsl.types.tensor_list import (
    TensorList,
)
from cannbot_dsl.types.datastruct import (
    CArray,
    StructField,
    StructRef,
    StructSchema,
)

# Public scalar types and aggregate containers. Dtype descriptors are
# namespaced under dtypes. The datastruct package attribute is its submodule;
# the decorator is exported from the root package and its definition module.
__all__ = [
    "ScalarValue",
    "Array",
    "CArray",
    "StructField",
    "StructRef",
    "StructSchema",
    "DType",
    "TensorList",
    "dtypes",
    "RoundingMode",
]
