"""AOT collection, source discovery and atomic publication shared by builders."""
import ast
from contextlib import ExitStack, contextmanager
from contextvars import ContextVar
from functools import wraps
import ctypes
import errno
import hashlib
import importlib
import importlib.util
import inspect
import json
import os
from pathlib import Path
import re
import sys
import threading
import types
from typing import Callable, NamedTuple


class CompilationError(RuntimeError):
    """An invalid compilation observation or collection request."""

COLLECTOR = ContextVar('cannbotdsl_compilation_collector', default=None)
_OBSERVERS = ContextVar('cannbotdsl_compile_observers', default=())
COLLECTION_OWNER = None


def current_collection():
    if COLLECTION_OWNER is not None and COLLECTION_OWNER != (os.getpid(), threading.get_ident()):
        raise CompilationError('compilation collection does not support concurrent threads or fork')
    return COLLECTOR.get()

@contextmanager
def observe_compilations(callback, *, aot_only=False):
    """Observe successful compilation artifacts within this context.

    callback(artifact, source_function) runs after collection records
    the artifact. Observers must not take ownership of the artifact. aot_only
    rejects direct run/JIT requests before compiling. Nested scopes all observe.
    """
    token = _OBSERVERS.set((*_OBSERVERS.get(), (callback, aot_only)))
    try:
        yield
    finally:
        _OBSERVERS.reset(token)


def observe(function):
    @wraps(function)
    def wrapped(fn, call_args, call_kwargs, **kwargs):
        if COLLECTION_OWNER is not None and COLLECTION_OWNER != (os.getpid(), threading.get_ident()):
            raise CompilationError("compilation collection does not support concurrent threads or fork")
        collector = COLLECTOR.get()
        if collector is not None and not kwargs.get('aot', False):
            raise CompilationError("collection requires compile(); direct run/JIT export is unsupported")
        observers = _OBSERVERS.get()
        if any(aot_only for _, aot_only in observers) and not kwargs.get('aot', False):
            raise CompilationError("compilation observer requires explicit compile()")
        artifact = function(fn, call_args, call_kwargs, **kwargs)
        if collector is not None:
            recorded = False
            try:
                collector.record(artifact, fn)
                recorded = True
            finally:
                if not recorded and artifact.owns_so and artifact.so_path:
                    from cannbot_dsl.core.compiler.function import _remove_owned_artifact

                    _remove_owned_artifact(artifact.so_path)
        for callback, _ in observers:
            callback(artifact, fn)
        return artifact
    return wrapped


class Mark(NamedTuple):
    """包构建器注入的导出标记：AST 识别名、入口属性与收集回调包装。

    ast_names：源码扫描识别的调用/装饰器名（含 import 别名解析）；
    attribute：入口对象上携带导出名（str）的属性；wrap：把入口包装为
    收集期零参回调。Mark 不预置任何标记，具体约定全部由构建器注入。
    """

    ast_names: frozenset
    attribute: str
    wrap: Callable[[object], Callable[[], object]]


def module_identity(name):
    """Stable module identity, independent of an isolated discovery session."""
    return re.sub(r"^_cannbot_collect_[0-9a-f]+\.", "", name)


def _name(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', value) or value in ('.', '..'):
        raise ValueError(f'invalid Native package/task name: {value!r}')
    return value


def _declares_registration(source, markers):
    """Find explicit export calls without executing unrelated Python files.

    Registration may be inline in an operator module or in a separate file.
    Recognize direct/qualified calls, import aliases and simple alias assignments;
    actual callable tags are checked after import, never inferred from the AST.
    markers：'export' 加上各注入 Mark 的 ast_names。
    """
    tree = ast.parse(source.read_bytes(), filename=str(source))
    names = set(markers)
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            names.update(alias.asname or alias.name for alias in node.names if alias.name in markers)

    def is_register(node):
        return (isinstance(node, ast.Name) and node.id in names) or (
            isinstance(node, ast.Attribute) and node.attr in markers
        )

    changed = True
    while changed:
        changed = False
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign) and is_register(node.value):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id not in names:
                        names.add(target.id)
                        changed = True
    return any(isinstance(node, ast.Call) and is_register(node.func)
               for node in ast.walk(tree))


@contextmanager
def discover(*, collectors, operators=None, pattern="*.py", marks=(), exclude_dirs=()):
    """Keep source modules alive until all collected requests have been compiled.

    默认识别 @export 标记的编译任务；marks 是构建器注入的导出标记
    （Mark），exclude_dirs 是扫描时跳过的相对路径中间目录名。
    同名 export 与注入入口组成一个任务，先执行 export；同类重名仍报错。
    """
    if not isinstance(pattern, str) or not pattern.endswith(".py") or "/" in pattern or "\\" in pattern:
        raise ValueError("pattern must be a Python filename pattern, e.g. collect.py")
    root = Path(collectors).resolve(strict=True)
    if not root.is_dir():
        raise ValueError('collectors must be a directory')
    tasks, exports = {}, {}
    markers = {'export'}
    for mark in marks:
        markers |= set(mark.ast_names)
    namespace = '_cannbot_collect_' + hashlib.sha256(os.urandom(32)).hexdigest()[:16]
    before = set(sys.modules)
    try:
        init = root / '__init__.py'
        if init.exists():
            spec = importlib.util.spec_from_file_location(namespace, init, submodule_search_locations=[str(root)])
            module = importlib.util.module_from_spec(spec)
            sys.modules[namespace] = module
            spec.loader.exec_module(module)
        else:
            module = types.ModuleType(namespace)
            module.__path__ = [str(root)]
            sys.modules[namespace] = module
        modules = [module]
        for source in sorted(root.rglob(pattern)):
            relative = source.relative_to(root)
            if any(part in exclude_dirs for part in relative.parts[:-1]):
                continue
            if any(part.startswith('.') or part == '__pycache__' for part in relative.parts):
                continue
            try:
                declared = _declares_registration(source, markers)
            except SyntaxError as exc:
                # Preserve SyntaxError location fields and the original cause.
                # Skipping could silently omit an operator from the export.
                message = (f'Native collector discovery failed while parsing {source}; '
                           f'scan root: {root}, pattern: {pattern!r}: {exc.msg}')
                raise SyntaxError(message, (exc.filename, exc.lineno, exc.offset,
                                           exc.text, exc.end_lineno, exc.end_offset)) from exc
            if not declared:
                continue
            parts = list(relative.with_suffix('').parts)
            if parts[-1] == '__init__':
                parts.pop()
            if not parts:
                continue
            if not all(part.isidentifier() for part in parts):
                raise ValueError(f'collector path is not a Python module: {relative}')
            modules.append(importlib.import_module(namespace + '.' + '.'.join(parts)))
        origins = {}
        for module in modules:
            for function in vars(module).values():
                marked = False
                for mark in marks:
                    exported_name = getattr(function, mark.attribute, None)
                    if isinstance(exported_name, str):
                        if exported_name in tasks and origins.get(exported_name) is not function:
                            raise ValueError(f"duplicate exported name: {exported_name}")
                        origins[exported_name] = function
                        tasks[exported_name] = mark.wrap(function)
                        marked = True
                        break
                if marked:
                    continue
                if not inspect.isfunction(function) or function.__module__ != module.__name__:
                    continue
                task = getattr(function, '__cannbot_aot_export__', None)
                if task is None:
                    continue
                if task in exports and exports[task] is not function:
                    raise ValueError(f'duplicate Native task: {task}')
                exports[task] = function
        for task, callback in exports.items():
            if task in tasks:
                def paired(callback=callback, entry=tasks[task]):
                    callback()
                    return entry()
                tasks[task] = paired
            else:
                tasks[task] = callback
        selected = sorted(tasks) if operators is None else list(operators)
        if not selected or len(set(selected)) != len(selected) or any(task not in tasks for task in selected):
            raise ValueError('empty, duplicate or unknown Native task selection')
        yield {task: tasks[task] for task in selected}
    finally:
        for module_name in set(sys.modules) - before:
            if module_name == namespace or module_name.startswith(namespace + '.'):
                sys.modules.pop(module_name, None)


_session_lock = threading.Lock()

def _json(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True) + '\n').encode()


class Collection:
    """One source-collection session and the lifetime of its compile-factory handles."""
    def __init__(self, target):
        if target not in ('dav-2201', 'dav-3510'):
            raise ValueError('compilation collection requires dav-2201 or dav-3510 target')
        self.target = target
        self.task = 'default'
        self.records, self.tasks = {}, {}
        self._extensions = {}
        self._cleanups = ExitStack()
        self._ready = False
        self._closed = False
        self._thread = threading.get_ident()
        self._pid = os.getpid()

    @property
    def task(self):
        return self._task

    @task.setter
    def task(self, value):
        if not isinstance(value, str) or not value or value in ('.', '..') or any(c in value for c in '/\\\x00'):
            raise ValueError('operator name must be a directory component')
        self._task = value

    def close(self):
        """Release collected temporary artifacts after publication; safe to call again."""
        self._ready = False
        self._closed = True
        try:
            self._cleanups.close()
        finally:
            self._extensions.clear()

    def extension(self, name, create):
        """Return session-local state owned by a package-builder extension."""
        if self._closed:
            raise RuntimeError("compilation collection is closed")
        if name not in self._extensions:
            self._extensions[name] = create()
        return self._extensions[name]

    def add_cleanup(self, callback):
        """Run a builder's cleanup when the collection is closed."""
        if self._closed:
            raise RuntimeError("compilation collection is closed")
        self._cleanups.callback(callback)

    def add_task_metadata(self, name, value):
        """Append JSON metadata to the current task, preserving core fields.

        Extensions own the meaning of their fields; factory_bindings entries
        must be objects with a nonempty string binary_key for artifact matching.
        Freeze values immediately;
        repeated equal entries are stored once, as with artifact references.
        """
        if self._closed:
            raise RuntimeError("compilation collection is closed")
        if not isinstance(name, str) or not name or name in {
            'name', 'requests', 'artifacts', 'sources', 'variants'
        }:
            raise ValueError("reserved or invalid task metadata field")
        value = json.loads(_json(value))
        if name == 'factory_bindings':
            if not isinstance(value, dict):
                raise ValueError('factory_bindings entry must be an object')
            if not isinstance(value.get('binary_key'), str) or not value['binary_key']:
                raise ValueError('factory_bindings.binary_key must be a nonempty string')
        values = self.tasks[self.task].setdefault(name, [])
        if value not in values:
            values.append(value)


@contextmanager
def collect(session):
    """Collect explicit compile requests; no changes to user return values."""
    global COLLECTION_OWNER
    if not _session_lock.acquire(blocking=False):
        raise RuntimeError('nested/concurrent compilation collection is unsupported')
    target = session.target
    token = None
    previous_target = os.environ.get("CANNBOTDSL_NPU_ARCH")
    try:
        token = COLLECTOR.set(session)
        os.environ["CANNBOTDSL_NPU_ARCH"] = target
        COLLECTION_OWNER = (os.getpid(), threading.get_ident())
        yield session
        session._ready = not session._closed
    finally:
        COLLECTION_OWNER = None
        if previous_target is None:
            os.environ.pop("CANNBOTDSL_NPU_ARCH", None)
        else:
            os.environ["CANNBOTDSL_NPU_ARCH"] = previous_target
        if token is not None:
            COLLECTOR.reset(token)
        _session_lock.release()
        if not session._ready:
            session.close()


def publish_path(source, destination):
    """Linux renameat2 prevents even an empty destination from being replaced."""
    libc = ctypes.CDLL(None, use_errno=True)
    rename = getattr(libc, "renameat2", None)
    if rename is None:
        raise OSError(errno.ENOSYS, "atomic non-replacing package publication requires renameat2")
    rename.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
    rename.restype = ctypes.c_int
    if rename(-100, os.fsencode(source), -100, os.fsencode(destination), 1):
        code = ctypes.get_errno()
        raise OSError(code, os.strerror(code), os.fspath(destination))


def host_source(value):
    """Return the source function of a DSL host callable, or None."""
    from cannbot_dsl.lang.host import HostFunction, _BoundHostMethod
    if isinstance(value, _BoundHostMethod):
        value = value._host_function
    return value.fn if isinstance(value, HostFunction) else None
