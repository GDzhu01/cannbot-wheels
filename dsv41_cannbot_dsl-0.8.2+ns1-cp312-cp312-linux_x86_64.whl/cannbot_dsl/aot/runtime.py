# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Installed Native artifacts, resolved by the independent Native binary key.

No dependency on the publication package: the publisher supplies a scoped observer.
Directory AOT files are snapshotted before mapping; OPP libraries retain their installed paths.

Resolution is fail-closed for registered resources: prefer falls back only when
no resources/variant apply or the schema/format/ABI is incompatible. Missing
registered manifests, malformed data, checksum failures and conflicting binaries
raise NativeBinaryError even in prefer mode. Discovery checks all registered
manifests, so a broken root can also block lookups for other operators. Off mode
bypasses resource discovery and loading.
"""

from collections import Counter, deque
from dataclasses import dataclass
import atexit
import configparser
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import stat
import sys
import tempfile
import threading

from cannbot_dsl.aot.collection import (
    CompilationError as NativeBinaryError,
    COLLECTOR,
    observe as observe,
    observe_compilations as observe_compilations,
)


def __getattr__(name):
    if name == "COLLECTION_OWNER":
        from cannbot_dsl.aot import collection

        return collection.COLLECTION_OWNER
    raise AttributeError(name)


SCHEMA = 3
_lock = threading.RLock()
_catalog = None
_registered_directories = set()
_private = None
_snapshots = {}
_opp_images = {}
_EVENT_LIMIT = 1024
_events = deque(maxlen=_EVENT_LIMIT)
_event_counts = Counter()
_events_dropped = 0
_DIGEST = re.compile(r"[0-9a-f]{64}\Z")


def _json(data):
    if len(data) > 16 * 1024 * 1024:
        raise NativeBinaryError("Native package JSON exceeds 16 MiB")

    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise NativeBinaryError(f"duplicate Native JSON key: {key}")
            result[key] = value
        return result

    try:
        return json.loads(data, object_pairs_hook=pairs)
    except (ValueError, RecursionError) as exc:
        raise NativeBinaryError("invalid Native package JSON") from exc


def _relative_path(relative):
    if not isinstance(relative, str):
        raise NativeBinaryError("invalid Native package path")
    path = PurePosixPath(relative)
    if not relative or path.is_absolute() or any(p in ("..", ".", "") for p in relative.split("/")) or "\\" in relative:
        raise NativeBinaryError("invalid Native package path")
    return path


def _read(root, relative, limit=256 * 1024 * 1024):
    path = _relative_path(relative)
    descriptors = []
    flags = os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW
    try:
        root = Path(root).absolute()
        parent = os.open(root.anchor, flags | os.O_DIRECTORY)
        descriptors.append(parent)
        for part in (*root.parts[1:], *path.parts[:-1]):
            parent = os.open(part, flags | os.O_DIRECTORY, dir_fd=parent)
            descriptors.append(parent)
        fd = os.open(path.name, flags | os.O_NONBLOCK, dir_fd=parent)
        descriptors.append(fd)
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
            raise NativeBinaryError("Native package file type/size is unsupported")
        chunks, count = [], 0
        while True:
            data = os.read(fd, min(1024 * 1024, limit - count + 1))
            if not data:
                break
            count += len(data)
            if count > limit:
                raise NativeBinaryError("Native package file exceeds size limit")
            chunks.append(data)
        after = os.fstat(fd)
        before_state = (before.st_size, before.st_mtime_ns, before.st_ctime_ns)
        after_state = (after.st_size, after.st_mtime_ns, after.st_ctime_ns)
        if before_state != after_state:
            raise NativeBinaryError("Native package changed while reading")
        return b"".join(chunks)
    except OSError as exc:
        raise NativeBinaryError(f"cannot read Native package file without symlinks: {relative}") from exc
    finally:
        for fd in reversed(descriptors):
            os.close(fd)


def event(kind, **fields):
    """Atomically refresh complete counts and the most recent bounded details."""
    global _events_dropped
    path = os.environ.get("CANNBOTDSL_NATIVE_BINARY_REPORT")
    if not path:
        return
    with _lock:
        _event_counts[kind] += 1
        if len(_events) == _events.maxlen:
            _events_dropped += 1
        _events.append(dict(event=kind, **fields))
        destination = Path(path).absolute()
        destination.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix=".native-report-", dir=destination.parent)
        try:
            with os.fdopen(fd, "w") as stream:
                json.dump(
                    {"counts": dict(_event_counts), "events": list(_events), "events_dropped": _events_dropped},
                    stream,
                    indent=2,
                )
            os.replace(name, destination)
        finally:
            if os.path.exists(name):
                os.unlink(name)


def mode():
    value = os.environ.get("CANNBOTDSL_NATIVE_BINARY_MODE", "prefer")
    if value not in ("prefer", "require", "off"):
        raise NativeBinaryError(f"invalid CANNBOTDSL_NATIVE_BINARY_MODE: {value}")
    return value


def enabled():
    if COLLECTOR.get() is not None or mode() == "require":
        return True
    if mode() != "prefer":
        return False
    try:
        return bool(_discover()) or bool(_opp_roots())
    except (KeyError, TypeError, ValueError, OSError, AttributeError) as exc:
        raise NativeBinaryError("invalid installed Native package") from exc


def register_directory(path):
    """Register a Native artifact directory containing manifest.json.

    Accept a string or PathLike, relative to the current working directory or
    absolute. Registration is lazy: no manifest or binary is read here.
    Repeated registration is inert; a new directory invalidates cached misses.
    Resources must be ordinary filesystem files, not ZIP members or symlinks.
    """
    try:
        value = os.fspath(path)
        if not isinstance(value, str) or not value or "\x00" in value:
            raise ValueError("expected a nonempty filesystem path")
        # Do not resolve symlinks: discovery must validate the original path.
        directory = Path(os.path.abspath(value))
    except (TypeError, ValueError, OSError) as exc:
        raise NativeBinaryError("invalid Native directory path") from exc
    global _catalog
    with _lock:
        if directory not in _registered_directories:
            _registered_directories.add(directory)
            _catalog = None


def _discover():
    global _catalog
    with _lock:
        if _catalog is not None:
            return _catalog
        catalog = {}
        for root in sorted(_registered_directories):
            manifest_bytes = _read(root, "manifest.json", 16 * 1024 * 1024)
            manifest = _json(manifest_bytes)
            from cannbot_dsl.core.compiler.binary_key import BINARY_KEY_SCHEMA
            from cannbot_dsl.core.compiler.abi import HOST_ABI_VERSION

            if (
                manifest.get("schema_version") != SCHEMA
                or manifest.get("binary_key_schema") != BINARY_KEY_SCHEMA
                or manifest.get("host_abi_version") != HOST_ABI_VERSION
            ):
                event("incompatible", reason="package_version")
                continue

            def installed_path(relative):
                _relative_path(relative)
                return relative

            manifest = dict(
                manifest,
                files={installed_path(name): digest for name, digest in manifest["files"].items()},
                index=installed_path(manifest["index"]),
            )
            files = manifest["files"]
            index_path = manifest["index"]
            index_bytes = _read(root, index_path, 16 * 1024 * 1024)
            if hashlib.sha256(index_bytes).hexdigest() != files[index_path]:
                raise NativeBinaryError("Native index checksum mismatch")
            entries = _json(index_bytes)
            if not isinstance(entries, dict) or len(entries) > 65536:
                raise NativeBinaryError("invalid Native index")
            for key, record in entries.items():
                descriptor_path = installed_path(record["descriptor"])
                descriptor_bytes = _read(root, descriptor_path, 16 * 1024 * 1024)
                if hashlib.sha256(descriptor_bytes).hexdigest() != files[descriptor_path]:
                    raise NativeBinaryError("Native descriptor checksum mismatch")
                record = _json(descriptor_bytes)
                if record["binary_key"] != key or record["binary_key_schema"] != BINARY_KEY_SCHEMA:
                    raise NativeBinaryError("Native descriptor binary key mismatch")
                if record["target"] != manifest["target"]:
                    raise NativeBinaryError("Native descriptor target mismatch")
                record = dict(record, **{field: installed_path(record[field]) for field in ("binary", "sidecar")})
                if not _DIGEST.fullmatch(key):
                    raise NativeBinaryError("invalid Native binary key")
                if record["binary"] not in files or record["sidecar"] not in files:
                    raise NativeBinaryError("unlisted Native artifact")
                catalog.setdefault(key, []).append((root, manifest, record))
        _catalog = catalog
        return catalog


@dataclass(frozen=True)
class NativeHit:
    so_path: str
    symbol_name: str
    host_abi_version: int
    content_key: str
    format_version_tag: str
    resource_roots: tuple[str, ...] | None = None


def _snapshot(binary, identity, *, sidecar=None):
    """Keep an immutable process-owned image, with a sidecar for directory AOT."""
    global _private
    with _lock:
        path = _snapshots.get(identity)
        if path is None:
            if _private is None:
                _private = tempfile.TemporaryDirectory(prefix="cannbotdsl-native-")
                atexit.register(_private.cleanup)
            directory = Path(_private.name) / hashlib.sha256(repr(identity).encode()).hexdigest()
            directory.mkdir(parents=True, exist_ok=True)
            image = directory / "provider.so"
            image.write_bytes(binary)
            if sidecar is not None:
                Path(str(image) + ".meta.json").write_bytes(sidecar)
            path = _snapshots[identity] = str(image)
        return path


def _resolve(key, contract, target):
    candidates = [item for item in _discover().get(key, ()) if item[1]["target"] == target]
    if not candidates:
        return None
    from cannbot_dsl.core.compiler import metadata
    from cannbot_dsl.core.compiler.binary_key import host_platform
    from cannbot_dsl.core.contracts.codec import contract_digest

    payload = None
    semantic = None
    chosen = None
    for root, manifest, record in candidates:
        incompatible_platform = record["host_platform"] != host_platform()
        incompatible_python = record["python_abi"] not in (None, sys.implementation.cache_tag)
        if incompatible_platform or incompatible_python:
            event("incompatible", reason="host_abi", key=key)
            continue
        binary = _read(root, record["binary"])
        sidecar = _read(root, record["sidecar"], 16 * 1024 * 1024)
        for name, data in ((record["binary"], binary), (record["sidecar"], sidecar)):
            if hashlib.sha256(data).hexdigest() != manifest["files"][name]:
                raise NativeBinaryError("Native artifact checksum mismatch")
        info = _json(sidecar)
        if info.get("version") != metadata.SIDECAR_VERSION:
            event("incompatible", reason="sidecar_version", key=key)
            continue
        symbol, actual, abi, digest, content_key, fmt = metadata.parse_metadata(info)
        if (
            content_key != record["build_provenance"]["cache_key"]
            or fmt != record["build_provenance"]["cache_format_tag"]
            or digest != hashlib.sha256(binary).hexdigest()
            or contract_digest(actual) != contract_digest(contract)
            or record["key_inputs"]["call_contract_sha256"] != contract_digest(actual)
        ):
            raise NativeBinaryError("Native artifact does not match compilation request")
        current = (binary, symbol, abi, contract_digest(actual), record["python_abi"])
        if semantic is not None and semantic != current:
            raise NativeBinaryError("conflicting installed Native artifacts for binary key")
        semantic = current
        payload, chosen = (binary, sidecar), (symbol, abi, content_key, fmt)
    if payload is None:
        return None
    identity = (key, hashlib.sha256(payload[0]).hexdigest(), hashlib.sha256(payload[1]).hexdigest())
    return NativeHit(_snapshot(payload[0], identity, sidecar=payload[1]), *chosen)


def lookup(key, contract, target, *, bypass=None):
    active = COLLECTOR.get()
    if active is not None:
        if target != active.target:
            raise NativeBinaryError("collection target differs from effective compiler target")
        if bypass is not None or key is None:
            raise NativeBinaryError(f"cannot collect non-persistent compilation: {bypass or 'key_error'}")
        return None
    policy = mode()
    if policy == "off":
        return None
    if key is None or bypass is not None:
        reason = bypass or "key_error"
        event("installed_miss", reason=reason)
        if policy == "require":
            raise NativeBinaryError(f"Native binary required: {reason}")
        return None
    try:
        hit = _resolve(key, contract, target)
        if hit is None:
            hit = _resolve_opp(key, contract, target, _opp_roots())
    except (KeyError, TypeError, ValueError, OSError, AttributeError) as exc:
        raise NativeBinaryError("invalid installed Native package") from exc
    event(
        "installed_hit" if hit else "installed_miss", key=key, binary_key_schema=1, reason=None if hit else "key_miss"
    )
    if hit is None and policy == "require":
        raise NativeBinaryError(
            f"Native binary required but not found: {key}; verify the target/ABI and re-export older packages"
        )
    return hit


_OPP_SOC = {"dav-3510": "ascend950", "dav-2201": "ascend910b"}


def _opp_roots():
    """Snapshot custom paths, configured vendors and the built-in package in order."""

    packages = [
        Path(value.strip()) for value in os.environ.get("ASCEND_CUSTOM_OPP_PATH", "").split(os.pathsep) if value.strip()
    ]
    opp = os.environ.get("ASCEND_OPP_PATH")
    if opp:
        priority = Path(opp) / "vendors/config.ini"
        if priority.is_file():
            config = configparser.ConfigParser()
            try:
                config.read_string("[vendors]\n" + priority.read_text())
                for name in config.get("vendors", "priority", fallback="").split(","):
                    name = name.strip()
                    if name and name not in (".", "..") and "/" not in name:
                        packages.append(Path(opp) / "vendors" / name)
            except (configparser.Error, OSError, UnicodeError) as error:
                raise NativeBinaryError("invalid OPP vendor configuration") from error
    home = os.environ.get("ASCEND_HOME_PATH")
    if home and (Path(home) / "opp_latest").is_dir():
        packages.append(Path(home) / "opp_latest/built-in")
    elif opp:
        packages.append(Path(opp) / "built-in")
    return tuple(dict.fromkeys(str((root / "op_impl/ai_core/tbe").resolve()) for root in packages))


def _validate_opp_environment(expected):
    if _opp_roots() != expected:
        raise NativeBinaryError(
            "OPP resource paths changed after resolving the Host program; call the source factory again"
        )


def _opp_device_image(directory, dependency, target):
    """Resolve one standard OPP device index exactly as the linked loader does."""

    root = Path(directory) / "kernel"
    soc = _OPP_SOC[target]
    config = root / "config" / soc
    repositories = [""]
    if config.is_dir():
        repositories += sorted(path.name for path in config.iterdir() if path.is_dir())
    op_type, key = dependency["opType"], dependency["binaryKey"]
    wanted = op_type + "/d=0,p=1/" + key
    for repository in repositories:
        index_path = f"config/{soc}/" + (repository + "/" if repository else "") + "binary_info_config.json"
        if not (root / index_path).exists() and not (root / index_path).is_symlink():
            continue
        table = _json(_read(root, index_path, 16 << 20))
        group = table.get(op_type)
        if group is None or group.get("simplifiedKeyMode") != 2:
            continue
        records = group["binaryList"]
        if not isinstance(records, list):
            raise NativeBinaryError("invalid OPP device index")
        matches = [record for record in records if wanted in record["simplifiedKey"]]
        if len(matches) > 1:
            raise NativeBinaryError("ambiguous OPP device binary key")
        if not matches:
            continue
        record = matches[0]

        def resource_path(logical, repository=repository):
            parts = _relative_path(logical).parts
            if parts[0] != soc:
                raise NativeBinaryError("OPP device index has an invalid SoC path")
            return "/".join((soc, repository, *parts[1:])) if repository else logical

        raw = _read(root, resource_path(record["jsonPath"]), 16 << 20)
        binary = _read(root, resource_path(record["binPath"]))
        description = _json(raw)
        from cannbot_dsl.core.compiler.metadata import _validate_device_resource

        _validate_device_resource(description, binary, dependency, target, record)
        return hashlib.sha256(binary).hexdigest(), description["cannbotdsl"]
    return None


def _validate_opp_devices(meta, key, target, directories, selected):
    dependencies = meta["deviceDependencies"]
    if not isinstance(dependencies, list):
        raise NativeBinaryError("invalid OPP device dependencies")
    required = [dependency for dependency in dependencies if dependency["binaryKey"] == key]
    if len(required) != 1 or required[0]["target"] != target:
        raise NativeBinaryError("missing or ambiguous OPP device dependency")
    dependency = required[0]
    image = _opp_device_image(selected, dependency, target)
    if image is None:
        raise NativeBinaryError("matching OPP device resources are missing from the selected Host package")
    # The linked runtime follows OPP priority. Earlier packages must not
    # redirect this Host entry to a different device image.
    for directory in directories:
        if directory == selected:
            break
        earlier = _opp_device_image(directory, dependency, target)
        if earlier is not None and earlier != image:
            raise NativeBinaryError("higher-priority OPP device resources conflict with the selected Host package")


def _resolve_opp(key, contract, target, directories):
    """Resolve an OPP entry under the existing AOT prefer/require/off policy."""
    from cannbot_dsl.core.compiler import metadata
    from cannbot_dsl.core.compiler.abi import HOST_ABI_VERSION
    from cannbot_dsl.core.compiler.binary_key import host_platform
    from cannbot_dsl.core.contracts.codec import contract_digest, contract_from_dict

    if not isinstance(key, str) or not _DIGEST.fullmatch(key):
        raise NativeBinaryError("invalid OPP binary key")
    arch = platform.machine()
    libraries = (
        f"op_host/lib/linux/{arch}/libophost_transformer.so",
        f"op_tiling/lib/linux/{arch}/libcust_opmaster_rt2.0.so",
    )
    try:
        for directory in directories:
            root = Path(directory)
            installed = [
                relative for relative in libraries if (root / relative).exists() or (root / relative).is_symlink()
            ]
            if len(installed) > 1:
                raise NativeBinaryError("ambiguous OPP Host libraries")
            if not installed:
                continue
            binary = _read(root, installed[0])
            raw = metadata._elf_metadata_section(binary)
            if raw is None:
                soc = _OPP_SOC.get(target)
                if soc and (root / f"config/{soc}/ops_transformer/native_info_config.json").exists():
                    raise NativeBinaryError(
                        "OPP Host lacks embedded metadata; rebuild and reinstall the operator package"
                    )
                continue  # An ASC-only library has no DSL entries.
            meta = _json(raw)
            if (
                not isinstance(meta, dict)
                or type(meta.get("schema")) is not int
                or meta["schema"] != 2
                or meta.get("artifactKind") != "host_provider"
                or meta.get("backend") != "external_device"
                or meta.get("resourceMode") != "opp"
                or type(meta.get("hostAbiVersion")) is not int
                or meta["hostAbiVersion"] != HOST_ABI_VERSION
                or meta.get("hostPlatform") != host_platform()
                or not isinstance(meta.get("target"), str)
            ):
                raise NativeBinaryError("unsupported OPP Host metadata/schema/ABI")
            if meta.get("target") != target:
                continue
            entries = meta["entries"]
            if not isinstance(entries, list) or len(entries) > 65536:
                raise NativeBinaryError("invalid OPP Host entries")
            seen, entry = set(), None
            for item in entries:
                candidate = item["binaryKey"]
                if not isinstance(candidate, str) or not _DIGEST.fullmatch(candidate) or candidate in seen:
                    raise NativeBinaryError("invalid or duplicate OPP Host binary key")
                seen.add(candidate)
                if candidate == key:
                    entry = item
            if entry is None:
                continue
            actual = contract_from_dict(entry["callContract"])
            if contract_digest(actual) != contract_digest(contract):
                raise NativeBinaryError("OPP Host call contract does not match compilation request")
            if not isinstance(entry["symbol"], str) or not metadata._SYMBOL_RE.fullmatch(entry["symbol"]):
                raise ValueError(f"invalid exported symbol name {entry['symbol']!r}")
            metadata._validate_provenance(entry["contentKey"], entry["formatVersionTag"])
            _validate_opp_devices(meta, key, target, directories, directory)
            # Keep the consumer's $ORIGIN dependency layout. Installed OPP libraries
            # and their dependencies must remain immutable while in use.
            path = str(root / installed[0])
            identity = (hashlib.sha256(binary).hexdigest(), directories)
            with _lock:
                if _opp_images.setdefault(path, identity) != identity:
                    raise NativeBinaryError(
                        "OPP Host library or resource paths changed after resolution; restart the consuming process"
                    )
            return NativeHit(
                path, entry["symbol"], HOST_ABI_VERSION, entry["contentKey"], entry["formatVersionTag"], directories
            )
    except (KeyError, TypeError, ValueError, OSError, AttributeError) as error:
        raise NativeBinaryError("invalid installed OPP Host resources: " + str(error)) from error
    return None
