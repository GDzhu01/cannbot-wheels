# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# Licensed under the CANN Open Software License Agreement Version 2.0.

"""Runtime-independent A5 device-callable source export."""

from __future__ import annotations

import hashlib
import inspect
import json
import re
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class KernelInfo:
    """Public identity of a kernel; exportability is checked by export_device."""

    kind: str
    signature: inspect.Signature
    configured: bool


def inspect_kernel(value) -> KernelInfo | None:
    """Describe a plain kernel or bound instance method without tracing it."""
    from cannbot_dsl.lang.kernel import KernelLauncher, _BoundKernelLauncher

    if isinstance(value, _BoundKernelLauncher):
        kind = "bound_method"
    elif isinstance(value, KernelLauncher):
        kind = "function"
    else:
        return None
    return KernelInfo(
        kind,
        value._surface.public_signature,
        value._block_dim is not None or value._thread_dim is not None or bool(value._dyn_ub_buf),
    )


def get_include() -> str:
    """Return the installed DSL extension header directory for consumers."""
    from cannbot_dsl.core.toolchain.ascendc import asc_ext_include_dir

    return str(asc_ext_include_dir())


def _validate_tensor_contract(parameter):
    from cannbot_dsl.core.contracts.elements import element_for_tag
    from cannbot_dsl.core.contracts.model import ConstantExpr

    tensor = parameter.argument
    prefix = f"device-callable parameter {parameter.name!r}"
    if tensor.address_space != "GM" or tensor.storage_encoding is not None:
        raise ValueError(f"{prefix} requires an ND GM tensor")
    if element_for_tag(tensor.element).dtype.bits < 8:
        raise ValueError(f"{prefix} does not support packed or sub-byte tensors")
    if tensor.stride and tensor.stride[-1] != ConstantExpr(1):
        raise ValueError(f"{prefix} requires innermost stride 1")
    for stride in tensor.stride:
        if isinstance(stride, ConstantExpr) and stride.value <= 0:
            raise ValueError(f"{prefix} requires positive strides")
    # Reject provably overlapping static rows. Dynamic views are subject to
    # the explicit consumer checks recorded in the execution contract.
    span = 1
    for shape, stride in reversed(tuple(zip(tensor.shape, tensor.stride))):
        if not isinstance(shape, ConstantExpr) or not isinstance(stride, ConstantExpr):
            break
        if shape.value > 1 and stride.value < span:
            raise ValueError(f"{prefix} requires non-overlapping rows")
        span += max(0, shape.value - 1) * stride.value


def _build_identity():
    from importlib.metadata import distribution
    from cannbot_dsl._version import __version__

    root = Path(get_include())
    headers = {
        p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted((root / "asc_ext").rglob("*"))
        if p.is_file()
    }
    if not headers:
        raise RuntimeError("DSL extension headers are missing; reinstall cannbot-dsl")
    fingerprint = hashlib.sha256(json.dumps(headers, sort_keys=True).encode()).hexdigest()
    direct_url = json.loads(distribution("cannbot-dsl").read_text("direct_url.json") or "{}")
    build_id = direct_url.get("vcs_info", {}).get("commit_id")
    return {"name": "cannbot-dsl", "version": __version__, "build_id": build_id}, {
        "language": "AscendC",
        "standard": "c++17",
        "device_function_mode": True,
        "dsl_headers": headers,
        "dsl_headers_sha256": fingerprint,
        "cann_headers": "consumer_resolved_sdk",
        "separate_translation_unit": True,
    }


@dataclass(frozen=True)
class DeviceExport:
    """Device source and its versioned ABI/requirements manifest.

    ``manifest`` returns a copy. Exporting does not compile or validate a binary;
    consumers loading only ``.text`` must additionally inspect object-file data
    references and the linked entry point (see docs/usage/DEVICE_EXPORT.md).
    """

    source: str
    _manifest_json: str

    @property
    def manifest(self) -> dict:
        return json.loads(self._manifest_json)

    def write(self, directory: str | Path) -> Path:
        """Write ``device_callable.hpp`` and ``manifest.json`` to directory."""
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        (directory / "device_callable.hpp").write_text(self.source, encoding="utf-8")
        (directory / "manifest.json").write_text(self._manifest_json + "\n", encoding="utf-8")
        return directory


def export_device(kernel, /, *args, arch="dav-3510", **kwargs) -> DeviceExport:
    """Export a ``@kernel`` function/bound method for device-side invocation.

    Arguments use the same descriptors and constexpr binding as ``compile``.
    ``arch`` is a reserved export option; A5 (``dav-3510``) is supported.
    The result describes the device Tensor POD ABI.
    A MIX export requires a co-scheduled AIC and two AIV participants.
    """
    from cannbot_dsl._mlir import ir
    from cannbot_dsl._mlir.dialects import cannir
    from cannbot_dsl.core.compiler.call_lowering import CallLoweringPlan
    from cannbot_dsl.core.compiler.host_schema import apply_physical_shape_upper_bound_attributes
    from cannbot_dsl.core.compiler.kernel_materialize import _materialize_device_function
    from cannbot_dsl.core.compiler.passes import _run_cannir_passes, _verify_array_contracts
    from cannbot_dsl.core.contracts.binding import bind_aot_call
    from cannbot_dsl.core.contracts.codec import contract_to_dict
    from cannbot_dsl.core.contracts.model import ScalarContract, TensorContract
    from cannbot_dsl.core.frontend.call_context import current_call_context
    from cannbot_dsl.core.frontend.compiler import frontend_options_scope, options_from_snapshot
    from cannbot_dsl.core.frontend.lowering_state import _CURRENT_LOWERING_STATE, JitLoweringState
    from cannbot_dsl.core.utils.env import env
    from cannbot_dsl.lang.kernel import KernelLauncher, _BoundKernelLauncher

    if arch != "dav-3510":
        raise ValueError("device-callable export supports A5 (arch='dav-3510') only")
    if current_call_context() is not None:
        raise RuntimeError("export_device() cannot be called during a DSL trace")
    if isinstance(kernel, _BoundKernelLauncher):
        launcher = kernel._launcher
        surface = kernel._surface
        call_args = (kernel._instance, *args)
    elif isinstance(kernel, KernelLauncher):
        launcher, surface, call_args = kernel, kernel._surface, args
    else:
        raise TypeError("export_device() expects a @kernel function or bound @kernel method")
    if inspect_kernel(kernel).configured:
        raise ValueError("export_device() accepts an unconfigured @kernel, without host launch dimensions")
    fn = launcher.fn
    surface.validate_void_return_annotation(path=fn.__qualname__)
    bound = bind_aot_call(fn, call_args, kwargs, surface_signature=surface)
    for parameter in bound.contract.runtime_parameters:
        if not isinstance(parameter.argument, (TensorContract, ScalarContract)):
            raise TypeError(f"device-callable parameter {parameter.name!r} must be a TensorSpec or scalar descriptor")
        if isinstance(parameter.argument, TensorContract):
            _validate_tensor_contract(parameter)
        elif parameter.argument.handle_kind:
            raise TypeError(f"device-callable parameter {parameter.name!r} cannot be a communication handle")
    if launcher.profile is not None:
        raise ValueError("device-callable export does not support host-managed profiling")

    with ir.Context(), ir.Location.unknown():
        module = ir.Module.create()
        plan = CallLoweringPlan.from_bound_call(fn, bound)
        state = JitLoweringState(module=module)
        token = _CURRENT_LOWERING_STATE.set(state)
        try:
            with frontend_options_scope(options_from_snapshot(env())):
                device, debug, _ = _materialize_device_function(
                    fn, plan, symbol_name=f"kernel_{fn.__name__}", materialized_block_dim=1
                )
            if debug is not None:
                raise ValueError("device-callable export does not support host-managed debug print buffers")
            # Validate before any canonicalization can erase launch queries.
            cannir.verify_device_callable_input(module.operation)
            apply_physical_shape_upper_bound_attributes(device, bound.contract)
            access = cannir.infer_kernel_argument_access(device.operation)
            attrs = list(device.attributes["arg_attrs"])
            for index, mask in enumerate(access):
                values = {item.name: item.attr for item in attrs[index]}
                values["cannbotdsl.device_access"] = ir.IntegerAttr.get(ir.IntegerType.get_signless(32), mask)
                attrs[index] = ir.DictAttr.get(values)
            device.attributes["arg_attrs"] = ir.ArrayAttr.get(attrs)
            module.operation.verify()
            _verify_array_contracts(module)
            _run_cannir_passes(module)
            source, manifest_json = cannir.translate_to_device_callable(module.operation)
        finally:
            _CURRENT_LOWERING_STATE.reset(token)

    manifest = json.loads(manifest_json)
    parameters = bound.contract.runtime_parameters
    for parameter in manifest["parameters"]:
        logical = parameters[parameter["logical_index"]]
        parameter["name"] = logical.name
        if isinstance(logical.argument, TensorContract):
            parameter["dtype"] = logical.argument.element
    manifest["contract"] = contract_to_dict(bound.contract)
    # Device export and Host call-frame protocols are independently versioned.
    manifest["contract"].pop("host_abi_version", None)
    manifest["contract"]["tensor_views"] = {
        "layout": "ND",
        "pointer": "first_valid_element",
        "offset_applied_by": "consumer",
        "positive_strides": True,
        "innermost_stride": 1,
        "non_overlapping": True,
        "validation": "consumer_must_prove_or_check_shapes_strides_and_dimension_relations",
    }
    manifest["contract"]["aliasing"] = {
        "single_parameter_inplace": True,
        "readonly_overlap": True,
        "cross_parameter_write_overlap": False,
    }
    # Scalar GM stores flush full A5 cache lines. Distinct element ranges are
    # insufficient to prove safe concurrent writes by independent cores.
    manifest["resources"]["gm_write_isolation"] = {
        "granularity_bytes": 64,
        "rule": "serialize_conflicting_cache_lines",
        "within_group": "kernel_author_must_ensure",
    }
    manifest["producer"], manifest["build_requirements"] = _build_identity()
    manifest["build_requirements"]["source_includes"] = sorted(
        set(re.findall(r'^#include [<"]([^>"\n]+)[>"]', source, re.MULTILINE))
    )
    manifest["build_requirements"]["targets"] = (
        ["aic", "aiv"] if manifest["core_type"] == "mixed" else [manifest["core_type"]]
    )
    manifest["source_sha256"] = hashlib.sha256(source.encode("utf-8")).hexdigest()
    return DeviceExport(source, json.dumps(manifest, indent=2, sort_keys=True))
