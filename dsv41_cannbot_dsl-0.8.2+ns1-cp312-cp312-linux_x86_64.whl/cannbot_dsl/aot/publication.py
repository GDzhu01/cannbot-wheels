# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Native export declarations, collection and atomic artifact publication."""
from contextlib import contextmanager
import hashlib
import inspect
import json
import os
from pathlib import Path
import tempfile
import threading

from . import runtime as native_binary
from .runtime import NativeBinaryError, register_directory, observe_compilations
from cannbot_dsl.aot.collection import (
    Collection as SourceCollection, collect as collect_sources,
    Mark, discover, module_identity, host_source, publish_path, _name, _json,
    _declares_registration,
)

__all__ = ["export", "build", "register_directory"]

def export(name):
    """Mark a no-argument function; importing a collector never invokes it."""
    _name(name)

    def decorate(function):
        if not inspect.isfunction(function) or inspect.iscoroutinefunction(function):
            raise TypeError("Native collector must be a synchronous function")
        if inspect.signature(function).parameters:
            raise TypeError("Native collector takes no arguments")
        if hasattr(function, "__cannbot_aot_export__"):
            raise ValueError("Native collector already registered")
        function.__cannbot_aot_export__ = name
        return function

    return decorate


def _sha(value):
    return hashlib.sha256(value).hexdigest()


class Collection(SourceCollection):
    """Collect and publish persistent Native binaries."""

    def __init__(self, target):
        super().__init__(target)
        self._temp = tempfile.TemporaryDirectory(prefix="cannbotdsl-collect-")
        self.add_cleanup(self._temp.cleanup)

    def record(self, artifact, function):
        if self._closed:
            raise RuntimeError("Native collection is closed")
        if threading.get_ident() != self._thread or os.getpid() != self._pid:
            raise RuntimeError("Native collection supports one thread/process")
        if not artifact.so_path or not artifact.content_key or not artifact.binary_key or artifact.debug_plans:
            raise native_binary.NativeBinaryError("collection requires a persistent, content-addressed Provider")
        from cannbot_dsl.core.compiler.metadata import publish_artifact

        key = artifact.binary_key
        source = {"function": function.__qualname__, "module": function.__module__, "mode": "aot"}
        task = self.tasks.setdefault(self.task, {"requests": 0, "artifacts": [], "sources": []})
        task["requests"] += 1
        if source not in task["sources"]:
            task["sources"].append(source)
        if key not in task["artifacts"]:
            task["artifacts"].append(key)
        directory = Path(self._temp.name) / key
        directory.mkdir(exist_ok=True)
        destination = directory / "provider.so"
        if key not in self.records:
            publish_artifact(
                artifact.so_path,
                str(destination),
                artifact.symbol_name,
                artifact.contract,
                host_abi_version=artifact.host_abi_version,
                content_key=artifact.content_key,
                format_version_tag=artifact.format_version_tag,
            )
            from cannbot_dsl.core.compiler.binary_key import build_provenance, host_platform

            self.records[key] = {
                "directory": directory,
                "owner": self.task,
                "descriptor": {
                    "binary_key_schema": artifact.binary_key_schema,
                    "binary_key": key,
                    "target": self.target,
                    "host_platform": host_platform(),
                    "python_abi": None,
                    "key_inputs": artifact.binary_key_inputs,
                    "build_provenance": dict(
                        build_provenance(), cache_key=artifact.content_key, cache_format_tag=artifact.format_version_tag
                    ),
                },
            }
        else:
            # Same key with different bytes is an identity conflict, never an overwrite.
            from cannbot_dsl.core.compiler.metadata import parse_metadata
            from cannbot_dsl.core.contracts.codec import contract_digest

            symbol, contract, abi, digest, _, _ = parse_metadata(
                json.loads(Path(str(destination) + ".meta.json").read_bytes())
            )
            if (
                digest != _sha(Path(artifact.so_path).read_bytes())
                or symbol != artifact.symbol_name
                or abi != artifact.host_abi_version
                or contract_digest(contract) != contract_digest(artifact.contract)
            ):
                raise native_binary.NativeBinaryError("different binaries produced the same binary key")

    def build_directory(self, output):
        """Atomically export to the exact output path; never overwrite it."""
        files = self._package_files()
        output = Path(output).absolute()
        output.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='.native-artifacts-', dir=output.parent) as temp:
            staged = Path(temp) / 'artifacts'
            staged.mkdir()
            for relative, data in sorted(files.items()):
                destination = staged / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)
            publish_path(staged, output)
        return output
    def _package_files(self):
        """Create the backend-independent, artifact-root-relative layout."""
        if not self._ready or not self.records:
            raise RuntimeError("Native package requires a completed, nonempty collection")
        from cannbot_dsl.core.compiler.binary_key import BINARY_KEY_SCHEMA
        from cannbot_dsl.core.compiler.abi import HOST_ABI_VERSION

        files, index = {}, {}
        for key, record in sorted(self.records.items()):
            base = f"operators/{record['owner']}/variants/{key}"
            binary, sidecar = base + "/provider.so", base + "/provider.so.meta.json"
            files[binary] = (record["directory"] / "provider.so").read_bytes()
            files[sidecar] = (record["directory"] / "provider.so.meta.json").read_bytes()
            descriptor = base + "/variant.json"
            files[descriptor] = _json(dict(record["descriptor"], binary=binary, sidecar=sidecar))
            index[key] = {"descriptor": descriptor}
        for name, task in sorted(self.tasks.items()):
            info = dict(task, name=name, variants={key: index[key] for key in sorted(task["artifacts"])})
            files[f"operators/{name}/operator.json"] = _json(info)
        index_path = "index.json"
        files[index_path] = _json(index)
        manifest_path = "manifest.json"
        files[manifest_path] = _json(
            {
                "schema_version": native_binary.SCHEMA,
                "target": self.target,
                "binary_key_schema": BINARY_KEY_SCHEMA,
                "host_abi_version": HOST_ABI_VERSION,
                "index": index_path,
                "files": {name: _sha(data) for name, data in sorted(files.items())},
            }
        )
        return files



@contextmanager
def collect(*, target):
    session = Collection(target)
    try:
        with collect_sources(session):
            yield session
    except BaseException:
        session.close()
        raise

def build(*, collectors, target, output, operators=None, pattern="*.py"):
    """Discover registered tasks, compile Providers and publish one Native package."""
    with discover(
        collectors=collectors,
        operators=operators,
        pattern=pattern,
        exclude_dirs=frozenset({"tests", "test", "build", "dist"}),
    ) as tasks:
        with collect(target=target) as session:
            for task, callback in tasks.items():
                session.task = task
                callback()
                if task not in session.tasks:
                    raise RuntimeError(f"Native task collected no Provider: {task}")
        try:
            return session.build_directory(output)
        finally:
            session.close()
