# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Ahead-of-time compilation and kernel launch export helpers."""

import ast
import hashlib
import inspect
import json
import logging
import textwrap


def compile(func, /, *args, **kwargs):
    """Compile a host entry; all args and kwargs bind to the source function."""
    return _compile(func, args, kwargs)


def _with_options(*, sk_configs=None):
    from cannbot_dsl.core.compiler.superkernel import SuperKernelOptions

    options = SuperKernelOptions.parse(sk_configs)

    def configured(func, /, *args, **kwargs):
        return _compile(func, args, kwargs, options)

    return configured


compile.with_options = _with_options


def _compile(func, args, kwargs, sk_options=None):
    """Compile a ``@host`` function or bound method into a ``ProviderCallable``.

    Descriptors and constexpr values in ``args`` and ``kwargs`` bind to the
    source function's signature, including its defaults. A bound receiver is
    available during tracing and is excluded from the runtime signature.
    ``func`` is positional-only so a source parameter named ``func`` can be
    supplied by keyword.
    """
    from cannbot_dsl.core.frontend.call_context import current_call_context
    from cannbot_dsl.lang.host import HostFunction, _BoundHostMethod
    from cannbot_dsl.core.compiler.builder import compile_to_artifact
    from cannbot_dsl.core.compiler.function import ProviderCallable
    from cannbot_dsl.core.contracts.binding import bind_aot_call

    if isinstance(func, _BoundHostMethod):
        host_function = getattr(func, "_host_function")
        surface = getattr(func, "_surface")
        call_args = (getattr(func, "_instance"), *args)
    elif isinstance(func, HostFunction):
        host_function = func
        surface = getattr(func, "_surface")
        call_args = args
    else:
        raise TypeError(
            "cannbot_dsl.compile() expects a @host function or bound @host method "
            f"as its first argument, got {type(func).__name__}"
        )

    if current_call_context() is not None:
        raise RuntimeError("cannbot_dsl.compile() cannot be called inside @host")
    surface.validate_void_return_annotation(path=host_function.__qualname__)
    bound_call = bind_aot_call(
        host_function.fn,
        call_args,
        kwargs,
        surface_signature=surface,
    )
    artifact = compile_to_artifact(
        host_function.fn,
        call_args,
        kwargs,
        aot=True,
        bound_call=bound_call,
        superkernel_options=sk_options,
    )
    if not artifact.so_path:
        return getattr(ProviderCallable, "_make_noop")(
            artifact.symbol_name,
            artifact.contract,
        )
    return getattr(ProviderCallable, "_create")(
        artifact.so_path,
        artifact.symbol_name,
        artifact.contract,
        host_abi_version=artifact.host_abi_version,
        owns_so=artifact.owns_so,
        debug_plans=artifact.debug_plans,
        content_key=artifact.content_key,
        format_version_tag=artifact.format_version_tag,
        resource_roots=artifact.resource_roots,
    )


def _add_launch_exports(module, host, source_fn, *, debug=False, enabled=True):
    """Export traced launches, using AST order only to label their call sites."""
    from cannbot_dsl.core.ir_transport import unwrap_operand
    from cannbot_dsl._mlir import ir
    from cannbot_dsl._mlir.dialects import func

    launches = []
    callsites = {}

    def collect(operation):
        if operation.name == "cannir.kernel_launch":
            launches.append(operation)
            if "cannbotdsl.callsite" in operation.attributes:
                callsites[len(launches) - 1] = tuple(ir.DenseI64ArrayAttr(operation.attributes["cannbotdsl.callsite"]))
                del operation.attributes["cannbotdsl.callsite"]
        return ir.WalkResult.ADVANCE

    host.operation.walk(collect)
    if not enabled or debug or not callsites:
        return []
    tree = next(
        n
        for n in ast.parse(textwrap.dedent(inspect.getsource(source_fn))).body
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
    )
    # Zero tags AST ordinals; legacy positive source-line offsets cannot match.
    stable_sites = {
        (n.lineno - 1, n.col_offset): [0, i]
        for i, n in enumerate(
            n for n in ast.walk(tree) if isinstance(n, ast.Call) and isinstance(n.func, ast.Subscript)
        )
    }
    root = ir.StringAttr(host.attributes["sym_name"]).value
    variants = []

    def parameter(typ, index):
        from cannbot_dsl._mlir.dialects import cannir

        if str(typ).startswith("!cannir.tensor<"):
            from cannbot_dsl.core.contracts.elements import element_for_storage_mlir_type

            tensor = cannir.TensorType(typ)

            def flatten(tree):
                if isinstance(tree, (tuple, list)):
                    return [leaf for child in tree for leaf in flatten(child)]
                return [int(tree)]

            # Host ABI represents DN2NZ/NZ2ND/ZN2ND access as identity.
            result = dict(
                kind="tensor",
                dtype=element_for_storage_mlir_type(tensor.pointer.dtype).tag,
                encoding=int(int(tensor.layout_map_kind) == 1),
                shape=flatten(tensor.logical_layout.shape_type.as_tuple),
                stride=flatten(tensor.logical_layout.stride_type.as_tuple),
            )
            if result["encoding"]:
                from cannbot_dsl.core.contracts.model import ConstantExpr, DimensionExpr
                from cannbot_dsl.core.contracts.storage import fractal_nz_storage_encoding
                from cannbot_dsl.core.contracts.codec import _expr_to_dict

                shape = tuple(
                    ConstantExpr(v) if v >= 0 else DimensionExpr(f"a{index}_s{i}")
                    for i, v in enumerate(result["shape"])
                )
                storage = fractal_nz_storage_encoding(shape, element=result["dtype"])
                result["storage_encoding"] = dict(
                    encoding=storage.encoding, physical_shape=[_expr_to_dict(v) for v in storage.physical_shape]
                )
            return result
        if ir.IntegerType.isinstance(typ):
            return dict(kind="bool" if ir.IntegerType(typ).width == 1 else "int")
        return dict(kind="float")

    for index, launch in enumerate(launches):
        wrapper = None
        try:
            if index not in callsites:
                continue
            types = [unwrap_operand(v).type for v in launch.operands]
            if any(
                not (
                    str(typ).startswith("!cannir.tensor<")
                    or ir.IntegerType.isinstance(typ)
                    or ir.F32Type.isinstance(typ)
                    or ir.F64Type.isinstance(typ)
                )
                for typ in types
            ):
                continue
            callsite = stable_sites[callsites[index]]
            parameters = [parameter(typ, i) for i, typ in enumerate(types)]
            digest = hashlib.sha256(json.dumps([str(typ) for typ in types]).encode()).hexdigest()
            variant = dict(
                callsite=callsite, digest=digest, parameters=parameters, symbol=root + "__launch_" + str(index)
            )
            with host.location, ir.InsertionPoint(module.body):
                wrapper = func.FuncOp(root + "__launch_" + str(index), (types, []))
                wrapper.attributes["cannir.host"] = ir.UnitAttr.get()
                wrapper.attributes["cannbotdsl.contract_digest"] = ir.StringAttr.get(digest)
                block = wrapper.add_entry_block()
                with ir.InsertionPoint(block):
                    ir.Operation.create(
                        "cannir.kernel_launch",
                        operands=[unwrap_operand(v) for v in block.arguments],
                        attributes={a.name: a.attr for a in launch.attributes},
                        loc=launch.location,
                    )
                    func.ReturnOp([])
            variants.append(variant)
        except (ValueError, TypeError, KeyError, AttributeError, OverflowError, ir.MLIRError) as error:
            if wrapper is not None:
                wrapper.operation.erase()
            logging.getLogger(__name__).debug("Skipping kernel export: %s", error)

    return variants
