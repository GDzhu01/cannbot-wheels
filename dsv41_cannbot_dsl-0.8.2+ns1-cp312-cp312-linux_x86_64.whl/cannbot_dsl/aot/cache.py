# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Cached compile factories shared by Python execution and Native collection."""

from contextvars import ContextVar
from concurrent.futures import Future
import functools
import ast
import hashlib
import textwrap
import inspect
import math
import json
import os
import threading

from contextlib import contextmanager
from dataclasses import dataclass

from cannbot_dsl.aot.collection import module_identity, current_collection


@dataclass(frozen=True)
class Compilation:
    """Owned identity of one successful AOT request; contains no compiler handles."""

    binary_key: str
    content_key: str
    symbol_name: str
    contract_digest: str


@contextmanager
def observe_compilations(callback, *, aot_only=True):
    from cannbot_dsl.aot import collection
    from cannbot_dsl.core.contracts.codec import contract_digest

    def observe(artifact, source):
        callback(
            Compilation(
                artifact.binary_key, artifact.content_key, artifact.symbol_name, contract_digest(artifact.contract)
            ),
            source,
        )

    with collection.observe_compilations(observe, aot_only=aot_only):
        yield


def matches_compilation(value, compilation):
    from cannbot_dsl.core.contracts.codec import contract_digest
    from cannbot_dsl import ProviderCallable

    return (
        isinstance(value, ProviderCallable)
        and value.symbol_name == compilation.symbol_name
        and getattr(value, "_content_key") == compilation.content_key
        and contract_digest(getattr(value, "_contract")) == compilation.contract_digest
    )


# Captures the artifact even when the underlying binary cache is warm.
FACTORY_REQUEST = ContextVar("cannbot_compile_factory_request", default=None)


# Callable-cache lookups retain the complete CANNBOTDSL_* environment identity.
# CPython's os._Environ stores immutable bytes/strings in a backing dict: compare
# that dict in C and only copy/decode/sort when the environment actually changes.
# Other implementations/mappings use the public snapshot path instead. Never
# mutate the backing dict or install process-global environment hooks.
_COMPILE_CACHE_ENV_STATE = (None, ())


def compile_cache_environment():
    """Fresh options with a cached unchanged snapshot and a portable fallback."""
    from .runtime import _opp_roots

    global _COMPILE_CACHE_ENV_STATE
    environ = os.environ
    backing = getattr(environ, "_data", None)
    if type(backing) is not dict or not isinstance(environ, getattr(os, "_Environ", ())):
        backing = dict(environ)
    previous, key = _COMPILE_CACHE_ENV_STATE
    if previous is not None and backing == previous:
        return key, _opp_roots() if os.environ.get("CANNBOTDSL_NATIVE_BINARY_MODE") != "off" else ()
    snapshot = backing.copy()
    options = []
    for name, value in snapshot.items():
        name = os.fsdecode(name)
        if name.startswith("CANNBOTDSL_") or name == "ASCEND_HOME_PATH":
            options.append((name, os.fsdecode(value)))
    key = tuple(sorted(options))
    # Publish the matching snapshot/key together. Concurrent readers may do
    # duplicate snapshot work, but cannot pair a new snapshot with an old key.
    _COMPILE_CACHE_ENV_STATE = (snapshot, key)
    return key, _opp_roots() if os.environ.get("CANNBOTDSL_NATIVE_BINARY_MODE") != "off" else ()


def config_value(value):
    """Stable, typed configuration encoding (bool and int remain distinct)."""
    from cannbot_dsl import DType

    if isinstance(value, DType):
        return {"kind": "dtype", "value": value.name}
    # Accept torch dtype without importing torch on the build path.
    if type(value).__module__ == "torch" and type(value).__name__ == "dtype":
        return {"kind": "dtype", "value": str(value).removeprefix("torch.")}
    if type(value) in (bool, int, str, float):
        if type(value) is float and not math.isfinite(value):
            raise TypeError("compile_cache configuration must be finite")
        if type(value) is int and not -(2**63) <= value < 2**63:
            raise TypeError("compile_cache integers must fit signed i64")
        return {"kind": type(value).__name__, "value": 0.0 if type(value) is float and value == 0 else value}
    raise TypeError("compile_cache configuration requires dtype, bool, int, float or str")


class CompileFactory:
    def __init__(self, fn):
        if not inspect.isfunction(fn) or inspect.iscoroutinefunction(fn):
            raise TypeError("compile_cache requires a synchronous factory function")
        self.signature = inspect.signature(fn)
        if any(p.kind in (p.VAR_POSITIONAL, p.VAR_KEYWORD) for p in self.signature.parameters.values()):
            raise TypeError("compile_cache does not support variadic factories")
        functools.update_wrapper(self, fn)
        self.__signature__ = self.signature
        self.fn = fn
        self._environment = compile_cache_environment
        self._cache = {}
        self._bindings = {}
        self._pending = {}
        self._generation = 0
        self._pid = os.getpid()
        self._lock = threading.RLock()

    def __call__(self, *args, **kwargs):
        pid = os.getpid()
        collecting = current_collection()
        if FACTORY_REQUEST.get() is not None:
            raise RuntimeError("nested compile_cache factories are unsupported")
        if self._pid != pid:
            self._lock = threading.RLock()
            self._cache = {}
            self._pending = {}
            self._pid = pid
        config_key, positional, keywords, config = self._bind(args, kwargs)
        if collecting is not None:
            return self._compile(positional, keywords, config, collecting)
        key = (config_key, self._environment())
        with self._lock:
            cached = self._cache.get(key)
            if cached is not None and not cached.closed:
                return cached
            pending = self._pending.get(key)
            owner = pending is None
            if owner:
                pending = Future()
                self._pending[key] = pending
            generation = self._generation
        if not owner:
            return pending.result()
        try:
            result = self._compile(positional, keywords, config, None)
            with self._lock:
                if generation == self._generation:
                    self._cache[key] = result
                pending.set_result(result)
            return result
        except BaseException as error:
            pending.set_exception(error)
            raise
        finally:
            with self._lock:
                if self._pending.get(key) is pending:
                    del self._pending[key]

    @property
    def identity(self):
        # Hash normalized syntax, not paths/line numbers or discovery module names.
        # Only the factory declaration is checked; implementation dependencies
        # are versioned and rebuilt through the Native publication workflow.
        try:
            function = ast.dump(ast.parse(textwrap.dedent(inspect.getsource(self.fn))), include_attributes=False)
        except (OSError, TypeError, SyntaxError) as error:
            raise ValueError("compile_cache publication requires readable Python source") from error
        digest = hashlib.sha256(function.encode()).hexdigest()
        return {
            "module": module_identity(self.fn.__module__),
            "function": self.fn.__qualname__,
            "source_digest": digest,
        }

    def cache_clear(self):
        """Release cached handles; active builds finish without repopulating it."""
        with self._lock:
            self._generation += 1
            self._pending.clear()
            for value in self._cache.values():
                value.close()
            self._cache.clear()
            self._bindings.clear()

    def _bind(self, args, kwargs):
        from cannbot_dsl import DType, dtypes

        # Type tags preserve bool/int and int/float distinctions in tuple keys.
        # Validate before hashing: arbitrary objects must never run __hash__.
        def typed(value):
            kind = type(value)
            if kind in (bool, int, str):
                return (kind, value)
            if isinstance(value, DType) or (kind.__module__ == "torch" and kind.__name__ == "dtype"):
                return (kind, value)
            if kind is float and math.isfinite(value):
                return (kind, value)
            config_value(value)  # raises the public configuration diagnostic
            raise TypeError("unsupported compile_cache configuration")

        raw = (tuple(typed(v) for v in args), tuple((k, typed(v)) for k, v in sorted(kwargs.items())))
        cached = self._bindings.get(raw)
        if cached is not None:
            return cached
        bound = self.signature.bind(*args, **kwargs)
        bound.apply_defaults()
        config = {name: config_value(value) for name, value in bound.arguments.items()}

        for name, encoded in config.items():
            bound.arguments[name] = (
                getattr(dtypes, encoded["value"]) if encoded["kind"] == "dtype" else encoded["value"]
            )
        key = tuple((name, v["kind"], v["value"]) for name, v in config.items())
        cached = (key, bound.args, bound.kwargs, config)
        self._bindings[raw] = cached
        return cached

    def _compile(self, positional, keywords, config, collecting):
        from cannbot_dsl import ProviderCallable

        requests = []
        token = FACTORY_REQUEST.set(requests)
        result = None
        try:
            with observe_compilations(lambda artifact, fn: requests.append((artifact, fn)), aot_only=True):
                result = self.fn(*positional, **keywords)
            if not isinstance(result, ProviderCallable) or result.closed:
                raise TypeError("compile_cache factory must return an open ProviderCallable")
            if len(requests) != 1:
                raise ValueError("compile_cache factory must make exactly one compile request")
            artifact, _ = requests[0]
            if not matches_compilation(result, artifact):
                raise ValueError("compile_cache factory must return its compiled Provider")
            if collecting is not None:
                record_factory(collecting, self.identity, config, artifact, result)
            return result
        except BaseException:
            if any(matches_compilation(result, artifact) for artifact, _ in requests):
                result.close()
            raise
        finally:
            FACTORY_REQUEST.reset(token)


def compile_cache(fn):
    """Cache a single-Provider compile factory by its normalized configuration."""
    return CompileFactory(fn)


class _FactoryBindings:
    """AOT factory provenance and handles for one publication session."""

    def __init__(self, session):
        self.bindings = {}
        self.handles = []
        session.add_cleanup(self.close)

    def close(self):
        while self.handles:
            self.handles.pop().close()


def record_factory(session, factory, config, artifact, handle):
    state = session.extension("cannbot_dsl.aot.compile_cache", lambda: _FactoryBindings(session))
    signature = [{"name": p.name, "kind": p.kind.name} for p in inspect.signature(handle).parameters.values()]
    binding = dict(factory=factory, config=config, signature=signature, binary_key=artifact.binary_key)
    key = json.dumps([factory, config], sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    previous = state.bindings.get(key)
    if previous is not None and previous != binding:
        raise ValueError("ambiguous compile_cache factory specialization")
    session.add_task_metadata("factory_bindings", binding)
    state.bindings[key] = binding
    state.handles.append(handle)
