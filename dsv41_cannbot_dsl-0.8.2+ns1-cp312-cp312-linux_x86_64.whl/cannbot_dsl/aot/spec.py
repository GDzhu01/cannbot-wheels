# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Pure Python descriptions accepted by
:func:`cannbot_dsl.compile`.

This module deliberately has no MLIR or runtime imports.  ``TensorSpec`` and
``Dim`` describe a call; compiler-only normalizers turn that description into IR
later.  In particular, a ``TensorSpec`` is not a tensor value and cannot be
used by a kernel body.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Generic, TypeVar

from cannbot_dsl.core.utils.type_checks import is_exact_instance
from cannbot_dsl.types._storage_format import FRACTAL_NZ_DTYPE_NAMES
from cannbot_dsl.types.dtypes import _DTYPES, DType, _resolve_dtype

_I64_MIN = -(1 << 63)
_I64_MAX = (1 << 63) - 1
_T = TypeVar("_T")


def _checked_int(value, *, what: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"{what} must be an int, got {type(value).__name__}")
    if value < _I64_MIN or value > _I64_MAX:
        from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

        raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, f"{what}={value} is outside signed int64 range")
    return value


class Constexpr(Generic[_T]):
    """Annotation marking a Python value as a trace-time constant.

    ``Constexpr`` is annotation-only.  Calls pass the underlying Python value,
    for example ``tile: Constexpr[int]`` followed by ``tile=64``.
    """

    __slots__ = ()

    def __new__(cls, *args, **kwargs):
        del args, kwargs
        from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

        raise CANNBotTypeError(
            DiagnosticCode.UNSUPPORTED_FEATURE,
            "Constexpr is annotation-only; pass the underlying Python value",
        )


class _ExpressionOps:
    __slots__ = ()

    def __add__(self, other):
        return _make_expression("add", self, other)

    def __radd__(self, other):
        return _make_expression("add", other, self)

    def __sub__(self, other):
        return _make_expression("sub", self, other)

    def __rsub__(self, other):
        return _make_expression("sub", other, self)

    def __mul__(self, other):
        return _make_expression("mul", self, other)

    def __rmul__(self, other):
        return _make_expression("mul", other, self)

    def __floordiv__(self, divisor):
        if isinstance(divisor, bool) or not isinstance(divisor, int):
            from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "Dim expressions may only be // divided by an int")
        if divisor <= 0:
            from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT,
                f"Dim expression floor-divisor must be a positive int, got {divisor}",
            )
        return _make_expression("floordiv", self, divisor)


@dataclass(frozen=True, slots=True)
class Dim(_ExpressionOps):
    """A named dynamic dimension and its runtime bounds."""

    name: str
    min: int = 1
    max: int | None = None
    multiple_of: int = 1

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name:
            from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "Dim.name must be a non-empty string")
        minimum = _checked_int(self.min, what=f"Dim({self.name!r}).min")
        if minimum < 0:
            from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

            raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, f"Dim({self.name!r}).min must be >= 0")
        maximum = self.max
        if maximum is not None:
            maximum = _checked_int(maximum, what=f"Dim({self.name!r}).max")
            if maximum < minimum:
                from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

                raise CANNBotValueError(
                    DiagnosticCode.INVALID_ARGUMENT,
                    f"Dim({self.name!r}).max must be >= min ({minimum}), got {maximum}",
                )
        multiple = _checked_int(self.multiple_of, what=f"Dim({self.name!r}).multiple_of")
        if multiple < 1:
            from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

            raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, f"Dim({self.name!r}).multiple_of must be >= 1")

    def __repr__(self) -> str:
        options = []
        if self.min != 1:
            options.append(f"min={self.min}")
        if self.max is not None:
            options.append(f"max={self.max}")
        if self.multiple_of != 1:
            options.append(f"multiple_of={self.multiple_of}")
        suffix = "" if not options else ", " + ", ".join(options)
        return f"Dim({self.name!r}{suffix})"


@dataclass(frozen=True, slots=True)
class _DimExpr(_ExpressionOps):
    op: str
    lhs: object
    rhs: object

    def __repr__(self) -> str:
        operator = {
            "add": "+",
            "sub": "-",
            "mul": "*",
            "floordiv": "//",
        }[self.op]
        return f"({self.lhs!r} {operator} {self.rhs!r})"


def _is_dimension_value(value) -> bool:
    return isinstance(value, (Dim, _DimExpr))


def _expr_sort_key(value) -> tuple:
    if isinstance(value, int):
        result = (0, value)
    elif isinstance(value, Dim):
        maximum = (0, 0) if value.max is None else (1, value.max)
        result = (1, value.name, value.min, maximum, value.multiple_of)
    else:
        result = (
            2,
            value.op,
            _expr_sort_key(value.lhs),
            _expr_sort_key(value.rhs),
        )
    return result


def _normalize_operand(value, *, what: str):
    if _is_dimension_value(value):
        return value
    if isinstance(value, bool) or not isinstance(value, int):
        return NotImplemented
    return _checked_int(value, what=what)


def _make_expression(op: str, lhs, rhs):
    lhs = _normalize_operand(lhs, what="Dim expression operand")
    rhs = _normalize_operand(rhs, what="Dim expression operand")
    if lhs is NotImplemented or rhs is NotImplemented:
        return NotImplemented

    if isinstance(lhs, int) and isinstance(rhs, int):
        if op == "add":
            return _checked_int(lhs + rhs, what="constant Dim expression")
        if op == "sub":
            return _checked_int(lhs - rhs, what="constant Dim expression")
        if op == "mul":
            return _checked_int(lhs * rhs, what="constant Dim expression")
        if op == "floordiv":
            return lhs // rhs

    if op == "add":
        if rhs == 0:
            return lhs
        if lhs == 0:
            return rhs
        if _expr_sort_key(rhs) < _expr_sort_key(lhs):
            lhs, rhs = rhs, lhs
    elif op == "sub":
        if rhs == 0:
            return lhs
    elif op == "mul":
        if lhs == 0 or rhs == 0:
            return 0
        if lhs == 1:
            return rhs
        if rhs == 1:
            return lhs
        if _expr_sort_key(rhs) < _expr_sort_key(lhs):
            lhs, rhs = rhs, lhs
    elif op == "floordiv":
        if rhs == 1:
            return lhs
    else:  # pragma: no cover - all construction is internal
        raise ValueError(f"unknown Dim expression op {op!r}")
    return _DimExpr(op, lhs, rhs)


def _validate_tensor_dtype(dtype) -> None:
    try:
        _resolve_dtype(dtype)
    except TypeError as exc:
        supported = ", ".join(f"dtypes.{item.name}" for item in _DTYPES)
        from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"TensorSpec.dtype must be a canonical dtype descriptor ({supported}), got {dtype!r}",
        ) from exc


def _normalize_slots(values, *, field_name: str) -> tuple:
    try:
        snapshot = tuple(values)
    except TypeError as exc:
        from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"TensorSpec.{field_name} must be an iterable") from exc
    result = []
    for index, value in enumerate(snapshot):
        if _is_dimension_value(value):
            result.append(value)
            continue
        value = _checked_int(value, what=f"TensorSpec.{field_name}[{index}]")
        if value < 0:
            from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE,
                f"TensorSpec.{field_name}[{index}] must be non-negative, got {value}",
            )
        result.append(value)
    return tuple(result)


def _compact_stride(shape: tuple) -> tuple:
    stride = [1] * len(shape)
    for index in range(len(shape) - 2, -1, -1):
        stride[index] = shape[index + 1] * stride[index + 1]
    return tuple(stride)


@dataclass(frozen=True, slots=True, init=False)
class TensorSpec:
    """Immutable host-tensor logical and provider-storage contract."""

    shape: tuple
    dtype: DType
    stride: tuple
    storage_format: str

    def __init__(self, shape, dtype, *, stride=None, storage_format="nd"):
        _validate_tensor_dtype(dtype)
        dtype = _resolve_dtype(dtype)
        if not is_exact_instance(storage_format, str):
            from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                f"TensorSpec.storage_format must be 'nd' or 'nz', got {type(storage_format).__name__}",
            )
        if storage_format not in {"nd", "nz"}:
            from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT,
                f"TensorSpec.storage_format must be 'nd' or 'nz', got {storage_format!r}",
            )
        normalized_shape = _normalize_slots(shape, field_name="shape")
        normalized_stride = (
            _compact_stride(normalized_shape) if stride is None else _normalize_slots(stride, field_name="stride")
        )
        if len(normalized_shape) != len(normalized_stride):
            from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE,
                f"TensorSpec shape rank {len(normalized_shape)} does not match stride rank {len(normalized_stride)}"
            )
        if storage_format == "nz":
            if dtype.name not in FRACTAL_NZ_DTYPE_NAMES:
                rendered = ", ".join(f"dtypes.{item.name}" for item in _DTYPES if item.name in FRACTAL_NZ_DTYPE_NAMES)
                from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

                raise CANNBotTypeError(
                    DiagnosticCode.INVALID_TYPE,
                    f"TensorSpec(storage_format='nz') supports only {rendered}, got dtypes.{dtype.name}",
                )
            if len(normalized_shape) not in (2, 3):
                from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

                raise CANNBotValueError(
                    DiagnosticCode.INVALID_SHAPE,
                    f"TensorSpec(storage_format='nz') requires rank 2 or 3, got rank {len(normalized_shape)}"
                )
            for index, value in enumerate(normalized_shape):
                if isinstance(value, int) and value <= 0:
                    from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

                    raise CANNBotValueError(
                        DiagnosticCode.INVALID_SHAPE,
                        "TensorSpec(storage_format='nz') requires positive "
                        f"shape dimensions, got shape[{index}]={value}"
                    )
                if isinstance(value, Dim) and value.min <= 0:
                    from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

                    raise CANNBotValueError(
                        DiagnosticCode.INVALID_ARGUMENT,
                        "TensorSpec(storage_format='nz') requires dynamic "
                        f"dimensions with min >= 1, got Dim({value.name!r}).min={value.min}"
                    )
            if dtype.is_packed_sub_byte:
                for index, value in enumerate(normalized_shape):
                    if not isinstance(value, int):
                        from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

                        raise CANNBotValueError(
                            DiagnosticCode.INVALID_SHAPE,
                            "TensorSpec(storage_format='nz') with the packed "
                            f"dtypes.{dtype.name} requires static shape "
                            f"dimensions, got a dynamic shape[{index}]"
                        )
                if normalized_shape[-1] % 2 != 0:
                    from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

                    raise CANNBotValueError(
                        DiagnosticCode.INVALID_SHAPE,
                        "TensorSpec(storage_format='nz') with the packed "
                        f"dtypes.{dtype.name} requires an even last extent "
                        f"so two elements share one byte carrier, got "
                        f"{normalized_shape[-1]}"
                    )
            expected_stride = _compact_stride(normalized_shape)
            if normalized_stride != expected_stride:
                from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

                raise CANNBotValueError(
                    DiagnosticCode.INVALID_ARGUMENT,
                    "TensorSpec(storage_format='nz') requires compact row-major "
                    f"stride {expected_stride!r}, got {normalized_stride!r}"
                )
        object.__setattr__(self, "shape", normalized_shape)
        object.__setattr__(self, "dtype", dtype)
        object.__setattr__(self, "stride", normalized_stride)
        object.__setattr__(self, "storage_format", storage_format)


@dataclass(frozen=True, slots=True)
class TensorListSpec:
    """AOT descriptor for a non-empty list of template-shaped Tensors.

    Dynamic dimensions in ``element`` are bound independently for every list
    position; dtype and rank remain common to the whole list.
    """

    element: TensorSpec
    length: int | Dim

    def __post_init__(self) -> None:
        if not isinstance(self.element, TensorSpec):
            from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                f"TensorListSpec.element must be TensorSpec, got {type(self.element).__name__}",
            )
        if self.element.storage_format != "nd":
            from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT,
                "TensorListSpec does not support private tensor storage; "
                "its element TensorSpec must use storage_format='nd'"
            )
        length = self.length
        if isinstance(length, bool) or not isinstance(length, (int, Dim)):
            from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                f"TensorListSpec.length must be a positive int or Dim, got {type(length).__name__}",
            )
        if isinstance(length, int):
            checked = _checked_int(length, what="TensorListSpec.length")
            if checked < 1:
                from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

                raise CANNBotValueError(
                    DiagnosticCode.INVALID_ARGUMENT,
                    f"TensorListSpec.length must be >= 1, got {checked}",
                )
            return
        if length.min < 1:
            from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT,
                f"TensorListSpec dynamic length requires Dim.min >= 1, got Dim({length.name!r}).min={length.min}"
            )


@dataclass(frozen=True, slots=True)
class StructSpec:
    """AOT descriptor for one logical runtime datastruct schema."""

    schema: object
    _internal_schema: object = field(init=False, repr=False, compare=True)

    def __post_init__(self) -> None:
        from cannbot_dsl.types.datastruct import StructSchema

        if not isinstance(self.schema, StructSchema):
            from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                f"StructSpec.schema must be StructSchema, got {type(self.schema).__name__}",
            )
        object.__setattr__(self, "_internal_schema", getattr(self.schema, "_internal_schema"))


__all__ = [
    "Constexpr",
    "Dim",
    "StructSpec",
    "TensorListSpec",
    "TensorSpec",
]
