# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Device-side builders for single-SGE URMA write descriptors."""

from ._device import JettyHandle, UrmaPeerHandle


def _build(kind, out, jetty, sq_head_bb, peer, remote_mem_idx, remote_offset, src_addr, nbytes, notification):
    from cannbot_dsl._mlir.dialects import cannir
    from cannbot_dsl.core.frontend.call_context import in_device_domain
    from cannbot_dsl.core.ir_transport import unwrap_operand
    from cannbot_dsl.types._numeric import UInt32, UInt64

    if not in_device_domain():
        from cannbot_dsl.core.diag.diagnostics import CANNBotRuntimeError, DiagnosticCode

        raise CANNBotRuntimeError(DiagnosticCode.INVALID_ARGUMENT, "URMA SQE builders require a Device kernel")
    if not isinstance(jetty, JettyHandle) or not isinstance(peer, UrmaPeerHandle):
        from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "expected a JettyHandle and a UrmaPeerHandle")
    fields = []
    if notification:
        index, offset, value = notification
        fields = [UInt32(index), UInt64(offset), UInt64(value)]
    op = cannir.UrmaBuildSqeOp(
        unwrap_operand(out), unwrap_operand(jetty), UInt64(sq_head_bb), unwrap_operand(peer),
        UInt32(remote_mem_idx), UInt64(remote_offset), UInt64(src_addr), UInt64(nbytes), fields, kind,
    )
    # Verify here as well as on direct IR input so both paths use the native layout proof.
    op.operation.verify()


def build_write_sqe(out, jetty, sq_head_bb, peer, remote_mem_idx, remote_offset, src_addr, nbytes):
    """Encode one 64-byte WRITE into UB. All offsets and lengths are bytes."""
    _build("write", out, jetty, sq_head_bb, peer, remote_mem_idx, remote_offset, src_addr, nbytes, ())
    return 1


def build_write_notify_sqe(out, jetty, sq_head_bb, peer, remote_mem_idx, remote_offset, src_addr, nbytes,
                           notify_mem_idx, notify_offset, notify_value):
    """Encode a 128-byte WRITE_WITH_NOTIFY, with independently selected notification memory."""
    _build("write_notify", out, jetty, sq_head_bb, peer, remote_mem_idx, remote_offset, src_addr, nbytes,
           (notify_mem_idx, notify_offset, notify_value))
    return 2
