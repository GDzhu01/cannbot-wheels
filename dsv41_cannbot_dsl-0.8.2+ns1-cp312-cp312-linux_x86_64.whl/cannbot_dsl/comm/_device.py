# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Device trace facades. Native pointers are runtime values, never constants."""


from cannbot_dsl.core.ir_transport import _CommunicationIrValue


_HANDLE_FACTORY = object()


def host_handle(handle_type, address):
    return handle_type(_HANDLE_FACTORY, address=address)


def device_handle(handle_type, operand):
    return handle_type(_HANDLE_FACTORY, operand=operand)


class _Handle(_CommunicationIrValue):
    __slots__ = ("_address",)
    handle_kind = ""

    def __init__(self, factory=None, *, address=None, operand=None):
        if factory is not _HANDLE_FACTORY:
            from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                "communication handles are returned by connection handle getters",
            )
        super().__init__(operand)
        self._address = address

    @classmethod
    def _from_ir(cls, value):
        return device_handle(cls, value)

    def _get(self, key, *index):
        from cannbot_dsl.core.frontend.call_context import in_device_domain

        if self._device_operand is None or not in_device_domain():
            from cannbot_dsl.core.diag.diagnostics import CANNBotRuntimeError, DiagnosticCode

            raise CANNBotRuntimeError(
                DiagnosticCode.INVALID_ARGUMENT,
                "field methods are available only in a DSL Device kernel",
            )
        import cannbot_dsl._mlir.ir as ir
        from cannbot_dsl._mlir.dialects import cannir
        from cannbot_dsl.types._numeric import UInt32, UInt64

        idx = None
        if index:
            idx = index[0]
            if isinstance(idx, int) and not isinstance(idx, bool):
                if not 0 <= idx < 2**32:
                    from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

                    raise CANNBotValueError(
                        DiagnosticCode.INVALID_ARGUMENT,
                        "memory_idx must be representable as uint32",
                    )
                idx = UInt32(idx)
            elif not isinstance(idx, UInt32):
                from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

                raise CANNBotTypeError(
                    DiagnosticCode.INVALID_TYPE,
                    "memory_idx must be uint32; use an explicit conversion",
                )
        if self.handle_kind == "jetty":
            value = cannir.CommGetJettyInfoOp(self._device_operand, key).result
        else:
            value = cannir.CommGetPeerInfoOp(self._device_operand, key, self.handle_kind, memory_idx=idx).result
        # C++ determines the result type. Normalize unsigned scalar results to
        # arith's signless carrier while retaining the frontend unsigned type.
        if ir.IntegerType.isinstance(value.type):
            return (UInt32 if ir.IntegerType(value.type).width == 32 else UInt64)(value)
        return value


class JettyHandle(_Handle):
    handle_kind = "jetty"

    def get_sq_base_addr(self):
        return self._get("SqBaseAddr")

    def get_cq_base_addr(self):
        return self._get("CqBaseAddr")

    def get_sq_doorbell_addr(self):
        return self._get("SqDoorbellAddr")

    def get_cq_doorbell_addr(self):
        return self._get("CqDoorbellAddr")

    def get_sq_depth(self):
        return self._get("SqDepth")

    def get_cq_depth(self):
        return self._get("CqDepth")

    def get_wqe_bb_size(self):
        return self._get("WqeBbSize")

    def get_cqe_size(self):
        return self._get("CqeSize")

    def get_sq_head_ptr(self):
        return self._get("SqHeadPtr")

    def get_sq_tail_ptr(self):
        return self._get("SqTailPtr")

    def get_cq_tail_ptr(self):
        return self._get("CqTailPtr")


class _Peer(_Handle):

    def get_rank_id(self):
        return self._get("RankId")

    def get_memory_size(self, memory_idx):
        return self._get("MemorySize", memory_idx)


class UbMemPeerHandle(_Peer):
    handle_kind = "ubmem_peer"

    def get_mapped_addr(self, memory_idx):
        return self._get("MappedAddr", memory_idx)


class UrmaPeerHandle(_Peer):
    handle_kind = "urma_peer"

    def get_tp_id(self):
        return self._get("TpId")

    def get_remote_eid(self):
        return self._get("RemoteEid")

    def get_remote_addr(self, memory_idx):
        return self._get("RemoteAddr", memory_idx)

    def get_token_id(self, memory_idx):
        return self._get("TokenId", memory_idx)

    def get_token_value(self, memory_idx):
        return self._get("TokenValue", memory_idx)


class _HandleList(_CommunicationIrValue):
    """Parameter annotation and kernel facade; Host values remain ordinary lists."""

    handle_kind = ""
    _static_length = False
    __slots__ = ("_contract",)

    def __new__(cls, *args, **kwargs):
        from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "pass a Python list; this class is a parameter annotation")

    @classmethod
    def _from_ir(cls, value, *, contract):
        result = cls._new_with_operand(value)
        result._contract = contract
        return result

    @property
    def length(self):
        from cannbot_dsl.core.contracts.model import ConstantExpr
        from cannbot_dsl.types._tensor import _cast_tensor_value

        if isinstance(self._contract.length, ConstantExpr):
            return self._contract.length.value
        return _cast_tensor_value(self._device_operand).shape[0]

    def __getitem__(self, index):
        from cannbot_dsl.core.frontend.call_context import in_device_domain
        from cannbot_dsl.types._tensor import _cast_tensor_value

        if not in_device_domain():
            from cannbot_dsl.core.diag.diagnostics import CANNBotRuntimeError, DiagnosticCode

            raise CANNBotRuntimeError(
                DiagnosticCode.INVALID_ARGUMENT,
                "handle list indexing is supported inside Device kernels",
            )
        if isinstance(index, bool) or (isinstance(index, int) and index < 0):
            from cannbot_dsl.core.diag.diagnostics import CANNBotIndexError, DiagnosticCode

            raise CANNBotIndexError(DiagnosticCode.INVALID_ARGUMENT, "handle index must be nonnegative")
        from cannbot_dsl.core.contracts.model import ConstantExpr

        if (
            isinstance(index, int)
            and isinstance(self._contract.length, ConstantExpr)
            and index >= self._contract.length.value
        ):
            from cannbot_dsl.core.diag.diagnostics import CANNBotIndexError, DiagnosticCode

            raise CANNBotIndexError(DiagnosticCode.INVALID_ARGUMENT, "handle index exceeds static list length")
        value = _cast_tensor_value(self._device_operand)[index]
        return device_handle(self.element_type, value)

    @property
    def length_signature(self):
        return repr(self._contract.length)


class JettyList(_HandleList):
    element_type = JettyHandle
    handle_kind = "jetty"


class UbMemPeerList(_HandleList):
    element_type = UbMemPeerHandle
    handle_kind = "ubmem_peer"


class UrmaPeerList(_HandleList):
    element_type = UrmaPeerHandle
    handle_kind = "urma_peer"


class StaticJettyList(JettyList):
    _static_length = True


class StaticUbMemPeerList(UbMemPeerList):
    _static_length = True


class StaticUrmaPeerList(UrmaPeerList):
    _static_length = True


class _Connection(_CommunicationIrValue):
    handle_kind = "connection"
    __slots__ = ()

    @classmethod
    def _from_ir(cls, value):
        return cls._new_with_operand(value)

    def _query(self, key, index=None):
        from cannbot_dsl.core.frontend.call_context import in_device_domain

        if self._device_operand is None or not in_device_domain():
            from cannbot_dsl.core.diag.diagnostics import CANNBotRuntimeError, DiagnosticCode

            raise CANNBotRuntimeError(DiagnosticCode.INVALID_ARGUMENT, "connection getters require a DSL Device kernel")
        from cannbot_dsl._mlir.dialects import cannir
        from cannbot_dsl.types._numeric import UInt32

        if index is not None:
            if isinstance(index, int) and not isinstance(index, bool):
                if not 0 <= index < 2**32:
                    from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

                    raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "connection index must fit uint32")
                index = UInt32(index)
            elif not isinstance(index, UInt32):
                from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

                raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "connection index requires uint32")
        value = cannir.CommGetConnectionInfoOp(self._device_operand, key, index=index).result
        if key == "Peer":
            return device_handle(self._peer_type, value)
        if key == "Jetty":
            return device_handle(JettyHandle, value)
        return UInt32(value)

    def get_peer(self, peer_idx):
        return self._query("Peer", peer_idx)

    def get_jetty(self, jetty_idx):
        return self._query("Jetty", jetty_idx)

    def get_peer_count(self):
        return self._query("PeerCount")

    def get_jetty_count(self):
        return self._query("JettyCount")
