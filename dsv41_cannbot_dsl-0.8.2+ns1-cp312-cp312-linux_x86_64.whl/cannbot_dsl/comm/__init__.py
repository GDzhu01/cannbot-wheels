# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Explicit AIV connections and typed Device field queries.

Host runtime loading is lazy. Business owns the communicator and buffers;
connections must be explicitly disconnected after all users have finished.
"""

from dataclasses import dataclass
from enum import Enum
from importlib import import_module
from . import urma
from ._device import (
    host_handle as _host_handle, _Connection, JettyHandle, JettyList, StaticJettyList,
    UbMemPeerHandle, UbMemPeerList, StaticUbMemPeerList,
    UrmaPeerHandle, UrmaPeerList, StaticUrmaPeerList,
)


class Protocol(Enum):
    RESERVED = "RESERVED"
    HCCS = "HCCS"
    ROCE = "ROCE"
    PCIE = "PCIE"
    SIO = "SIO"
    UBC_TP = "UBC_TP"
    UBOE = "UBOE"
    HCCS_ONLY = "HCCS_ONLY"
    UB_RTP = "UB_RTP"
    UBG = "UB_RTP"
    UB_MEM = "UB_MEM"
    UB_CTP = "UB_CTP"
    UBC_CTP = "UB_CTP"


class UbMemProtocol(Enum):
    PCIE = "PCIE"
    UB_MEM = "UB_MEM"


class UrmaProtocol(Enum):
    UBC_TP = "UBC_TP"
    UBOE = "UBOE"
    UB_RTP = "UB_RTP"
    UBG = "UB_RTP"
    UB_CTP = "UB_CTP"
    UBC_CTP = "UB_CTP"


class CommError(RuntimeError):
    def __init__(self, message, *, cleanup_connection=None, stage=None, peer_rank=None, sdk_api=None, sdk_code=None):
        super().__init__(message)
        self.cleanup_connection = cleanup_connection
        self._stage, self._peer_rank = stage, peer_rank
        self._sdk_api, self._sdk_code = sdk_api, sdk_code

    @property
    def stage(self):
        return self._stage

    @property
    def peer_rank(self):
        return self._peer_rank

    @property
    def sdk_api(self):
        return self._sdk_api

    @property
    def sdk_code(self):
        return self._sdk_code


@dataclass(frozen=True)
class MemoryDesc:
    """Business-owned GM extent; storing its address does not keep a buffer alive."""

    addr: int
    size: int


@dataclass(frozen=True, kw_only=True)
class UbMem:
    """Mapped-memory transport. Business buffers must outlive their HCOMM registrations."""

    protocol: UbMemProtocol = UbMemProtocol.UB_MEM

    def __post_init__(self):
        if not isinstance(self.protocol, UbMemProtocol):
            from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "protocol must be UbMemProtocol")


@dataclass(frozen=True, kw_only=True)
class Urma:
    """URMA transport. timeout_ms bounds the Channel READY wait."""

    protocol: UrmaProtocol = UrmaProtocol.UB_CTP
    jetty_count: int
    timeout_ms: int = 60000

    def __post_init__(self):
        if not isinstance(self.protocol, UrmaProtocol):
            from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "protocol must be UrmaProtocol")


def _raise_failure(info, connection=None):
    info = dict(info)
    message = info.pop("message")
    kind = info.pop("kind")
    # No resources may escape as a ValueError: incomplete rollback always needs
    # CommError's cleanup_connection, even if validation was the original error.
    if kind == 1 and connection is None:
        raise ValueError(message)
    raise CommError(message, cleanup_connection=connection, **info)


def _native():
    try:
        return import_module("cannbot_dsl._comm_native")
    except (ImportError, OSError) as error:
        raise CommError("native communication runtime is unavailable", stage="load_runtime") from error


def _invoke(target, operation, *args):
    try:
        return getattr(target, operation)(*args)
    except RuntimeError as error:
        if isinstance(error, CommError):
            raise
        raise CommError(str(error)) from error


def _uint(value, bits, name):
    if type(value) is not int:
        from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"{name} must be an integer")
    if not 0 <= value < (1 << bits):
        from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

        raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, f"{name} is outside uint{bits} range")
    return value


def _protocol(value):
    native = _native()
    for protocol in Protocol:
        if getattr(native, protocol.value, None) == value:
            return protocol
    # Preserve unknown SDK values in query results instead of silently filtering.
    return value


def _peer_ranks(peers):
    if not isinstance(peers, list):
        from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "peers must be a list")
    ranks = [_uint(peer, 32, "peer") for peer in peers]
    if not ranks or len(set(ranks)) != len(ranks):
        from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

        raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "peers must be nonempty and unique")
    return ranks


def _memory_extents(memories):
    if not isinstance(memories, list):
        from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "memories must be a list")
    extents = []
    for mem in memories:
        if not isinstance(mem, MemoryDesc):
            from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "memories must contain MemoryDesc")
        extents.append((_uint(mem.addr, 64, "addr"), _uint(mem.size, 64, "size")))
    return extents


class CommHandle:
    """Borrowed communicator, resolved once by name in the native runtime."""

    __slots__ = ("_native",)

    def __init__(self, native, *, _internal=False):
        if not _internal:
            from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "CommHandle is returned by get_comm_by_name")
        self._native = native

    @staticmethod
    def _protocol_for(transport):
        if not isinstance(transport, (UbMem, Urma)):
            from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "transport must be UbMem or Urma")
        return Protocol(transport.protocol.value)

    def connect(self, *, peers, layer, transport, memories, tag):
        """Connect to the ordered peer ranks on one layer."""
        ranks = _peer_ranks(peers)
        layer = _uint(layer, 32, "layer")
        protocol = self._protocol_for(transport)
        is_urma = isinstance(transport, Urma)
        if not isinstance(tag, str):
            from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "tag must be str")
        if not tag or "\0" in tag:
            from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

            raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "tag must be nonempty without NUL")
        timeout = _uint(transport.timeout_ms, 32, "timeout_ms") if is_urma else 60000
        jettys = _uint(transport.jetty_count, 32, "jetty_count") if is_urma else 0
        if is_urma and (not timeout or not jettys):
            from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

            raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "timeout_ms and jetty_count must be positive")
        extents = _memory_extents(memories)
        status, raw, diagnostic = _invoke(
            self._native,
            "connect",
            layer,
            getattr(_native(), protocol.value),
            jettys,
            extents,
            tag,
            ranks,
            timeout,
        )
        cls = UrmaConnection if is_urma else UbMemConnection
        connection = cls(raw, _internal=True) if raw is not None else None
        if status:
            _raise_failure(diagnostic, connection)
        return connection

    def get_rank_id(self):
        return _invoke(self._native, "get_rank_id")

    def get_rank_size(self):
        return _invoke(self._native, "get_rank_size")

    def get_layers(self):
        return _invoke(self._native, "get_layers")

    def get_topo_type(self, layer):
        return _invoke(self._native, "get_topo_type", _uint(layer, 32, "layer"))

    def get_protocols(self, layer):
        values = _invoke(self._native, "get_protocols", _uint(layer, 32, "layer"))
        return [_protocol(value) for value in values]

    def check_reachable(self, src_rank, dst_rank, layer, protocol):
        if not isinstance(protocol, Protocol):
            from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "protocol must be Protocol")
        return _invoke(
            self._native,
            "check_reachable",
            _uint(src_rank, 32, "src_rank"),
            _uint(dst_rank, 32, "dst_rank"),
            _uint(layer, 32, "layer"),
            getattr(_native(), protocol.value),
        )



class ConnectHandle(_Connection):
    """Explicitly managed connection; no cleanup is performed by Python GC."""

    __slots__ = ("_native",)

    def __init__(self, native, *, _internal=False):
        if not _internal:
            from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                "connections are returned by CommHandle connection methods",
            )
        super().__init__(None)
        self._native = native

    @property
    def _address(self):
        return _invoke(self._native, "device_address")

    def get_peers(self):
        return [_host_handle(self._peer_type, value) for value in _invoke(self._native, self._peer_getter)]

    def disconnect(self):
        status, diagnostic = _invoke(self._native, "disconnect")
        if status:
            _raise_failure(diagnostic, self)

    def closed(self):
        return _invoke(self._native, "closed")


class UbMemConnection(ConnectHandle):
    _peer_type = UbMemPeerHandle
    _peer_getter = "get_ubmem_peers"
    handle_kind = "ubmem_connection"
    __slots__ = ()


class UrmaConnection(ConnectHandle):
    _peer_type = UrmaPeerHandle
    _peer_getter = "get_urma_peers"
    handle_kind = "urma_connection"
    __slots__ = ()

    def get_jettys(self):
        return [_host_handle(JettyHandle, value) for value in _invoke(self._native, "get_jettys")]


def get_comm_by_name(name):
    if not isinstance(name, str):
        from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode

        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "name must be str")
    if not name or "\0" in name:
        from cannbot_dsl.core.diag.diagnostics import CANNBotValueError, DiagnosticCode

        raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "name must be a nonempty native communicator name")
    return CommHandle(_invoke(_native(), "get_comm_by_name", name), _internal=True)


__all__ = [
    "urma",
    "JettyList",
    "UbMemPeerList",
    "UrmaPeerList",
    "StaticJettyList",
    "StaticUbMemPeerList",
    "StaticUrmaPeerList",
    "Protocol",
    "UbMemProtocol",
    "UrmaProtocol",
    "CommError",
    "MemoryDesc",
    "UbMem",
    "Urma",
    "UbMemConnection",
    "UrmaConnection",
    "CommHandle",
    "ConnectHandle",
    "JettyHandle",
    "UbMemPeerHandle",
    "UrmaPeerHandle",
    "get_comm_by_name",
]
