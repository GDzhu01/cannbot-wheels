# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# Generated from pyproject.toml; do not edit.
__version__ = "0.8.2+ns1"
