# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""CANNBotDSL: Python frontend for building CANNIR MLIR from Python."""

from ._build_online import ensure_native as _ensure_native
_ensure_native(__file__)
del _ensure_native

import sys

from cannbot_dsl.core.utils.logger import init_logger as _init_logger

_init_logger()

# Complete types aggregation and tensor definitions before AttrBuilder
# registration and high-level APIs. Caster registration itself only stores
# callbacks; their first use requires the public Tensor/Layout definitions.
from cannbot_dsl import types as _types  # noqa: F401
from cannbot_dsl import tensor

# AttrBuilder registrations must run before any dialect op constructor sees
# a PipeEnum / AscRoundingModeEnum argument. Imported for side effect only.
from cannbot_dsl.core.frontend import attr_builders  # noqa: F401

from cannbot_dsl.ops.arch import (
    get_block_idx,
    get_block_num,
    get_core_id,
    get_ctrl,
    get_squeeze_status,
    get_status,
    get_subblock_dim,
    get_subblock_id,
    get_system_cycle,
    get_vf_len,
    is_aic,
    is_aiv,
    set_ctrl,
)
from cannbot_dsl.ops.info import (
    PlatformInfo,
    get_mem_size,
    get_platform_info,
)
from cannbot_dsl.lang.constexpr import const_expr, range_constexpr
from cannbot_dsl.ops.conv import (
    Conv2dSpec,
    Conv2dTile,
    conv2d_load_filter,
    conv2d_load_fmap,
    conv2d_load_im2col,
    conv2d_store_output,
    make_conv2d_fmap_l1,
    make_conv2d_spec,
)
from cannbot_dsl.lang.control_flow import range
from cannbot_dsl.core.compiler import (
    ProviderCallable,
    clear_compile_cache,
    load,
)
from cannbot_dsl.core.diag.diagnostics import (
    CANNBotError,
    CANNBotInternalError,
    CANNBotOverflowError,
    CANNBotIndexError,
    CANNBotNotImplementedError,
    CANNBotRuntimeError,
    CANNBotTypeError,
    CANNBotValueError,
    DiagnosticCode,
)
from cannbot_dsl.core.diag.debug import print
from cannbot_dsl.core.diag.native_dump import dump_reg, dump_tensor
from cannbot_dsl.core.diag.time_stamp import print_time_stamp
from cannbot_dsl.types.datastruct import (
    CArray,
    StructField,
    StructRef,
    StructSchema,
    datastruct,
)
from cannbot_dsl.types import dtypes
from cannbot_dsl.ops import cube
from cannbot_dsl.ops import scalar
from cannbot_dsl.ops import simt
from cannbot_dsl.types.dtypes import DType
from cannbot_dsl.aot.compiler import compile
from cannbot_dsl.aot.device_export import DeviceExport, KernelInfo, export_device, get_include, inspect_kernel
from cannbot_dsl.lang.host import host
from cannbot_dsl.lang.jit import jit
from cannbot_dsl.lang.kernel import kernel
from cannbot_dsl.lang.launch import dim3
from cannbot_dsl.core import profiling as profiler
from cannbot_dsl.core.profiling import ProfileSpec
from cannbot_dsl.ops.matmul import matmul
from cannbot_dsl.ops.memcpy import (
    ChannelSplitMode,
    cv_valid_extent,
    copy_options,
    mem_copy,
)
from cannbot_dsl.aot.spec import (
    Constexpr,
    Dim,
    StructSpec,
    TensorListSpec,
    TensorSpec,
)
from cannbot_dsl.types.tensor_list import TensorList
from cannbot_dsl.ops.sync import (
    GroupSync,
    cube_get_buf,
    cube_release_buf,
    cube_sync_all,
    cube_sync_block_arrive,
    cube_sync_block_wait,
    cube_sync_intra_arrive,
    cube_sync_intra_wait,
    cube_sync_pipe,
    dcci_entire_atomic,
    dcci_entire_out,
    dcci_single,
    dci,
    global_sync_all,
    vec_busy_wait,
    vec_get_buf,
    vec_release_buf,
    vec_sync_all,
    vec_sync_block_arrive,
    vec_sync_block_wait,
    vec_sync_intra_arrive,
    vec_sync_intra_wait,
    vec_sync_pipe,
)
from cannbot_dsl.tensor import (
    Coord,
    Layout,
    PartitionTiler,
    Shape,
    Stride,
    Tensor,
    Tile,
    Tiler,
    cat,
    ceil_div,
    make_layout,
    make_tensor,
    from_tensor,
    idx2crd,
    make_tiler,
    tile_slice,
    tile_slice_multi,
    storage_bits,
)
from cannbot_dsl.ring_buffer import make_ring_buffer
from cannbot_dsl.ops.scalar import data_barrier
from cannbot_dsl.types import Array, RoundingMode, ScalarValue
from cannbot_dsl.tensor import MemLoc
from cannbot_dsl.ops.sync import PIPE, CmpOp
from cannbot_dsl.ops.reg.cast import RegLayout
from cannbot_dsl.lang.vf import vf

# The raw-register and collective surfaces are namespaced, not flattened:
# `cbd.reg.vadd(...)` and `cbd.comm.get_comm_by_name(...)`. Registering
# them in sys.modules under the short names keeps `import cannbotdsl.reg` and
# `from cannbotdsl.reg import vadd` working alongside attribute access.
#
# Namespacing `reg` is also what removes the old `vmax` / `vselect` collision:
from cannbot_dsl.ops import reg  # noqa: F401
from cannbot_dsl import comm

sys.modules[__name__ + ".reg"] = reg

from cannbot_dsl._version import __version__

from cannbot_dsl.ops.load3d import (
    load3d, Load3DFeatureMap, Load3DWindow, Load3DRepeat, Load3DDestination, Load3DPadding
)
from cannbot_dsl.ops.vnchwconv import vnchwconv

__all__ = [
    "DeviceExport",
    "KernelInfo",
    "export_device",
    "get_include",
    "inspect_kernel",
    "vnchwconv",
    "load3d",
    "Load3DFeatureMap",
    "Load3DWindow",
    "Load3DRepeat",
    "Load3DDestination",
    "Load3DPadding",

    "tensor",
    "profiler",
    "ProfileSpec",
    "__version__",
    "Buffer",
    "Array",
    "CArray",
    "RingBuffer",
    "GroupSync",
    "data_barrier",
    "CANNBotError",
    "CANNBotInternalError",
    "CANNBotOverflowError",
    "CANNBotIndexError",
    "CANNBotNotImplementedError",
    "CANNBotRuntimeError",
    "CANNBotTypeError",
    "CANNBotValueError",
    "CmpOp",
    "Constexpr",
    "Conv2dSpec",
    "Conv2dTile",
    "Coord",
    "DiagnosticCode",
    "Dim",
    "DType",
    "Layout",
    "MemLoc",
    "PIPE",
    "PartitionTiler",
    "PlatformInfo",
    "ProviderCallable",
    "RegLayout",
    "ScalarValue",
    "RoundingMode",
    "Shape",
    "Stride",
    "StructField",
    "StructRef",
    "StructSchema",
    "StructSpec",
    "Tensor",
    "from_tensor",
    "storage_bits",
    "UB",
    "L1",
    "L0A",
    "L0B",
    "L0C",
    "BIAS",
    "SSBUF",
    "FBUF",
    "FBUF_ACT",
    "TensorList",
    "TensorListSpec",
    "TensorSpec",
    "Tile",
    "Tiler",
    "ceil_div",
    "onchip_rewind",
    "clear_compile_cache",
    "compile",
    "const_expr",
    "conv2d_load_filter",
    "conv2d_load_fmap",
    "conv2d_load_im2col",
    "conv2d_store_output",
    "cube",
    "cube_get_buf",
    "cube_release_buf",
    "cube_sync_all",
    "cube_sync_block_arrive",
    "cube_sync_block_wait",
    "cube_sync_intra_arrive",
    "cube_sync_intra_wait",
    "cube_sync_pipe",
    "datastruct",
    "dcci_entire_atomic",
    "dcci_entire_out",
    "dcci_single",
    "dci",
    "comm",
    "dtypes",
    "get_block_idx",
    "is_aic",
    "get_block_num",
    "get_core_id",
    "get_ctrl",
    "get_mem_size",
    "get_platform_info",
    "get_squeeze_status",
    "get_status",
    "get_subblock_dim",
    "is_aiv",
    "get_subblock_id",
    "get_system_cycle",
    "get_vf_len",
    "idx2crd",
    "set_ctrl",
    "host",
    "jit",
    "kernel",
    "global_sync_all",
    "load",
    "make_conv2d_fmap_l1",
    "make_conv2d_spec",
    "copy_options",
    "ChannelSplitMode",
    "cv_valid_extent",
    "make_layout",
    "make_tiler",
    "make_buffer",
    "make_ring_buffer",
    "make_tensor",
    "matmul",
    "mem_copy",
    "cat",
    "dump_tensor",
    "dump_reg",
    "print_time_stamp",
    "print",
    "range",
    "range_constexpr",
    "reg",
    "scalar",
    "simt",
    "dim3",
    "tile_slice",
    "tile_slice_multi",
    "vec_busy_wait",
    "vec_get_buf",
    "vec_release_buf",
    "vec_sync_all",
    "vec_sync_block_arrive",
    "vec_sync_block_wait",
    "vec_sync_intra_arrive",
    "vec_sync_intra_wait",
    "vec_sync_pipe",
    "vf",
]


def __getattr__(name):
    if name in ("Buffer", "UB", "L1", "L0A", "L0B", "L0C", "BIAS", "SSBUF", "FBUF", "FBUF_ACT", "make_buffer"):
        from cannbot_dsl import buffer

        value = getattr(buffer, name)
        globals()[name] = value
        return value
    if name == "RingBuffer":
        from cannbot_dsl.ring_buffer import RingBuffer

        globals()[name] = RingBuffer
        return RingBuffer
    if name == "onchip_rewind":
        from cannbot_dsl.ops.sync import onchip_rewind

        globals()[name] = onchip_rewind
        return onchip_rewind
    raise AttributeError(f"module 'cannbotdsl' has no attribute {name!r}")
