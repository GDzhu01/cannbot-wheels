# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Reusable on-chip storage slots with independent head and tail positions.

``next_write()`` and ``next_read()`` select a slot, bind its declared Tensor
and advance their respective cursor immediately. Data accesses determine
synchronization; selecting a slot does not initialize data, wait, check
fullness, or copy the stored data. Each result captures an address.

The compiler derives local and cross-core synchronization from Tensor accesses.

For single-slot VF-internal scratch space (no ring-buffer semantics), use
``cannbot_dsl.buffer.Buffer``. Buffer and RingBuffer allocation declarations share
the pass-side address planner. Byte slices and ``Tensor.view`` describe
contiguous ND aliases; ``reinterpret`` describes explicit physical layouts.
Neither view operation requests another allocation.
"""

from __future__ import annotations

import cannbot_dsl._mlir.ir as ir
from cannbot_dsl._mlir.dialects import cannir
from cannbot_dsl.core.diag.diagnostics import (
    CANNBotTypeError,
    CANNBotValueError,
    DiagnosticCode,
)
from cannbot_dsl.core.ir_transport import unwrap_operand
from cannbot_dsl.core.utils.type_checks import is_exact_instance
from cannbot_dsl.ops.sync import onchip_rewind as onchip_rewind
from cannbot_dsl.tensor import MemLoc, Tensor

_CUBE_MEM_LOCS = {MemLoc.L1, MemLoc.L0A, MemLoc.L0B, MemLoc.L0C, MemLoc.BIAS}


@ir.register_value_caster(cannir.RingBufferType.get_static_typeid())
class _RingBufferValue(ir.Value):
    """SSA-level RingBuffer value. Auto-cast from RingBufferType SSA values."""

    @property
    def dtype(self):
        memref_ty = cannir.TensorType(self.type.element)
        from cannbot_dsl.core.contracts.elements import dtype_for_storage_mlir_type

        return dtype_for_storage_mlir_type(cannir.PointerType(memref_ty.pointer).dtype)

    @property
    def memloc(self):
        memref_ty = cannir.TensorType(self.type.element)
        return cannir.PointerType(memref_ty.pointer).memloc

    @property
    def layout(self):
        return cannir.extract_layout(self)

    @property
    def physical_layout(self):
        return cannir.extract_physical_layout(self)

    @property
    def shape(self):
        return self.layout.shape

    @property
    def stride(self):
        return self.layout.stride

    @property
    def depth(self):
        return self.type.depth

    @property
    def element(self):
        return self.type.element

    @property
    def data_format(self):
        from cannbot_dsl.tensor import LayoutMapKind, _physical_format_for_map

        memref_ty = cannir.TensorType(self.type.element)
        return _physical_format_for_map(LayoutMapKind(memref_ty.layout_map_kind))


class RingBuffer:
    """A depth-N slot pool with independent advancing cursors.

    ``next_write()`` selects ``slots[head]`` and advances head modulo depth;
    ``next_read()`` does the same for tail. Both start at zero whenever the
    declaration executes. The result is a Tensor bound to the declared layout.
    Use from_tensor to bind another layout. Each result keeps its selected slot, even
    after further selections. Overwriting that slot is visible to old aliases.
    """

    def __init_subclass__(cls, **kwargs):
        del cls, kwargs
        raise TypeError("RingBuffer is a sealed CANNBotDSL resource type")

    def __init__(
        self,
        mem_loc,
        dtype,
        layout,
        *,
        depth,
        physical_layout=None,
        data_format=None,
    ):
        from cannbot_dsl.buffer import Buffer

        if mem_loc not in _CUBE_MEM_LOCS and mem_loc != MemLoc.UB:
            raise CANNBotValueError(
                DiagnosticCode.UNSUPPORTED_FEATURE, f"unsupported mem_loc for ring_buffer: {mem_loc!r}"
            )
        if not is_exact_instance(depth, int):
            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "RingBuffer depth must be a compile-time Python int")
        if depth < 1:
            raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "RingBuffer depth must be >= 1")
        tensors = tuple(
            Buffer(mem_loc, dtype, layout,
                   physical_layout=physical_layout, data_format=data_format)
            for _ in range(depth)
        )
        self._depth, self._mem_loc = depth, mem_loc
        self._logical_layout_value = unwrap_operand(layout)
        self._physical_layout_value = unwrap_operand(physical_layout) if physical_layout is not None else None
        self._layout_ir_value = unwrap_operand(tensors[0])
        self._slot_storage_values = tuple(unwrap_operand(tensor) for tensor in tensors)
        self._resource = cannir.RingBufferResourceOp.build_generic(results=[ir.NoneType.get()], operands=[]).results[0]
        bound = []
        for index, value in enumerate(self._slot_storage_values):
            slot = cannir.RingBufferSlotOp.build_generic(
                results=[value.type],
                operands=[value, self._resource],
                attributes={"slot": ir.IntegerAttr.get(ir.IntegerType.get_signless(64), index)},
            )
            bound.append(unwrap_operand(slot.results[0]))
        self._root_ir_value = cannir.MakeRingBufferOp.build_generic(operands=bound).results[0]
        self._ir_value = self._root_ir_value

    def _declared_type(self):
        type = self._layout_ir_value.type
        return cannir.TensorType(type)

    def _select(self, operation):
        from cannbot_dsl.lang.vf import _current_vf_mode

        if _current_vf_mode() is not None:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT,
                "RingBuffer cursors must be advanced outside VF regions; pass a selected Tensor into the VF"
            )
        selected = unwrap_operand(operation(self._root_ir_value).res)
        # Selection carries the slot address. Bind the declared layout SSA
        # explicitly so runtime dimensions survive cursor normalization.
        default_view = cannir.make_tensor(
            self._layout_ir_value.type, cannir.extract_pointer(selected),
            self._logical_layout_value, physical_layout=self._physical_layout_value,
            map_symbols=[],
        )
        if self._physical_layout_value is not None:
            unwrap_operand(default_view).owner.attributes["cannir.explicit_physical_layout"] = ir.UnitAttr.get()
        return Tensor._from_ir(unwrap_operand(default_view))

    def next_write(self) -> Tensor:
        """Select the current head slot, then advance head modulo depth.

        Return the selected Tensor with its declared layout.
        A one-dimensional uint8 layout reserves byte storage. The result captures
        storage, not a snapshot or a lease. Selection neither accesses storage
        nor waits for another operation.
        """
        return self._select(cannir.RingBufferNextWriteOp)

    def next_read(self) -> Tensor:
        """Select the current tail slot, then advance tail modulo depth.

        Return the selected Tensor with its declared layout.
        The declared view does not change to match the latest write. No pairing
        or FIFO full/empty checks are performed.
        """
        return self._select(cannir.RingBufferNextReadOp)

    @property
    def dtype(self):
        memref_ty = self._declared_type()
        from cannbot_dsl.core.contracts.elements import dtype_for_storage_mlir_type

        return dtype_for_storage_mlir_type(cannir.PointerType(memref_ty.pointer).dtype)

    def _declared_view(self):
        self._declared_type()
        return Tensor._from_ir(self._layout_ir_value)

    @property
    def layout(self):
        return self._declared_view().layout

    @property
    def physical_layout(self):
        return self._declared_view().physical_layout

    @property
    def shape(self):
        return self.layout.shape

    @property
    def stride(self):
        return self.layout.stride

    @property
    def memloc(self):
        return self._mem_loc

    @property
    def data_format(self):
        return self._declared_view().data_format

    @property
    def depth(self):
        return self._ir_value.type.depth

    def __repr__(self):
        return f"RingBuffer({self.memloc}, {self.shape}, {self.dtype}, depth={self.depth})"


def make_ring_buffer(tensors) -> RingBuffer:
    """Create a RingBuffer from unbound static on-chip space Tensors.

    Slots may have different origins, but must have identical Tensor types.
    Bound resources cannot be transferred into a RingBuffer.
    Each slot keeps its input dtype and layout. To reinterpret an element type,
    call ``view(dtype)`` on the Tensor returned by ``next_write()`` or
    ``next_read()``.
    """
    from cannbot_dsl.buffer import (
        _ensure_static_view,
        _find_space_root,
        _has_bound_resource,
    )

    if not isinstance(tensors, (list, tuple)) or not tensors:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT, "make_ring_buffer requires a non-empty list or tuple of views"
        )
    slots = []
    for tensor in tensors:
        if not isinstance(tensor, Tensor) or _find_space_root(tensor) is None:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT, "make_ring_buffer requires views derived from an on-chip space view()"
            )
        if tensor.memloc not in _CUBE_MEM_LOCS and tensor.memloc != MemLoc.UB:
            raise CANNBotValueError(
                DiagnosticCode.UNSUPPORTED_FEATURE, f"unsupported mem_loc for ring_buffer: {tensor.memloc!r}"
            )
        if _has_bound_resource(tensor):
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT,
                "make_ring_buffer requires unbound views; Buffer ownership transfer is not supported",
            )
        _ensure_static_view(tensor)
        if slots and unwrap_operand(tensor).type != unwrap_operand(slots[0]).type:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE,
                "make_ring_buffer slots must have identical dtype, shape, stride and layout",
            )
        slots.append(tensor)

    ch = object.__new__(RingBuffer)
    ch._depth = len(slots)
    ch._mem_loc = slots[0].memloc
    ch._logical_layout_value = unwrap_operand(slots[0].layout)
    ch._physical_layout_value = unwrap_operand(slots[0].physical_layout)
    ch._resource = cannir.RingBufferResourceOp.build_generic(results=[ir.NoneType.get()], operands=[]).results[0]
    # Capture each resource window as-is. A rank-1 byte cast would expose its
    # bounding span as packed storage and lose the bank gaps.
    ch._slot_storage_values = tuple(unwrap_operand(slot) for slot in slots)
    bound = []
    for index, slot in enumerate(ch._slot_storage_values):
        marker = cannir.RingBufferSlotOp.build_generic(
            results=[unwrap_operand(slot).type],
            operands=[unwrap_operand(slot), getattr(ch, "_resource")],
            attributes={
                "slot": ir.IntegerAttr.get(ir.IntegerType.get_signless(64), index),
                "cannir.buffer.explicit_binding": ir.UnitAttr.get(),
            },
        ).results[0]
        bound.append(unwrap_operand(marker))
    op = cannir.MakeRingBufferOp.build_generic(operands=bound)
    ch._ir_value = ch._root_ir_value = op.results[0]
    from cannbot_dsl.tensor import _raw

    ch._layout_ir_value = _raw(slots[0])
    return ch
