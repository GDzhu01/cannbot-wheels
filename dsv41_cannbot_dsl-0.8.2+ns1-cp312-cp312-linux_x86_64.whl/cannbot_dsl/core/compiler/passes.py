# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""MLIR ``PassManager`` wrapper for the CANNIR pipeline.

The pipeline string is driven by ``CANNBOTDSL_CANNIR_PIPELINE``. Invalid
pipelines fail before execution; no substitute pipeline changes the contract.

Lives next to :mod:`cannbot_dsl.core.compiler.builder` because the build
orchestrator is its only caller (JIT enters through builder as well).
"""

import logging

import cannbot_dsl._mlir.ir as ir
from cannbot_dsl._mlir import passmanager as pm

from cannbot_dsl.core.utils.timer import timer as _timer

_LOG = logging.getLogger(__name__)


@_timer("transform:run_ir_passes")
def _run_cannir_passes(module: ir.Module) -> None:
    """Run CANNIR/MLIR passes on the module using the MLIR Python PassManager."""
    # The pipeline can be overridden through CANNBOTDSL_CANNIR_PIPELINE; for
    # example, its value can be ``builtin.module(canonicalize,cse)``.
    from cannbot_dsl.core.utils.env import env

    _env = env()
    print_mlir = _env.print_mlir
    pipeline = _env.cannir_pipeline
    ir.Context.current.enable_multithreading(False)

    # Logged before parsing so caplog-based tests can inspect the pre-pass
    # module when pipeline parsing fails.
    if _LOG.isEnabledFor(logging.DEBUG):
        _LOG.debug("Original module before passes:\n%s", str(module))

    pmgr = None
    try:
        pmgr = pm.PassManager.parse(pipeline)
        if print_mlir:
            pmgr.enable_ir_printing()
    except Exception as e:
        raise RuntimeError(f"Failed to parse pass pipeline '{pipeline}': {e}") from e

    try:
        pmgr.run(module.operation)
    except Exception as e:
        if _LOG.isEnabledFor(logging.DEBUG):
            _LOG.debug("Module before failed pass run:\n%s", str(module))
        raise RuntimeError(f"Failed to run pass pipeline '{pipeline}': {e}") from e

    # Snapshot string: ``module`` is mutated in place by the pipeline; logging
    # may defer ``%`` formatting until handlers run, so pass a plain string.
    if _LOG.isEnabledFor(logging.DEBUG):
        module_text = str(module)
        _LOG.debug("Original module after passes:\n%s", module_text)
        _LOG.debug("Module after pass pipeline '%s':\n%s", pipeline, module_text)


# Versioned independently of the configurable optimization pipeline; also part
# of cache/native binary identity so old artifacts cannot bypass new contracts.
ARRAY_CONTRACT_VERSION = 3


def _verify_array_contracts(module: ir.Module) -> None:
    pm.PassManager.parse("builtin.module(cannir-verify-array-contracts)").run(module.operation)
