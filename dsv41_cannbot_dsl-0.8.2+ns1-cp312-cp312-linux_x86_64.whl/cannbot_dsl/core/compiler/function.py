# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""The sole reusable runtime program object."""

from __future__ import annotations

import logging
import os
import shutil

from cannbot_dsl.core.compiler.abi import HOST_ABI_VERSION
from cannbot_dsl.core.compiler.parameter_lowering import ParameterLoweringPlan
from cannbot_dsl.core.compiler import runtime_bridge
from cannbot_dsl.core.contracts.codec import contract_digest
from cannbot_dsl.core.contracts.model import CallContract
from cannbot_dsl.core.mlir_context import _has_current_context
from cannbot_dsl.core.diag.diagnostics import (
    ABI101_RUNTIME_ARGUMENT_REJECTED,
    CANNBotError,
    CANNBotTypeError,
    CANNBotValueError,
)


_LOG = logging.getLogger(__name__)
_FACTORY_TOKEN = object()


def _raise_provider_argument_error(exc: TypeError | ValueError):
    error_type = CANNBotTypeError if isinstance(exc, TypeError) else CANNBotValueError
    raise error_type(
        ABI101_RUNTIME_ARGUMENT_REJECTED,
        str(exc),
        phase="host-abi",
        path="ProviderCallable invocation",
        hint="Pass values matching the callable signature and persisted host ABI contract.",
    ) from exc


class _BenchmarkInvocation:
    """Opaque benchmark-only owner of one prefilled native invocation."""

    __slots__ = ("__bound",)

    def __init__(self, bound) -> None:
        self.__bound = bound

    def invoke(self) -> None:
        self.__bound.invoke()


class _BenchmarkResolution:
    """Opaque per-call benchmark state; native leases are never returned."""

    __slots__ = (
        "__plan",
        "__lease",
        "__stream",
        "__physical",
        "__private_layouts",
        "__exports",
    )

    def __init__(self, plan, lease, stream, physical, private_layouts, exports) -> None:
        self.__plan = plan
        self.__lease = lease
        self.__stream = stream
        self.__physical = physical
        self.__private_layouts = private_layouts
        self.__exports = exports

    def _bind(self, plan) -> _BenchmarkInvocation:
        if plan is not self.__plan:
            raise ValueError("benchmark resolution belongs to another callable")
        bound = getattr(plan, "_benchmark_bind")(
            self.__lease,
            self.__stream,
            self.__physical,
            self.__exports,
            self.__private_layouts or None,
        )
        return _BenchmarkInvocation(bound)


def _remove_owned_artifact(path: str) -> None:
    if not path:
        return
    try:
        if os.path.exists(path):
            os.unlink(path)
    except OSError as error:
        _LOG.debug("Failed to unlink %s: %s", path, error)
    parent = os.path.dirname(path)
    if parent and os.path.basename(parent).startswith("cannbotdsl_aot_"):
        shutil.rmtree(parent, ignore_errors=True)


class ProviderCallable:
    """Reusable synchronous host program for provider-owned tensors."""

    def __init__(self, *args, **kwargs):
        if kwargs.pop("_factory_token", None) is not _FACTORY_TOKEN:
            raise TypeError(
                "ProviderCallable objects are created by cannbot_dsl.compile(), "
                "direct @host execution, or cannbot_dsl.load()"
            )
        self._initialize(*args, **kwargs)

    def __call__(self, *args, **kwargs) -> None:
        # Capture the native plan before semantic binding. close() prevents new
        # calls but an invocation that has crossed this boundary owns the local
        # strong reference it needs to finish synchronously.
        try:
            plan = self._acquire_plan()
            physical = self._physical_values(args, kwargs)
            tensor_items = self._parameter_lowering.provider_tensor_items(physical)
            runtime_bridge.invoke_provider_call(
                plan,
                physical,
                tensor_items,
                self._debug_plans,
                struct_ref_items=self._struct_ref_items(physical),
                expected_contracts=(self._parameter_lowering.provider_tensor_contract_items(physical)),
            )
        except (TypeError, ValueError) as exc:
            if isinstance(exc, CANNBotError):
                raise
            _raise_provider_argument_error(exc)

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def __enter__(self) -> "ProviderCallable":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.close()

    def __repr__(self) -> str:
        state = "closed" if self._closed else ("stub" if self._noop else "live")
        return (
            f"ProviderCallable(symbol={self._symbol_name!r}, "
            f"so_path={self._so_path!r}, host_abi_version="
            f"{self._host_abi_version}, contract={self._contract_digest[:16]}, "
            f"state={state})"
        )

    @classmethod
    def _create(
        cls,
        so_path: str,
        symbol_name: str,
        contract: CallContract,
        *,
        host_abi_version: int,
        owns_so: bool = True,
        debug_plans=(),
        content_key: str = "",
        format_version_tag: str = "",
        resource_roots: tuple[str, ...] | None = None,
    ) -> "ProviderCallable":
        try:
            return cls(
                so_path,
                symbol_name,
                contract,
                host_abi_version=host_abi_version,
                owns_so=owns_so,
                debug_plans=debug_plans,
                content_key=content_key,
                format_version_tag=format_version_tag,
                resource_roots=resource_roots,
                _factory_token=_FACTORY_TOKEN,
            )
        except BaseException:
            if owns_so:
                _remove_owned_artifact(so_path)
            raise

    @classmethod
    def _make_noop(
        cls,
        symbol_name: str,
        contract: CallContract,
    ) -> "ProviderCallable":
        instance = cls.__new__(cls)
        instance._initialize_common(
            "",
            symbol_name,
            contract,
            host_abi_version=HOST_ABI_VERSION,
            owns_so=False,
            debug_plans=(),
            content_key="",
            format_version_tag="",
        )
        instance._program_image = None
        instance._host_call_plan = None
        instance._noop = True
        return instance

    @property
    def so_path(self) -> str:
        return self._so_path

    @property
    def symbol_name(self) -> str:
        return self._symbol_name

    @property
    def host_abi_version(self) -> int:
        return self._host_abi_version

    @property
    def contract_digest(self) -> str:
        return self._contract_digest

    @property
    def closed(self) -> bool:
        return self._closed

    def save(self, dst_path: str) -> str:
        if self._resource_roots is not None:
            raise RuntimeError(
                "OPP ProviderCallable depends on installed resources and cannot be saved as a standalone artifact"
            )
        if self._debug_plans:
            raise RuntimeError("debug-bearing ProviderCallable cannot be saved")
        if self._noop:
            raise RuntimeError("Cannot save a stub ProviderCallable (no .so was produced)")
        if self._closed:
            raise RuntimeError("Cannot save a closed ProviderCallable")
        if not self._so_path or not os.path.exists(self._so_path):
            raise RuntimeError(f"ProviderCallable .so not found at {self._so_path!r}")
        if os.path.isdir(dst_path):
            dst_path = os.path.join(dst_path, f"{self._symbol_name}.so")
        from cannbot_dsl.core.compiler import metadata

        return metadata.publish_artifact(
            self._so_path,
            dst_path,
            self._symbol_name,
            self._contract,
            host_abi_version=self._host_abi_version,
            content_key=self._content_key,
            format_version_tag=self._format_version_tag,
        )

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        # In-flight calls hold local Python references to the native plan,
        # ProgramImage, exchange lease, stream owner, and frame.
        self._host_call_plan = None
        self._program_image = None
        if self._owns_so and self._owner_pid == os.getpid():
            _remove_owned_artifact(self._so_path)

    def _initialize_common(
        self,
        so_path,
        symbol_name,
        contract,
        *,
        host_abi_version,
        owns_so,
        debug_plans,
        content_key,
        format_version_tag,
        resource_roots=None,
    ) -> None:
        if host_abi_version != HOST_ABI_VERSION:
            raise ValueError(
                f"artifact uses host ABI {host_abi_version}; runtime requires "
                f"ABI {HOST_ABI_VERSION}. Recompile the artifact."
            )
        if not isinstance(contract, CallContract):
            raise TypeError("ProviderCallable requires a CallContract")
        if contract.host_abi_version != host_abi_version:
            raise ValueError(
                f"call contract host ABI {contract.host_abi_version} does not match binary host ABI {host_abi_version}"
            )

        lowering = ParameterLoweringPlan(contract)
        if not lowering.layout.provider_slot_indices:
            raise TypeError(
                "ProviderCallable requires at least one canonical "
                "TensorContract, TensorListContract, or StructRefContract leaf"
            )

        self._so_path = str(so_path)
        self._symbol_name = str(symbol_name)
        self._contract = contract
        self._contract_digest = contract_digest(contract)
        self._host_abi_version = int(host_abi_version)
        self._parameter_lowering = lowering
        self._layout = lowering.layout
        self.__signature__ = lowering.signature
        self._debug_plans = tuple(debug_plans or ())
        self._content_key = str(content_key)
        self._format_version_tag = str(format_version_tag)
        self._resource_roots = resource_roots
        self._owns_so = bool(owns_so)
        self._owner_pid = os.getpid()
        self._closed = False
        self._noop = False

    def _initialize(self, *args, **kwargs) -> None:
        self._initialize_common(*args, **kwargs)
        from cannbot_dsl.core.compiler.host_schema import build_host_program_spec

        native = runtime_bridge.host_native(required=True)
        host_program_spec = build_host_program_spec(
            self._contract,
            self._parameter_lowering.ctypes_types(),
            self._debug_plans,
        )
        self._host_program_spec = host_program_spec
        program_image = native.ProgramImage(
            self._so_path,
            self._symbol_name,
            host_program_spec.to_native(),
        )
        host_call_plan = native.HostCallPlan(program_image)
        if host_call_plan.public_slot_count != self._layout.public_slot_count:
            raise RuntimeError("native/public physical slot count is inconsistent")
        if host_call_plan.slot_count != len(host_program_spec.schema_slots):
            raise RuntimeError("native/full physical slot count is inconsistent")
        self._program_image = program_image
        self._host_call_plan = host_call_plan

    def _acquire_plan(self):
        if self._resource_roots is not None:
            from cannbot_dsl.aot.runtime import _validate_opp_environment

            _validate_opp_environment(self._resource_roots)
        if self._closed:
            raise RuntimeError("ProviderCallable is closed")
        if self._noop:
            raise RuntimeError(
                "ProviderCallable is a stub (CANNBOTDSL_PIPE_STAGE early-exit); "
                "unset CANNBOTDSL_PIPE_STAGE to enable execution"
            )
        if _has_current_context():
            raise RuntimeError(
                "ProviderCallable cannot execute during DSL/MLIR tracing; "
                "call the @host entry or compiled program from ordinary Python"
            )
        plan = self._host_call_plan
        if plan is None:
            raise RuntimeError("ProviderCallable is closed")
        return plan

    def _physical_values(self, args, kwargs):
        return self._parameter_lowering.bind_physical(args, kwargs)

    def _struct_ref_items(self, physical):
        return tuple(
            (
                self._layout.physical_slot_names[index],
                physical[index],
                int(self._parameter_lowering.abi_arguments[index].schema.size),
            )
            for index in self._layout.struct_ref_indices
        )

    def _benchmark_resolve(self, *args, **kwargs):
        """Benchmark-only provider-resolution boundary."""

        try:
            plan = self._acquire_plan()
            physical = self._physical_values(args, kwargs)
            tensor_items = self._parameter_lowering.provider_tensor_items(physical)
            lease, stream, _, private_layouts, exports = runtime_bridge.resolve_provider_call(
                plan,
                physical,
                tensor_items,
                self._struct_ref_items(physical),
                expected_contracts=(self._parameter_lowering.provider_tensor_contract_items(physical)),
            )
            return _BenchmarkResolution(plan, lease, stream, physical, private_layouts, exports)
        except (TypeError, ValueError) as exc:
            if isinstance(exc, CANNBotError):
                raise
            _raise_provider_argument_error(exc)

    def _benchmark_bind(self, resolution):
        """Benchmark-only physical bind/guard boundary."""

        plan = self._acquire_plan()
        if not isinstance(resolution, _BenchmarkResolution):
            raise TypeError("_benchmark_bind() requires this callable's resolution")
        return getattr(resolution, "_bind")(plan)


__all__ = ["ProviderCallable"]
