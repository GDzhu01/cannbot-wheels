# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Explicit Native matching identity; independent of compilation cache identity."""

import hashlib
import io
import json
import platform
import struct
import subprocess

BINARY_KEY_SCHEMA = 1


def _json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def normalized_ir(module):
    """Strip all debug locations on a clone using MLIR's recursive pass."""
    from cannbot_dsl._mlir.passmanager import PassManager

    clone = module.operation.clone()
    PassManager.parse("builtin.module(strip-debuginfo)").run(clone)
    buffer = io.BytesIO()
    clone.operation.write_bytecode(buffer)
    return buffer.getvalue()


def compute_binary_key(module, *, contract, target, pipeline, barall):
    from cannbot_dsl.core.contracts.codec import canonical_contract_bytes

    # Reject invalid pipelines rather than claiming the requested pipeline ran.
    from cannbot_dsl._mlir.passmanager import PassManager

    PassManager.parse(pipeline)
    ir_bytes = normalized_ir(module)
    contract_bytes = canonical_contract_bytes(contract)
    from cannbot_dsl.core.compiler.passes import ARRAY_CONTRACT_VERSION

    options = {"barall": bool(barall), "array_contract_version": ARRAY_CONTRACT_VERSION}
    attrs = module.operation.attributes
    config = attrs["cannir.superkernel"] if "cannir.superkernel" in attrs else None
    if config is not None:
        from cannbot_dsl.core.compiler.superkernel import SuperKernelOptions

        sk_options = SuperKernelOptions(
            enabled=config["enabled"].value,
            num_variants=config["num_variants"].value,
        )
        options.update(sk_options.native_compile_options)
    parts = (
        ("schema", b"cannbotdsl-native-binary-v1"),
        ("verified-ir", ir_bytes),
        ("call-contract", contract_bytes),
        ("target", target.encode()),
        ("backend-pipeline", pipeline.encode()),
        ("codegen-options", _json(options)),
    )
    digest = hashlib.sha256()
    for name, payload in parts:
        name = name.encode()
        digest.update(struct.pack(">I", len(name)) + name)
        digest.update(struct.pack(">Q", len(payload)) + payload)
    return digest.hexdigest(), {
        "verified_ir_sha256": hashlib.sha256(ir_bytes).hexdigest(),
        "call_contract_sha256": hashlib.sha256(contract_bytes).hexdigest(),
        "backend_pipeline": pipeline,
        "codegen_options": options,
    }


def host_platform():
    return {"os": platform.system().lower(), "arch": platform.machine()}


def build_provenance():
    from cannbot_dsl import __version__
    from cannbot_dsl.core.compiler.cache_key import _cann_release_identity, _toolchain_version
    from cannbot_dsl.core.toolchain.ascendc import resolve_bisheng

    resolution = resolve_bisheng(required=False)
    details = {"cann": _cann_release_identity(resolution.ascend_home)}
    if resolution.path:
        try:
            result = subprocess.run(
                [resolution.path, "--version"], capture_output=True, text=True, timeout=60, check=False
            )
            details["bisheng"] = (result.stdout or result.stderr).strip()
        except (OSError, subprocess.SubprocessError) as exc:
            details["bisheng_probe_error"] = type(exc).__name__
    return {
        "version": __version__,
        "toolchain_identity": _toolchain_version(),
        "toolchain_details": details,
    }
