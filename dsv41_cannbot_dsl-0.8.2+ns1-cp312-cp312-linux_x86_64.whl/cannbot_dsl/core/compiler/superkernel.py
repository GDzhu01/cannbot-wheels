# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.


"""Explicit, immutable SuperKernel export options for one compilation."""

from collections.abc import Mapping
from dataclasses import dataclass

_ENABLE = "superkernel_enable"
_VARIANTS = "superkernel_num_variants"
_DCCI = "superkernel_disable_dcci"


@dataclass(frozen=True)
class SuperKernelOptions:
    enabled: bool = False
    num_variants: int = 4
    disable_dcci: bool = False

    @property
    def native_compile_options(self):
        if self.enabled:
            return {"disable_function_merging": True}
        return {}

    @classmethod
    def parse(cls, configs=None):
        if configs is None:
            return cls()
        if not isinstance(configs, Mapping):
            raise TypeError("sk_configs must be a mapping")
        unknown = set(configs) - {_ENABLE, _VARIANTS, _DCCI}
        if unknown:
            raise ValueError(f"Unknown compile sk_configs: {sorted(unknown, key=str)!r}")
        enabled = configs.get(_ENABLE, False)
        variants = configs.get(_VARIANTS, 4)
        dcci = configs.get(_DCCI, False)
        if not isinstance(enabled, bool) or not isinstance(dcci, bool):
            raise TypeError("superkernel_enable and superkernel_disable_dcci must be bool")
        if isinstance(variants, bool) or not isinstance(variants, int) or not 1 <= variants <= 4:
            raise ValueError("superkernel_num_variants must be an integer in [1, 4]")
        if not enabled and (_VARIANTS in configs or _DCCI in configs):
            raise ValueError("SuperKernel-specific options require superkernel_enable=True")
        return cls(enabled, variants, dcci)

    def apply(self, module):
        if not self.enabled:
            return
        from cannbot_dsl._mlir import ir

        module.operation.attributes["cannir.superkernel"] = ir.DictAttr.get(
            {
                "enabled": ir.BoolAttr.get(True),
                "num_variants": ir.IntegerAttr.get(ir.IntegerType.get_signless(64), self.num_variants),
                "disable_dcci": ir.BoolAttr.get(self.disable_dcci),
            }
        )
