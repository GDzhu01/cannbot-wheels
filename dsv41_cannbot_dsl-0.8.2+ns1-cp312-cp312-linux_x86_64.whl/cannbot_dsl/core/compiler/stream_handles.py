# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
from __future__ import annotations

import ctypes


def as_stream_handle(raw) -> int:
    """Normalize a provider stream handle to a validated non-negative integer."""
    if isinstance(raw, ctypes.c_void_p):
        raw = raw.value
    if isinstance(raw, bool):
        raise TypeError("provider stream handle must be an integer pointer")
    try:
        handle = int(raw or 0)
    except (TypeError, ValueError, OverflowError) as error:
        raise TypeError("provider stream handle must be an integer pointer") from error
    if handle < 0:
        raise ValueError("provider stream handle must be non-negative")
    return handle
