# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Cache key computation shared by JIT and AOT compile paths.

The post-trace IR bytecode is the primary cache-key input.
The orchestration lives in ``builder.compile_to_artifact``; this file
exposes only the key-composition pieces so the lookup point can be a
single ``_cache.lookup(_compute_key(module))`` call from the builder.

Key composition uses length-prefixed named sections for verified IR, the
canonical call contract, a canonical environment snapshot, frontend/backend
options, target, runtime identity, toolchain identity, and cache
format tags.

The IR bytecode subsumes source body, helper edits, closure values, and
bound-instance attribute reads. The independent call-contract section
retains dynamic dimension identity, constraints, and expression relations
that all lower to the same dynamic IR slots. The env snapshot catches backend-affecting
inputs that don't transit through IR (for example, an explicit pipeline
override). The toolchain section is an additional
best-effort invalidation input; its current coverage is documented in
``docs/design/compile_cache.md``.

Both the runtime and toolchain sections are **content-derived, not
path-derived**, so a disk cache stays shareable across machines that
install the same CANN release and the same wheel at different prefixes
or at different times. Installed contents use standard RECORD hashes. Editable
Python sources and extension headers are read on every lookup so edits with
preserved timestamps also invalidate. Toolchain probes alone use stat-stamped
memoization — see :func:`_stamped_digest`.

Observability and source-reuse flags are omitted from the key because
those modes bypass both cache tiers entirely.
"""

import base64
import hashlib
import io
import json
import logging
import os
import struct
import subprocess
from enum import Enum
from importlib import metadata as importlib_metadata
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Dict, Optional, Tuple
from urllib.parse import urlparse
from urllib.request import url2pathname

import cannbot_dsl._mlir.ir as ir
from cannbot_dsl.core.utils.type_checks import is_exact_instance, is_exact_instance_of

_LOG = logging.getLogger(__name__)


# Bump (via env var or this constant) when the cache layout or hash
# composition changes such that any existing entry must be considered
# stale. Users hit ``CANNBOTDSL_CACHE_FORMAT_TAG`` for ad-hoc invalidation
# without redeploying; developers bump ``_FORMAT_VERSION_TAG`` for a
# global one-shot bust.
#
# v17: contract schema v3 and sidecar v11 retain only the standard call
# contract paths while preserving the physical Host ABI v9 layout.
# v18: contract schema v4 and sidecar v12 add provider-backed StructRef
# schemas while preserving the physical Host ABI v9 layout.
# v19: contract schema v5 and sidecar v13 add runtime-dynamic TensorList
# contracts and their asynchronous descriptor-staging ABI projection.
# v20: contract schema v6, sidecar v14, and TensorList descriptor v2 add
# per-element AOT template binding and positional heterogeneous JIT layouts
# while preserving the physical Host ABI v9 layout.
# v21: lossless integer promotion and index normalization change generated IR;
# Host ABI v9, contract schema v6, and sidecar v14 remain unchanged.
# v22: reinterpret access-window normalization and internal storage casts.
# v23: integrate aligned tilers, DualParam access metadata, and slot pitch.
# v24: static copy descriptors, runtime controls, unified scale and block mapping.
# v25: preserve parent L1 pitches for formatted subwindows and FIXPIPE tails.
# v26: propagate UB copy access extents; keep page offsets independent of pitch.
# v27: explicit Channel cursor SSA, Tensor slot identities and automatic
# same-core Buffer synchronization replace implicit same-core transactions.
# v28: unify L1 full and tail tiles on declared pitch.
# v29: restrict Native provider exports to the three Host ABI entry points.
# v30: pass emitted kernel task type and MIX ratio through profiling callbacks.
# v31: use the current SDK VF debug header and TLV publication protocol.
# v32: select the VF dump protocol from the SDK header layout, including legacy CANN.
# v33: pass the dynamically queried debug-buffer address from scalar code into VFs.
# v34: shared AscDataType element formats replace CANNIR-owned dtype identities.
# v35: standard distribution RECORD plus live editable sources replace build metadata.
# v36: first-class TensorView expressions and consumption-time copy reads.
# v39: RingBuffer selects its declared TensorView unless bare=True is explicit.
# v43: Preserve selected view addresses across heterogeneous backing extents.
# v44: Buffer defaults to a View; explicit Storage and binding provenance cross SSA boundaries.
# v45: NDDMA is an explicit copy_options(engine="nddma") selection, never layout-inferred.
# v46: explicit View metadata, composed index maps and safe empty tile extents.
# v47: explicit pitch policies, i64 logical padding, composed NZ windows;
# remove the copy engine tail-alignment field.
# v57: typed scale NZ plans, explicit paired address maps and result metadata refinement.
# v95: zero inactive GM2UB/UB2GM burst strides at instruction emission.
# v96: allocation handles, canonical memory bindings and IR-owned allocation modes.
# v97: reinterpret binds explicit logical/physical Layout operands and runtime byte offsets.
# v98: opaque Buffer identities are lowered separately from hardware mutex IDs.
# v99: Layout-only bindings and aligned dynamic paired-encoding extents.
# v100: explicit Tensor bindings replace Storage; view capacity is caller-owned.
_FORMAT_VERSION_TAG = "cannbotdsl-cache-v100"


# Env fields that do NOT affect the .so contents. Observability /
# pipeline-staging / source-reuse flags only — everything else in the
# env snapshot is folded into the key. Black-list (rather than
# white-list) so new env fields default to "affects key", which is the
# safe direction: a stale cache miss is harmless, a stale cache hit is
# a correctness bug.
#
# ``debug_asc_sync`` is the one entry here that is NOT a
# doesn't-affect-the-artifact flag. It is the raw spelling of
# ``CANNBOTDSL_DEBUG_ASC_SYNC``, which the same snapshot already carries
# fully decoded as ``debug_asc_pipe_sync`` / ``debug_asc_vf_sync`` — and
# those two ARE keyed. Keying the raw string as well only splits the
# cache across spellings of one setting: "all", "pipe,vf" and "vf,pipe"
# are the same request and used to produce three keys for one artifact.
# Nothing outside the key ever reads it (env.py only stores and passes
# it through). Do not read this as licence to add flags here: the test
# is "some other keyed field already determines this one", not "I don't
# think it matters".
_KEY_IGNORED_ENV = frozenset(
    {
        "dump_dir",
        "dump_mlir",
        "dump_ascendc",
        "reuse_ascendc",
        "print_mlir",
        "print_ascendc",
        "pipe_stage",
        "jit_time_profiling",
        "debug_asc_sync",
    }
)


# ---------------------------------------------------------------------------
# Stat-stamped memoization
# ---------------------------------------------------------------------------

# Toolchain probes only: ``(path, producer) -> ((mtime_ns, size), digest)``.
# Runtime source/header contents deliberately bypass this memoization.
_STAMPED_DIGESTS: Dict[Tuple[str, str], Tuple[Tuple[int, int], str]] = {}


def _file_stamp(path: str) -> Optional[Tuple[int, int]]:
    """``(mtime_ns, size)`` for ``path``, or ``None`` if it can't be stat-ed."""
    try:
        st = os.stat(path)
    except OSError:
        result = None
    else:
        result = (st.st_mtime_ns, st.st_size)
    return result


def _stamped_digest(path: str, produce: Callable[[str], bytes]) -> str:
    """Digest of ``produce(path)``, memoized on the file's ``(mtime_ns, size)``.

    Falls back to computing without memoizing when the path cannot be
    stat-ed, so a caller that hands over a virtual/packaged resource
    still gets a correct (just uncached) answer. ``produce`` is part of
    the memo key so two readings of the same file don't alias.
    """
    memo_key = (path, produce.__name__)
    stamp = _file_stamp(path)
    if stamp is not None:
        cached = _STAMPED_DIGESTS.get(memo_key)
        if cached is not None and cached[0] == stamp:
            return cached[1]
    digest = hashlib.blake2b(produce(path), digest_size=16).hexdigest()
    if stamp is not None:
        _STAMPED_DIGESTS[memo_key] = (stamp, digest)
    return digest


# ---------------------------------------------------------------------------
# Toolchain identity
# ---------------------------------------------------------------------------


def _info_file_fields(path: str, keys: Tuple[str, ...]) -> Optional[str]:
    """Extract ``key=value`` lines from a CANN ``*.info`` file, in order."""
    try:
        text = Path(path).read_text(encoding="utf-8", errors="replace")
    except OSError:
        result = None
    else:
        found: Dict[str, str] = {}
        for line in text.splitlines():
            name, sep, value = line.partition("=")
            if sep and name.strip() in keys:
                found[name.strip()] = value.strip()
        result = ",".join(f"{key}={found[key]}" for key in keys if key in found) or None
    return result


def _cann_release_identity(ascend_home: Optional[str]) -> str:
    """Content-derived CANN release identity, or a machine-local fallback.

    ``ascend_toolkit_install.info`` carries ``version`` (e.g. ``9.2.0``)
    and ``innerversion`` (e.g. ``V100R001C11B104``) — the pair identifies
    one CANN build, independent of where it was unpacked. That matters
    because the AscendC headers under ``ASCEND_HOME_PATH`` feed every
    compile: the old key used the absolute install path, which made a
    shared disk cache miss on every machine.
    """
    if not ascend_home:
        return "<unset>"

    from cannbot_dsl.core.toolchain.ascendc import _host_sdk_directory

    candidates = []
    host_dir = _host_sdk_directory()
    if host_dir:
        candidates.append(
            (os.path.join(ascend_home, host_dir, "ascend_toolkit_install.info"), ("version", "innerversion"))
        )
    candidates.append((os.path.join(ascend_home, "compiler", "version.info"), ("Version",)))

    for path, keys in candidates:
        fields = _info_file_fields(path, keys)
        if fields:
            return fields

    # No release marker: degrade to a machine-local identity rather than
    # pretending two unidentified installs are the same one.
    return f"local-only:{ascend_home}"


def _bisheng_identity(path: str) -> str:
    """First line of ``bisheng --version``, memoized on ``(mtime_ns, size)``.

    That line carries the compiler build timestamp and the clang/flang
    commit ids, so it identifies the binary without hashing 150 MB (a
    full content hash measured ~1.75 s). Later lines are dropped because
    ``InstalledDir:`` leaks the absolute prefix.

    Any failure degrades to a machine-local stamp so a shared cache
    partitions per machine instead of colliding across compilers.
    """

    def produce(p: str) -> bytes:
        try:
            proc = subprocess.run(
                [p, "--version"],
                capture_output=True,
                text=True,
                timeout=60,
                check=False,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            _LOG.debug("bisheng --version failed (%s); using a machine-local stamp", exc)
            return f"local-only:{_file_stamp(p)}".encode("utf-8")
        first = (proc.stdout or proc.stderr or "").strip().splitlines()
        if proc.returncode != 0 or not first:
            _LOG.debug("bisheng --version returned no usable output; using a machine-local stamp")
            return f"local-only:{_file_stamp(p)}".encode("utf-8")
        return first[0].strip().encode("utf-8")

    return _stamped_digest(path, produce)


def _toolchain_version() -> str:
    """Lazy-probed toolchain identity string.

    Uses the same resolver as compilation. The resolver itself is
    intentionally not cached — tests and long-running build processes may
    change toolchain environment variables between compilations — but the
    per-binary probes behind it are memoized on ``(mtime_ns, size)``.
    """
    from cannbot_dsl.core.toolchain.ascendc import resolve_bisheng

    resolution = resolve_bisheng(required=False)
    parts = [f"cann={_cann_release_identity(resolution.ascend_home)}"]
    if resolution.path:
        stamp = _file_stamp(resolution.path)
        parts.append(f"bisheng_size={stamp[1] if stamp else '<stat-error>'}")
        parts.append(f"bisheng={_bisheng_identity(resolution.path)}")
    else:
        parts.append("bisheng=<not-found>")
    return "|".join(parts)


def _runtime_distribution():
    distribution = importlib_metadata.distribution("cannbot-dsl")
    if distribution.read_text("RECORD") is not None:
        return distribution

    # Running from a setuptools checkout can put its generated egg-info before
    # the installed dist-info. Only accept a distribution belonging
    # to the package actually imported, never an unrelated environment's copy.
    import cannbot_dsl

    source = Path(cannbot_dsl.__file__).resolve()
    for candidate in importlib_metadata.distributions(name="cannbot-dsl"):
        if candidate.read_text("RECORD") is None:
            continue
        if Path(candidate.locate_file("cannbotdsl/__init__.py")).resolve() == source:
            return candidate
        direct = json.loads(candidate.read_text("direct_url.json") or "{}")
        if not direct.get("dir_info", {}).get("editable", False):
            continue
        url = urlparse(direct.get("url", ""))
        if url.scheme != "file" or url.netloc not in {"", "localhost"}:
            continue
        project = Path(url2pathname(url.path)).resolve()
        if source.is_relative_to(project) and candidate.read_text("RECORD") is not None:
            return candidate
    return distribution


def _runtime_identity() -> str:
    """Hash installed RECORD contents, live editable Python and actual headers.

    No installation prefix or editable redirector enters the digest. Missing
    installation metadata raises so the caller logs the reason and disables
    caching for this compilation instead of sharing an unversioned identity.
    """
    distribution = _runtime_distribution()
    records = distribution.files
    if not distribution.version or not records:
        raise ValueError("cannbot-dsl runtime identity requires distribution version and RECORD")
    direct = json.loads(distribution.read_text("direct_url.json") or "{}")
    editable = direct.get("dir_info", {}).get("editable", False)
    contents = {}
    for entry in records:
        path = PurePosixPath(entry)
        if not path.parts or path.parts[0] not in {'cannbot_dsl', "cannbot_dsl.libs"}:
            continue
        if "__pycache__" in path.parts or path.suffix in {".pyc", ".pyo"}:
            continue
        if path.is_absolute() or ".." in path.parts or "\\" in str(entry) or str(path) in contents:
            raise ValueError(f"Invalid runtime RECORD path: {entry}")
        if not entry.hash or entry.hash.mode not in {"sha256", "sha384", "sha512"} or not entry.hash.value:
            raise ValueError(f"Missing runtime RECORD hash: {entry}")
        if not Path(distribution.locate_file(entry)).is_file():
            raise ValueError(f"Missing installed runtime file: {entry}")
        encoded = entry.hash.value
        digest = base64.b64decode(encoded + "=" * (-len(encoded) % 4), altchars=b"-_", validate=True)
        if len(digest) != hashlib.new(entry.hash.mode).digest_size:
            raise ValueError(f"Invalid runtime RECORD hash: {entry}")
        contents[str(path)] = (entry.hash.mode, digest.hex())
    if not any(name.endswith(".so") for name in contents):
        raise ValueError("cannbot-dsl RECORD has no native runtime")
    if editable:
        import cannbot_dsl

        # __file__ follows the actual import, including scikit-build's redirect.
        source = Path(cannbot_dsl.__file__).parent
        if not (source / "__init__.py").is_file():
            raise ValueError("Cannot locate editable cannbotdsl Python sources")
        for path in sorted(source.rglob("*.py")):
            relative = path.relative_to(source)
            if not {"__pycache__", "_mlir"}.intersection(relative.parts):
                contents["cannbotdsl/" + relative.as_posix()] = (
                    "sha256",
                    hashlib.sha256(path.read_bytes()).hexdigest(),
                )
    elif "cannbotdsl/__init__.py" not in contents:
        raise ValueError("cannbot-dsl RECORD has no Python package")

    from cannbot_dsl.core.toolchain.ascendc import asc_ext_include_dir

    extension_root = asc_ext_include_dir() / "asc_ext"
    headers = [
        (path.relative_to(extension_root).as_posix(), hashlib.sha256(path.read_bytes()).hexdigest())
        for path in sorted(extension_root.rglob("*"))
        if path.is_file()
    ]
    if not headers:
        raise ValueError("Cannot identify AscendC extension headers: no installed headers")
    hasher = _KeyComposer()
    hasher.add("version", distribution.version.encode("utf-8"))
    hasher.add("contents", json.dumps(sorted(contents.items()), separators=(",", ":")).encode("utf-8"))
    hasher.add("asc-ext-headers", json.dumps(headers, separators=(",", ":")).encode("utf-8"))
    return hasher.hexdigest()


def _env_snapshot() -> Dict[str, Any]:
    """Extract key-affecting fields from a fresh cannbotdsl env snapshot.

    Walks ``vars(env())`` and skips anything in ``_KEY_IGNORED_ENV``.
    """
    from cannbot_dsl.core.utils.env import env

    snap: Dict[str, Any] = {}
    for k, v in vars(env()).items():
        if k in _KEY_IGNORED_ENV:
            continue
        snap[k] = v
    return snap


class _KeyComposer:
    """Length-prefix named byte sections into one fixed-size digest."""

    def __init__(self) -> None:
        self._digest = hashlib.sha256()

    def add(self, name: str, payload: bytes) -> None:
        encoded_name = name.encode("utf-8")
        self._digest.update(struct.pack(">I", len(encoded_name)))
        self._digest.update(encoded_name)
        self._digest.update(struct.pack(">Q", len(payload)))
        self._digest.update(payload)

    def hexdigest(self) -> str:
        return self._digest.hexdigest()


def _stable_json_value(value: Any, *, path: str) -> Any:
    """Convert option-domain values to a path- and repr-free JSON tree."""

    if value is None or is_exact_instance_of(value, (bool, int, float, str)):
        return value
    if isinstance(value, Enum):
        value_type = type(value)
        return {
            "enum": f"{value_type.__module__}.{value_type.__qualname__}",
            "name": value.name,
        }
    if isinstance(value, (tuple, list)):
        return [_stable_json_value(item, path=f"{path}[{index}]") for index, item in enumerate(value)]
    if isinstance(value, (set, frozenset)):
        items = [_stable_json_value(item, path=f"{path}[]") for item in value]
        return sorted(
            items,
            key=lambda item: json.dumps(
                item,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ),
        )
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            if not is_exact_instance(key, str):
                raise TypeError(f"{path} option keys must be strings, got {key!r}")
            result[key] = _stable_json_value(item, path=f"{path}.{key}")
        return result
    raise TypeError(f"{path} contains unsupported option value {type(value).__name__}")


def _encode_options(snapshot: Dict[str, Any], *, path: str) -> bytes:
    if not isinstance(snapshot, dict):
        raise TypeError(f"{path} must be a dict")
    tree = _stable_json_value(snapshot, path=path)
    return json.dumps(
        tree,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _encode_env_snapshot(snapshot: Dict[str, Any]) -> bytes:
    """Encode an environment snapshot as canonical logical JSON."""

    return _encode_options(snapshot, path="environment")


def _compute_key(
    module: ir.Module,
    *,
    runtime_identity: str,
    contract=None,
    env_snapshot: Optional[Dict[str, Any]] = None,
    compile_options: Optional[Dict[str, Any]] = None,
    target: Optional[str] = None,
    toolchain: Optional[str] = None,
) -> str:
    """Compose the SHA-256 cache key for verified IR plus its call contract.

    Caller is responsible for passing a module that has already been
    ``operation.verify()``-ed — invalid IR will still produce a stable
    bytecode but storing such an entry is meaningless.
    """
    composer = _KeyComposer()

    buf = io.BytesIO()
    module.operation.write_bytecode(buf)
    composer.add("verified-ir", buf.getvalue())

    if contract is None:
        contract_payload = b""
    else:
        from cannbot_dsl.core.contracts.codec import canonical_contract_bytes

        contract_payload = canonical_contract_bytes(contract)
    composer.add("call-contract", contract_payload)

    snap = env_snapshot if env_snapshot is not None else _env_snapshot()
    composer.add("environment", _encode_env_snapshot(snap))
    options = compile_options if compile_options is not None else {}
    composer.add(
        "compile-options",
        _encode_options(options, path="compile-options"),
    )
    target_identity = target if target is not None else str(snap.get("npu_arch", "<unspecified>"))
    composer.add("target", target_identity.encode("utf-8"))

    composer.add("runtime", runtime_identity.encode("utf-8"))

    tc = toolchain if toolchain is not None else _toolchain_version()
    composer.add("toolchain", tc.encode("utf-8"))

    composer.add("format", _FORMAT_VERSION_TAG.encode("utf-8"))
    user_tag = os.environ.get("CANNBOTDSL_CACHE_FORMAT_TAG", "")
    composer.add("user-format", user_tag.encode("utf-8"))

    return composer.hexdigest()
