# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Optional, pure-Python TorchNPU runtime integration."""

from __future__ import annotations

import ctypes
import inspect
import weakref
from dataclasses import dataclass

from cannbot_dsl.core.contracts.model import ConstantExpr, StorageEncodingContract
from cannbot_dsl.core.contracts.storage import constant_values
from cannbot_dsl.core.utils.type_checks import is_exact_instance
from cannbot_dsl.core.compiler.stream_handles import as_stream_handle
from cannbot_dsl.types._storage_format import (
    FRACTAL_NZ_ELEMENT_TAGS,
    FRACTAL_NZ_MX_ELEMENT_TAGS,
    fractal_nz_c0,
)

_INT64_MAX = (1 << 63) - 1


def _checked_nonnegative_int(value, *, path: str) -> int:
    if not is_exact_instance(value, int):
        raise RuntimeError(f"{path} must be an integer, got {value!r}")
    if value < 0:
        raise ValueError(f"{path} must be non-negative, got {value}")
    if value > _INT64_MAX:
        raise OverflowError(f"{path} exceeds signed int64")
    return value


def _checked_vector(value, *, path: str, positive: bool = False) -> tuple[int, ...]:
    if not isinstance(value, (tuple, list)):
        raise RuntimeError(f"{path} must be a vector of integers")
    result = tuple(_checked_nonnegative_int(item, path=f"{path}[{index}]") for index, item in enumerate(value))
    if positive and any(item <= 0 for item in result):
        raise BufferError(f"{path} entries must be positive, got {result}")
    return result


def _checked_product(values: tuple[int, ...], *, path: str) -> int:
    product = 1
    for index, value in enumerate(values):
        if value and product > _INT64_MAX // value:
            raise OverflowError(f"{path} overflows signed int64 at axis {index}")
        product *= value
    return product


def _checked_ceildiv(value: int, divisor: int, *, path: str) -> int:
    """Compute ceildiv for a positive int64 without an overflowing add."""

    if value <= 0:
        raise ValueError(f"{path} must be positive, got {value}")
    result = (value - 1) // divisor + 1
    if result > _INT64_MAX:  # Defensive if this helper is ever generalized.
        raise OverflowError(f"{path} ceildiv exceeds signed int64")
    return result


def _compact_runtime_stride(shape: tuple[int, ...]) -> tuple[int, ...]:
    if not shape:
        return ()
    stride = [1] * len(shape)
    for index in range(len(shape) - 2, -1, -1):
        stride[index] = _checked_product(
            (shape[index + 1], stride[index + 1]),
            path="FRACTAL_NZ physical compact stride",
        )
    return tuple(stride)


def _safe_formats(torch_npu):
    """Return public formats whose logical DLPack layout describes storage."""

    try:
        format_type = getattr(torch_npu, "Format")
    except Exception as error:
        raise RuntimeError("the installed torch_npu does not expose Format") from error
    if format_type is None:
        raise RuntimeError("the installed torch_npu does not expose Format")
    formats = tuple(
        getattr(format_type, name)
        for name in (
            "NCHW",
            "NHWC",
            "ND",
            "HWCN",
            "NDHWC",
            "NCDHW",
            "NC",
            "NCL",
        )
        if hasattr(format_type, name)
    )
    if not formats:
        raise RuntimeError("the installed torch_npu Format enum has no ND-compatible formats")
    return formats


def _required_attribute(owner, name: str, *, path: str):
    try:
        return getattr(owner, name)
    except Exception as error:
        raise RuntimeError(f"{path} requires readable {name}") from error


def _required_call(owner, name: str, *, path: str):
    method = _required_attribute(owner, name, path=path)
    if not callable(method):
        raise RuntimeError(f"{path} requires callable {name}()")
    try:
        return method()
    except Exception as error:
        raise RuntimeError(f"{path} failed while calling {name}()") from error


@dataclass(frozen=True, slots=True)
class RuntimePhysicalLayout:
    """Provider-neutral, per-call private layout snapshot."""

    encoding: str
    physical_shape: tuple[int, ...]
    physical_stride: tuple[int, ...]

    def to_contract(self) -> StorageEncodingContract:
        return StorageEncodingContract(
            self.encoding,
            tuple(ConstantExpr(item) for item in self.physical_shape),
        )

    def to_native(self) -> dict[str, object]:
        return {
            "encoding": self.encoding,
            "physical_shape": self.physical_shape,
            "physical_stride": self.physical_stride,
        }


@dataclass(frozen=True, slots=True)
class DebugResult:
    payload: bytes
    counters: tuple[int, ...]


class TorchNPUDebugSession:
    __slots__ = (
        "_torch",
        "_torch_npu",
        "_device_id",
        "_specs",
        "_debug_tensors",
        "_tensors",
        "_closed",
    )

    def __init__(self, torch, torch_npu, device_id: int, specs) -> None:
        self._torch = torch
        self._torch_npu = torch_npu
        self._device_id = int(device_id)
        self._specs = tuple(specs)
        self._debug_tensors = []
        tensors = []
        self._closed = False
        device = f"npu:{self._device_id}"
        with torch.npu.device(self._device_id):
            for spec in self._specs:
                payload = torch.empty(int(spec.payload_bytes), dtype=torch.int8, device=device)
                counter_bytes = int(spec.counter_bytes)
                if counter_bytes % 8:
                    raise ValueError("debug counter byte size must be a multiple of 8")
                counter = torch.zeros(counter_bytes // 8, dtype=torch.int64, device=device)
                tensors.extend((payload, counter))
                self._debug_tensors.append((spec, payload, counter))
        self._tensors = tuple(tensors)

    @property
    def tensors(self) -> tuple[object, ...]:
        return self._tensors

    def before_invoke(self, effective_stream_handle: int) -> None:
        if self._closed:
            raise RuntimeError("TorchNPU debug session is closed")
        accessor = getattr(
            getattr(self._torch_npu, "_C", None),
            "_npu_getCurrentRawStream",
            None,
        )
        if not callable(accessor):
            raise RuntimeError(
                "the installed torch_npu does not expose the task-queue-aware "
                "raw stream accessor required by debug calls"
            )
        with self._torch.npu.device(self._device_id):
            actual = _as_stream_handle(accessor(self._device_id))
        if actual == 0 or actual != int(effective_stream_handle):
            raise RuntimeError("the current torch_npu stream changed during debug allocation")

    def finish(self) -> tuple[DebugResult, ...]:
        if self._closed:
            raise RuntimeError("TorchNPU debug session is closed")
        synchronize = getattr(self._torch.npu, "synchronize", None)
        if not callable(synchronize):
            raise RuntimeError(
                "the installed torch_npu does not expose the synchronization required for debug readback"
            )
        with self._torch.npu.device(self._device_id):
            synchronize()
            results = []
            for _, payload, counter in self._debug_tensors:
                results.append(
                    DebugResult(
                        payload.cpu().contiguous().numpy().tobytes(),
                        tuple(int(item) for item in counter.cpu().contiguous().tolist()),
                    )
                )
        return tuple(results)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._tensors = ()
        self._debug_tensors = []


_as_stream_handle = as_stream_handle


@dataclass(frozen=True, slots=True)
class _TensorExport:
    original: object
    exporter: object
    device: tuple[int, int]
    # Original address, shape, strides and internal ABI dtype, when adapted.
    layout: tuple | None = None
    dlpack_call_mode: str = "full"


class TorchNPUIntegration:
    """Exact-type TorchNPU policy using public Python metadata only."""

    def __init__(self, torch, torch_npu) -> None:
        self._torch = torch
        self._torch_npu = torch_npu
        self._dlpack_call_modes = {}

    @staticmethod
    def _required_metadata_call(owner, name: str, *, path: str):
        try:
            method = getattr(owner, name)
        except Exception as error:
            raise RuntimeError(f"{path} exact TorchNPU StructRef validation requires callable {name}()") from error
        if not callable(method):
            raise RuntimeError(f"{path} exact TorchNPU StructRef validation requires callable {name}()")
        try:
            return method()
        except Exception as error:
            raise RuntimeError(f"{path} exact TorchNPU StructRef validation failed while calling {name}()") from error

    def declared_device(self, tensor) -> tuple[int, int]:
        if not is_exact_instance(tensor, self._torch.Tensor):
            raise TypeError("TorchNPU execution requires an exact torch.Tensor")
        device = tensor.device
        if device.type not in {"npu", "privateuseone"}:
            raise ValueError("TorchNPU tensors must use DLPack kDLExtDev (12)")
        if not is_exact_instance(device.index, int) or device.index < 0:
            raise ValueError("TorchNPU tensor has an invalid device index")
        # Torch's Python __dlpack_device__ does not recognize renamed
        # PrivateUse1 backends in 2.9/2.10. The C++ exporter uses kDLExtDev.
        return (12, device.index)

    def export_tensor(self, tensor, device: tuple[int, int]) -> _TensorExport:
        """Use standard DLPack transport without changing Torch/DSL semantics."""
        from cannbot_dsl.core.contracts.elements import element_for_torch_dtype

        if not is_exact_instance(tensor, self._torch.Tensor):
            raise TypeError("TorchNPU export requires an exact torch.Tensor")
        self._validate_tensor_semantics(tensor, name="tensor")
        dtype_name = str(tensor.dtype)
        if dtype_name == "torch.float8_e8m0fnu":
            dtype = (14, 8, 1)
        else:
            info = element_for_torch_dtype(dtype_name)
            dtype = (info.dlpack_code, info.dlpack_bits, 1)
        layout = (int(tensor.data_ptr()), tuple(tensor.shape), tuple(tensor.stride()), dtype)
        exporter = tensor.detach() if tensor.requires_grad else tensor
        if dtype[0] in {10, 12, 14}:
            exporter = exporter.view(self._torch.int8)
        # Keep both storage wrappers alive while comparing StorageImpl identity.
        # Equal addresses alone do not prove that a detach/byte view shares its
        # allocator owner with the original tensor (e.g. DLPack imports).
        original_storage = tensor.untyped_storage()
        export_storage = exporter.untyped_storage()
        if exporter is not tensor:
            has_invalid_export_view = (
                not is_exact_instance(exporter, self._torch.Tensor)
                or exporter.data_ptr() != layout[0]
                or exporter.device != tensor.device
                or tuple(exporter.shape) != layout[1]
                or tuple(exporter.stride()) != layout[2]
                or exporter.storage_offset() != tensor.storage_offset()
                or getattr(export_storage, "_cdata") != getattr(original_storage, "_cdata")
            )
            if has_invalid_export_view:
                raise BufferError("Torch DLPack export view must share the original storage and layout")
        return _TensorExport(tensor, exporter, device, layout, self._dlpack_call_mode(exporter))

    def preflight_tensor_subclasses(self, tensors: tuple[tuple[str, object], ...]) -> None:
        """Reject private-format Tensor subclasses before DLPack callbacks."""

        accepted = _safe_formats(self._torch_npu)
        exact_type = self._torch.Tensor
        for name, tensor in tensors:
            if is_exact_instance(tensor, exact_type):
                continue
            actual = self._format(tensor, name=name)
            if actual in accepted:
                continue
            actual_type = type(tensor)
            qualified_type = f"{actual_type.__module__}.{actual_type.__qualname__}"
            raise BufferError(
                f"{name} is {qualified_type} using torch_npu private storage "
                f"format {actual!r}; private-format Tensor subclasses cannot "
                "cross the DLPack Exchange boundary. Pass an allocation-root "
                f"exact torch.Tensor, for example {name}.detach()"
            )

    def validate_storage(self, tensors: tuple[tuple[str, object], ...]) -> None:
        accepted = _safe_formats(self._torch_npu)
        for name, tensor in tensors:
            actual = self._format(tensor, name=name)
            if actual not in accepted:
                raise BufferError(
                    f"{name} uses torch_npu private storage format {actual}; the compiled contract requires ND storage"
                )

    def inspect_storage(
        self,
        tensors: tuple[tuple[str, object], ...],
        snapshots=None,
        expected_contracts=None,
        *,
        preflight: bool = False,
    ) -> tuple[RuntimePhysicalLayout | None, ...]:
        """Validate storage and derive canonical FRACTAL_NZ physical layouts."""

        from cannbot_dsl.core.compiler.physical_abi import host_carrier
        from cannbot_dsl.core.contracts.elements import (
            element_for_dlpack,
            element_for_tag,
            element_for_torch_dtype,
        )

        tensors = tuple(tensors)
        if snapshots is not None and len(snapshots) != len(tensors):
            raise RuntimeError("TorchNPU storage snapshot count mismatch")
        if expected_contracts is not None and len(expected_contracts) != len(tensors):
            raise RuntimeError("TorchNPU storage expectation count mismatch")

        accepted = _safe_formats(self._torch_npu)
        try:
            format_type = getattr(self._torch_npu, "Format")
            nz_format = getattr(format_type, "FRACTAL_NZ")
        except Exception as error:
            raise RuntimeError("TorchNPU FRACTAL_NZ validation requires Format.FRACTAL_NZ") from error
        layouts = []
        for index, (name, tensor) in enumerate(tensors):
            expected_contract = None if expected_contracts is None else expected_contracts[index]
            expected = None if expected_contract is None else getattr(expected_contract, "storage_encoding", None)
            actual_format = self._format(tensor, name=name)
            if actual_format in accepted:
                if expected is not None:
                    raise BufferError(
                        f"{name} requires FRACTAL_NZ storage but received TorchNPU format {actual_format!r}"
                    )
                layouts.append(None)
                continue
            if actual_format != nz_format:
                raise BufferError(
                    f"{name} uses unsupported torch_npu private storage format "
                    f"{actual_format!r}; only FRACTAL_NZ is supported"
                )
            if expected_contracts is not None and expected is None:
                raise BufferError(
                    f"{name} uses FRACTAL_NZ storage but the compiled tensor contract requires ND storage"
                )

            shape = _checked_vector(
                _required_attribute(tensor, "shape", path=name),
                path=f"{name} shape",
                positive=True,
            )
            stride = _checked_vector(
                _required_call(tensor, "stride", path=name),
                path=f"{name} stride",
            )
            if len(shape) not in (2, 3) or len(stride) != len(shape):
                raise BufferError(
                    f"{name} FRACTAL_NZ requires logical rank 2 or 3 with a "
                    f"matching stride, got shape rank {len(shape)} and "
                    f"stride rank {len(stride)}"
                )
            if stride != _compact_runtime_stride(shape):
                raise BufferError(f"{name} FRACTAL_NZ logical stride must be compact row-major")

            is_view = _required_call(tensor, "_is_view", path=name)
            if not is_exact_instance(is_view, bool):
                raise RuntimeError(f"{name} _is_view() must return a bool, got {is_view!r}")
            if is_view:
                raise BufferError(f"{name} is a Torch view of FRACTAL_NZ storage; pass the allocation-root tensor")
            storage_offset = _checked_nonnegative_int(
                _required_call(tensor, "storage_offset", path=name),
                path=f"{name} storage_offset()",
            )
            if storage_offset != 0:
                raise BufferError(f"{name} FRACTAL_NZ storage_offset must be 0, got {storage_offset}")
            data_ptr = _checked_nonnegative_int(
                _required_call(tensor, "data_ptr", path=name),
                path=f"{name} data_ptr()",
            )
            storage = _required_call(tensor, "untyped_storage", path=name)
            storage_ptr = _checked_nonnegative_int(
                _required_call(storage, "data_ptr", path=f"{name} untyped storage"),
                path=f"{name} untyped_storage().data_ptr()",
            )
            if data_ptr == 0 or data_ptr != storage_ptr:
                raise BufferError(f"{name} FRACTAL_NZ data pointer does not identify the root allocation")
            device = _required_attribute(tensor, "device", path=name)
            device_type = _required_attribute(device, "type", path=f"{name} device")
            if not is_exact_instance(device_type, str):
                raise RuntimeError(f"{name} device.type must be a string, got {device_type!r}")
            if device_type not in {"npu", "privateuseone"}:
                raise BufferError(f"{name} FRACTAL_NZ tensor must be on an NPU device, got {device_type!r}")

            dtype = _required_attribute(tensor, "dtype", path=name)
            try:
                dtype_name = str(dtype)
            except Exception as error:
                raise RuntimeError(f"{name} dtype cannot be rendered") from error
            # A packed sub-byte contract (fp4x2_e2m1) has no torch dtype: the
            # caller hands over the packed bytes through torch.int8/uint8 in
            # FRACTAL_NZ layout.  Resolve the contract element instead and
            # keep every later check in logical-element units.
            packed_element = None
            if expected_contract is not None and expected is not None:
                if element_for_tag(
                    expected_contract.element
                ).dtype.is_packed_sub_byte:
                    packed_element = expected_contract.element
            tensor_info = element_for_torch_dtype(dtype_name)
            if packed_element is not None:
                if tensor_info.tag not in ("i8", "u8"):
                    raise TypeError(
                        f"{name} FRACTAL_NZ dtype {tensor_info.dtype.name} is "
                        "unsupported as the packed "
                        f"{packed_element} byte carrier; pass torch.int8/uint8"
                    )
                tensor_info = element_for_tag(packed_element)
            elif tensor_info.tag not in FRACTAL_NZ_ELEMENT_TAGS:
                raise TypeError(
                    f"{name} FRACTAL_NZ dtype {tensor_info.dtype.name} is unsupported"
                )
            # Same rule as physical_abi._packed_carrier: only a byte-carried
            # element packs 8 // bits per byte.  A bare width test would also
            # catch bool, whose logical i1 is still byte-addressed.
            per_carrier = (
                8 // tensor_info.dtype.bits
                if tensor_info.dtype.is_packed_sub_byte
                else 1
            )

            snapshot = None if snapshots is None else snapshots[index]
            if snapshot is not None:
                if snapshot.byte_offset != 0 or snapshot.data != data_ptr:
                    raise BufferError(f"{name} DLPack metadata does not identify the root allocation")
                if snapshot.shape != shape or snapshot.stride != stride:
                    raise BufferError(f"{name} DLPack logical shape/stride does not match Torch metadata")
                snapshot_info = element_for_dlpack(
                    snapshot.dtype_code,
                    snapshot.dtype_bits,
                    snapshot.dtype_lanes,
                )
                if packed_element is not None:
                    if snapshot_info.tag not in ("i8", "u8"):
                        raise BufferError(
                            f"{name} DLPack dtype {snapshot_info.dtype.name} does "
                            "not describe the packed "
                            f"{packed_element} byte carrier"
                        )
                elif snapshot_info is not tensor_info:
                    raise BufferError(
                        f"{name} DLPack dtype {snapshot_info.dtype.name} does not "
                        f"match Torch dtype {tensor_info.dtype.name}"
                    )
            elif not preflight:
                if expected_contract is None or expected is None:
                    raise RuntimeError(f"{name} FRACTAL_NZ validation has no compiled storage expectation")
                expected_info = element_for_tag(expected_contract.element)
                if tensor_info is not expected_info:
                    raise BufferError(
                        f"{name} TorchNPU dtype {dtype_name} does not match compiled dtype {expected_info.torch_name}"
                    )
                # A packed element reaches the host as its byte carrier.  Derive
                # that carrier from host_carrier -- the same helper the host ABI
                # slots and the JIT binding guard are built from -- so a caller
                # can never satisfy one and violate the other, and so shape and
                # stride come out of one computation instead of two.
                carrier = (
                    host_carrier(expected_contract)
                    if packed_element is not None
                    else expected_contract
                )
                view = " (carrier view)" if packed_element is not None else ""
                expected_shape = constant_values(carrier.shape)
                if expected_shape is not None and expected_shape != shape:
                    raise BufferError(
                        f"{name} logical shape changed: expected "
                        f"{expected_shape}{view}, got {shape}"
                    )
                expected_stride = constant_values(carrier.stride)
                if expected_stride is not None and expected_stride != stride:
                    raise BufferError(
                        f"{name} logical stride changed: expected "
                        f"{expected_stride}{view}, got {stride}"
                    )

            c0 = fractal_nz_c0(tensor_info.tag)
            m, n = shape[-2:]
            # A packed carrier stores two sub-byte elements per torch element;
            # the canonical physical geometry counts logical elements.
            n *= per_carrier
            if (
                len(shape) == 3
                and tensor_info.tag in FRACTAL_NZ_MX_ELEMENT_TAGS
                and (n + c0 - 1) // c0 % (64 // c0) != 0
            ):
                # The raw-copy K-stripe zero-fill is lowered only for the
                # single-matrix (rank-4 physical) spelling: a batched
                # allocation interleaves the per-batch gap stripes into one
                # constant-stride burst stream, which the DMA cannot express.
                raise BufferError(
                    f"{name} batched block-scaled FRACTAL_NZ requires the "
                    "last logical extent to cover whole 64-element MX groups "
                    "(the GM->L1 zero-fill is single-matrix only), got last "
                    f"extent {n}"
                )
            physical_shape = shape[:-2] + (
                _checked_ceildiv(n, c0, path=f"{name} N extent"),
                _checked_ceildiv(m, 16, path=f"{name} M extent"),
                16,
                c0,
            )
            physical_stride = _compact_runtime_stride(physical_shape)
            physical_elements = _checked_product(
                physical_shape, path=f"{name} physical allocation elements"
            )
            if physical_elements % per_carrier != 0:
                raise BufferError(
                    f"{name} canonical FRACTAL_NZ layout packs "
                    f"{physical_elements} sub-byte elements, which cannot divide "
                    "into byte carriers"
                )
            public_storage_elements = self._storage_size(tensor, name=name)
            if physical_elements // per_carrier != public_storage_elements:
                raise BufferError(
                    f"{name} canonical FRACTAL_NZ layout requires "
                    f"{physical_elements} elements, which does not match "
                    f"torch_npu.get_storage_size() {public_storage_elements}"
                )
            element_bits = tensor_info.dlpack_bits
            required_bits = physical_elements * element_bits
            if required_bits % 8 != 0:
                raise BufferError(
                    f"{name} canonical FRACTAL_NZ layout requires "
                    f"{required_bits} bits, which is not a whole number of bytes"
                )
            required_bytes = required_bits // 8
            allocation_bytes = _checked_nonnegative_int(
                _required_call(storage, "nbytes", path=f"{name} untyped storage"),
                path=f"{name} untyped_storage().nbytes()",
            )
            if allocation_bytes < required_bytes:
                raise BufferError(
                    f"{name} FRACTAL_NZ allocation has {allocation_bytes} bytes; "
                    f"canonical layout requires at least {required_bytes}"
                )
            if expected is not None:
                if expected.encoding != "fractal_nz":
                    raise BufferError(f"{name} compiled storage encoding {expected.encoding!r} is not FRACTAL_NZ")
                expected_values = constant_values(expected.physical_shape)
                if expected_values is not None and expected_values != physical_shape:
                    raise BufferError(
                        f"{name} FRACTAL_NZ physical shape changed: expected {expected_values}, got {physical_shape}"
                    )
            layouts.append(RuntimePhysicalLayout("fractal_nz", physical_shape, physical_stride))
        return tuple(layouts)

    def validate_struct_ref_storage(self, tensors) -> None:
        for name, tensor, expected_bytes in tensors:
            offset = self._required_metadata_call(tensor, "storage_offset", path=name)
            if isinstance(offset, bool) or not isinstance(offset, int):
                raise RuntimeError(f"{name} storage_offset() must return an integer")
            if offset != 0:
                raise ValueError(f"{name} StructRef TorchNPU storage_offset must be 0, got {offset}")
            storage = self._required_metadata_call(tensor, "untyped_storage", path=name)
            nbytes = self._required_metadata_call(storage, "nbytes", path=name)
            if isinstance(nbytes, bool) or not isinstance(nbytes, int):
                raise RuntimeError(f"{name} untyped_storage().nbytes() must return an integer")
            if nbytes != expected_bytes:
                raise ValueError(
                    f"{name} StructRef TorchNPU allocation size must equal {expected_bytes} bytes, got {nbytes}"
                )

    def resolve_stream(self, reference: object, device_id: int):
        del reference
        current_stream = getattr(self._torch.npu, "current_stream", None)
        if not callable(current_stream):
            raise RuntimeError("the installed torch_npu does not expose current_stream")
        device_id = int(device_id)
        with self._torch.npu.device(device_id):
            owner = current_stream(device_id)
            owner_handle = _as_stream_handle(getattr(owner, "npu_stream", None))
        if owner_handle == 0:
            raise RuntimeError("the current torch_npu stream has a null handle")
        return owner_handle, owner

    def prepare_submit(self, tensors, *, device_id: int, handle: int, owner) -> None:
        """Record storage use and drain TorchNPU tasks at the native DSO boundary."""
        raw_stream = getattr(getattr(self._torch_npu, "_C", None), "_npu_getCurrentRawStream", None)
        if not callable(raw_stream):
            raise RuntimeError("torch_npu must expose the task-queue-aware raw stream accessor")
        with self._torch.npu.device(device_id):
            storages = {}
            for tensor in tensors:
                storage = tensor.untyped_storage()
                key = (tensor.device, getattr(storage, "_cdata"))
                if key not in storages:
                    # Retain StorageImpl identity through the entire check and
                    # task-queue drain; addresses may alias across allocators.
                    storages[key] = storage
                    tensor.record_stream(owner)
            actual = _as_stream_handle(raw_stream(device_id))
        if actual == 0 or actual != handle or _as_stream_handle(owner.npu_stream) != handle:
            raise RuntimeError("torch_npu returned inconsistent current stream handles before submission")

    def create_debug_session(self, reference: object, device_id: int, specs):
        if not is_exact_instance(reference, self._torch.Tensor):
            raise TypeError("TorchNPU debug reference must be an exact torch.Tensor")
        return TorchNPUDebugSession(self._torch, self._torch_npu, device_id, specs)
    def _dlpack_call_mode(self, exporter) -> str:
        """Recognize only an explicit stream-only signature, without exporting."""
        method = exporter.__dlpack__
        bound = inspect.ismethod(method)
        # Bound method objects are ephemeral. Cache their function, but keep
        # instance-assigned functions distinct from bound uses of that function.
        identity = method.__func__ if bound else method
        key = (id(identity), bound)
        cache = self._dlpack_call_modes
        cached = cache.get(key)
        if cached is not None and cached[0]() is identity:
            return cached[1]
        mode = "full"
        try:
            parameters = tuple(inspect.signature(method, follow_wrapped=False).parameters.values())
        except (TypeError, ValueError):
            pass  # Unknown signatures keep the standard producer contract.
        else:
            if (
                len(parameters) == 1
                and parameters[0].name == "stream"
                and parameters[0].kind
                in (
                    inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    inspect.Parameter.KEYWORD_ONLY,
                )
            ):
                mode = "stream_only"

        def forget(reference):
            entry = cache.get(key)
            if entry is not None and entry[0] is reference:
                del cache[key]

        try:
            reference = weakref.ref(identity, forget)
        except TypeError:
            return mode
        # Never retain a tensor, bound method, callable owner or capsule here.
        cache[key] = (reference, mode)
        return mode

    def _validate_tensor_semantics(self, tensor, *, name: str) -> None:
        """Reject views whose logical values cannot be described by DLPack."""
        if tensor.is_neg():
            raise BufferError(f"{name} has an unresolved negative view bit; DLPack requires materialized values")
        if tensor.is_conj():
            raise BufferError(f"{name} has an unresolved conjugate view bit; DLPack requires materialized values")
        if tensor.layout is not self._torch.strided:
            raise BufferError(f"{name} must have torch.strided layout for DLPack")

    def _format(self, tensor, *, name: str):
        self._validate_tensor_semantics(tensor, name=name)
        checker = getattr(self._torch_npu, "get_npu_format", None)
        if not callable(checker):
            raise RuntimeError("the installed torch_npu does not expose get_npu_format")
        try:
            return checker(tensor)
        except Exception as error:
            raise RuntimeError(f"{name} storage validation failed while calling torch_npu.get_npu_format()") from error

    def _storage_size(self, tensor, *, name: str) -> int:
        checker = getattr(self._torch_npu, "get_storage_size", None)
        if not callable(checker):
            raise RuntimeError("the installed torch_npu does not expose get_storage_size")
        try:
            value = checker(tensor)
        except Exception as error:
            raise RuntimeError(
                f"{name} storage validation failed while calling torch_npu.get_storage_size()"
            ) from error
        return _checked_nonnegative_int(value, path=f"{name} torch_npu.get_storage_size()")



__all__ = [
    "DebugResult",
    "RuntimePhysicalLayout",
    "TorchNPUIntegration",
]
