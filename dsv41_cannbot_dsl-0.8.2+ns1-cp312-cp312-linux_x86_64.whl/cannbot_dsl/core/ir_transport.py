# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Private semantic-value/SSA transport boundary.

Only framework-owned value kinds are recognized.  This module intentionally
does not expose a registry or a duck-typed protocol: supporting a new semantic
value requires an explicit branch and an explicit rebuild policy here.
"""

from __future__ import annotations

from collections.abc import Iterable

from cannbot_dsl.core.utils.type_checks import is_exact_instance


class _CommunicationIrValue:
    """Shared storage for the compiler operand of a communication handle or handle list."""

    __slots__ = ("_ssa_value",)

    def __init__(self, value):
        self._ssa_value = None if value is None else unwrap_operand(value)

    @property
    def _device_operand(self):
        return self._ssa_value

    @classmethod
    def _new_with_operand(cls, value):
        result = object.__new__(cls)
        _CommunicationIrValue.__init__(result, value)
        return result


def _raw_carrier(value):
    from cannbot_dsl.comm._device import _Connection, _Handle, _HandleList

    if isinstance(value, (_Connection, _Handle, _HandleList)):
        carrier = value._ssa_value
        if carrier is None:
            raise TypeError("Host handle cannot be captured as a Device constant")
        return carrier
    from cannbot_dsl.tensor import Layout, Tensor

    if isinstance(value, (Tensor, Layout)):
        return object.__getattribute__(value, "_ssa_value")
    from cannbot_dsl.types.tensor_list import TensorList

    if is_exact_instance(value, TensorList):
        return object.__getattribute__(value, "_ssa_value")
    from cannbot_dsl.ring_buffer import RingBuffer

    if is_exact_instance(value, RingBuffer):
        return object.__getattribute__(value, "_ir_value")

    import cannbot_dsl._mlir.ir as ir

    if isinstance(value, ir.Value):
        return value
    raise TypeError(
        "CANNIR operands must be framework Tensor, TensorList, Layout, RingBuffer, "
        f"or an MLIR value; got {type(value).__name__}"
    )


def _has_dynamic_shape(shape):
    if isinstance(shape, (tuple, list)):
        return any(_has_dynamic_shape(child) for child in shape)
    return shape == -1


def unwrap_operand(value):
    """Return the backend operand for one whitelisted semantic value."""
    return _raw_carrier(value)


def capture_tensor_state(value):
    """Generalize View fields at a control-flow boundary, preserving its binding."""
    from cannbot_dsl.tensor import Tensor
    from cannbot_dsl._mlir import ir
    from cannbot_dsl._mlir.dialects import cannir

    if not isinstance(value, Tensor):
        return value
    carrier = _raw_carrier(value)
    if isinstance(carrier, ir.OpResult) and carrier.owner.name == "cannir.capture_view":
        return value
    # Even an already-dynamic producer needs an explicit boundary: layout
    # inference can refine its result later, while region types must stay stable.
    result = Tensor._from_ir(cannir.CaptureViewOp(carrier).res)
    return result


def extract_ir_values(value) -> tuple:
    """Extract the SSA carriers owned by one supported dynamic leaf."""

    from cannbot_dsl.comm._device import _Connection, _Handle, _HandleList

    if isinstance(value, (_Connection, _Handle, _HandleList)):
        return (_raw_carrier(value),)

    import cannbot_dsl._mlir.ir as ir
    from cannbot_dsl.tensor import Layout, Tensor

    if isinstance(value, Tensor):
        return (_raw_carrier(value),)

    if isinstance(value, Layout):
        carrier = _raw_carrier(value)
        if not isinstance(carrier, ir.Value):  # pragma: no cover - invariant
            raise TypeError("framework semantic value has no MLIR carrier")
        source = value._view_source
        return (carrier, source) if source is not None else (carrier,)
    from cannbot_dsl.types.tensor_list import TensorList

    if is_exact_instance(value, TensorList):
        carrier = _raw_carrier(value)
        if not isinstance(carrier, ir.Value):  # pragma: no cover - invariant
            raise TypeError("TensorList semantic value has no MLIR carrier")
        return (carrier,)
    if isinstance(value, ir.Value):
        return (value,)
    raise TypeError(f"unsupported dynamic value {type(value).__name__}")


def rebuild_ir_values(template, values: Iterable):
    """Rebuild one semantic leaf from carriers using a closed policy."""

    carriers = tuple(values)
    from cannbot_dsl.comm._device import _Connection, _Handle, _HandleList

    if isinstance(template, (_Connection, _Handle)):
        return type(template)._from_ir(carriers[0])
    if isinstance(template, _HandleList):
        return type(template)._from_ir(carriers[0], contract=template._contract)
    from cannbot_dsl.tensor import Layout, Tensor

    if is_exact_instance(template, Layout):
        expected = 2 if template._view_source is not None else 1
        if len(carriers) != expected:
            raise ValueError(f"Layout transport expects {expected} carriers, got {len(carriers)}")
        return Layout._from_ir(
            _raw_carrier(carriers[0]), view_source=_raw_carrier(carriers[1]) if expected == 2 else None
        )
    if len(carriers) != 1:
        raise ValueError(f"semantic leaf expects one carrier, got {len(carriers)}")
    carrier = _raw_carrier(carriers[0])

    if isinstance(template, Tensor):
        return getattr(Tensor, "_from_ir")(carrier)
    from cannbot_dsl.types.tensor_list import TensorList

    if is_exact_instance(template, TensorList):
        return getattr(TensorList, "_from_ir")(
            carrier,
            contract=object.__getattribute__(template, "_contract"),
        )

    import cannbot_dsl._mlir.ir as ir

    if isinstance(template, ir.Value):
        template_type = type(template)
        if template_type is ir.Value:
            return carrier
        from cannbot_dsl.core.frontend.runtime.integer_policy import copy_policy

        return copy_policy(template_type(carrier), template, dynamic=True)
    raise TypeError(f"unsupported semantic template {type(template).__name__}")


def semantic_value_tag(value) -> tuple[object, ...] | None:
    """Return a stable identity for a framework composition leaf."""

    from cannbot_dsl.comm._device import _Connection, _Handle, _HandleList

    if isinstance(value, (_Handle, _Connection)):
        return ("comm_handle", value.handle_kind)
    if isinstance(value, _HandleList):
        return ("comm_list", value.handle_kind, value.length_signature)

    from cannbot_dsl.tensor import Layout, Tensor

    if isinstance(value, Tensor):
        return ("tensor",)
    if is_exact_instance(value, Layout):
        return ("layout", str(value._view_source.type) if value._view_source is not None else None)
    from cannbot_dsl.types.tensor_list import TensorList

    if is_exact_instance(value, TensorList):
        contract = object.__getattribute__(value, "_contract")
        return ("tensor_list", contract)
    return None


__all__: list[str] = []
