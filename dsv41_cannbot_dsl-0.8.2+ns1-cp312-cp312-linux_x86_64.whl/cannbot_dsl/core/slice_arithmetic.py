# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# Licensed under the CANN Open Software License Agreement Version 2.0.
"""Bounded, local arithmetic folding before constructing a slice's ShapeType.

Input SSA is read-only. Positive-step and nonoverflowing interval assumptions
apply only to the extent being built, never to other uses of its operands.
"""

from cannbot_dsl._mlir import ir
from cannbot_dsl._mlir.dialects import arith
from cannbot_dsl.core.scalar_conversion import _constant_i64, _index_value

_MAX_INPUT_NODES = 256
_I64_MIN, _I64_MAX = -(1 << 63), (1 << 63) - 1
_INTEGER_OPS = {"arith.addi", "arith.subi", "arith.muli"}
_CAST_OPS = {"arith.extsi", "arith.extui", "arith.index_cast", "arith.trunci"}


class _SliceFolder:
    def __init__(self):
        self.i64 = ir.IntegerType.get_signless(64)
        self.results = {}
        self.nodes = {}
        self.equivalent = {}
        self.created = []
        self.constants = {}
        self.converted = {}

    def result(self, value):
        if type(value) is int:
            return value
        value = ir.Value(value)  # Avoid the DSL's overloaded equality.
        return self.results.get(value, value)

    def analyze(self, *roots):
        roots = [ir.Value(v) for v in roots if type(v) is not int]
        # Reserve the endpoints before exploring a deep shared producer, so
        # the budget still permits recognizing (start + count) - start.
        admitted = set(roots[:_MAX_INPUT_NODES])
        stack = [(v, None) for v in reversed(roots)]
        while stack:
            value, owner = stack.pop()
            if value in self.results:
                continue
            if owner is not None:
                self.results[value] = self.fold(value, owner)
                continue
            known = _constant_i64(value)
            if known is not None:
                self.results[value] = known
                continue
            if value not in admitted:
                if len(admitted) >= _MAX_INPUT_NODES:
                    self.results[value] = value
                    continue
                admitted.add(value)
            owner = value.owner
            name = getattr(owner, "name", None)
            if name in _INTEGER_OPS and value.type == self.i64:
                stack.append((value, owner))
                stack.extend((ir.Value(v), None) for v in reversed(list(owner.operands)))
            elif name in _CAST_OPS:
                # Identical conversions may share an identity, but arithmetic
                # on the other side of a width conversion stays opaque.
                self.results[value] = self.intern(value, owner, tuple(ir.Value(v) for v in owner.operands))
            else:
                self.results[value] = value

    def intern(self, value, owner, operands):
        attributes = tuple((a.name, a.attr) for a in owner.attributes)
        key = (owner.name, value.type, attributes, operands)
        return self.equivalent.setdefault(key, value)

    def parts(self, value, name):
        node = self.nodes.get(value) if type(value) is not int else None
        return node[1] if node is not None and node[0] == name else None

    def fold(self, value, owner):
        name = owner.name
        operands = tuple(self.result(v) for v in owner.operands)
        self.nodes[value] = (name, operands)
        lhs, rhs = operands
        if type(lhs) is int and type(rhs) is int:
            if name == "arith.addi":
                known = lhs + rhs
            elif name == "arith.subi":
                known = lhs - rhs
            elif name == "arith.muli":
                known = lhs * rhs
            elif name == "arith.ceildivsi" and lhs >= 0 and rhs > 0:
                known = lhs // rhs + int(lhs % rhs != 0)
            else:
                known = None
            if known is not None and _I64_MIN <= known <= _I64_MAX:
                return known
        if name == "arith.addi":
            if lhs == 0:
                return rhs
            if rhs == 0:
                return lhs
        elif name == "arith.subi":
            if lhs == rhs:
                return 0
            if rhs == 0:
                return lhs
            pair = self.parts(lhs, "arith.addi")
            if pair is not None:
                for term, other in (pair, pair[::-1]):
                    if term == rhs:
                        return other
                    inner = self.parts(term, "arith.addi") if other == 1 else None
                    if inner is not None:
                        for base, span in (inner, inner[::-1]):
                            if base == rhs:
                                return self.emit(arith.addi, span, 1)
        elif name == "arith.muli":
            if lhs == 1:
                return rhs
            if rhs == 1:
                return lhs
        elif name == "arith.ceildivsi":
            if rhs == 1 or lhs == 0:
                return lhs
            distance, extra = lhs, 0
            pair = self.parts(distance, "arith.addi")
            if pair is not None:
                if pair[0] == 1:
                    distance, extra = pair[1], 1
                elif pair[1] == 1:
                    distance, extra = pair[0], 1
            if distance == rhs:
                return 1 + extra
            product = self.parts(distance, "arith.muli")
            if product is not None:
                for factor, step in (product, product[::-1]):
                    if step == rhs:
                        if extra and type(factor) is int and factor == _I64_MAX:
                            raise ValueError("Tensor slice size must be a nonnegative signed i64 integer")
                        return self.emit(arith.addi, factor, 1) if extra else factor
        return self.intern(value, owner, operands)

    def scalar(self, value):
        if type(value) is not int:
            return value
        if value not in self.constants:
            constant = ir.Value(arith.constant(self.i64, value))
            self.created.append(constant.owner)
            self.constants[value] = constant
            self.results[constant] = value
        return self.constants[value]

    def coerce(self, original):
        value = self.result(original)
        if type(value) is int or value.type == self.i64:
            return value
        # Preserve the original wrapper's signedness at the adaptation boundary.
        key = (ir.Value(original), bool(getattr(original, "unsigned", False)))
        if key not in self.converted:
            converted = ir.Value(_index_value(original, operation="slice bound"))
            self.converted[key] = converted
            casts = []
            while converted != ir.Value(original):
                # Integer adaptation emits a unary conversion chain. Own only
                # that new chain, stopping at the caller's original SSA.
                casts.append(converted.owner)
                converted = ir.Value(converted.owner.operands[0])
            self.created.extend(reversed(casts))
        return self.converted[key]

    def emit(self, operation, lhs, rhs):
        value = ir.Value(operation(self.scalar(lhs), self.scalar(rhs)))
        self.created.append(value.owner)
        result = self.fold(value, value.owner)
        self.results[value] = result
        return result

    def lower_ceildiv(self, value):
        operands = self.parts(value, "arith.ceildivsi")
        if operands is None:
            return value
        distance, step = map(self.scalar, operands)
        quotient = arith.divsi(distance, step)
        remainder = arith.remsi(distance, step)
        extra = arith.cmpi(arith.CmpIPredicate.ne, remainder, self.scalar(0))
        increment = arith.extui(self.i64, extra)
        result = arith.addi(quotient, increment)
        self.created.extend(v.owner for v in (quotient, remainder, extra, increment, result))
        return ir.Value(result)

    def cleanup(self, *retained):
        keep = {ir.Value(v) for v in retained if type(v) is not int}
        for operation in reversed(self.created):
            if all(ir.Value(v) not in keep and not list(v.uses) for v in operation.results):
                operation.erase()


def build_slice_extent(start, stop, step, *, parent_extent):
    """Return (size, normalized_step) after literal clipping by the caller."""
    folder = _SliceFolder()
    retained = ()
    try:
        folder.analyze(start, stop, step)
        a, b, s = (folder.result(v) for v in (start, stop, step))
        for name, bound in (("start", a), ("stop", b)):
            if type(bound) is int and bound < 0:
                raise NotImplementedError(f"negative Tensor slice {name} is not supported")
        if type(s) is int and not 0 < s <= _I64_MAX:
            raise ValueError("Tensor slice step must be a positive signed i64 integer")
        if type(parent_extent) is int:
            for name, bound in (("start", a), ("stop", b)):
                if type(bound) is int and bound > parent_extent:
                    raise ValueError(f"Tensor interval {name} {bound} exceeds parent extent {parent_extent}")
        if type(a) is int and type(b) is int and a > b:
            raise ValueError(f"Tensor interval must have non-negative size, got [{a}:{b}]")
        if all(type(v) is int for v in (a, b, s)):
            return (b - a) // s + int((b - a) % s != 0), s
        a, b, s = (folder.coerce(v) for v in (start, stop, step))
        distance = folder.emit(arith.subi, b, a)
        if type(distance) is int and distance < 0:
            raise ValueError("Tensor interval must have non-negative size")
        size = folder.emit(arith.ceildivsi, distance, s)
        if type(size) is int and not 0 <= size <= _I64_MAX:
            raise ValueError("Tensor slice size must be a nonnegative signed i64 integer")
        size = folder.lower_ceildiv(size)
        retained = (size, s)
        return retained
    finally:
        folder.cleanup(*retained)
