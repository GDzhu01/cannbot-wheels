# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""AscendC source -> shared library compilation via bisheng."""

import logging
import os
import platform
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from importlib import resources as importlib_resources
from pathlib import Path
from typing import Optional, Sequence, Tuple

from cannbot_dsl.core.utils.env import _getenv_binary_bool
from cannbot_dsl.core.utils.timer import timer as _timer

_LOG = logging.getLogger(__name__)
_DEFAULT_NPU_ARCH = "dav-3510"
_NPU_ARCH_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]*$")


# Linked only into Native providers with framework profiling callbacks. The
# linker rewrites their direct Msprof references; it does not interpose CANN
# shared libraries or change generated kernel source/symbols.
_PROFILING_BOUNDARY_SOURCE = r"""
#include <cstdint>
#include <cstring>

// Only these provider-local duplicate records are replaced by the framework.
// Other levels/types, CANN DSOs and the original device symbols stay intact.
static bool isNodeRecord(const void* data, uint32_t bytes, uint32_t type) {
  if (!data || bytes < 8) return false;
  uint16_t magic, level;
  uint32_t recordType;
  std::memcpy(&magic, data, 2);
  std::memcpy(&level, static_cast<const char*>(data) + 2, 2);
  std::memcpy(&recordType, static_cast<const char*>(data) + 4, 4);
  return magic == 0x5A5A && level == 10000 && recordType == type;
}

extern "C" int32_t __real_MsprofReportApi(uint32_t, const void*);
extern "C" int32_t __real_MsprofReportCompactInfo(uint32_t, const void*, uint32_t);
extern "C" int32_t __real_MsprofReportAdditionalInfo(uint32_t, const void*, uint32_t);

extern "C" int32_t __wrap_MsprofReportApi(uint32_t flag, const void* api) {
  if (isNodeRecord(api, 8, 5)) return 0;
  return __real_MsprofReportApi(flag, api);
}

extern "C" int32_t __wrap_MsprofReportCompactInfo(uint32_t flag, const void* data, uint32_t bytes) {
  if (isNodeRecord(data, bytes, 0)) return 0;
  return __real_MsprofReportCompactInfo(flag, data, bytes);
}

extern "C" int32_t __wrap_MsprofReportAdditionalInfo(uint32_t flag, const void* data, uint32_t bytes) {
  if (isNodeRecord(data, bytes, 1)) return 0;
  return __real_MsprofReportAdditionalInfo(flag, data, bytes);
}
"""
_PROFILING_BOUNDARY_SYMBOLS = ("MsprofReportApi", "MsprofReportCompactInfo", "MsprofReportAdditionalInfo")


def asc_ext_include_dir() -> Path:
    """The installed extension headers used by compilation and cache identity."""
    return Path(str(importlib_resources.files('cannbot_dsl').joinpath("include")))


@dataclass(frozen=True)
class BishengResolution:
    """Resolved external compiler and the candidates considered."""

    path: Optional[str]
    ascend_home: Optional[str]
    checked: Tuple[str, ...]


def _host_sdk_directory(machine: Optional[str] = None) -> Optional[str]:
    """Map the Python host architecture to CANN's SDK directory name."""

    normalized = (machine or platform.machine()).strip().lower()
    if normalized in {"x86_64", "amd64"}:
        return "x86_64-linux"
    if normalized in {"aarch64", "arm64"}:
        return "aarch64-linux"
    return None


def _detect_npu_arch() -> str:
    """Best-effort runtime SoC query; empty when CANN is unavailable.

    Imported lazily so that toolchain resolution stays importable on hosts
    without CANN libraries.
    """

    try:
        from cannbot_dsl.ops.info import _detect_npu_arch as detect

        return detect()
    except Exception as error:
        _LOG.debug("runtime NPU arch detection failed: %s", error)
        return ""


def resolve_npu_arch(value: Optional[str] = None) -> str:
    """Return and validate the Bisheng ``--npu-arch`` value.

    Priority: explicit ``value`` argument, ``CANNBOTDSL_NPU_ARCH``, a runtime
    SoC query, then ``dav-3510``.  The environment variable wins over the
    query so cross-compilation setups stay deterministic.
    """

    arch = value or os.environ.get("CANNBOTDSL_NPU_ARCH") or _detect_npu_arch() or _DEFAULT_NPU_ARCH
    if not _NPU_ARCH_PATTERN.fullmatch(arch):
        raise ValueError(f"CANNBOTDSL_NPU_ARCH must contain only letters, digits, '.', '_' or '-'; got {arch!r}")
    return arch


def resolve_bisheng(*, required: bool = True) -> BishengResolution:
    """Resolve Bisheng for both compilation and cache-key computation.

    Search order is an explicit CANNBotDSL override, the architecture-specific
    locations below ``ASCEND_HOME_PATH``, the toolchain-generic locations,
    then ``PATH``. The function is deliberately side-effect free and does not
    alter process-wide loader paths.
    """

    ascend_home_value = os.environ.get("ASCEND_HOME_PATH")
    ascend_home = os.path.realpath(os.path.expanduser(ascend_home_value)) if ascend_home_value else None
    override = os.environ.get("CANNBOTDSL_BISHENG_PATH") or os.environ.get("CANNBOTDSL_BISHENG")
    candidates = []
    checked = []

    if override:
        candidates.append(
            (
                "CANNBOTDSL_BISHENG_PATH/CANNBOTDSL_BISHENG",
                os.path.realpath(os.path.expanduser(override)),
            )
        )
    else:
        checked.append("CANNBOTDSL_BISHENG_PATH/CANNBOTDSL_BISHENG: <unset>")

    if ascend_home:
        host_dir = _host_sdk_directory()
        if host_dir:
            candidates.extend(
                (
                    (
                        f"ASCEND_HOME_PATH {host_dir} ccec compiler",
                        os.path.join(ascend_home, host_dir, "ccec_compiler", "bin", "bisheng"),
                    ),
                    (
                        f"ASCEND_HOME_PATH {host_dir} bin",
                        os.path.join(ascend_home, host_dir, "bin", "bisheng"),
                    ),
                )
            )
        else:
            checked.append(f"ASCEND_HOME_PATH host bin: unsupported host {platform.machine()!r}")
        candidates.extend(
            (
                (
                    "ASCEND_HOME_PATH bin",
                    os.path.join(ascend_home, "bin", "bisheng"),
                ),
                (
                    "ASCEND_HOME_PATH compiler",
                    os.path.join(ascend_home, "compiler", "bin", "bisheng"),
                ),
                (
                    "ASCEND_HOME_PATH tools compiler",
                    os.path.join(ascend_home, "tools", "bisheng_compiler", "bin", "bisheng"),
                ),
            )
        )
    else:
        checked.append("ASCEND_HOME_PATH: <unset>")

    seen = set()
    for label, candidate in candidates:
        candidate = os.path.abspath(candidate)
        if candidate in seen:
            continue
        seen.add(candidate)
        checked.append(f"{label}: {candidate}")
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return BishengResolution(candidate, ascend_home, tuple(checked))

    path_candidate = shutil.which("bisheng")
    checked.append(f"PATH bisheng: {path_candidate}" if path_candidate else "PATH bisheng: <not found>")
    if path_candidate:
        return BishengResolution(os.path.realpath(path_candidate), ascend_home, tuple(checked))

    resolution = BishengResolution(None, ascend_home, tuple(checked))
    if required:
        searched = "\n".join(f"  - {item}" for item in resolution.checked)
        raise RuntimeError(
            "bisheng compiler was not found. Checked:\n"
            f"{searched}\n"
            "Set CANNBOTDSL_BISHENG_PATH, configure ASCEND_HOME_PATH, or add "
            "bisheng to PATH. MLIR transformation and AscendC translation do "
            "not require CANN; only native kernel compilation does."
        )
    return resolution


def _run_subprocess(cmd, *, input=None, env=None, check=False):
    """Run a subprocess with proper Ctrl-C (SIGINT) handling.

    ``subprocess.run(capture_output=True)`` can swallow KeyboardInterrupt
    while waiting on pipe reads.  Using ``Popen`` directly lets us kill
    the child and re-raise immediately.
    """
    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    try:
        stdout, stderr = proc.communicate(input=input.encode() if isinstance(input, str) else input)
    except KeyboardInterrupt:
        proc.kill()
        proc.wait()
        raise
    stdout = stdout.decode() if stdout else ""
    stderr = stderr.decode() if stderr else ""
    if check and proc.returncode != 0:
        raise subprocess.CalledProcessError(proc.returncode, cmd, output=stdout, stderr=stderr)
    return subprocess.CompletedProcess(cmd, proc.returncode, stdout=stdout, stderr=stderr)


class AscendCCompiler:
    """Compile generated AscendC source into a shared library."""

    def __init__(
        self,
        *,
        project_root=None,
        npu_arch: Optional[str] = None,
        barall: Optional[bool] = None,
        disable_function_merging: bool = False,
    ):
        # Retain ``project_root`` for source compatibility. A wheel must not
        # derive loader paths from either the repository or its install tree.
        self.project_root = project_root
        self.npu_arch = resolve_npu_arch(npu_arch)
        self.barall = _getenv_binary_bool("CANNBOTDSL_BARALL") if barall is None else barall
        self.disable_function_merging = disable_function_merging

    @_timer("compile:compile_asc_to_so")
    def compile_ascendc_to_so(
        self,
        c_code: str,
        *,
        output_path: Optional[str] = None,
        keep_object: bool = False,
        exported_symbols: Optional[Sequence[str]] = None,
    ) -> str:
        """Compile AscendC C++ source directly to a shared library (.so).

        This method never deletes the .so it produces — the caller owns
        the returned file. The intermediate .asc
        and (by default) .o are cleaned up.

        :param output_path: If set, the .so is written directly to this path
            and the tempdir is cleaned up. If None, the .so is left under
            ``tempfile.mkdtemp(prefix='cannbotdsl_aot_')`` and the caller is
            responsible for unlinking it (and optionally rmtree-ing its
            parent dir whose basename starts with ``cannbotdsl_aot_``).
        :param exported_symbols: Exact public C symbol names to retain. When set,
            all other definitions are local to this DSO. None preserves the
            generic compiler interface's unrestricted exports.
        :param keep_object: If True, keep the intermediate ``kernel.o`` next
            to the .so for AOT debugging. Default False.

        Raises :class:`RuntimeError` only when the compile stage is entered and
        no compiler can be resolved.
        """
        resolution = resolve_bisheng()
        return self._compile_and_link(
            c_code,
            resolution.path,
            resolution.ascend_home,
            output_path=output_path,
            keep_object=keep_object,
            exported_symbols=exported_symbols,
        )

    def _get_env(self):
        return os.environ.copy()

    def _compile_and_link(
        self,
        c_code,
        bisheng,
        ascend_home,
        *,
        output_path: Optional[str] = None,
        keep_object: bool = False,
        exported_symbols: Optional[Sequence[str]] = None,
    ):
        """Compile AscendC source to .o, then link to .so via bisheng."""
        if exported_symbols is not None:
            if isinstance(exported_symbols, str):
                raise ValueError("exported_symbols must be a sequence of C symbol names")
            exported_symbols = tuple(exported_symbols)
            if not exported_symbols or any(
                not isinstance(name, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name)
                for name in exported_symbols
            ):
                raise ValueError("exported_symbols must contain valid C symbol names")
        workdir = tempfile.mkdtemp(prefix="cannbotdsl_aot_")
        asc_path = os.path.join(workdir, "kernel.asc")
        obj_path = os.path.join(workdir, "kernel.o")
        exports_path = os.path.join(workdir, "exports.map")
        boundary_path = os.path.join(workdir, "profiling_boundary.cpp")
        boundary_obj = os.path.join(workdir, "profiling_boundary.o")
        # When output_path is set, link directly there and rmtree workdir
        # afterwards; otherwise leave .so inside workdir for the caller.
        intermediate_so = os.path.join(workdir, "kernel.so")
        final_so = output_path if output_path is not None else intermediate_so

        with open(asc_path, "w", encoding="utf-8") as f:
            f.write(c_code)

        try:
            env = self._get_env()
            if ascend_home:
                env["ASCEND_HOME_PATH"] = ascend_home

            # Step 1: Compile .asc -> .o
            from cannbot_dsl.core.utils.timer import time_block as _time_block

            with _time_block("compile:bisheng_asc_to_obj"):
                compile_command = [
                    bisheng,
                    "-fPIC",
                    f"--npu-arch={self.npu_arch}",
                    "-c",
                    "-O3",
                    "-lineinfo",
                    "-x",
                    "asc",
                    "-I",
                    str(asc_ext_include_dir()),
                ]
                if "// CANNBOTDSL_PURE_SIMT=1" in c_code:
                    compile_command.append("--enable-simt")
                native_dump_sync = "// CANNBOTDSL_NATIVE_DUMP_REQUIRES_BARALL=1" in c_code
                if self.barall or native_dump_sync:
                    compile_command.extend(["-mllvm", "-cce-aicore-sync-bar-all=true"])
                if self.disable_function_merging:
                    compile_command.extend(["-mllvm", "-cce-aicore-merge-function=false"])
                compile_command.extend([asc_path, "-o", obj_path])
                _run_subprocess(
                    compile_command,
                    check=True,
                    env=env,
                )
            _LOG.debug("AscendC compiled: %s", obj_path)

            # Keep the generated Native ABI public, but bind implementation
            # symbols (notably C++ templates) within the provider at link time.
            # Leave generic compile_ascendc_to_so callers unchanged.
            export_options = []
            if exported_symbols is not None:
                with open(exports_path, "w", encoding="utf-8") as f:
                    f.write("{\n  global:\n")
                    for name in sorted(set(exported_symbols)):
                        f.write(f"    {name};\n")
                    f.write("  local: *;\n};\n")
                export_options = [f"-Wl,--version-script={exports_path}"]

            # Compiler-generated NODE records otherwise hide ProfileSpec's
            # logical name behind the C++ device symbol in msprof summaries.
            profiling_options = []
            if exported_symbols and any(name.endswith("__cannbot_invoke_profile_v1") for name in exported_symbols):
                Path(boundary_path).write_text(_PROFILING_BOUNDARY_SOURCE, encoding="utf-8")
                _run_subprocess(
                    [bisheng, "-fPIC", "-O2", "-std=c++17", "-c", "-x", "c++", boundary_path, "-o", boundary_obj],
                    check=True,
                    env=env,
                )
                profiling_options = [boundary_obj, *(f"-Wl,--wrap={name}" for name in _PROFILING_BOUNDARY_SYMBOLS)]

            # Step 2: Link .o -> .so
            with _time_block("compile:bisheng_obj_to_so"):
                _run_subprocess(
                    [
                        bisheng,
                        "-shared",
                        "-fPIC",
                        f"--npu-arch={self.npu_arch}",
                        "-o",
                        final_so,
                        obj_path,
                        # Host-side scalar fmod/minnum/maxnum lower to libm.
                        # Device-side variants use AICore intrinsics and do
                        # not leave host-library references.
                        "-lm",
                        *export_options,
                        *profiling_options,
                    ],
                    check=True,
                    env=env,
                )
            _LOG.debug("AscendC linked: %s", final_so)
            return final_so
        except subprocess.CalledProcessError as e:
            failed_cmd = " ".join(e.cmd) if isinstance(e.cmd, list) else str(e.cmd)
            error_msg = f"bisheng compilation failed!\nCOMMAND:\n{failed_cmd}\nSTDOUT:\n{e.stdout}\nSTDERR:\n{e.stderr}"
            _LOG.error(error_msg)
            # Clean up workdir on failure; caller never sees a partial .so.
            shutil.rmtree(workdir, ignore_errors=True)
            # An explicit output_path lives outside workdir, so a partially
            # linked .so there would survive the rmtree above.
            if output_path is not None and os.path.exists(output_path):
                try:
                    os.unlink(output_path)
                except OSError:
                    pass
            raise RuntimeError(error_msg) from e
        finally:
            for path in (boundary_path, boundary_obj):
                if os.path.exists(path):
                    os.unlink(path)
            if os.path.exists(exports_path):
                os.unlink(exports_path)
            if os.path.exists(asc_path):
                os.unlink(asc_path)
            if os.path.exists(obj_path):
                if keep_object:
                    shutil.copy(obj_path, final_so + ".o")
                os.unlink(obj_path)
            # If output_path was provided, the final .so lives outside workdir;
            # the workdir itself is no longer needed.
            if output_path is not None and os.path.isdir(workdir):
                shutil.rmtree(workdir, ignore_errors=True)
