# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Device timestamp markers through the CANN native debug channel."""

import cannbot_dsl._mlir.ir as ir
from cannbot_dsl._mlir.dialects import cannir
from cannbot_dsl.core.utils.type_checks import is_exact_instance
from cannbot_dsl.types import dtypes


def print_time_stamp(marker_id: int) -> None:
    """Print a device cycle/PC record with core identity through CANN's debug channel.

    ``marker_id`` is a user-defined code-location marker, matching the native
    ``descId`` field. It identifies neither a core nor a device.
    Call on the scalar side of a ``@kernel``, outside any VF. ``marker_id``
    accepts integer constants in the uint32 range or dtypes.uint32 kernel
    values. Other dynamic types are rejected. IDs above 0xffff avoid CANN's
    reserved range. Host arguments follow the existing uint32 ABI checks.
    Instrumented code enables the native timestamp facility automatically.
    Calls CANN's asc_time_stamp directly for cycle/PC and native binary records.
    A separate timestamp-core line adds coreType, coreIndex, logical blockIdx,
    descId and entry; the user ID only identifies the code location. Do not
    associate interleaved core and timestamp lines solely by arrival order.
    Output is asynchronous; synchronize the device before collecting logs.
    Timestamps are counter cycles, not wall-clock time or a pipeline barrier.
    """
    from cannbot_dsl.core.scalar_conversion import coerce_scalar_value
    from cannbot_dsl.core.contracts.elements import trace_scalar_for_value
    from cannbot_dsl.core.frontend.call_context import in_device_domain
    from cannbot_dsl.lang.vf import _CURRENT_VF

    if not in_device_domain():
        raise RuntimeError("print_time_stamp must be called inside a @kernel device body")
    if _CURRENT_VF.get() is not None:
        raise ValueError("print_time_stamp must be outside a VF region")
    if isinstance(marker_id, ir.Value):
        if trace_scalar_for_value(marker_id, path="marker_id").dtype is not dtypes.uint32:
            raise TypeError("marker_id must be a dtypes.uint32 scalar; cast explicitly after checking its range")
        marker_id_value = marker_id
    else:
        if not is_exact_instance(marker_id, int) or not 0 <= marker_id < 2**32:
            raise ValueError("marker_id must be a uint32 integer")
        marker_id_value = marker_id
    cannir.PrintTimeStampOp(coerce_scalar_value(marker_id_value, ir.IntegerType.get_signless(32), target_unsigned=True))
