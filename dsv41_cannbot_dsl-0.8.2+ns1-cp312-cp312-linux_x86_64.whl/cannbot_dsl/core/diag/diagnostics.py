# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Shared exception data and rendering; source discovery runs only on failure."""

from __future__ import annotations

import sys
import types
import unicodedata
import weakref
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cannbot_dsl.core.frontend.api import SourceSpan


class DiagnosticCode(str, Enum):
    """Stable categories; selection rules and examples are in diagnostic_reporting.md."""

    INVALID_TYPE = "INVALID_TYPE"
    INVALID_ARGUMENT = "INVALID_ARGUMENT"
    INVALID_SHAPE = "INVALID_SHAPE"
    UNSUPPORTED_FEATURE = "UNSUPPORTED_FEATURE"
    TS101_INVALID_SCALAR_LITERAL = "TS101_INVALID_SCALAR_LITERAL"
    CT101_INVALID_RUNTIME_DEFAULT = "CT101_INVALID_RUNTIME_DEFAULT"
    ST101_UNSUPPORTED_DYNAMIC_ARGUMENT = "ST101_UNSUPPORTED_DYNAMIC_ARGUMENT"
    ST102_NON_VOID_ENTRY_RETURN = "ST102_NON_VOID_ENTRY_RETURN"
    KM101_INVALID_BLOCK_DIM = "KM101_INVALID_BLOCK_DIM"
    ABI101_RUNTIME_ARGUMENT_REJECTED = "ABI101_RUNTIME_ARGUMENT_REJECTED"
    IN001_COMPILER_INVARIANT = "IN001_COMPILER_INVARIANT"


TS101_INVALID_SCALAR_LITERAL = DiagnosticCode.TS101_INVALID_SCALAR_LITERAL
CT101_INVALID_RUNTIME_DEFAULT = DiagnosticCode.CT101_INVALID_RUNTIME_DEFAULT
ST101_UNSUPPORTED_DYNAMIC_ARGUMENT = DiagnosticCode.ST101_UNSUPPORTED_DYNAMIC_ARGUMENT
ST102_NON_VOID_ENTRY_RETURN = DiagnosticCode.ST102_NON_VOID_ENTRY_RETURN
KM101_INVALID_BLOCK_DIM = DiagnosticCode.KM101_INVALID_BLOCK_DIM
ABI101_RUNTIME_ARGUMENT_REJECTED = DiagnosticCode.ABI101_RUNTIME_ARGUMENT_REJECTED
IN001_COMPILER_INVARIANT = DiagnosticCode.IN001_COMPILER_INVARIANT

# Reuse frontend SourceUnit/SourceSpan data when available. Source discovery
# is imported lazily on failure, including before the first materialization.
_source_resolver = None
_sources = {}


def _register_source(code, source):
    """Weak registration preserves code-object lifetime and execution identity."""
    identity = id(code)
    # Code objects compare structurally; equal code from different files must
    # keep distinct source entries. The weak reference only controls lifetime.
    reference = weakref.ref(code, lambda _: _sources.pop(identity, None))
    _sources[identity] = (reference, source)
    for constant in code.co_consts:
        if isinstance(constant, types.CodeType):
            _register_source(constant, source)


def _source_frames():
    frame = sys._getframe(1)
    try:
        while frame is not None:
            yield frame, frame.f_lineno, frame.f_lasti
            frame = frame.f_back
    finally:
        del frame


def _source_locations():
    """Yield DSL sources or ordinary Python callers of a framework API."""
    frames = _source_frames()
    frame = None
    call = None
    callee_module = ""
    try:
        for frame, line, lasti in frames:
            module = frame.f_globals.get("__name__", "")
            calls_api = (callee_module.startswith("cannbot_dsl.")
                         and not callee_module.startswith("cannbot_dsl.core.diag."))
            callee_module = module
            if (module == "cannbot_dsl.core.frontend.call_context"
                    and frame.f_code.co_name == "dispatch_call"):
                values = frame.f_locals
                call = (values.get("source"), values.get("line"), values.get("column"), values.get("target"))
            registered = _sources.get(id(frame.f_code))
            if registered is not None and registered[0]() is frame.f_code:
                source = registered[1]
            elif calls_api and module != 'cannbot_dsl' and not module.startswith("cannbot_dsl."):
                # The adjacent callee establishes the API boundary. Do not pick
                # arbitrary non-framework frames, or callers of error helpers.
                source = frame.f_code
            else:
                continue
            column = None
            target = None
            if call is not None and not isinstance(source, types.CodeType) and call[0] is source.function:
                line, column, target = call[1:]
            elif hasattr(frame.f_code, "co_positions"):
                positions = list(frame.f_code.co_positions())
                if 0 <= lasti // 2 < len(positions):
                    start, _, column, _ = positions[lasti // 2]
                    if start is not None:
                        line = start
            yield source, line, column, target
    finally:
        frames.close()
        del frame


def _resolve_source(*, span=None, argument=None):
    try:
        resolver = _source_resolver
        if resolver is None:
            # Host-side API checks can fail before any DSL materialization.
            from cannbot_dsl.core.diag.source_reporting import resolve_source

            resolver = resolve_source
        return resolver(span=span, argument=argument)
    except Exception:  # noqa: BLE001 -- diagnostic lookup must not replace a failure
        return span, None, 1


def argument_span(name: str | int) -> SourceSpan | None:
    """Return an available argument span, falling back to the current call."""
    return _resolve_source(argument=name)[0]


def annotation_source(function, name: str) -> dict:
    """Return source fields for an explicitly identified parameter annotation."""
    try:
        from cannbot_dsl.core.diag.source_reporting import resolve_annotation_source

        return resolve_annotation_source(function, name)
    except Exception:  # noqa: BLE001 -- a missing declaration must not hide the type error
        return {"source": ""}


def _byte_col_to_character_col(line: str, byte_col: int) -> int:
    """Convert an AST UTF-8 byte offset to a zero-based character offset."""

    encoded = line.encode("utf-8")
    prefix = encoded[: max(0, min(byte_col, len(encoded)))]
    return len(prefix.decode("utf-8", errors="ignore"))


def _display_width(text: str) -> int:
    return sum(0 if unicodedata.combining(c) else 2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in text)


def format_source_excerpt(
    source: str | None,
    span: SourceSpan | None,
    *,
    source_first_line: int = 1,
) -> str | None:
    """Render the existing multi-line excerpt, accounting for tabs and display width."""

    if source is None or span is None:
        return None
    lines = source.splitlines()
    if not lines:
        return None
    first_index = span.start_line - source_first_line
    last_index = span.end_line - source_first_line
    if first_index < 0 or first_index >= len(lines):
        return None
    last_index = max(first_index, min(last_index, len(lines) - 1))
    number_width = len(str(source_first_line + last_index))
    rendered: list[str] = []
    for index in range(first_index, last_index + 1):
        line = lines[index]
        line_number = source_first_line + index
        if index == first_index:
            caret_start = _byte_col_to_character_col(line, span.start_col)
        else:
            caret_start = 0
        if index == last_index:
            caret_end = _byte_col_to_character_col(line, span.end_col)
        else:
            caret_end = len(line)
        # AST columns count UTF-8 bytes; terminal carets count display cells.
        prefix_width = _display_width(line[:caret_start].expandtabs(8))
        end_width = _display_width(line[:caret_end].expandtabs(8))
        caret_width = max(1, end_width - prefix_width)
        rendered.append(f"{line_number:>{number_width}} | {line.expandtabs(8)}")
        rendered.append(f"{'':>{number_width}} | {' ' * prefix_width}{'^' * caret_width}")
    return "\n".join(rendered)


def _format_source(span, source, source_first_line):
    if span is None:
        return ""
    column = span.start_col + 1
    if source is not None:
        lines = source.splitlines()
        index = span.start_line - source_first_line
        if 0 <= index < len(lines):
            column = _byte_col_to_character_col(lines[index], span.start_col) + 1
    text = f"  --> {span.filename}:{span.start_line}:{column}"
    excerpt = format_source_excerpt(source, span, source_first_line=source_first_line)
    return text + ("\n" + excerpt if excerpt else "")


class CANNBotError(Exception):
    """A classified error. Only code and message are required at a check site."""

    _code_type = DiagnosticCode
    _auto_source = True

    def __init__(
        self,
        code: DiagnosticCode | Enum,
        message: str,
        *,
        span: SourceSpan | None = None,
        hint: str | None = None,
        note: str | None = None,
        source: str | None = None,
        source_first_line: int = 1,
        phase: str | None = None,
        path: str | None = None,
    ) -> None:
        self.code = self._code_type(code)
        self.message = str(message)
        self.phase = str(phase) if phase is not None else None
        self.path = str(path) if path is not None else None
        self.hint = str(hint) if hint is not None else None
        self.note = str(note) if note is not None else None
        if self._auto_source and source is None:
            # path is diagnostic metadata, not a source argument selector.
            # Check sites request parameter locations explicitly with argument_span().
            resolved_span, resolved_source, first_line = _resolve_source(span=span)
            if resolved_span is not None:
                span, source, source_first_line = resolved_span, resolved_source, first_line
        self.span, self.source, self.source_first_line = span, source, source_first_line
        # Preserve the baseline exception args as well as its str() interface.
        super().__init__(str(self))

    def __str__(self) -> str:
        try:
            return self._format()
        except Exception:  # noqa: BLE001 -- source rendering must not hide the reason
            return f"{self.code.value}: {self.message}"

    def _format(self) -> str:
        parts = [f"{self.code.value}: {self.message}"]
        location = _format_source(self.span, self.source, self.source_first_line)
        if location:
            parts.append(location)
        if self.phase:
            parts.append(f"phase: {self.phase}")
        if self.path:
            parts.append(f"path: {self.path}")
        if self.note:
            parts.append(f"note: {self.note}")
        if self.hint:
            parts.append(f"hint: {self.hint}")
        return "\n".join(parts)


class CANNBotTypeError(CANNBotError, TypeError):
    """Type mismatch, also catchable as TypeError."""


class CANNBotValueError(CANNBotError, ValueError):
    """Invalid value, also catchable as ValueError."""


class CANNBotRuntimeError(CANNBotError, RuntimeError):
    """Runtime or compilation failure, also catchable as RuntimeError."""


class CANNBotOverflowError(CANNBotError, OverflowError):
    """An unrepresentable numeric extent, also catchable as OverflowError."""


class CANNBotIndexError(CANNBotError, IndexError):
    """Invalid index, also catchable as IndexError and LookupError."""


class CANNBotNotImplementedError(CANNBotRuntimeError, NotImplementedError):
    """Unsupported API capability, also catchable as NotImplementedError."""


class CANNBotInternalError(CANNBotRuntimeError):
    """A confirmed compiler invariant violation."""


__all__ = [
    "ABI101_RUNTIME_ARGUMENT_REJECTED",
    "CT101_INVALID_RUNTIME_DEFAULT",
    "IN001_COMPILER_INVARIANT",
    "KM101_INVALID_BLOCK_DIM",
    "ST101_UNSUPPORTED_DYNAMIC_ARGUMENT",
    "ST102_NON_VOID_ENTRY_RETURN",
    "TS101_INVALID_SCALAR_LITERAL",
    "CANNBotError",
    "CANNBotInternalError",
    "CANNBotOverflowError",
    "CANNBotIndexError",
    "CANNBotNotImplementedError",
    "CANNBotRuntimeError",
    "CANNBotTypeError",
    "CANNBotValueError",
    "DiagnosticCode",
    "annotation_source",
    "argument_span",
    "format_source_excerpt",
]
