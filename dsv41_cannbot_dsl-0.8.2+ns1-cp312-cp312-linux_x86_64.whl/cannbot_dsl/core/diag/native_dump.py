# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Thin bindings to CANN native tensor and vector-register diagnostics."""

import math

import cannbot_dsl._mlir.ir as ir
from cannbot_dsl._mlir.dialects import ascvec, cannir
from cannbot_dsl.core.diag import debug as _debug
from cannbot_dsl.core.utils.type_checks import is_exact_instance
from cannbot_dsl.tensor import MemLoc
from cannbot_dsl.types import dtypes


def _native_dump_uint32(value, name, *, positive=False, dynamic=False):
    """Validate constants before emission and accept integer SSA parameters."""
    raw = value if isinstance(value, ir.Value) else getattr(value, "value", value)
    if dynamic and isinstance(raw, ir.Value):
        if isinstance(raw.type, ir.IndexType) or (isinstance(raw.type, ir.IntegerType) and raw.type.width > 1):
            return raw
        raise TypeError(f"{name} must be an integer SSA value")
    minimum = 1 if positive else 0
    if not is_exact_instance(value, int) or not minimum <= value < 2**32:
        qualifier = "positive " if positive else ""
        raise ValueError(f"{name} must be a {qualifier}uint32 integer")
    return value


def _native_dump_type(source_dtype: dtypes.DType, dtype: dtypes.DType | None) -> tuple[ir.Type, int]:
    """Resolve CANN's printed type; bool occupies one byte in native memory."""
    from cannbot_dsl.core.contracts.elements import element_for_dtype

    element = element_for_dtype(source_dtype if dtype is None else dtype)
    result = element.dtype
    if result is dtypes.float64:
        raise TypeError("native dump does not support float64")
    bits = 8 if result is dtypes.bool else result.bits
    if bits < 8 or bits % 8:
        raise TypeError("native dump requires a whole-byte element dtype")
    return element.mlir_type(), bits


def dump_tensor(
    tensor,
    *,
    desc=None,
    dump_size=None,
    offset=0,
    shape=None,
    dtype=None,
):
    """Dump a contiguous physical span to the native CANN diagnostic stream.

    Accepts a Tensor in GM, UB, L1, L0C, BIAS or FIXBUF. For RingBuffer storage,
    bind ``next_write().view()`` or ``next_read().view()``, or reuse a previously
    bound Tensor view. Select the slot before entering a VF region.
    ``dump_size`` and ``offset`` use element units.
    The default size is the static physical extent, capped at 1 KiB; an explicit
    size may be larger. Runtime view offsets are preserved. The caller must
    guarantee bounds for dynamic views, offsets and sizes. ``desc`` and
    ``dump_size`` accept integer SSA values. ``dtype`` may reinterpret elements
    of the same byte width, including byte storage as CANN bool.

    ``shape`` optionally supplies up to eight dimensions of display metadata,
    independently of the printed element count. Inside a raw VF only
    UB is supported, without shape metadata. Native records do not appear in
    ``get_debug_prints()``. FIXBUF can be inspected through an explicit typed
    ``make_pointer``/``make_tensor`` view of an existing allocation.

    Scalar UB/L1 addresses require 32-byte alignment. L0C addresses require
    1024-byte alignment; CANN may read a complete tile for a partial dump.
    Each raw VF record must fit its payload and 72-byte header in the 2024-byte native FIFO. Cumulative
    output and repeated calls are handled by CANN, including in dynamic loops.
    Output is asynchronous, as with CANN; synchronize before collecting it.
    """
    from cannbot_dsl.ops._operands import _tensor_operand
    from cannbot_dsl.core.scalar_conversion import coerce_scalar_value
    from cannbot_dsl.lang.vf import _CURRENT_VF, _current_vf_mode
    from cannbot_dsl.ops.reg._common import _tag_raw_op

    carrier = _tensor_operand(tensor)
    tensor_type = cannir.TensorType(carrier.type)
    memloc = MemLoc(tensor_type.pointer.memloc)
    supported = (
        MemLoc.GM,
        MemLoc.UB,
        MemLoc.L1,
        MemLoc.L0C,
        MemLoc.BIAS,
        MemLoc.FBUF,
        MemLoc.FBUF_ACT,
    )
    if memloc not in supported:
        raise NotImplementedError(f"dump_tensor does not support memory location {memloc.name}")
    source_dtype = tensor.dtype
    source_bits = 8 if source_dtype is dtypes.bool else source_dtype.bits
    dump_dtype, bits = _native_dump_type(source_dtype, dtype)
    if source_bits != bits:
        raise TypeError("dump_tensor dtype must preserve element byte width")
    physical_shape = getattr(_debug, "_type_shape_tuple")(tensor_type.physical_layout)
    extent = math.prod(physical_shape) if physical_shape and all(dim > 0 for dim in physical_shape) else None
    if is_exact_instance(offset, int) and offset < 0:
        raise ValueError("dump_tensor offset must be non-negative")
    offset_value = offset if isinstance(offset, ir.Value) else getattr(offset, "value", offset)
    if not is_exact_instance(offset_value, int):
        valid_ssa = isinstance(offset_value, ir.Value) and (
            isinstance(offset_value.type, ir.IndexType)
            or (isinstance(offset_value.type, ir.IntegerType) and offset_value.type.width > 1)
        )
        if not valid_ssa:
            raise TypeError("dump_tensor offset must be an integer or integer SSA value")
    if dump_size is None:
        if extent is None or not is_exact_instance(offset, int):
            raise ValueError("dynamic views or offsets require dump_size")
        dump_size = min(extent - offset, 1024 // (bits // 8))
    count = _native_dump_uint32(
        dump_size,
        "dump_size",
        dynamic=True,
    )
    static_count = is_exact_instance(count, int)
    if static_count and count * (bits // 8) >= 2**32:
        raise ValueError("dump_tensor byte count must fit in uint32")
    if static_count and extent is not None and is_exact_instance(offset, int) and offset + count > extent:
        raise ValueError("dump_tensor span exceeds the tensor's physical extent")
    display_shape = () if shape is None else shape
    if not isinstance(display_shape, (tuple, list)) or len(display_shape) > 8:
        raise ValueError("dump_tensor shape must contain at most eight dimensions")
    for dim in display_shape:
        _native_dump_uint32(dim, "shape dimension", positive=True)
    vf_mode = _current_vf_mode()
    if _CURRENT_VF.get() is not None and (vf_mode != "simd" or memloc != MemLoc.UB or display_shape):
        raise ValueError("VF dump_tensor requires simd mode, UB, and no shape")
    # CANN 9.2 reserves 2024 bytes after the VF FIFO header. A tensor TLV
    # consumes 72 bytes, leaving 1952 bytes of aligned payload per record.
    if vf_mode == "simd" and static_count and count * (bits // 8) > 1952:
        raise ValueError("simd VF dump_tensor payload must not exceed 1952 bytes")
    plan = getattr(_debug, "_find_current_plan")("dump_tensor")
    desc = plan.native_dump_count if desc is None else desc
    desc = _native_dump_uint32(desc, "desc", dynamic=True)
    integer_type = ir.IntegerType.get_signless(64)
    op = cannir.DumpTensorOp(
        carrier,
        coerce_scalar_value(offset, ir.IndexType.get()),
        coerce_scalar_value(desc, integer_type),
        coerce_scalar_value(count, integer_type),
        ir.DenseI64ArrayAttr.get(display_shape),
        ir.TypeAttr.get(dump_dtype),
    )
    _tag_raw_op(op)
    plan.native_dump_count += 1


def dump_reg(register, *, desc=None, dump_size=None, dtype=None):
    """Dump raw vector-register lanes to CANN inside ``vf(mode='simd')``.

    ``dump_size`` defaults to all lanes in one 256-byte register. It must not
    exceed that register's capacity. The source register is preserved.
    ``dtype`` selects CANN's template element type independently of the carrier
    register, for example bool over an int8 register. Integer SSA values are
    accepted for ``desc`` and ``dump_size``; dynamic sizes must fit the register.
    """
    from cannbot_dsl.core.scalar_conversion import coerce_scalar_value
    from cannbot_dsl.lang.vf import _require_raw_mode
    from cannbot_dsl.ops.reg import RawVReg
    from cannbot_dsl.ops.reg._common import _tag_raw_op

    _require_raw_mode("dump_reg")
    if not isinstance(register, RawVReg):
        raise TypeError("dump_reg expects a RawVReg")
    dump_dtype, bits = _native_dump_type(register.dtype, dtype)
    capacity = 2048 // bits
    count = capacity if dump_size is None else dump_size
    count = _native_dump_uint32(count, "dump_size", dynamic=True)
    if is_exact_instance(count, int) and count > capacity:
        raise ValueError("dump_reg size exceeds one vector register")
    plan = getattr(_debug, "_find_current_plan")("dump_reg")
    desc = plan.native_dump_count if desc is None else desc
    desc = _native_dump_uint32(desc, "desc", dynamic=True)
    integer_type = ir.IntegerType.get_signless(64)
    op = ascvec.DumpRegOp(
        register,
        coerce_scalar_value(desc, integer_type),
        coerce_scalar_value(count, integer_type),
        ir.TypeAttr.get(dump_dtype),
    )
    _tag_raw_op(op)
    plan.native_dump_count += 1
