# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Diagnostic adapter for existing frontend sources and Python API callers.
Stack inspection and AST lookup occur only on failure or explicit reporting.
"""

from __future__ import annotations

import ast
import inspect
import textwrap
from types import CodeType

from cannbot_dsl.core.diag import diagnostics
from cannbot_dsl.core.frontend.api import SourceSpan


def _units():
    return {id(unit): unit for _, unit in list(diagnostics._sources.values())}.values()


def _contains(source, span):
    return (source.filename == span.filename
            and source.target.lineno <= span.start_line <= span.end_line <= source.target.end_lineno)


def _presentation(raw, normalized, first_line, span):
    raw_lines, normalized = raw.splitlines(), normalized.splitlines()

    def shift(line):
        index = line - first_line
        if 0 <= index < len(raw_lines) and index < len(normalized):
            return len(raw_lines[index].encode("utf-8")) - len(normalized[index].encode("utf-8"))
        return 0

    adjusted = SourceSpan(span.filename, span.start_line, span.start_col + shift(span.start_line),
                          span.end_line, span.end_col + shift(span.end_line))
    return adjusted, raw, first_line


def _positional_index(target, argument: str | int) -> int | None:
    """Map a declared parameter to a written position, without evaluating arguments."""
    if isinstance(argument, int):
        return argument
    if target is None:
        return None
    try:
        parameters = inspect.signature(target).parameters.values()
    except (TypeError, ValueError):
        return None
    positional = []
    for parameter in parameters:
        if parameter.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD):
            positional.append(parameter.name)
    return positional.index(argument) if argument in positional else None


def _call_span(tree, filename, line, column, argument, target=None):
    calls = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and node.lineno <= line <= node.end_lineno:
            calls.append(node)
    if column is not None:
        exact = [node for node in calls if node.lineno == line and node.col_offset == column]
        calls = exact if exact else []
    if len(calls) != 1:
        return None
    node = calls[0]
    if argument is not None:
        for keyword in node.keywords:
            if keyword.arg == argument:
                return SourceSpan.from_node(keyword.value, filename)
        position = _positional_index(target, argument)
        if (position is not None and 0 <= position < len(node.args)
                and not any(isinstance(arg, ast.Starred) for arg in node.args[:position + 1])):
            return SourceSpan.from_node(node.args[position], filename)
    return SourceSpan.from_node(node, filename)


def _line_span(text, filename, first_line, line):
    # Python 3.10 may only provide a line. Do not choose one of several calls.
    index = line - first_line
    lines = text.splitlines()
    if 0 <= index < len(lines):
        text = lines[index]
        start = len(text.encode("utf-8")) - len(text.lstrip().encode("utf-8"))
        return SourceSpan(filename, line, start, line, max(start + 1, len(text.encode("utf-8"))))
    return None


def _python_source(code):
    try:
        # inspect.getsourcelines(code) treats module code as a single block;
        # the failing API call may be after that block.
        if code.co_name == "<module>":
            lines, _ = inspect.findsource(code)
            return "".join(lines), 1
        lines, first_line = inspect.getsourcelines(code)
        return "".join(lines), first_line
    except (OSError, TypeError):
        return None, 1


def _python_location(code, line, column, argument):
    """Read an executing helper only on failure; never execute its source."""
    raw, first_line = _python_source(code)
    if raw is None:
        start = column if column is not None else 0
        return SourceSpan(code.co_filename, line, start, line, start + 1), None, 1
    normalized = textwrap.dedent(raw)
    if column is not None:
        index = line - first_line
        original_lines, normalized_lines = raw.splitlines(), normalized.splitlines()
        if 0 <= index < len(original_lines):
            column -= (len(original_lines[index].encode("utf-8"))
                       - len(normalized_lines[index].encode("utf-8")))
    try:
        tree = ast.parse(normalized, filename=code.co_filename)
        ast.increment_lineno(tree, first_line - 1)
        span = _call_span(tree, code.co_filename, line, column, argument)
    except SyntaxError:
        span = None
    span = span or _line_span(normalized, code.co_filename, first_line, line)
    if span is None:
        return SourceSpan(code.co_filename, line, 0, line, 1), None, 1
    return _presentation(raw, normalized, first_line, span)


def resolve_source(*, span=None, argument=None):
    if span is not None:
        candidates = [unit for unit in _units() if _contains(unit, span)]
        texts = {(unit.original_source or unit.source, unit.first_line) for unit in candidates}
        if len(texts) == 1:
            text, first = texts.pop()
            return span, text, first
        if candidates:
            return span, None, 1

    locations = diagnostics._source_locations()
    try:
        for source, line, column, target in locations:
            if isinstance(source, CodeType):
                if span is None:
                    return _python_location(source, line, column, argument)
                if source.co_filename == span.filename:
                    raw, first_line = _python_source(source)
                    if (raw is not None
                            and first_line <= span.start_line <= span.end_line < first_line + len(raw.splitlines())):
                        return span, raw, first_line
                continue
            if span is not None:
                continue
            located = _call_span(source.target, source.filename, line, column, argument, target)
            located = located or _line_span(source.source, source.filename, source.first_line, line)
            if located is not None:
                return _presentation(source.original_source or source.source, source.source, source.first_line, located)
        return span, None, 1
    finally:
        locations.close()


diagnostics._source_resolver = resolve_source


def resolve_annotation_source(function, name):
    """Read a binder's target declaration only on failure, without evaluating annotations."""
    if inspect.ismethod(function):
        function = function.__func__
    if not inspect.isfunction(function):
        return {"source": ""}
    code = function.__code__
    fallback = {
        "span": SourceSpan(code.co_filename, code.co_firstlineno, 0, code.co_firstlineno, 1),
        "source": "",
        "note": "Location identifies the function; parameter annotation source is unavailable.",
    }
    try:
        from cannbot_dsl.core.frontend.source import SourceUnit

        unit = SourceUnit.capture(function)
        args = unit.target.args
        parameters = [*args.posonlyargs, *args.args, *args.kwonlyargs]
        parameters += [arg for arg in (args.vararg, args.kwarg) if arg is not None]
        parameter = next((arg for arg in parameters if arg.arg == name), None)
        if parameter is None or parameter.annotation is None:
            return fallback
        span, source, first_line = _presentation(
            unit.original_source or unit.source, unit.source, unit.first_line,
            unit.span(parameter.annotation),
        )
        return {"span": span, "source": source, "source_first_line": first_line}
    except Exception:  # noqa: BLE001 -- source lookup cannot replace an annotation error
        return fallback


register_source = diagnostics._register_source
