# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""SSBUF Tensor access rules over existing CANNIR/SCF execution guards.

These memory-space-specific rules support Tensor indexing; they do not analyze
Python source or change the generic frontend's control-flow lowering.
"""

from cannbot_dsl._mlir import ir


def _possible_values(value, cube, memo, depth=0):
    # Strip registered DSL value subclasses: their equality emits device IR.
    value = ir.Value(value)
    if value in memo:
        return memo[value]
    if depth > 64 or ir.BlockArgument.isinstance(value):
        return None
    op = value.owner.operation
    name = op.name
    result = None
    if name in ("cannir.is_aic", "cannir.is_aiv"):
        result = frozenset({int(cube == (name == "cannir.is_aic"))})
    elif name == "arith.constant" and ir.IntegerAttr.isinstance(op.attributes["value"]):
        constant = ir.IntegerAttr(op.attributes["value"]).value
        result = frozenset({constant & 1 if str(value.type) == "i1" else constant})
    elif name in ("arith.extui", "arith.extsi", "arith.index_cast", "arith.index_castui"):
        # Role predicates reach integer comparisons through Boolean coercions.
        # Sign extension of i1 true is -1, not +1.
        result = _possible_values(op.operands[0], cube, memo, depth + 1)
        if result is not None and not result.issubset({0, 1}):
            result = None
        if result is not None and name in ("arith.extsi", "arith.index_cast") and str(op.operands[0].type) == "i1":
            result = frozenset(-v for v in result)
    elif name in ("arith.andi", "arith.ori", "arith.xori") and str(value.type) == "i1":
        lhs = _possible_values(op.operands[0], cube, memo, depth + 1)
        rhs = _possible_values(op.operands[1], cube, memo, depth + 1)
        combine = {"arith.andi": int.__and__, "arith.ori": int.__or__, "arith.xori": int.__xor__}[name]
        result = frozenset(combine(a, b) for a in (lhs or {0, 1}) for b in (rhs or {0, 1}))
    elif name == "arith.cmpi":
        lhs = _possible_values(op.operands[0], cube, memo, depth + 1)
        rhs = _possible_values(op.operands[1], cube, memo, depth + 1)
        predicate = ir.IntegerAttr(op.attributes["predicate"]).value
        if lhs is not None and rhs is not None and predicate in (0, 1):
            result = frozenset(int((a == b) == (predicate == 0)) for a in lhs for b in rhs)
    elif name == "scf.if":
        condition = _possible_values(op.operands[0], cube, memo, depth + 1)
        index = ir.OpResult(value).result_number
        values = set()
        for region_index, truth in ((0, 1), (1, 0)):
            if condition is not None and truth not in condition:
                continue
            block = op.regions[region_index].blocks[0]
            terminator = list(block.operations)[-1]
            branch = _possible_values(terminator.operands[index], cube, memo, depth + 1)
            if branch is None:
                break
            values.update(branch)
        else:
            result = frozenset(values)
    memo[value] = result
    return result


def _refine_core_candidates(condition, truth, candidates, memo):
    for cube in tuple(candidates):
        values = _possible_values(condition, cube, memo.get(cube, {}))
        if values is not None and truth not in values:
            candidates.remove(cube)


def ssbuf_execution_core():
    """Prove exactly one core from enclosing scf.if guards, including short circuiting."""
    candidates = {False, True}
    memo = {False: {}, True: {}}
    block = ir.InsertionPoint.current.block
    while block is not None:
        parent = block.owner.operation
        if parent.name == "scf.if":
            truth = int(block == parent.regions[0].blocks[0])
            _refine_core_candidates(parent.operands[0], truth, candidates, memo)
        if parent.name in ("func.func", "builtin.module"):
            break
        block = ir.InsertionPoint(parent).block
    if len(candidates) != 1:
        raise TypeError(
            "SSBUF point access requires an unambiguous execution core; place it inside an is_aic() or is_aiv() branch"
        )
    return "cube" if True in candidates else "vec"
