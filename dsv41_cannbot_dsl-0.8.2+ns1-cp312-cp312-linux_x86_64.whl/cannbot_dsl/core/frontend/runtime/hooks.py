# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Context-local hooks shared by all structured control-flow operations."""

from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from functools import partial
from typing import Any, Callable, Iterator, Protocol

from cannbot_dsl.core.frontend.api import SourceSpan
from cannbot_dsl.core.frontend.diagnostics import FrontendError
from cannbot_dsl.core.utils.type_checks import is_exact_instance


@dataclass(frozen=True, slots=True)
class RegionInfo:
    id: int
    kind: str
    span: SourceSpan
    source: str
    source_first_line: int
    emit_line_info: bool = False

    def error(
        self,
        code,
        message: str,
        *,
        hint: str | None = None,
    ) -> FrontendError:
        return FrontendError(
            code,
            message,
            span=self.span,
            hint=hint,
            source=self.source,
            source_first_line=self.source_first_line,
        )


class RegionHook(Protocol):
    """Observer around construction of a for/if/while operation."""

    def enter(self, kind: str, operation: Any, region_info: RegionInfo) -> object | None:
        ...

    def exit(
        self,
        kind: str,
        operation: Any,
        region_info: RegionInfo,
        token: object | None,
        error: BaseException | None,
    ) -> None:
        ...


class RegionObserver(RegionHook, Protocol):
    """Composable observer that also sees individual structured children."""

    def enter_child(
        self,
        kind: str,
        child: str,
        operation: Any,
        region_info: RegionInfo,
    ) -> object | None:
        ...

    def exit_child(
        self,
        kind: str,
        child: str,
        operation: Any,
        region_info: RegionInfo,
        token: object | None,
        error: BaseException | None,
    ) -> None:
        ...


class _DeferredRegionOperation:
    """Stable hook handle for a staged operation that is bound later.

    Dynamic conditional expressions must trace their branches before the
    result types of the final ``scf.if`` are known.  Hooks nevertheless need
    to enter before branch tracing (notably to establish raw-VF context) and
    must observe a single logical operation.  This proxy delegates to the
    staging operation until ``bind`` transfers its attributes and switches to
    the final attached operation.
    """

    __slots__ = ("_current", "_is_bound")

    def __init__(self, staging_operation: Any) -> None:
        self._current = staging_operation
        self._is_bound = False

    def __getattr__(self, name: str):
        return getattr(self._current, name)
    @property
    def operation(self):
        current = self._current
        return current.operation if hasattr(current, "operation") else current

    def bind(self, final_operation: Any) -> None:
        if self._is_bound:
            raise RuntimeError("Deferred region operation is already bound")
        source = self.operation
        target = final_operation.operation if hasattr(final_operation, "operation") else final_operation
        for named_attribute in source.attributes:
            target.attributes[named_attribute.name] = named_attribute.attr
        self._current = final_operation
        self._is_bound = True



@contextmanager
def _detach_on_failure(operation: Any) -> Iterator[None]:
    """Make construction of one attached IR operation transactional."""

    try:
        yield
    except BaseException:
        target = operation.operation if hasattr(operation, "operation") else operation
        target.detach_from_parent()
        raise


class _RawVfRegionHook:
    __slots__ = ()

    def enter(self, kind: str, operation: Any, region_info: RegionInfo) -> object | None:
        del kind, region_info
        from cannbot_dsl.lang.vf import _current_vf_mode, _tag_if_in_vf

        if _current_vf_mode() != "simd":
            return None
        from cannbot_dsl.ops.reg import _INSIDE_RAW_VF_LOOP_BODY

        if _INSIDE_RAW_VF_LOOP_BODY.get():
            return None
        _tag_if_in_vf(operation)
        return (_INSIDE_RAW_VF_LOOP_BODY, _INSIDE_RAW_VF_LOOP_BODY.set(True))

    def exit(
        self,
        kind: str,
        operation: Any,
        region_info: RegionInfo,
        token: object | None,
        error: BaseException | None,
    ) -> None:
        del kind, operation, region_info, error
        if token is not None:
            context_var, context_token = token
            context_var.reset(context_token)


_CURRENT_REGION_HOOK: ContextVar[RegionHook | None] = ContextVar("cannbotdsl_frontend_region_hook", default=None)
_CURRENT_REGION_OBSERVERS: ContextVar[tuple[RegionObserver, ...]] = ContextVar(
    "cannbotdsl_frontend_region_observers", default=()
)
_RAW_VF_HOOK = _RawVfRegionHook()


@contextmanager
def use_region_hook(hook: RegionHook | None) -> Iterator[None]:
    """Temporarily override the region hook in the current context."""

    token = _CURRENT_REGION_HOOK.set(hook)
    try:
        yield
    finally:
        _CURRENT_REGION_HOOK.reset(token)


def _push_region_observer(observer: RegionObserver, *, replace_same_type: bool = False):
    current = _CURRENT_REGION_OBSERVERS.get()
    if replace_same_type:
        current = tuple(item for item in current if not is_exact_instance(item, observer.__class__))
    return _CURRENT_REGION_OBSERVERS.set((*current, observer))


def _pop_region_observer(token) -> None:
    _CURRENT_REGION_OBSERVERS.reset(token)


def _cleanup_all(cleanups) -> BaseException | None:
    """Run every cleanup callback; return the first failure, if any.

    One failing cleanup must never skip the remaining ones: observers keep
    per-observer state (frames, ContextVar tokens) that leaks otherwise.
    """
    first_failure = None
    for cleanup in cleanups:
        try:
            cleanup()
        except BaseException as exc:
            if first_failure is None:
                first_failure = exc
    return first_failure


@contextmanager
def _observer_scope(
    enter: Callable[[Any], Any],
    exit_partial: Callable[..., Callable[[], Any]],
    exit_hook: Callable[[BaseException | None], Any] | None = None,
) -> Iterator[None]:
    """Shared observer enter/yield/exit bookkeeping for region scopes.

    ``enter(observer)`` returns the observer's token, and ``exit_partial(
    observer, token, error)`` builds that observer's cleanup callback. The
    optional ``exit_hook`` runs after the observer cleanups: on the
    enter-rollback path its failures are swallowed, while in the final
    cleanup a failure is re-raised only when the body itself succeeded.
    """
    observer_tokens = []
    try:
        for observer in _CURRENT_REGION_OBSERVERS.get():
            observer_tokens.append((observer, enter(observer)))
    except BaseException as enter_error:
        # The original enter error keeps propagating; cleanup failures on the
        # rollback path are secondary and must not mask it.
        _cleanup_all(
            [
                exit_partial(observer, observer_token, enter_error)
                for observer, observer_token in reversed(observer_tokens)
            ]
        )
        if exit_hook is not None:
            try:
                exit_hook(enter_error)
            except BaseException:
                pass
        raise
    error: BaseException | None = None
    try:
        yield
    except BaseException as exc:
        error = exc
        raise
    finally:
        cleanup_failure = _cleanup_all(
            [
                exit_partial(observer, observer_token, error)
                for observer, observer_token in reversed(observer_tokens)
            ]
        )
        if exit_hook is not None:
            try:
                exit_hook(error)
            except BaseException as exc:
                if cleanup_failure is None:
                    cleanup_failure = exc
        if cleanup_failure is not None and error is None:
            raise cleanup_failure


@contextmanager
def region_hook_scope(
    kind: str,
    operation: Any,
    region_info: RegionInfo,
) -> Iterator[None]:
    hook = _CURRENT_REGION_HOOK.get() or _RAW_VF_HOOK
    token = hook.enter(kind, operation, region_info)
    with _observer_scope(
        lambda observer: observer.enter(kind, operation, region_info),
        lambda observer, observer_token, error: partial(
            observer.exit, kind, operation, region_info, observer_token, error
        ),
        lambda error: hook.exit(kind, operation, region_info, token, error),
    ):
        yield


@contextmanager
def region_child_scope(
    kind: str,
    child: str,
    operation: Any,
    region_info: RegionInfo,
) -> Iterator[None]:
    with _observer_scope(
        lambda observer: observer.enter_child(kind, child, operation, region_info),
        lambda observer, observer_token, error: partial(
            observer.exit_child, kind, child, operation, region_info, observer_token, error
        ),
    ):
        yield


__all__ = [
    "RegionHook",
    "RegionObserver",
    "RegionInfo",
    "region_child_scope",
    "region_hook_scope",
    "use_region_hook",
]
