# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.


"""Trace-time integer provenance and SIMD/SIMT boundary adaptation.

Metadata belongs to a semantic wrapper, never to its shared SSA carrier.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class IntegerPolicy:
    origin: str = "default"
    constant: bool = False
    scope: object = None
    literal: int | None = None


_FIXED_POLICY = IntegerPolicy(origin="fixed")


def current_scope():
    from cannbot_dsl.lang.vf import _CURRENT_VF

    return _CURRENT_VF.get()


def policy(value):
    return getattr(value, "_integer_policy", _FIXED_POLICY)


def default_integer_width(value):
    """Select a default literal type only where VF policy applies."""
    return 32 if current_scope() is not None and -(1 << 31) <= value < (1 << 31) else 64


def mark(value, *, origin="default", constant=False, scope=None, literal=None):
    from cannbot_dsl.types._integer import Integer

    if isinstance(value, Integer) and value.type.width != 1:
        value._integer_policy = IntegerPolicy(origin, constant, scope, literal)
    return value


def copy_policy(result, source, *, dynamic=False):
    p = policy(source)
    return mark(
        result,
        origin=p.origin,
        constant=p.constant and not dynamic,
        scope=current_scope() if dynamic else p.scope,
        literal=None if dynamic else p.literal,
    )


def explicit(value):
    return mark(value, origin="explicit", constant=policy(value).constant, scope=current_scope())


def computed(result, *operands):
    # Booleans retain their fixed policy even though bool is an int subclass.
    ps = [policy(v) for v in operands if not isinstance(v, int) or isinstance(v, bool)]
    if any(p.origin == "explicit" for p in ps):
        origin = "explicit"
    elif any(p.origin == "fixed" for p in ps):
        origin = "fixed"
    else:
        origin = "default"
    return mark(result, origin=origin, constant=all(p.constant for p in ps), scope=current_scope())


def read_integer(value):
    from cannbot_dsl.types._integer import Integer, Int32

    if not isinstance(value, Integer) or value.type.width == 1:
        return value
    scope = current_scope()
    if scope is None:
        return value
    p = policy(value)
    if p.origin != "default":
        return value
    if p.constant:
        if p.literal is not None and default_integer_width(p.literal) == 32 and value.type.width != 32:
            return mark(Int32(p.literal), constant=True, scope=scope, literal=p.literal)
        return value
    if p.scope is scope:
        return value
    # arith.trunci specifies low-bit truncation, including out-of-range inputs.
    return mark(Int32(value), scope=scope)


def read_state(value):
    """Adapt newly captured state without rebinding the caller's containers."""
    if isinstance(value, tuple):
        return tuple(read_state(item) for item in value)
    if isinstance(value, list):
        return [read_state(item) for item in value]
    if isinstance(value, dict):
        return {key: read_state(item) for key, item in value.items()}
    return read_integer(value)


def merge_state(result, *sources):
    """A phi retains explicit/fixed intent from every incoming binding."""
    if isinstance(result, (tuple, list)):
        items = (merge_state(item, *(source[i] for source in sources)) for i, item in enumerate(result))
        return tuple(items) if isinstance(result, tuple) else list(items)
    if isinstance(result, dict):
        return {key: merge_state(item, *(source[key] for source in sources)) for key, item in result.items()}
    computed(result, *sources)
    return mark(result, origin=policy(result).origin, scope=current_scope())


__all__: list[str] = []
