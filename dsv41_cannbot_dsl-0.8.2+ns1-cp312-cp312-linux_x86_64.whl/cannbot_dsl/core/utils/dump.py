# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Atomic text dump to ``$CANNBOTDSL_DUMP_DIR``.

Used by ``core/compiler/builder.py`` to materialise ``.mlir`` / ``.asc``
artifacts when ``CANNBOTDSL_DUMP_MLIR`` / ``CANNBOTDSL_DUMP_ASCENDC`` are set.
"""

import contextlib
import hashlib
import json
import os
import re
import tempfile

_FILENAME_SAFE_RE = re.compile(r"[^0-9A-Za-z_.-]+")


def safe_basename(name: str, fallback: str = "jit") -> str:
    """Sanitise ``name`` for use as a dump file basename."""
    cleaned = _FILENAME_SAFE_RE.sub("_", name).strip("._-")
    return cleaned or fallback


def dump_text(
    filename: str,
    text: str,
    *,
    dump_dir: str | None = None,
) -> str:
    """Atomically write ``text`` to ``$CANNBOTDSL_DUMP_DIR/<filename>``.

    Writes to a sibling temp file in the same directory (so ``os.replace`` is
    same-device and therefore atomic on POSIX), then renames over the final
    path. Concurrent writers (e.g. ``pytest -n auto`` workers parameterised
    over the same kernel) won't observe a partial file.
    """
    if dump_dir is None:
        from cannbot_dsl.core.utils.env import env

        dump_dir = env().dump_dir
    os.makedirs(dump_dir, exist_ok=True)
    final_path = os.path.join(dump_dir, filename)
    fd, tmp_path = tempfile.mkstemp(
        prefix=f".{filename}.",
        suffix=".tmp",
        dir=dump_dir,
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp_path, final_path)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(tmp_path)
        raise
    return final_path


def _ascendc_contract_label(contract: dict) -> str:
    """Readable parameter summary; the full variant hash remains authoritative."""

    def expression(value):
        if value["kind"] == "constant":
            return str(value["value"])
        if value["kind"] == "dimension":
            return value["name"]
        return "(" + expression(value["lhs"]) + "-" + value["op"] + "-" + expression(value["rhs"]) + ")"

    def shape(values):
        return "x".join(expression(v) if isinstance(v, dict) else str(v) for v in values) or "scalar"

    def dtype(value):
        return {"f16": "fp16", "f32": "fp32", "f64": "fp64"}.get(value, value)

    tensors, others = [], []
    for parameter in contract["parameters"]:
        argument = parameter["argument"]
        if argument is None:
            continue
        name, kind = parameter["name"], argument["kind"]
        if kind == "tensor":
            tensors.append(name + "-" + shape(argument["shape"]) + "-" + dtype(argument["element"]))
        elif kind == "tensor_list":
            layout = argument["layout"]
            shapes = (
                shape(layout["shape_expressions"])
                if layout["kind"] == "template"
                else "_".join(shape(item["shape"]) for item in layout["items"])
            )
            tensors.append(
                name + "-list" + expression(argument["length"]) + "-" + shapes + "-" + dtype(argument["element_type"])
            )
        else:
            others.append(name + "-" + dtype(argument.get("element", kind)))
    label = safe_basename("__".join(tensors or others), fallback="no-tensors")
    # Keep the whole component below 255 bytes, including the 64-digit hash.
    return label if len(label) <= 160 else label[:154] + "__more"


def dump_ascendc_variant(
    source: str,
    *,
    function,
    contract,
    target: str,
    dump_dir: str,
    source_kind: str = "native",
    host_source: str = "",
) -> str:
    """Archive each generated variant; publish metadata after its files.

    Contracts separate static shapes/dtypes even if generated text is identical.
    Source digests also distinguish bound-instance values, helper edits and
    codegen options. Concurrent identical requests publish identical files.
    """
    from cannbot_dsl.aot.collection import current_collection, module_identity
    from cannbot_dsl.core.contracts.codec import contract_to_dict

    def encode(value):
        return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":"))

    def digest(text):
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    collection = current_collection()
    # Group by the actual Python callable, not an arbitrary collector task name.
    callable_identity = {
        "module": module_identity(getattr(function, "__module__", "")),
        "function": getattr(function, "__qualname__", function.__name__),
    }
    operator = {
        "task": collection.task if collection is not None else None,
        **callable_identity,
    }
    label = ".".join(value for value in callable_identity.values() if value)
    operator_name = safe_basename(label)[:112] + "-" + digest(encode(callable_identity))[:16]
    variant = {
        "schema_version": 1,
        "operator": operator,
        "target": target,
        "source_kind": source_kind,
        "contract": contract_to_dict(contract),
        "source_sha256": digest(source),
        "host_source_sha256": digest(host_source) if host_source else None,
    }
    variant_id = digest(encode(variant))
    variant_label = _ascendc_contract_label(variant["contract"])
    directory = os.path.join(dump_dir, "asc", operator_name, variant_label + "--" + variant_id)
    path = dump_text("kernel.asc", source, dump_dir=directory)
    if host_source:
        dump_text("host.cpp", host_source, dump_dir=directory)
    metadata = dict(
        variant,
        variant_id=variant_id,
        variant_label=variant_label,
        source="kernel.asc",
        host_source="host.cpp" if host_source else None,
        python_source=getattr(getattr(function, "__code__", None), "co_filename", None),
    )
    dump_text("metadata.json", json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", dump_dir=directory)
    return path
