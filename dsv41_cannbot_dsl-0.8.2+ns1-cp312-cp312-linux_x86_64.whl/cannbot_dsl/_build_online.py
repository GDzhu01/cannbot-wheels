# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Reuse native libraries and build CPython bindings for the importing interpreter."""

import fcntl
import hashlib
import importlib.abc
import importlib.util
import json
import os
import platform
import shutil
import subprocess
import sys
import sysconfig
import tempfile
import threading
import time
from pathlib import Path

_lock = threading.Lock()


def check_python():
    if sys.implementation.name != "cpython" or sysconfig.get_config_var("Py_GIL_DISABLED"):
        raise RuntimeError("CANNBotDSL/OpKit require regular CPython (GIL enabled)")


def cmake_quote(value):
    # Bracket quoting preserves spaces, semicolons, dollars and backslashes.
    delimiter = "="
    while "]" + delimiter + "]" in str(value):
        delimiter += "="
    return "[" + delimiter + "[" + str(value) + "]" + delimiter + "]"


def binding_paths(root, manifest):
    suffix = sysconfig.get_config_var("EXT_SUFFIX")
    return {manifest["package"] + "." + name: root / (name.replace(".", "/") + suffix) for name in manifest["modules"]}


class _BindingsFinder(importlib.abc.MetaPathFinder):
    def __init__(self, paths):
        self.paths = paths

    def find_spec(self, fullname, path=None, target=None):
        location = self.paths.get(fullname)
        if location is not None:
            return importlib.util.spec_from_file_location(fullname, location)
        return None


def build_bindings(package, source, manifest, destination):
    if not (Path(sysconfig.get_path("include")) / "Python.h").is_file():
        raise RuntimeError(
            "Python development headers are required; install the development package for " + sys.executable
        )
    try:
        import pybind11
    except ImportError as error:
        raise RuntimeError("Binding compilation requires pybind11>=2.13.6 in " + sys.executable) from error
    cmake = shutil.which("cmake")
    if cmake is None:
        raise RuntimeError("Binding compilation requires CMake >=3.20 and a C++17 compiler")
    q = cmake_quote
    started = time.perf_counter()
    jobs = os.environ.get("CANNBOT_BINDING_JOBS", "32")
    prefix = f"[{manifest['package']}]"
    with tempfile.TemporaryDirectory(prefix=".bindings-", dir=destination.parent) as temporary:
        work = Path(temporary)
        output = work / "output"
        lines = []
        for i, (name, module) in enumerate(manifest["modules"].items()):
            target = "binding_" + str(i)
            lines.append(
                f"pybind11_add_module({target} MODULE NO_EXTRAS "
                + " ".join(q(source / s) for s in module["sources"])
                + ")"
            )
            lines.append(
                f"target_include_directories({target} PRIVATE "
                + " ".join(q(source / s) for s in module["includes"])
                + ")"
            )
            lines.append(
                f"target_compile_definitions({target} PRIVATE " + " ".join(q(s) for s in module["definitions"]) + ")"
            )
            parent, _, leaf = name.rpartition(".")
            directory = output / parent.replace(".", "/")
            capi = package / manifest["capi"]
            lines.append(
                f"set_target_properties({target} PROPERTIES OUTPUT_NAME {q(leaf)} "
                f"LIBRARY_OUTPUT_DIRECTORY {q(directory)} BUILD_RPATH {q(capi.parent)})"
            )
            if name != "_host_runtime":
                lines.append(f"target_link_libraries({target} PRIVATE {q(capi)})")
            else:
                lines.append(f"target_link_libraries({target} PRIVATE ${{CMAKE_DL_LIBS}})")
        targets = work / "targets.cmake"
        targets.write_text("\n".join(lines) + "\n")
        log = work / "build.log"
        commands = [
            [
                cmake,
                "-S",
                str(source),
                "-B",
                str(work / "build"),
                "-DCMAKE_BUILD_TYPE=Release",
                "-DPython_EXECUTABLE=" + sys.executable,
                "-Dpybind11_DIR=" + pybind11.get_cmake_dir(),
                "-DBINDING_TARGETS=" + str(targets),
            ],
            [cmake, "--build", str(work / "build"), "--parallel", jobs],
        ]
        with log.open("w") as stream:
            for phase, command in zip(("configuring bindings", f"compiling bindings (parallel jobs={jobs})"), commands):
                print(f"{prefix} {phase}; build log: {log}", file=sys.stderr, flush=True)
                result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, check=False)
                if result.returncode:
                    stream.flush()
                    failure = destination.parent / (destination.name + ".log")
                    shutil.copyfile(log, failure)
                    raise RuntimeError(
                        "Python binding compilation failed; see " + str(failure) + "\n" + log.read_text()[-6000:]
                    )
        if not all(p.is_file() for p in binding_paths(output, manifest).values()):
            raise RuntimeError("Binding compilation did not produce all expected extensions")
        if destination.exists():
            shutil.rmtree(destination)
        output.rename(destination)
        print(
            f"{prefix} bindings ready in {time.perf_counter() - started:.1f}s; cache: {destination}",
            file=sys.stderr,
            flush=True,
        )


def binding_cache_identity(package, source, manifest_file, manifest):
    identity = hashlib.sha256()
    # Include installation location: cached extensions link to its common CAPI.
    identity.update(str(package).encode())
    identity.update(str(sysconfig.get_config_var("SOABI")).encode())
    identity.update(platform.machine().encode())
    for path in (manifest_file, source / "CMakeLists.txt", Path(__file__), package / manifest["capi"]):
        identity.update(path.read_bytes())
    return identity.hexdigest()


def ensure_native(package_file):
    check_python()
    package = Path(package_file).resolve().parent
    source = package / "_native_build"
    manifest_file = source / "manifest.json"
    if not manifest_file.is_file():
        return  # Source/editable builds use their normal CMake extensions.
    manifest = json.loads(manifest_file.read_text())
    if manifest["prebuilt_soabi"] == sysconfig.get_config_var("SOABI") and all(
        path.is_file() for path in binding_paths(package, manifest).values()
    ):
        return
    identity = binding_cache_identity(package, source, manifest_file, manifest)
    cache_home = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache"))
    if not cache_home.is_absolute():
        cache_home = Path.home() / ".cache"
    parent = cache_home / "cannbot" / "bindings" / manifest["package"]
    parent.mkdir(parents=True, exist_ok=True)
    destination = parent / identity
    with _lock, (parent / (destination.name + ".lock")).open("a") as guard:
        # Keep the lock inode persistent so waiters always lock the same file.
        fcntl.flock(guard, fcntl.LOCK_EX)
        paths = binding_paths(destination, manifest)
        marker = destination / "bindings.json"
        try:
            inventory = json.loads(marker.read_text())
            valid = inventory == {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()}
        except (OSError, ValueError):
            valid = False
        if not valid:
            for name, expected in manifest["files"].items():
                if hashlib.sha256((source / name).read_bytes()).hexdigest() != expected:
                    raise RuntimeError("Binding source checksum mismatch: " + name)
            print(
                f"[{manifest['package']}] building bindings for {sysconfig.get_config_var('SOABI')}",
                file=sys.stderr,
                flush=True,
            )
            build_bindings(package, source, manifest, destination)
            marker.write_text(
                json.dumps(
                    {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in paths.items()},
                    sort_keys=True,
                )
                + "\n"
            )
        if not any(isinstance(finder, _BindingsFinder) and finder.paths == paths for finder in sys.meta_path):
            sys.meta_path.insert(0, _BindingsFinder(paths))
