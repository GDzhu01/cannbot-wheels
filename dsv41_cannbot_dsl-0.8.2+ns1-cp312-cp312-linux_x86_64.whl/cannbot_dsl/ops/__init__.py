# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""cannbot_dsl.ops -- compute, data movement, synchronisation and topology.

The tensor-level surfaces (matmul, conv, memcpy, sync,
arch and platform info) are re-exported here. The register-level and
collective surfaces stay behind their own namespaces and are reached as
``cannbot_dsl.reg.*`` and ``cannbot_dsl.distributed.*``.
"""

from cannbot_dsl._mlir.dialects import cannir
from cannbot_dsl.core.scalar_conversion import coerce_scalar_value
from cannbot_dsl.tensor import Tensor

# Initialize language entry points before distributed datastruct declarations.
from cannbot_dsl.lang.vf import vf as _vf  # noqa: F401
from cannbot_dsl.ops.matmul import matmul
from cannbot_dsl.ops.conv import (
    arith,
    Conv2dInputWindow,
    Conv2dTile,
    Conv2dSpec,
    make_conv2d_spec,
    make_conv2d_fmap_l1,
    conv2d_load_fmap,
    conv2d_load_im2col,
    conv2d_load_filter,
    conv2d_store_output,
)
from cannbot_dsl.ops.memcpy import (
    CopyOptions,
    ChannelSplitMode,
    copy_options,
    mem_copy,
)
from cannbot_dsl.ops.info import (
    PlatformInfo,
    get_mem_size,
    get_platform_info,
)
from cannbot_dsl.ops.arch import (
    get_block_idx,
    get_block_num,
    get_core_id,
    get_ctrl,
    get_squeeze_status,
    get_status,
    get_subblock_dim,
    get_subblock_id,
    get_system_cycle,
    get_vf_len,
    is_aic,
    is_aiv,
    set_ctrl,
)

# Namespace modules. Keep register-level operations under reg.
from cannbot_dsl.ops import (  # noqa: F401
    arch,
    cube,
    info,
    memcpy,
    reg,
    scalar,
    simt,
    sync,
)

from cannbot_dsl.ops.load3d import (
    load3d, Load3DFeatureMap, Load3DWindow, Load3DRepeat, Load3DDestination, Load3DPadding
)
from cannbot_dsl.ops.vnchwconv import vnchwconv

__all__ = [
    "vnchwconv",
    "load3d",
    "Load3DFeatureMap",
    "Load3DWindow",
    "Load3DRepeat",
    "Load3DDestination",
    "Load3DPadding",

    "Conv2dInputWindow",
    "Conv2dSpec",
    "Conv2dTile",
    "CopyOptions",
    "ChannelSplitMode",
    "PlatformInfo",
    "Tensor",
    "arch",
    "arith",
    "cannir",
    "coerce_scalar_value",
    "conv2d_load_filter",
    "conv2d_load_fmap",
    "conv2d_load_im2col",
    "conv2d_store_output",
    "cube",
    "get_block_idx",
    "get_block_num",
    "get_core_id",
    "get_ctrl",
    "get_mem_size",
    "get_platform_info",
    "get_squeeze_status",
    "get_status",
    "get_subblock_dim",
    "get_subblock_id",
    "get_system_cycle",
    "get_vf_len",
    "info",
    "is_aic",
    "is_aiv",
    "set_ctrl",
    "make_conv2d_fmap_l1",
    "make_conv2d_spec",
    "copy_options",
    "matmul",
    "mem_copy",
    "memcpy",
    "reg",
    "scalar",
    "simt",
    "sync",
]
