# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Data movement: copies, copy options and explicit L1 fills.

The instruction enums, immutable ``CopyOptions`` configuration and
``copy_options`` live here rather than in ``cannbot_dsl.tensor`` so every
setting and data structure a caller needs sits next to the copy interface.
Tensor operations express data transformations. The options supply remaining
copy controls; ``mem_copy`` expands them into operation operands.
``cube_fill_l1`` and ``cube_fill_l1_zero`` fill explicit L1 DataBlocks.
"""

from dataclasses import dataclass, replace
from enum import IntEnum
from cannbot_dsl.core.diag.diagnostics import (
    CANNBotOverflowError, CANNBotTypeError, CANNBotValueError, DiagnosticCode, argument_span,
)
import cannbot_dsl._mlir.ir as ir
from cannbot_dsl._mlir.dialects import cannir
from cannbot_dsl.core.ir_transport import unwrap_operand
from cannbot_dsl.core.scalar_conversion import _render_literal, coerce_scalar_value
from cannbot_dsl.core.utils.type_checks import is_exact_instance
from cannbot_dsl.ops._operands import _operand_memref_type
from cannbot_dsl.tensor import (
    LayoutMapKind,
    MemLoc,
    Tensor,
    cat as _cat,
    _make_partition_tiler,
    _normalize_part_id,
    _partition_full_shape,
)


class CopyEngineKind(IntEnum):
    """Physical engine of a GM -> UB copy; ``Auto`` is the ordinary DMA."""

    Auto = 0
    NDDMA = 1


class ChannelSplitMode(IntEnum):
    """Fixpipe channel-split policy for an fp32 L0C fixpipe store.

    The fp32 L0C fractal is N0=16 wide; a typed fp32 NZ destination
    organizes its fractals at C0=8 (standard FRACTAL_NZ) or C0=16 (the
    L0C mirror, spelled by an explicit physical layout).
    """

    AUTO = 0
    ON = 1
    OFF = 2


@dataclass(frozen=True, eq=False)
class _StaticCopyConfig:
    channel_split: object = None
    engine: object = None


@dataclass(frozen=True, eq=False)
class _CopyControls:
    dst_subblock: object = None
    unit_flag: object = 0
    mx_scale: object = None
    l2_cache_ctl: object = 0
    atomic_add: object = False
    pad_val: object = "first"


@dataclass(frozen=True, eq=False)
class CopyOptions:
    """Immutable copy configuration consumed by :func:`mem_copy`.

    The wrapped CANNIR value contains static hardware choices. Runtime values
    stay in ``controls`` and are expanded into mem_copy operands when the copy
    is emitted. Use ``copy_options(existing, option=value)`` to derive a
    configuration while reusing the existing static engine whenever possible.
    """

    _value: object
    _static: _StaticCopyConfig
    _controls: _CopyControls

    @property
    def type(self):
        if self._value is None:
            raise AttributeError("this CopyOptions contains only per-copy controls")
        return self._value.type

    @property
    def channel_split(self):
        return ChannelSplitMode(_CHANNEL_SPLIT_MAP[self._static.channel_split])

    @property
    def engine(self):
        """The explicitly selected engine name: ``"auto"`` or ``"nddma"``."""
        if self._static.engine is None:
            return "auto"
        return self._static.engine


_ENGINE_KIND_MAP = {
    None: CopyEngineKind.Auto,
    "auto": CopyEngineKind.Auto,
    "nddma": CopyEngineKind.NDDMA,
}

_CHANNEL_SPLIT_MAP = {
    None: ChannelSplitMode.AUTO,
    True: ChannelSplitMode.ON,
    False: ChannelSplitMode.OFF,
}


class _Inherit:
    def __repr__(self):
        return "<inherit>"


_UNSET = _Inherit()


def _view_source(source, operation):
    if not isinstance(source, Tensor):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"{operation} expects a Tensor; select a RingBuffer slot first if applicable; got {type(source).__name__}",
        )
    return source


def _partition(source, *, dim, part_id, alignment):
    if not isinstance(source, Tensor):
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"partition expects a Tensor; got {type(source).__name__}")
    if not is_exact_instance(dim, int) or dim not in (0, 1):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT if type(dim) is int else DiagnosticCode.INVALID_TYPE,
            f"partition dim must be 0 or 1; got {_render_literal(dim) if type(dim) is int else type(dim).__name__}",
            span=argument_span("dim"),
        )
    if not is_exact_instance(alignment, int) or alignment < 1:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT if type(alignment) is int else DiagnosticCode.INVALID_TYPE,
            "partition alignment must be a positive integer; "
            f"got {_render_literal(alignment) if type(alignment) is int else type(alignment).__name__}",
            span=argument_span("alignment"),
        )
    if dim == 1 and alignment != 1:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            f"partition dim=1 requires alignment=1; got {_render_literal(alignment)}",
            span=argument_span("alignment"),
        )
    shape = source.shape
    if len(shape) != 2 or any(isinstance(extent, tuple) for extent in shape):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_SHAPE,
            f"partition requires a flat rank-2 Tensor; got rank {len(shape)} with shape {shape}",
        )
    full_shape = _partition_full_shape(source)
    if part_id is not None:
        if is_exact_instance(part_id, int) and part_id not in (0, 1):
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT,
                f"part_id must be in [0, 1]; got {_render_literal(part_id)}",
                span=argument_span("part_id"),
            )
        _normalize_part_id(part_id)
    from cannbot_dsl.tensor import _expression

    controls = [] if part_id is None else [_normalize_part_id(part_id)]
    result_shape = list(shape)
    if part_id is not None:
        tiler = _make_partition_tiler(shape, full_shape, axis=dim, alignment=alignment)
        result_shape[dim] = tiler.valid_extent(part_id)
    return _expression(
        "partition",
        [source],
        controls=controls,
        shape=result_shape,
        parameters={"dim": dim, "alignment": alignment, "full_shape": tuple(full_shape)},
    )


def _tile_slice_multi(source, block_shape, *, repeats, step):
    from cannbot_dsl.tensor import tile_slice

    if not isinstance(source, Tensor):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"tile_slice_multi expects a Tensor; "
            f"select a RingBuffer slot first if applicable; got {type(source).__name__}",
        )
    if source.rank != 2 or type(repeats) is not int:
        from cannbot_dsl.tensor import _repeat_nd

        return _repeat_nd(source, block_shape, repeats=repeats, step=step)
    for name, value in (("block_shape", block_shape), ("step", step)):
        if not isinstance(value, (tuple, list)) or len(value) != 2 or any(not is_exact_instance(v, int) for v in value):
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                f"tile_slice_multi {name} must be a pair of static integers",
                span=argument_span(name),
            )
    if not is_exact_instance(repeats, int) or repeats < 1 or any(v < 1 for v in block_shape):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT, "tile_slice_multi block_shape and repeats must be positive")
    if any(v < 0 for v in step):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT, "tile_slice_multi step must be non-negative", span=argument_span("step"))
    shape = source.shape
    if len(shape) != 2 or any(isinstance(v, tuple) for v in shape):
        raise CANNBotValueError(DiagnosticCode.INVALID_SHAPE, "tile_slice_multi requires a flat rank-2 Tensor")
    for axis, extent in enumerate(shape):
        end = (repeats - 1) * step[axis] + block_shape[axis]
        if end > (1 << 63) - 1:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE,
                f"tile_slice_multi extent overflows int64 on axis {axis}; got {_render_literal(end)}",
            )
        if is_exact_instance(extent, int) and end > extent:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_SHAPE,
                f"tile_slice_multi complete blocks exceed extent on axis {axis}; "
                f"required {_render_literal(end)}, available {_render_literal(extent)}",
            )
    source = _view_source(source, "tile_slice_multi")
    # Reuse the existing first-tile window validation. Keep the full carrier
    # for DMA inference: a block-sized carrier would clip later repetitions.
    # The repeat relation stays compact instead of emitting R separate copies.
    tile_slice(source, tuple(block_shape), (0, 0))
    from cannbot_dsl.tensor import _expression

    return _expression(
        "repeat",
        [source],
        shape=(repeats, *block_shape),

        data_format="nd",
        parameters={"block_shape": tuple(block_shape), "repeats": repeats, "step": tuple(step)},
    )


def _axis_number(dim, rank, operation):
    if not is_exact_instance(dim, int):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"{operation} dim must be a compile-time integer; got {type(dim).__name__}",
        )
    dim = dim + rank if dim < 0 else dim
    if not 0 <= dim < rank:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            f"{operation} dim is out of range for rank {rank}; normalized dim={_render_literal(dim)}",
        )
    return dim


def _flat_axis_shape(source, operation):
    if not isinstance(source, Tensor):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"{operation} expects a Tensor or a supported axis view; got {type(source).__name__}",
        )
    shape = source.shape
    if not isinstance(shape, tuple) or not shape or any(isinstance(d, tuple) for d in shape):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_SHAPE,
            f"{operation} requires a flat, non-scalar shape",
        )
    return shape


def _extent_product(sizes):
    product = 1
    for size in sizes:
        product = product * size
        if is_exact_instance(product, int) and product > (1 << 63) - 1:
            raise CANNBotOverflowError(
                DiagnosticCode.INVALID_SHAPE,
                f"axis view element count overflows int64; got {_render_literal(product)}",
            )
    return product


def _flatten(source, start_dim=0, end_dim=-1):
    from cannbot_dsl.tensor import _expression

    shape = _flat_axis_shape(source, "flatten")
    start = _axis_number(start_dim, len(shape), "flatten")
    end = _axis_number(end_dim, len(shape), "flatten")
    if start > end:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            f"flatten start_dim must not exceed end_dim; "
            f"got start_dim={_render_literal(start_dim)}, end_dim={_render_literal(end_dim)}",
        )
    if start == end:
        return source
    result = (*shape[:start], _extent_product(shape[start : end + 1]), *shape[end + 1 :])
    return _expression(
        "flatten",
        [source],
        shape=result,

        data_format="nd",
        parameters={"axes": (start, end)},
    )


def _unflatten(source, dim, sizes):
    from cannbot_dsl.tensor import _runtime_extent_carrier, _constant_i64

    shape = _flat_axis_shape(source, "unflatten")
    dim = _axis_number(dim, len(shape), "unflatten")
    if not isinstance(sizes, (tuple, list)) or not sizes:
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_ARGUMENT if isinstance(sizes, (tuple, list)) else DiagnosticCode.INVALID_TYPE,
            "unflatten sizes must be a nonempty tuple or list",
            span=argument_span("sizes"),
        )
    normalized = []
    for size in sizes:
        carrier = _runtime_extent_carrier(size)
        constant = _constant_i64(carrier) if carrier is not None else size
        if constant is None:
            normalized.append(carrier)
        elif not is_exact_instance(constant, int) or constant <= 0:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT if type(constant) is int else DiagnosticCode.INVALID_TYPE,
                "unflatten sizes must be positive integers or runtime extents; -1 is unsupported",
                span=argument_span("sizes"),
            )
        else:
            normalized.append(constant)
    sizes = tuple(normalized)
    product = _extent_product(sizes)
    if is_exact_instance(shape[dim], int) and is_exact_instance(product, int) and shape[dim] != product:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_SHAPE,
            f"unflatten product(sizes) must equal the source axis extent; "
            f"got product={_render_literal(product)}, extent={_render_literal(shape[dim])}",
            span=argument_span("sizes"),
        )
    result = (*shape[:dim], *sizes, *shape[dim + 1 :])
    from cannbot_dsl.tensor import _expression

    static_sizes = tuple(s if type(s) is int else -1 for s in sizes)
    return _expression(
        "unflatten",
        [source],
        shape=result,

        data_format="nd",
        parameters={"dim": dim, "sizes": static_sizes},
    )


def _materialize_copy_engine(config):
    if config.channel_split is not None and not is_exact_instance(config.channel_split, bool):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"channel_split must be a compile-time bool or None; got {type(config.channel_split).__name__}",
            span=argument_span("channel_split"),
        )
    engine_type = cannir.CopyEngineType.get(
        channel_split=int(_CHANNEL_SPLIT_MAP[config.channel_split]),
        kind=int(_ENGINE_KIND_MAP[config.engine]),
    )
    return cannir.make_copy_engine(engine_type)


def copy_options(
    base=None,
    *,
    engine=_UNSET,
    dst_subblock=_UNSET,
    unit_flag=_UNSET,
    mx_scale=_UNSET,
    l2_cache_ctl=_UNSET,
    atomic_add=_UNSET,
    pad_val=_UNSET,
    channel_split=_UNSET,
):
    """Create or derive an immutable configuration for one or more copies.

    ``copy_options(base, unit_flag=3)`` reuses ``base`` and overrides only
    ``unit_flag``. The base object is never mutated, so it remains safe to reuse
    for later copies. Static options materialize a CANNIR copy engine; per-copy
    values are expanded by :func:`mem_copy` into that operation's operands.

    ``engine`` selects the physical GM -> UB copy engine: ``"auto"`` (default)
    plans an ordinary burst/loop DMA from the View address recurrences, while
    ``"nddma"`` explicitly selects the per-axis NDDMA walk. Automatic selection
    never picks NDDMA. Layouts the ordinary DMA cannot express (replicated or
    multi-axis padding, non-affine address maps) are compile-time errors unless
    ``engine="nddma"`` is given. Element-strided layouts such as transposes
    remain legal but are emitted as per-element bursts; prefer
    ``engine="nddma"`` for them. NDDMA requires identity format and composes
    with ``pad`` views (constant or replicate) and runtime padding operands;
    the padding mode is derived from the pad view, not set here.
    Ordinary format conversion follows the two tensor layouts. Use
    Tensor.permute/flatten/unflatten, partition, tile_slice_multi and the
    finite copy operations for logical transformations. Scale operands use
    explicit paired layouts and View transformations as well.

    Tail pitch is declared by the explicit destination layout.
    ``pad_val="first"`` (default) selects hardware first-element tail filling
    for ordinary GM -> UB/L1 copies. An integer/float constant or scalar SSA
    value selects constant filling; ``storage_bits(value)`` supplies encoded
    storage bits. The destination strides and DMA mode determine the 32-byte
    tail boundaries, including after flatten. Explicit logical ``pad`` uses
    its own constant for the shared fill register; an explicit numeric
    ``pad_val`` must agree with that value. NDDMA and formatted copies do not
    accept a constant ``pad_val``.
    Tensor.partition expresses the logical copy partition.
    l2_cache_ctl, unit_flag and dst_subblock
    retain their existing instruction and synchronization contracts.
    atomic_add=True (or a runtime i1) accumulates a UB/L0C copy into GM
    through the atomic DMA path instead of a plain store.

    ``channel_split`` (bool, default ``None``=auto) configures the fixpipe
    channel split of an fp32 L0C -> GM/UB/L1 store. The fp32 L0C fractal is
    N0=16 wide: ``None``/``True`` re-chunk each source fractal into a typed NZ
    destination's two C0=8 halves (the standard FRACTAL_NZ layout), while
    ``False`` stores each fractal 1:1 into the C0=16 L0C-mirror spelling --
    a destination declared with an explicit ``physical_layout`` of
    ``(N1, M1, 16, 16)`` fractals. It requires same-dtype fp32 operands and,
    for L0C -> GM/UB, a typed NZ (``data_format="nz"``) destination.
    """

    if base is not None and not isinstance(base, CopyOptions):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"base must be a CopyOptions or None; got {type(base).__name__}",
            span=argument_span("base"),
        )
    if engine is not _UNSET and engine not in _ENGINE_KIND_MAP:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            f'Unknown engine: {_render_literal(engine)}; expected "auto" or "nddma"',
            span=argument_span("engine"),
        )

    static_overrides = {
        name: value
        for name, value in {
            "engine": engine,
            "channel_split": channel_split,
        }.items()
        if value is not _UNSET
    }
    control_overrides = {
        name: value
        for name, value in {
            "dst_subblock": dst_subblock,
            "unit_flag": unit_flag,
            "mx_scale": mx_scale,
            "l2_cache_ctl": l2_cache_ctl,
            "atomic_add": atomic_add,
            "pad_val": pad_val,
        }.items()
        if value is not _UNSET
    }

    static = _StaticCopyConfig() if base is None else getattr(base, "_static")
    controls = _CopyControls() if base is None else getattr(base, "_controls")
    if static_overrides:
        static = replace(static, **static_overrides)
    if control_overrides:
        controls = replace(controls, **control_overrides)

    if base is not None and not static_overrides:
        value = getattr(base, "_value")
    elif static_overrides or not control_overrides:
        value = _materialize_copy_engine(static)
    else:
        # Runtime controls do not select an engine or a layout transform.
        value = None
    return CopyOptions(value, static, controls)


def cv_valid_extent(tensor, *, axis, alignment=1, part_id):
    """Runtime valid extent of one part of ``tensor``'s current tile.

    The shape-query counterpart of Tensor.partition with matching axis and
    alignment over the same full-side operand: the
    tile's full shape comes from its static declaration and its actual
    shape from ``tensor.shape``.
    """
    full_shape = _partition_full_shape(tensor)
    actual_shape = tuple(tensor.shape)
    return _make_partition_tiler(actual_shape, full_shape, axis=axis, alignment=alignment).valid_extent(part_id)


def _normalize_copy_control(value, name, choices):
    """Keep cache policy on the copy, including when it is a constant."""
    from cannbot_dsl.types._numeric import Int32

    if isinstance(value, int) and not isinstance(value, bool):
        if value not in choices:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT, f"{name} must be one of {choices}; got {_render_literal(value)}",
                span=argument_span(name),
            )
        return Int32(value)
    if isinstance(value, ir.Value) and value.type == ir.IntegerType.get_signless(32):
        return value
    raise CANNBotTypeError(
        DiagnosticCode.INVALID_TYPE,
        f"{name} must be an integer constant or an i32 SSA value; got {type(value).__name__}",
        span=argument_span(name),
    )


def _normalize_l2_cache_ctl(value):
    # The load-side vector DMA CAPI also accepts NOTALLOC_CLEAN (5) and
    # NOTALLOC_DROP (6). Direction-specific validation remains in CANNIR:
    # store paths must reject these values because the store enum has no 5/6.
    return _normalize_copy_control(value, "l2_cache_ctl", (0, 1, 2, 4, 5, 6))


def _normalize_pad_val(value):
    from cannbot_dsl.tensor import StorageBits
    from cannbot_dsl.types._numeric import Float32, Int64

    if isinstance(value, str) and value == "first":
        return None, False
    storage_bits = isinstance(value, StorageBits)
    if storage_bits:
        value = value.value
    if type(value) is int:
        value = Int64(value)
    elif type(value) is float:
        value = Float32(value)
    if not isinstance(value, ir.Value) or not isinstance(value.type, (ir.IntegerType, ir.FloatType)):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            'pad_val must be "first", a numeric scalar constant/SSA value, or storage_bits(value); '
            f"got {type(value).__name__}",
            span=argument_span("pad_val"),
        )
    return value, storage_bits


def _validate_sequence_options(controls, message: str) -> None:
    if (
        controls.mx_scale is not None
        or controls.atomic_add is not False
        or controls.dst_subblock is not None
        or not (isinstance(controls.unit_flag, int) and controls.unit_flag == 0)
        or not (isinstance(controls.pad_val, str) and controls.pad_val == "first")
    ):
        raise CANNBotValueError(
            DiagnosticCode.UNSUPPORTED_FEATURE,
            message,
            span=argument_span("options"),
        )


def mem_copy(
    dst: "Tensor | tuple[Tensor, ...] | list[Tensor]",
    src: "Tensor | tuple[Tensor, ...] | list[Tensor]",
    options: CopyOptions | None = None,
) -> None:
    """Copy ``src`` to ``dst``.

    Return ``None``. Bind the destination Tensor's layout and actual domain
    explicitly before copying, and use that Tensor for subsequent operations.
    Copying preserves existing Tensor interpretations.

    GM -> UB copies use the ordinary burst/loop DMA planned from the View
    address recurrences. Pass ``copy_options(engine="nddma")`` to explicitly
    select the per-axis NDDMA walk instead; automatic selection never picks
    NDDMA, so layouts the ordinary DMA cannot express are compile-time errors
    without it.

    UB -> UB format conversion requires a user-written raw VF. This API
    supports ordinary UB copies and hardware DMA format conversions.

    Use ``src.permute(1, 0)`` and declare the destination layout for an
    L1 -> L0A/L0B transpose. The compiler selects the hardware format change.

    A nonempty tuple/list of GM or UB Tensors copies their contents, in source
    order. Use ``cat(sources, dim=0)`` for equal-rank concatenation.
    GM sources copy into UB or L1; UB sources copy into
    ND L1 on AIV MTE3 with ``l2_cache_ctl=0`` and no format conversion.
    All sources must use the same memory space. Equal-rank sources concatenate
    on axis 0 with provably equal inner extents. Use explicit reshape/flatten
    to give sources a common rank before concatenation. Larger destinations
    preserve untouched logical values. Arbitrary ranks and multi-row sources
    are supported when their layouts form one regular DMA burst stream.
    This is one RingBuffer write access and lowers to exactly one DMA instruction.
    Sources must share a provable base and have equal address intervals.
    Unequal or unprovable intervals are compilation errors, with no split
    fallback or source reordering. A dynamic interval must be non-negative and
    fit the target DMA range at runtime, like a dynamic single-source stride.
    For GM sources, a NZ L1 destination selects ND-to-NZ conversion, including regular batches
    of matrices. The format is derived from the operands, with default
    addressing and zero padding only.
    A single source may carry a data-dependent (gathered) address: a source
    view whose origin is a runtime scalar — e.g.
    ``tile_slice(cache[locator // page, n, None, None], (1, k),
    (locator % page, 0))``
    — is accepted, and a (1, k) or few-row destination window on the NZ slot
    (see ``tile_slice`` row windows) lands it at an arbitrary row. Arbitrary
    per-row gathers are spelled as one mem_copy per row; the multi-source
    form above is not a gather, since its sources must share provably equal
    address intervals.
    UB-to-L1 addresses, burst lengths and gaps must be 32-byte aligned. It
    supports up to 4095 bursts, each 1..65535 DataBlocks (32 bytes), with
    non-negative source/destination gaps of at most 65535 DataBlocks.
    Dynamic parameters must satisfy these bounds at runtime.

    A nonempty tuple/list of UB or L1 Tensor views as ``dst`` broadcasts one
    ND GM source into every listed destination using one MTE2 outer-loop DMA.
    The list order and length are fixed while tracing. The first destination
    supplies the hardware base and the first two destination views supply the
    byte stride. Every later destination must follow the same affine address
    progression; this is a caller contract and is not re-proven by lowering.
    Broadcast only accepts default Identity GM->UB/GM->L1 or GM->L1 ND2NZ
    copies, without padding, split, atomic, or scale.

    ``tensor.partition(dim=..., part_id=..., alignment=...)`` selects a
    two-part copy on the full-data GM/L1 operand. L0C -> UB puts partition on
    the L0C source and omits part_id for hardware dual-destination routing.

    ``tile_slice_multi(tensor, block_shape, repeats=..., step=...)`` on both
    ends expresses repeated blocks, with independently chosen element steps.
    It retains existing ND2NZ GM -> L1 and L1 -> L0A/L0B hardware limits.

    An L0C -> GM/UB copy whose destination is a typed NZ tensor
    (``data_format="nz"``) keeps the L0C fractal payload: FIXPIPE runs in
    its raw DMA mode and no NZ2ND/NZ2DN expansion happens on the fly. The
    destination is addressed by its own NZ physical layout. This raw mode
    currently supports same-dtype fp32 operands only, and rejects deq_scale,
    relu, and atomic_add.
    ``copy_options(channel_split=...)`` selects how FIXPIPE delivers the
    payload into the explicitly declared fp32 destination layout: the default
    re-chunks each N0=16 source fractal into two C0=8 halves, while
    ``channel_split=False`` stores each fractal 1:1 into a destination declared
    with a C0=16 L0C-mirror physical layout. It never changes that layout. For
    L0C -> UB, the split-M dual-destination form (``tensor.partition(dim=0)``
    on the L0C source without ``part_id``) keeps the NZ payload with an
    n0-preserved delivery: the flattened M extent (m1*m0 rows) is halved
    across the two Vector sub-cores -- each receives m1*m0/2 rows, which
    for even m1 is the (n1, m1/2, m0, n0) fractal half frame. The split-N
    form (``tensor.partition(dim=1)``) instead halves the n1 fractal
    planes: each sub-core receives (n1/2, m1, m0, n0). In both forms the
    destination declares that C0=n0 mirror half frame and no channel-split
    re-chunking composes with dual routing (that combination faults the
    device). The AIV partition form (``part_id``) requires an ND
    destination.

    L1 -> UB is a flat byte copy bounded by the destination's physical
    storage span, issued by AIC to the selected Vector sub-core as one
    non-synchronizing ``asc_copy_l12ub`` burst. Both operands must have
    matching dtypes and static physical layouts; the destination span must be
    positive, 32-byte aligned, at most 65535 DataBlocks, and no larger than
    the source span (a full-size fractal L1 slot may hold a smaller compact
    payload, such as a smallc0 packing). ``dst_subblock`` selects the receiving Vector sub-core
    (0 or 1, constant or runtime i32; default 0), with the same semantics as
    the single-destination L0C -> UB routing. No copy options, scale, padding,
    partition, or cache-policy operand is accepted; strided or gapped burst
    geometry remains with the raw escape hatch. RingBuffer operands provide the
    cross-core ownership and synchronization protocol.

    ``l2_cache_ctl`` is a constant or runtime i32 policy. Vector GM -> UB
    (including NDDMA) accepts the load policies 0, 1, 2, 4, 5, and 6;
    UB -> GM accepts the store policies 0, 1, 2, and 4. GM -> L1 and
    L0C -> GM keep the existing 0, 1, 2, and 4 policy set. The default is 0.
    For an i32 SSA policy, the caller must keep runtime values in the
    direction-specific CAPI domain; constant values are verified by CANNIR.

    Use ``copy_options(atomic_add=True)`` for UB/L0C accumulation into GM.
    The GM destination dtype selects the AscendC atomic setter. A runtime
    choice takes an i1 SSA value (``copy_options(atomic_add=pred)``) or an
    explicit branch between the two options forms.

    ``mem_copy(dst, src.relu())`` enables the fixpipe on-the-fly ReLU epilogue (the CAPI
    ``relu_pre`` argument, ReluMode 1=NORMAL_RELU) for an L0C -> GM, L0C -> UB
    or L0C -> L1 store. It composes with the fixpipe quant modes; any other
    copy direction is rejected by the verifier instead of being silently
    dropped. It cannot be combined with the dual-destination FIXPIPE mode
    (partition on the L0C source): hardware dual destination
    requires all other fixpipe functions to be bypassed.

    ``src.convert(dtype, scale=...)`` describes FIXPIPE conversion and scale;
    dtype must match dst.dtype. ``src.pad((left, right, ...), ...)`` describes
    DMA padding from the innermost dimension outwards. Views retain their storage identity and captured coordinates. Source and
    scale-table contents are read when this copy executes; a View is not a snapshot.
    """
    _tile_copy(dst, src, options)


def _tile_copy(
    dst: "Tensor | tuple[Tensor, ...] | list[Tensor]",
    src: "Tensor | tuple[Tensor, ...] | list[Tensor]",
    options: CopyOptions | None = None,
) -> Tensor | tuple[Tensor, ...]:
    """Emit a copy and expose its inferred result views to internal callers."""
    from cannbot_dsl.lang.vf import _tag_if_in_vf
    from cannbot_dsl.tensor import _require_tensor, _raw

    if isinstance(src, (tuple, list)):
        src = _cat(src)
    if options is None:
        controls = _CopyControls()
        engine = None
    elif isinstance(options, CopyOptions):
        controls = getattr(options, "_controls")
        engine = getattr(options, "_value")
    else:
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"options must be created by copy_options; got {type(options).__name__}",
            span=argument_span("options"),
        )
    dst_subblock = controls.dst_subblock
    unit_flag = controls.unit_flag
    mx_scale = controls.mx_scale
    l2_cache_ctl = controls.l2_cache_ctl
    atomic_add = controls.atomic_add

    dst_is_sequence = isinstance(dst, (tuple, list))
    singleton_sequence = dst_is_sequence and len(dst) == 1
    src_is_sequence = isinstance(src, (tuple, list))
    if dst_is_sequence and src_is_sequence:
        raise CANNBotValueError(
            DiagnosticCode.UNSUPPORTED_FEATURE,
            "mem_copy does not support sequence-to-sequence copies",
        )
    # A singleton list has no second view from which to derive a repeat
    # stride.  Preserve ordinary mem_copy semantics instead of materializing
    # a degenerate loop-DMA operation.
    if dst_is_sequence and len(dst) == 1:
        dst = dst[0]
        dst_is_sequence = False
    if dst_is_sequence:
        if not dst:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT,
                "multi-destination mem_copy requires at least one destination; got 0",
                span=argument_span("dst"),
            )
        if not isinstance(src, Tensor):
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                f"multi-destination mem_copy requires one GM Tensor source; got {type(src).__name__}",
                span=argument_span("src"),
            )
        _validate_sequence_options(
            controls,
            "multi-destination mem_copy supports only default GM -> UB/L1 copies with l2_cache_ctl",
        )
        _operand_memref_type(src)
        for destination in dst:
            if not isinstance(destination, Tensor):
                raise CANNBotTypeError(
                    DiagnosticCode.INVALID_TYPE,
                    f"multi-destination mem_copy destinations must be Tensor views; got {type(destination).__name__}",
                    span=argument_span("dst"),
                )
            _operand_memref_type(destination)
        op = cannir.MultiDstCopyOp(
            [_raw(_require_tensor(destination)) for destination in dst],
            _raw(_require_tensor(src)),
            _normalize_l2_cache_ctl(l2_cache_ctl),
            engine=engine,
        )
        _tag_if_in_vf(op)
        results = tuple(Tensor._from_ir(value) for value in op.results)
        return results

    # Validate the semantic memory boundary even when explicit options
    # bypass auto-inference.
    _operand_memref_type(dst)
    _operand_memref_type(src)
    if mx_scale is not None:
        _operand_memref_type(mx_scale)
    kwargs = {
        "l2_cache_ctl": _normalize_l2_cache_ctl(l2_cache_ctl),
        "unit_flag": _normalize_copy_control(unit_flag, "unit_flag", (0, 1, 2, 3)),
    }
    pad_val, pad_storage_bits = _normalize_pad_val(controls.pad_val)
    if pad_val is not None:
        kwargs["pad_val"] = pad_val
        kwargs["pad_storage_bits"] = pad_storage_bits
    if dst_subblock is not None:
        kwargs["dst_subblock"] = _normalize_copy_control(dst_subblock, "dst_subblock", (0, 1))

    if isinstance(atomic_add, bool):
        kwargs["atomic_add"] = atomic_add
    elif (
        isinstance(atomic_add, ir.Value) and isinstance(atomic_add.type, ir.IntegerType) and atomic_add.type.width == 1
    ):
        kwargs["atomic_add_value"] = atomic_add
    else:
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"atomic_add must be a bool or an i1 SSA value; got {type(atomic_add).__name__}",
            span=argument_span("atomic_add"),
        )
    if engine is not None:
        kwargs["engine"] = engine
    if mx_scale is not None:
        kwargs["mx_scale"] = _raw(_require_tensor(mx_scale))
    dst_value = _raw(_require_tensor(dst))
    src_value = _raw(_require_tensor(src))
    if Tensor._from_ir(dst_value).rank != Tensor._from_ir(src_value).rank:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_SHAPE,
            "mem_copy source and destination View ranks must match; apply flatten or reshape explicitly; "
            f"got source rank {Tensor._from_ir(src_value).rank}, destination rank {Tensor._from_ir(dst_value).rank}",
        )
    op = cannir.MemCopyOp(dst_value, src_value, **kwargs)
    dst_type = cannir.TensorType(dst_value.type)
    src_type = cannir.TensorType(src_value.type)
    dst_memloc = dst_type.pointer.memloc
    src_memloc = src_type.pointer.memloc
    if src_memloc == int(MemLoc.GM) and dst_memloc in (int(MemLoc.UB), int(MemLoc.L1)):
        # This is an executable device-pipeline obligation. Standalone IR
        # fragments used to inspect View normalization have no device entry;
        # the planner still verifies them when explicitly run on the fragment.
        parent = op.operation.parent
        while parent is not None and parent.name != "func.func":
            parent = parent.parent
        if parent is not None and "cannir.device" in parent.attributes:
            if dst_memloc == int(MemLoc.UB):
                op.operation.attributes["cannir.requires_gm2ub_plan"] = ir.UnitAttr.get()
            elif (
                int(dst_type.layout_map_kind) == int(LayoutMapKind.Identity)
                and int(src_type.layout_map_kind) == int(LayoutMapKind.Identity)
            ):
                # Only ordinary identity GM -> L1 copies are proven by
                # cannir-plan-gm2l1-dma; formatted NZ/ZN copies
                # keep their existing lowerings and must not carry the marker.
                op.operation.attributes["cannir.requires_gm2l1_plan"] = ir.UnitAttr.get()
    _tag_if_in_vf(op)
    result = Tensor._from_ir(op.res)
    return (result,) if singleton_sequence else result


def _ensure_i32_value(val) -> ir.Value:
    """Convert Python int / MLIR Value to an MLIR i32 Value."""
    return coerce_scalar_value(val, ir.IntegerType.get_signless(32))


def _ensure_index_value(val) -> ir.Value:
    """Convert Python int / MLIR Value to an MLIR index Value."""
    return coerce_scalar_value(val, ir.IndexType.get())


def _unwrap_tensor(value):
    """Raw memory operations consume an explicitly selected Tensor."""
    from cannbot_dsl.ops._operands import _tensor_operand

    return unwrap_operand(_tensor_operand(value))


def _fill_l1_value(value, value_dtype):
    from cannbot_dsl import dtypes

    supported = (dtypes.uint32, dtypes.float16, dtypes.bfloat16)
    if value_dtype is None:
        value_dtype = getattr(value, "dtype", None)
        if value_dtype is None:
            if is_exact_instance(value, int):
                value_dtype = dtypes.uint32
            elif is_exact_instance(value, float):
                value_dtype = dtypes.float16
    if value_dtype not in supported:
        names = ", ".join(f"dtypes.{dtype.name}" for dtype in supported)
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"asc_fill_l1 value_dtype must be one of: {names}",
            span=argument_span("value_dtype"),
        )
    return unwrap_operand(value_dtype(value)), value_dtype


def _validate_fill_l1_config(*, offset_elems, repeat, blk_num, dst_gap):
    if is_exact_instance(offset_elems, int) and offset_elems < 0:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            f"asc_fill_l1 offset_elems must be non-negative; got {_render_literal(offset_elems)}",
            span=argument_span("offset_elems"),
        )
    for name, value in (("repeat", repeat), ("blk_num", blk_num)):
        if is_exact_instance(value, int) and not 1 <= value <= 32767:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT,
                f"asc_fill_l1 {name} must be in [1, 32767]; got {_render_literal(value)}",
                span=argument_span(name),
            )
    if is_exact_instance(dst_gap, int) and not 0 <= dst_gap <= 32767:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            f"asc_fill_l1 dst_gap must be in [0, 32767]; got {_render_literal(dst_gap)}",
            span=argument_span("dst_gap"),
        )


def cube_fill_l1(
    l1_buf, value, *, value_dtype=None, offset_elems: int = 0, repeat: int = 1, blk_num: int = 1, dst_gap: int = 0
):
    """Fill L1 DataBlocks with a uint32 bit pattern, half, or bfloat16 value.

    Python integers default to the ``uint32_t`` bit-pattern overload and Python
    floats default to ``half``. Pass ``value_dtype`` explicitly when a literal
    must use another supported overload. A ``bfloat16_t`` fill value is valid
    only for a bfloat16 L1 destination, matching the Ascend C API.
    """
    from cannbot_dsl import dtypes

    _validate_fill_l1_config(
        offset_elems=offset_elems,
        repeat=repeat,
        blk_num=blk_num,
        dst_gap=dst_gap,
    )
    fill_value, resolved_dtype = _fill_l1_value(value, value_dtype)
    dst_dtype = getattr(l1_buf, "dtype", None)
    normal_destinations = {
        dtypes.int16,
        dtypes.uint16,
        dtypes.float16,
        dtypes.int32,
        dtypes.uint32,
        dtypes.float32,
    }
    if dst_dtype == dtypes.bfloat16:
        pass
    elif dst_dtype in normal_destinations:
        if resolved_dtype == dtypes.bfloat16:
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE,
                "a bfloat16 asc_fill_l1 value requires a bfloat16 destination",
            )
    else:
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            "cube_fill_l1 destination dtype is not supported by asc_fill_l1",
            span=argument_span("l1_buf"),
        )
    cannir.raw_fill_l1(
        _unwrap_tensor(l1_buf),
        _ensure_index_value(offset_elems),
        fill_value,
        _ensure_i32_value(repeat),
        _ensure_i32_value(blk_num),
        _ensure_i32_value(dst_gap),
    )


def cube_fill_l1_zero(l1_buf, *, offset_elems: int = 0, repeat: int = 1, blk_num: int = 1, dst_gap: int = 0):
    """Compatibility zero-fill, including internal aliased fp8 L1 buffers."""
    _validate_fill_l1_config(
        offset_elems=offset_elems,
        repeat=repeat,
        blk_num=blk_num,
        dst_gap=dst_gap,
    )
    cannir.raw_fill_l1(
        _unwrap_tensor(l1_buf),
        _ensure_index_value(offset_elems),
        _ensure_i32_value(0),
        _ensure_i32_value(repeat),
        _ensure_i32_value(blk_num),
        _ensure_i32_value(dst_gap),
    )


__all__ = [
    "ChannelSplitMode",
    "CopyOptions",
    "cv_valid_extent",
    "copy_options",
    "cube_fill_l1",
    "cube_fill_l1_zero",
    "mem_copy",
]
