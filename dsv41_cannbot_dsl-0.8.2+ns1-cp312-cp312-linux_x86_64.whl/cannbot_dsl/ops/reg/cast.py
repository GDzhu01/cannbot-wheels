# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode dtype cast and rounding ops."""


from enum import IntEnum as _IntEnum

from cannbot_dsl.core.diag.diagnostics import (
    CANNBotTypeError, CANNBotValueError, DiagnosticCode,
)

import cannbot_dsl._mlir.ir as ir
from cannbot_dsl._mlir.dialects import ascvec
from cannbot_dsl.types import dtypes
from cannbot_dsl.types.rounding import RoundingMode, _parse_rounding

from cannbot_dsl.lang.vf import _require_raw_mode

from cannbot_dsl.ops.reg._common import _dtype_bits, _dtype_type, _is_storage_dtype, _raw_vreg_type, _tag_raw_op
from cannbot_dsl.ops.reg.mask import Mask
from cannbot_dsl.ops.reg.reg_defs import RawVReg


class RegLayout(_IntEnum):
    UNKNOWN = -1
    ZERO = 0
    ONE = 1
    TWO = 2
    THREE = 3


def _normalize_rounding(rounding) -> RoundingMode:
    return _parse_rounding(rounding, operation="vcast")


def _normalize_reg_layout(reg_layout) -> RegLayout:
    if isinstance(reg_layout, RegLayout):
        return reg_layout
    raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "vcast: reg_layout must be a RegLayout")


def _is_full_mask(mask: "Mask") -> bool:
    """True when ``mask`` was produced by full_mask/create_mask (pset).

    A full mask is granularity-agnostic (b8 all-true covers b16/b32 lanes),
    so callers may accept it for any element bit width.
    """
    try:
        defining_op = mask.value.owner
        return getattr(defining_op, "name", "") == "cannir.raw_reg.full_mask"
    except Exception:
        return False


def vcast(
    src: RawVReg,
    dtype,
    *,
    mask: Mask,
    rounding=RoundingMode.NA,
    saturate=False,
    reg_layout=RegLayout.UNKNOWN,
) -> RawVReg:
    """Cast a raw vector register to ``dtype``.

    ``rounding=RoundingMode.NA`` (default) lets the DSL pick per AscendC
    conventions: widening casts carry no rounding (exact); narrowing casts
    auto-select RN. Pass an explicit RoundingMode to pin the behavior.

    ``saturate`` selects the per-instruction C API spelling only; it never
    modifies global CTRL saturation bits. Configure those explicitly through
    ``cannbot_dsl.ops.arch.get_ctrl`` / ``set_ctrl`` when required by the device.

    For fp4x2_e2m1 to bfloat16, ``RegLayout.ZERO`` through
    ``RegLayout.THREE`` select source positions P0 through P3. The conversion
    uses an 8-bit mask because each physical source carrier holds two fp4
    values.
    """
    _require_raw_mode("vcast")
    dtype = _dtype_type(dtype)
    src_type = _dtype_type(src.dtype)
    if src_type == dtype:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            "vcast: source and destination dtypes must differ; use the dedicated rounding operation",
        )
    src_bits = _dtype_bits(src.dtype)
    dst_bits = _dtype_bits(dtype)
    rounding = _normalize_rounding(rounding)
    if rounding is RoundingMode.RH:
        raise CANNBotValueError(
            DiagnosticCode.UNSUPPORTED_FEATURE, "vcast: RH rounding is not supported by register casts"
        )
    fp8_types = (ir.Float8E4M3FNType, ir.Float8E5M2Type)
    src_is_fp8 = isinstance(src_type, fp8_types)
    dst_is_fp8 = isinstance(dtype, fp8_types)
    src_is_f32 = isinstance(src_type, ir.F32Type)
    dst_is_f32 = isinstance(dtype, ir.F32Type)
    src_is_f16 = isinstance(src_type, ir.F16Type)
    dst_is_f16 = isinstance(dtype, ir.F16Type)
    src_is_bf16 = isinstance(src_type, ir.BF16Type)
    dst_is_bf16 = isinstance(dtype, ir.BF16Type)
    src_integer_type = src_type if isinstance(src_type, ir.IntegerType) else None
    dst_integer_type = dtype if isinstance(dtype, ir.IntegerType) else None
    src_is_int4 = _is_storage_dtype(src.dtype, dtypes.int4x2)
    dst_is_int4 = _is_storage_dtype(dtype, dtypes.int4x2)
    src_is_integer = src_integer_type is not None or src_is_int4
    dst_is_integer = dst_integer_type is not None or dst_is_int4
    src_is_i16 = src_integer_type is not None and src_integer_type.width == 16 and not src_integer_type.is_unsigned
    src_is_i32 = src_integer_type is not None and src_integer_type.width == 32 and not src_integer_type.is_unsigned
    src_is_i64 = src_integer_type is not None and src_integer_type.width == 64 and not src_integer_type.is_unsigned
    src_is_u16 = src_integer_type is not None and src_integer_type.width == 16 and src_integer_type.is_unsigned
    src_is_u32 = src_integer_type is not None and src_integer_type.width == 32 and src_integer_type.is_unsigned
    dst_is_i8 = dst_integer_type is not None and dst_integer_type.width == 8 and not dst_integer_type.is_unsigned
    dst_is_i16 = dst_integer_type is not None and dst_integer_type.width == 16 and not dst_integer_type.is_unsigned
    dst_is_i32 = dst_integer_type is not None and dst_integer_type.width == 32 and not dst_integer_type.is_unsigned
    dst_is_i64 = dst_integer_type is not None and dst_integer_type.width == 64 and not dst_integer_type.is_unsigned
    dst_is_u8 = dst_integer_type is not None and dst_integer_type.width == 8 and dst_integer_type.is_unsigned
    dst_is_u16 = dst_integer_type is not None and dst_integer_type.width == 16 and dst_integer_type.is_unsigned
    src_is_hif8 = _is_storage_dtype(src.dtype, dtypes.hifloat8)
    dst_is_hif8 = _is_storage_dtype(dtype, dtypes.hifloat8)
    dst_is_fp4 = _is_storage_dtype(dtype, dtypes.fp4x2_e2m1) or _is_storage_dtype(dtype, dtypes.fp4x2_e1m2)
    packed4_to_wider = src_bits == 4 and dst_bits > 4
    fp8_cast = (src_is_fp8 and dst_is_f32) or (src_is_f32 and dst_is_fp8)
    hif8_cast = (src_is_hif8 and (dst_is_f16 or dst_is_f32)) or ((src_is_f16 or src_is_f32) and dst_is_hif8)
    if (src_is_hif8 or dst_is_hif8) and not hif8_cast:
        raise CANNBotValueError(
            DiagnosticCode.UNSUPPORTED_FEATURE, "vcast: hifloat8 only casts from float16/float32 or to float16/float32"
        )
    # NA means no user-selected rounding. Float-to-integer conversion still
    # requires a rounding mode even when the integer carrier is wider.
    if rounding == RoundingMode.NA:
        requires_rounding = (
            src_bits >= dst_bits
            or ((src_is_f16 or src_is_f32 or src_is_bf16) and dst_is_integer)
            or ((src_is_f16 or src_is_bf16) and dst_is_fp4)
        )
        if requires_rounding:
            rounding = RoundingMode.RN
    # Both families pack a narrow float against a wider one, so the mask is
    # always denominated in source elements.
    narrow_float_cast = fp8_cast or hif8_cast
    reg_layout = _normalize_reg_layout(reg_layout)
    width_ratio = max(src_bits, dst_bits) // min(src_bits, dst_bits)
    if width_ratio == 1:
        if reg_layout != RegLayout.UNKNOWN:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT, "vcast: same-width casts require RegLayout.UNKNOWN"
            )
    elif width_ratio == 2:
        if reg_layout not in (
            RegLayout.UNKNOWN,
            RegLayout.ZERO,
            RegLayout.ONE,
        ):
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT, "vcast: 1:2 and 2:1 casts require RegLayout.UNKNOWN, ZERO, or ONE"
            )
    elif width_ratio == 4:
        if reg_layout not in (
            RegLayout.UNKNOWN,
            RegLayout.ZERO,
            RegLayout.ONE,
            RegLayout.TWO,
            RegLayout.THREE,
        ):
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT,
                "vcast: 1:4 and 4:1 casts require RegLayout.UNKNOWN, ZERO, ONE, TWO, or THREE",
            )
    if not isinstance(saturate, bool):
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "vcast: saturate must be a bool")
    saturating_pair = (
        (
            src_is_f32
            and (dst_is_f16 or dst_is_bf16 or dst_is_i16 or dst_is_i32 or dst_is_i64 or dst_is_hif8 or dst_is_fp8)
        )
        or (src_is_f16 and (dst_is_i8 or dst_is_i16 or dst_is_u8 or dst_is_int4 or dst_is_hif8))
        or (src_is_bf16 and (dst_is_f16 or dst_is_i32))
        or (src_is_i16 and dst_is_u8)
        or (src_is_i32 and (dst_is_i16 or dst_is_u16 or dst_is_u8))
        or (src_is_u16 and dst_is_u8)
        or (src_is_u32 and (dst_is_i16 or dst_is_u16 or dst_is_u8))
        or (src_is_i64 and dst_is_i32)
    )
    if saturate and not saturating_pair:
        if src_bits <= dst_bits:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT, "vcast: saturate only applies to narrowing casts (src wider than dst)"
            )
        raise CANNBotValueError(
            DiagnosticCode.UNSUPPORTED_FEATURE, "vcast: saturation is not supported for this source/destination pair"
        )
    if fp8_cast and rounding not in (RoundingMode.RN, RoundingMode.NA):
        raise CANNBotValueError(DiagnosticCode.UNSUPPORTED_FEATURE, "vcast: fp8 casts only support RN rounding")
    # The half->hif8 store has round-half-to-even (spelled `_rh`) and
    # round-nearest-away variants; the widening direction is RN only.
    if (
        hif8_cast
        and dst_is_hif8
        and rounding
        not in (
            RoundingMode.RN,
            RoundingMode.RNA,
        )
    ):
        raise CANNBotValueError(
            DiagnosticCode.UNSUPPORTED_FEATURE,
            "vcast: float16/float32 to hifloat8 casts only support RN or RNA rounding",
        )
    if hif8_cast and src_is_hif8 and rounding not in (RoundingMode.RN, RoundingMode.NA):
        raise CANNBotValueError(
            DiagnosticCode.UNSUPPORTED_FEATURE, "vcast: hifloat8 widening casts only support RN rounding"
        )
    layout_selects_source = src_bits < dst_bits and reg_layout != RegLayout.UNKNOWN
    # Packed four-bit values are carried two per byte, and their widening
    # conversions consume a b8 mask.
    expected_mask_bits = (
        8 if packed4_to_wider else (src_bits if narrow_float_cast or layout_selects_source else max(src_bits, dst_bits))
    )
    if mask.elem_bits != expected_mask_bits and not _is_full_mask(mask):
        if packed4_to_wider:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT, "vcast: packed four-bit source mask elem_bits must be 8"
            )
        if narrow_float_cast or layout_selects_source:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT, "vcast: layout-selecting cast mask elem_bits must match src_bits"
            )
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT, "vcast: mask elem_bits must match max(src_bits, dst_bits)"
        )
    kwargs = {"rounding": rounding, "saturate": saturate}
    if reg_layout != RegLayout.UNKNOWN:
        kwargs["reg_layout"] = reg_layout
    op = ascvec.VCastOp(_raw_vreg_type(dtype), src.value, mask.value, **kwargs)
    _tag_raw_op(op)
    return RawVReg(op.result, dtype)


def _rounding_unary(src: RawVReg, mask: Mask, op_type, name: str) -> RawVReg:
    _require_raw_mode(name)
    from cannbot_dsl.ops.reg._common import _reject_b64

    _reject_b64(name, src)
    if src.dtype not in (dtypes.float16, dtypes.bfloat16, dtypes.float32):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE, f"{name}: source dtype must be float16, bfloat16, or float32"
        )
    bits = _dtype_bits(src.dtype)
    if mask.elem_bits != bits and not _is_full_mask(mask):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT, f"{name}: mask elem_bits must match source dtype bit-width"
        )
    op = op_type(_raw_vreg_type(src.dtype), src.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vceil(src: RawVReg, *, mask: Mask) -> RawVReg:
    """Round toward positive infinity with ``asc_ceil``."""
    return _rounding_unary(src, mask, ascvec.VCeilOp, "vceil")


def vfloor(src: RawVReg, *, mask: Mask) -> RawVReg:
    """Round toward negative infinity with ``asc_floor``."""
    return _rounding_unary(src, mask, ascvec.VFloorOp, "vfloor")


def vtrunc(src: RawVReg, *, mask: Mask) -> RawVReg:
    """Round toward zero with ``asc_trunc``."""
    return _rounding_unary(src, mask, ascvec.VTruncOp, "vtrunc")


def vround(src: RawVReg, *, mask: Mask) -> RawVReg:
    """Round to nearest with ties away from zero using ``asc_round``."""
    return _rounding_unary(src, mask, ascvec.VRoundOp, "vround")


def vrint(src: RawVReg, *, mask: Mask) -> RawVReg:
    """Round to nearest with ties to even using ``asc_rint``."""
    return _rounding_unary(src, mask, ascvec.VRintOp, "vrint")
