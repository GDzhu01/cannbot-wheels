# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Raw register-mode arithmetic and elementwise math ops."""

from cannbot_dsl.core.diag.diagnostics import (
    CANNBotTypeError, CANNBotValueError, DiagnosticCode,
)

from cannbot_dsl._mlir.dialects import ascvec
from cannbot_dsl.types import dtypes

from cannbot_dsl.lang.vf import _require_raw_mode

from cannbot_dsl.ops.reg._common import (
    _dtype_bits,
    _dtype_type,
    _is_integer_dtype,
    _is_storage_dtype,
    _raw_mask_type,
    _raw_vreg_type,
    _reject_b64,
    _scalar_value,
    _tag_raw_op,
)
from cannbot_dsl.ops.reg.mask import Mask, _binary, _unary
from cannbot_dsl.ops.reg.reg_defs import RawVReg


def _carry_dtype_check(name: str, src0: RawVReg, src1: RawVReg):
    if src0.dtype != src1.dtype:
        raise CANNBotValueError(DiagnosticCode.INVALID_TYPE, f"{name}: dtype mismatch {src0.dtype} vs {src1.dtype}")
    if not _is_integer_dtype(src0.dtype) or src0.dtype.bits != 32:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_TYPE, f"{name}: carry ops are uint32-only (CAPI asc_addc/asc_add overloads)"
        )


def vaddc(src0: RawVReg, src1: RawVReg, carry_src: Mask, *, mask: Mask):
    """Vector add with per-lane carry-in / carry-out (arch35 ``vaddcs``).

    Returns ``(carry, dst)``: ``dst = src0 + src1 + carry_src`` with the
    per-lane carry flag ``carry``. Lowers to ``asc_addc(...)``. uint32-only.
    """
    _require_raw_mode("vaddc")
    _carry_dtype_check("vaddc", src0, src1)
    bits = _dtype_bits(src0.dtype)
    op = ascvec.VAddcOp(
        _raw_mask_type(bits),
        _raw_vreg_type(src0.dtype),
        src0.value,
        src1.value,
        mask.value,
        carry_src=carry_src.value,
    )
    _tag_raw_op(op)
    return Mask(op.carry, bits), RawVReg(op.dst, src0.dtype)


def vsubc(src0: RawVReg, src1: RawVReg, borrow_src: Mask, *, mask: Mask):
    """Vector subtract with per-lane borrow-in / borrow-out (arch35 ``vsubcs``).

    Returns ``(borrow, dst)``. Lowers to ``asc_subc(...)``. uint32-only.

    NOTE: the hardware ``vsubcs`` is an adder in disguise:
    ``dst = src0 + ~src1 + carry_in`` and ``carry_out`` is the *adder* carry
    (1 = no borrow). So a plain subtraction needs ``carry_in = all true``
    (``dst = src0 + ~src1 + 1``); chaining words passes ``carry_out`` through
    unchanged. Passing an all-false mask yields ``src0 - src1 - 1``.
    """
    _require_raw_mode("vsubc")
    _carry_dtype_check("vsubc", src0, src1)
    bits = _dtype_bits(src0.dtype)
    op = ascvec.VSubcOp(
        _raw_mask_type(bits),
        _raw_vreg_type(src0.dtype),
        src0.value,
        src1.value,
        mask.value,
        carry_src=borrow_src.value,
    )
    _tag_raw_op(op)
    return Mask(op.carry, bits), RawVReg(op.dst, src0.dtype)


def vaddco(src0: RawVReg, src1: RawVReg, *, mask: Mask):
    """Vector add with carry-out only (asc_add carry overload, 5-arg form).

    Returns ``(carry, dst)``: ``dst = src0 + src1`` with the per-lane carry
    flag ``carry`` (no carry-in). uint32-only.
    """
    _require_raw_mode("vaddco")
    _carry_dtype_check("vaddco", src0, src1)
    bits = _dtype_bits(src0.dtype)
    op = ascvec.VAddcOp(
        _raw_mask_type(bits),
        _raw_vreg_type(src0.dtype),
        src0.value,
        src1.value,
        mask.value,
    )
    _tag_raw_op(op)
    return Mask(op.carry, bits), RawVReg(op.dst, src0.dtype)


def vsubbo(src0: RawVReg, src1: RawVReg, *, mask: Mask):
    """Vector subtract with borrow-out only (asc_sub borrow overload, 5-arg form).

    Returns ``(borrow, dst)``: ``dst = src0 - src1`` with the per-lane borrow
    flag ``borrow`` (no borrow-in). uint32-only.
    """
    _require_raw_mode("vsubbo")
    _carry_dtype_check("vsubbo", src0, src1)
    bits = _dtype_bits(src0.dtype)
    op = ascvec.VSubcOp(
        _raw_mask_type(bits),
        _raw_vreg_type(src0.dtype),
        src0.value,
        src1.value,
        mask.value,
    )
    _tag_raw_op(op)
    return Mask(op.carry, bits), RawVReg(op.dst, src0.dtype)


def vmull(src0: RawVReg, src1: RawVReg, dtype, *, mask: Mask):
    """Wide vector multiply (arch35 ``vmull``).

    Returns ``(dst0, dst1)``: the 64-bit product of u32 lanes split into low
    (dst0) and high (dst1) 32-bit registers. Lowers to ``asc_mull(...)``.
    """
    _require_raw_mode("vmull")
    if src0.dtype != src1.dtype:
        raise CANNBotValueError(DiagnosticCode.INVALID_TYPE, f"vmull: dtype mismatch {src0.dtype} vs {src1.dtype}")
    dtype = _dtype_type(dtype)
    # The CAPI only provides 32x32 -> (low32, high32) overloads (u32/i32).
    if _dtype_bits(src0.dtype) != 32 or _dtype_bits(dtype) != 32:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_TYPE,
            f"vmull: only 32-bit sources and 32-bit result are supported "
            f"(asc_mull has no {_dtype_bits(src0.dtype)}-bit overload), got "
            f"src={src0.dtype}, result={dtype}"
        )
    out_ty = _raw_vreg_type(dtype)
    op = ascvec.VMullOp(out_ty, out_ty, src0.value, src1.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.dst0, dtype), RawVReg(op.dst1, dtype)


def vadd(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    return _binary(lhs, rhs, mask, ascvec.VAddOp, "vadd")


def vsub(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    return _binary(lhs, rhs, mask, ascvec.VSubOp, "vsub")


def vmul(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    return _binary(lhs, rhs, mask, ascvec.VMulOp, "vmul")


def vdiv(lhs: RawVReg, rhs: RawVReg, *, mask: Mask, precision_mode: bool = False) -> RawVReg:
    """Elementwise divide.

    ``precision_mode=True`` (f32 only) selects the IEEE754 round-to-nearest
    (0 ULP) implementation instead of the hardware divide whose results may
    deviate by up to 1 ULP. Incurs a longer software sequence.

    """
    if precision_mode and lhs.dtype is not dtypes.float32:
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE, f"vdiv precision_mode=True only supports f32, got {lhs.dtype}"
        )
    if precision_mode:
        _require_raw_mode("vdiv")
        if lhs.dtype != rhs.dtype:
            raise CANNBotValueError(DiagnosticCode.INVALID_TYPE, f"vdiv: dtype mismatch {lhs.dtype} vs {rhs.dtype}")
        op = ascvec.VDivOp(_raw_vreg_type(lhs.dtype), lhs.value, rhs.value, mask.value, precision_mode=True)
        _tag_raw_op(op)
        return RawVReg(op.result, lhs.dtype)
    return _binary(lhs, rhs, mask, ascvec.VDivOp, "vdiv")


def vmax(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    return _binary(lhs, rhs, mask, ascvec.VMaxOp, "vmax")


def vmin(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    return _binary(lhs, rhs, mask, ascvec.VMinOp, "vmin")


def vexp(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.VExpOp, "vexp")


def vlog(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.VLnOp, "vlog")


def vsqrt(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.VSqrtOp, "vsqrt")


def vrelu(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.VReluOp, "vrelu")


def vabs(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.VAbsOp, "vabs")


def vneg(src: RawVReg, *, mask: Mask) -> RawVReg:
    return _unary(src, mask, ascvec.VNegOp, "vneg")


def vabs_sub(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    _reject_b64("vabs_sub", lhs, rhs)
    return _binary(lhs, rhs, mask, ascvec.VAbsSubOp, "vabs_sub")


def vprelu(src: RawVReg, slope: RawVReg, *, mask: Mask) -> RawVReg:
    _reject_b64("vprelu", src, slope)
    return _binary(src, slope, mask, ascvec.VPreluOp, "vprelu")


def vexp_sub(lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    _require_raw_mode("vexp_sub")
    if lhs.dtype != rhs.dtype:
        raise CANNBotValueError(DiagnosticCode.INVALID_TYPE, f"vexp_sub: dtype mismatch {lhs.dtype} vs {rhs.dtype}")
    if lhs.dtype not in (dtypes.float16, dtypes.float32):
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "vexp_sub: source dtype must be f16 or f32")
    out_dtype = dtypes.float32
    op = ascvec.VExpSubOp(_raw_vreg_type(out_dtype), lhs.value, rhs.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, out_dtype)


def vcast_exp_sub(lhs: RawVReg, rhs: RawVReg, *, mask: Mask, dtype=None) -> RawVReg:
    """exp(lhs) - exp(rhs) with implicit cast of mismatched inputs to f32.

    When ``lhs``/``rhs`` are f16 the result is f32 (asc_exp_sub_half2float);
    f32 inputs pass through unchanged. Unlike :func:`vexp_sub` this accepts
    mixed f16/f32 inputs by casting the f16 side to f32 first. ``dtype``
    selects the result element type; only f32 is supported today (default).
    """
    _require_raw_mode("vcast_exp_sub")
    if dtype is not None and not _is_storage_dtype(dtype, dtypes.float32):
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "vcast_exp_sub: only dtype=float32 is supported")
    if lhs.dtype not in (dtypes.float16, dtypes.float32) or rhs.dtype not in (dtypes.float16, dtypes.float32):
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "vcast_exp_sub: source dtype must be f16 or f32")
    if lhs.dtype != rhs.dtype:
        # local import: cast.py is a peer module in this package
        from cannbot_dsl.ops.reg.cast import vcast

        if lhs.dtype is dtypes.float16:
            lhs = vcast(lhs, dtypes.float32, mask=mask)
        if rhs.dtype is dtypes.float16:
            rhs = vcast(rhs, dtypes.float32, mask=mask)
    return vexp_sub(lhs, rhs, mask=mask)


def vmadd(lhs: RawVReg, rhs: RawVReg, addend: RawVReg, *, mask: Mask) -> RawVReg:
    _require_raw_mode("vmadd")
    _reject_b64("vmadd", lhs, rhs, addend)
    if lhs.dtype != rhs.dtype or lhs.dtype != addend.dtype:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_TYPE, f"vmadd: dtype mismatch {lhs.dtype}/{rhs.dtype}/{addend.dtype}"
        )
    op = ascvec.VMaddOp(_raw_vreg_type(lhs.dtype), lhs.value, rhs.value, addend.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, lhs.dtype)


def vmula(acc: RawVReg, lhs: RawVReg, rhs: RawVReg, *, mask: Mask) -> RawVReg:
    """Vector multiply-accumulate: ``result = acc + lhs * rhs``.

    Unlike :func:`vmadd` (which lowers to the float-only ``asc_madd``), this
    maps to the int-capable ``asc_mula`` CAPI and is the accumulator form the
    AscendC basic_api implementations use for B64 cross terms.
    """
    _require_raw_mode("vmula")
    _reject_b64("vmula", acc, lhs, rhs)
    if acc.dtype != lhs.dtype or acc.dtype != rhs.dtype:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_TYPE, f"vmula: dtype mismatch {acc.dtype}/{lhs.dtype}/{rhs.dtype}"
        )
    op = ascvec.VMulaOp(_raw_vreg_type(acc.dtype), acc.value, lhs.value, rhs.value, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, acc.dtype)


def vmuls(src: RawVReg, scalar, *, mask: Mask) -> RawVReg:
    """Vector * scalar (same-dtype) with mask. Lowers to `asc_mul_scalar`."""
    _require_raw_mode("vmuls")
    _reject_b64("vmuls", src)
    scalar_v = _scalar_value(scalar, src.dtype)
    op = ascvec.VMulScalarOp(_raw_vreg_type(src.dtype), src.value, scalar_v, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vadds(src: RawVReg, scalar, *, mask: Mask) -> RawVReg:
    """Vector + scalar (same-dtype) with mask. Lowers to `asc_add_scalar`."""
    _require_raw_mode("vadds")
    _reject_b64("vadds", src)
    scalar_v = _scalar_value(scalar, src.dtype)
    op = ascvec.VAddScalarOp(_raw_vreg_type(src.dtype), src.value, scalar_v, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vmaxs(src: RawVReg, scalar, *, mask: Mask) -> RawVReg:
    """Vector max scalar (same-dtype) with mask. Lowers to `asc_max_scalar`."""
    _require_raw_mode("vmaxs")
    _reject_b64("vmaxs", src)
    scalar_v = _scalar_value(scalar, src.dtype)
    op = ascvec.VMaxScalarOp(_raw_vreg_type(src.dtype), src.value, scalar_v, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vmins(src: RawVReg, scalar, *, mask: Mask) -> RawVReg:
    """Vector min scalar (same-dtype) with mask. Lowers to `asc_min_scalar`."""
    _require_raw_mode("vmins")
    _reject_b64("vmins", src)
    scalar_v = _scalar_value(scalar, src.dtype)
    op = ascvec.VMinScalarOp(_raw_vreg_type(src.dtype), src.value, scalar_v, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vleakyrelu(src: RawVReg, slope, *, mask: Mask) -> RawVReg:
    """Vector leaky ReLU with scalar slope. Lowers to `asc_leakyrelu`."""
    _require_raw_mode("vleakyrelu")
    _reject_b64("vleakyrelu", src)
    scalar_v = _scalar_value(slope, src.dtype)
    op = ascvec.VLeakyReluOp(_raw_vreg_type(src.dtype), src.value, scalar_v, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, src.dtype)


def vaxpy(acc: RawVReg, src: RawVReg, scalar, *, mask: Mask) -> RawVReg:
    _require_raw_mode("vaxpy")
    _reject_b64("vaxpy", acc, src)
    if acc.dtype != src.dtype:
        raise CANNBotValueError(DiagnosticCode.INVALID_TYPE, f"vaxpy: dtype mismatch {acc.dtype} vs {src.dtype}")
    scalar_v = _scalar_value(scalar, src.dtype)
    op = ascvec.VAxpyOp(_raw_vreg_type(acc.dtype), acc.value, src.value, scalar_v, mask.value)
    _tag_raw_op(op)
    return RawVReg(op.result, acc.dtype)
