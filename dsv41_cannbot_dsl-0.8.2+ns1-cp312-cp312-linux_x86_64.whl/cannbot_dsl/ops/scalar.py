# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""3510 scalar-instruction frontend.

This module intentionally contains only target scalar instructions with no
ordinary Python-operator equivalent.  Normal Tensor point indexing retains
its cached memory semantics; use ``load_bypass`` and the explicit
``cube_store_bypass``/``vec_store_bypass`` interfaces for the C API
DCache-bypass operations.

The frontend never infers cache-coherence requirements and never inserts
``dcci``/``dci`` implicitly for direct GM accesses. Cache maintenance and
cross-core visibility remain the caller's responsibility.

Pointer consumers accept pointer SSA values and validate their type, address
space and element dtype, independently of the producing operation.

Scalar atomics execute on AIV. For integer counters without a returned old
value, use ``cube_store_bypass(..., atomic_add=True)`` on AIC or
``vec_store_bypass(..., atomic_add=True)`` on AIV. Neither interface establishes
DMA ordering or cross-core synchronization. In a MIX kernel, both AIV
subcores execute scalar atomics unless guarded by the caller.
"""

from __future__ import annotations

from enum import IntEnum as _IntEnum

from cannbot_dsl.core.diag.diagnostics import (
    CANNBotNotImplementedError, CANNBotTypeError, CANNBotValueError, DiagnosticCode,
)

import cannbot_dsl._mlir.ir as ir
from cannbot_dsl._mlir.dialects import ascscalar, cannir
from cannbot_dsl.core.utils.type_checks import is_exact_instance
from cannbot_dsl.types import dtypes
from cannbot_dsl.types._tensor import _require_pointer_type
from cannbot_dsl.types.rounding import RoundingMode, _parse_rounding
from cannbot_dsl.core.contracts.elements import (
    coerce_scalar_to_storage,
    dtype_for_storage_mlir_type,
    wrap_produced_scalar,
)
from cannbot_dsl.tensor import MemLoc
from cannbot_dsl.tensor import Tensor


class _StoreCore(_IntEnum):
    AIC = 0
    AIV = 1


class _DataBarrierScope(_IntEnum):
    GM = 0
    ALL = 1
    UB = 2


_BYPASS_DTYPES = frozenset(
    {
        dtypes.int8,
        dtypes.uint8,
        dtypes.int16,
        dtypes.uint16,
        dtypes.int32,
        dtypes.uint32,
        dtypes.int64,
        dtypes.uint64,
    }
)
_ATOMIC_ADD_DTYPES = frozenset(
    {
        dtypes.int32,
        dtypes.uint32,
        dtypes.float32,
        dtypes.int64,
        dtypes.uint64,
    }
)
_ATOMIC_INTEGER_DTYPES = frozenset(
    {
        dtypes.int32,
        dtypes.uint32,
        dtypes.int64,
        dtypes.uint64,
    }
)
_ATOMIC_COUNTER_DTYPES = frozenset({dtypes.uint32, dtypes.uint64})


def _u64_type():
    """Build ui64 only while a tracing MLIR context is active."""
    return ir.IntegerType.get_unsigned(64)


def _i64_type():
    """Build i64 only while a tracing MLIR context is active."""
    return ir.IntegerType.get_signless(64)


def _i32_type():
    """Build i32 only while a tracing MLIR context is active."""
    return ir.IntegerType.get_signless(32)


def _f32_type():
    """Build f32 only while a tracing MLIR context is active."""
    return ir.F32Type.get()


def _u64(value, *, api_name: str):
    return coerce_scalar_to_storage(value, _u64_type(), path=f"{api_name} value")


def _i64(value, *, api_name: str):
    return coerce_scalar_to_storage(value, _i64_type(), path=f"{api_name} value")


def _wrap_i64(value):
    return wrap_produced_scalar(value, storage_type=_i64_type())


def _wrap_u64(value):
    return wrap_produced_scalar(value, storage_type=_u64_type())


def popc(value):
    """Return the number of set bits in one ``uint64`` scalar."""
    return _wrap_i64(ascscalar.popc(_i64_type(), _u64(value, api_name="scalar.popc")))


def clz(value):
    """Return the leading-zero count of one ``uint64`` scalar."""
    return _wrap_i64(ascscalar.clz(_i64_type(), _u64(value, api_name="scalar.clz")))


def zero_bits_cnt(value):
    """Return the total number of zero bits in one ``uint64`` scalar."""
    return _wrap_i64(ascscalar.zero_bits_cnt(_i64_type(), _u64(value, api_name="scalar.zero_bits_cnt")))


def ffs(value):
    """Return the first set-bit position, or -1 when absent."""
    return _wrap_i64(ascscalar.ffs(_i64_type(), _u64(value, api_name="scalar.ffs")))


def ffz(value):
    """Return the first zero-bit position, or -1 when absent."""
    return _wrap_i64(ascscalar.ffz(_i64_type(), _u64(value, api_name="scalar.ffz")))


def sflbits(value):
    """Return the count of leading bits equal to the sign bit."""
    return _wrap_i64(ascscalar.sflbits(_i64_type(), _i64(value, api_name="scalar.sflbits")))


def set_nthbit(bits, idx):
    """Set bit ``idx`` in one ``uint64`` scalar."""
    return _wrap_u64(
        ascscalar.set_nthbit(
            _u64_type(),
            _u64(bits, api_name="scalar.set_nthbit"),
            _i64(idx, api_name="scalar.set_nthbit"),
        )
    )


def clear_nthbit(bits, idx):
    """Clear bit ``idx`` in one ``uint64`` scalar."""
    return _wrap_u64(
        ascscalar.clear_nthbit(
            _u64_type(),
            _u64(bits, api_name="scalar.clear_nthbit"),
            _i64(idx, api_name="scalar.clear_nthbit"),
        )
    )


def _normalize_rounding(rounding) -> RoundingMode:
    return _parse_rounding(
        rounding,
        operation="scalar.cast",
        supported=(
            RoundingMode.RN,
            RoundingMode.RNA,
            RoundingMode.RD,
            RoundingMode.RU,
        ),
    )


def cast(value, *, dtype, rounding: RoundingMode | str = RoundingMode.RN):
    """Convert one scalar with a 3510 target rounding mode.

    Supports ``dtypes.float32 -> dtypes.int32`` with this module's
    ``RoundingMode`` or a matching string. Register and SIMT conversions
    reuse the same shared ``RoundingMode`` class.
    """
    if dtype is not dtypes.int32:
        actual = getattr(dtype, "name", repr(dtype))
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE, f"scalar.cast currently supports only dtype=dtypes.int32, got {actual}"
        )
    rounding = _normalize_rounding(rounding)
    value = coerce_scalar_to_storage(value, _f32_type(), path="scalar.cast value")
    result = ascscalar.float2int32(_i32_type(), value, rounding)
    return wrap_produced_scalar(result, storage_type=_i32_type())


def _point_operands(tensor, coord, *, api_name: str):
    from cannbot_dsl.tensor import (
        _classify_tensor_index_intent,
        _make_point_coord,
        _tensor_memloc,
    )

    if not isinstance(tensor, Tensor):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE, f"{api_name}: tensor must be a Tensor, got {type(tensor).__name__}"
        )
    if _tensor_memloc(tensor) not in (MemLoc.GM, MemLoc.UB):
        raise CANNBotNotImplementedError(
            DiagnosticCode.UNSUPPORTED_FEATURE, f"{api_name}: supports only GM or UB tensors"
        )
    intent = _classify_tensor_index_intent(coord, api_name=api_name)
    coord_value = _make_point_coord(tensor, coord, api_name=api_name, intent=intent)
    from cannbot_dsl.tensor import _require_tensor, _raw

    return _raw(_require_tensor(tensor)), coord_value


def _tensor_ptr(tensor, coord) -> ir.Value:
    """Create a pointer SSA value to one GM or UB scalar element of ``tensor``.

    This is pure address formation: no memory is accessed until the pointer is
    consumed by ``scalar.load_bypass``, ``scalar.cube_store_bypass``,
    ``scalar.vec_store_bypass``, or one of the ``scalar.atomic_*`` interfaces.
    The same pointer may be reused by several such accesses.  Public entry
    point: ``Tensor.ptr(coord)``.
    """
    memref, coord_value = _point_operands(tensor, coord, api_name="tensor.ptr")
    return cannir.ScalarPtrOp(memref, coord_value).res


def _checked_ptr(ptr, allowed_dtypes, *, api_name: str) -> cannir.PointerType:
    pointer_type = _require_pointer_type(ptr, api_name=api_name)
    if MemLoc(pointer_type.memloc) != MemLoc.GM:
        raise CANNBotNotImplementedError(DiagnosticCode.UNSUPPORTED_FEATURE, f"{api_name}: supports only GM tensors")
    dtype = dtype_for_storage_mlir_type(pointer_type.dtype)
    if dtype not in allowed_dtypes:
        names = ", ".join(sorted(item.name for item in allowed_dtypes))
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"{api_name}: unsupported pointer element dtype dtypes.{dtype.name}; expected one of {names}"
        )
    return pointer_type


def data_barrier(*, scope="all"):
    """Order/complete this core's data accesses with an explicit scope.

    ``scope='gm'`` waits for GM accesses with DSB_DDR. ``scope='all'`` waits
    for GM and UB accesses with DSB_ALL; it does not include L0C or L1.
    ``scope='ub'`` waits only for UB accesses with DSB_UB. This scalar barrier
    neither completes other execution pipes nor invalidates DCache. In MIX it
    executes on every current core reaching it.
    """
    if scope not in ("gm", "all", "ub"):
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT, "data_barrier currently supports only scope='gm', 'all' or 'ub'"
        )
    from cannbot_dsl.lang.vf import _current_vf_mode
    if _current_vf_mode() is not None:
        raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "data_barrier cannot execute inside VF")
    scope_value = {
        "gm": _DataBarrierScope.GM,
        "all": _DataBarrierScope.ALL,
        "ub": _DataBarrierScope.UB,
    }[scope]
    ascscalar.DataBarrierOp(scope=int(scope_value))


def load_bypass(ptr):
    """Read one GM integer scalar through ``asc_load_dev`` (DCache bypass)."""
    storage_type = _checked_ptr(ptr, _BYPASS_DTYPES, api_name="scalar.load_bypass").dtype
    return wrap_produced_scalar(
        ascscalar.load_dev(storage_type, ptr),
        storage_type=storage_type,
    )


def _store_on_core(ptr, value, *, api_name: str, core: _StoreCore, atomic_add: bool) -> None:
    if not is_exact_instance(atomic_add, bool):
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"{api_name} atomic_add must be a compile-time bool")
    allowed_dtypes = _ATOMIC_INTEGER_DTYPES if atomic_add else _BYPASS_DTYPES
    storage_type = _checked_ptr(ptr, allowed_dtypes, api_name=api_name).dtype
    value = coerce_scalar_to_storage(value, storage_type, path=f"{api_name} value")
    if atomic_add:
        ascscalar.atomic_add(storage_type, ptr, value, core=core)
    else:
        ascscalar.store_dev(ptr, value, core=core)


def cube_store_bypass(ptr, value, *, atomic_add: bool = False) -> None:
    """Write one GM integer scalar from the AIC half of a MIX kernel.

    With the compile-time bool ``atomic_add=True``, atomically add ``value``
    instead of overwriting the destination; the old value is discarded.
    Atomic addition supports int32/uint32/int64/uint64 pointers on 3510.
    Both modes bypass DCache. Callers must establish cache coherence and
    MTE/FIXPIPE-to-Scalar ordering explicitly; neither mode is a fence or
    a MIX-wide synchronization protocol.
    """
    _store_on_core(
        ptr,
        value,
        api_name="scalar.cube_store_bypass",
        core=_StoreCore.AIC,
        atomic_add=atomic_add,
    )


def vec_store_bypass(ptr, value, *, atomic_add: bool = False) -> None:
    """Write one GM integer scalar from the AIV half of a MIX kernel.

    With the compile-time bool ``atomic_add=True``, atomically add ``value``
    instead of overwriting the destination; the old value is discarded.
    Atomic addition supports int32/uint32/int64/uint64 pointers on 3510.
    Both AIV subcores execute this operation in a MIX kernel. Guard it with
    ``get_subblock_id() == 0`` when one vector writer is required. Both modes
    bypass DCache; callers must establish cache coherence and MTE-to-Scalar
    ordering explicitly. Neither mode is a fence or MIX-wide synchronization.
    """
    _store_on_core(
        ptr,
        value,
        api_name="scalar.vec_store_bypass",
        core=_StoreCore.AIV,
        atomic_add=atomic_add,
    )


def _atomic_binary(ptr, value, *, api_name, allowed_dtypes, op):
    storage_type = _checked_ptr(ptr, allowed_dtypes, api_name=api_name).dtype
    value = coerce_scalar_to_storage(value, storage_type, path=f"{api_name} value")
    return wrap_produced_scalar(
        op(storage_type, ptr, value), storage_type=storage_type
    )


def atomic_add(ptr, value):
    """Atomically add to one GM scalar and return its value before the update.

    The instruction bypasses DCache.  Callers must establish cache coherence
    and MTE/Scalar ordering explicitly when the same GM range is shared with
    cached accesses or DMA.
    """
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_add", allowed_dtypes=_ATOMIC_ADD_DTYPES, op=ascscalar.atomic_add
    )


def atomic_sub(ptr, value):
    """Atomically subtract ``value`` from one GM scalar and return the old value."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_sub", allowed_dtypes=_ATOMIC_ADD_DTYPES, op=ascscalar.atomic_sub
    )


def atomic_exch(ptr, value):
    """Atomically replace one GM scalar and return the old value."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_exch", allowed_dtypes=_ATOMIC_ADD_DTYPES, op=ascscalar.atomic_exch
    )


def atomic_max(ptr, value):
    """Atomically write the maximum of one GM scalar and ``value``."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_max", allowed_dtypes=_ATOMIC_ADD_DTYPES, op=ascscalar.atomic_max
    )


def atomic_min(ptr, value):
    """Atomically write the minimum of one GM scalar and ``value``."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_min", allowed_dtypes=_ATOMIC_ADD_DTYPES, op=ascscalar.atomic_min
    )


def atomic_and(ptr, value):
    """Atomically apply bitwise AND and return the old GM value."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_and", allowed_dtypes=_ATOMIC_INTEGER_DTYPES, op=ascscalar.atomic_and
    )


def atomic_or(ptr, value):
    """Atomically apply bitwise OR and return the old GM value."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_or", allowed_dtypes=_ATOMIC_INTEGER_DTYPES, op=ascscalar.atomic_or
    )


def atomic_xor(ptr, value):
    """Atomically apply bitwise XOR and return the old GM value."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_xor", allowed_dtypes=_ATOMIC_INTEGER_DTYPES, op=ascscalar.atomic_xor
    )


def atomic_inc(ptr, value):
    """Atomically increment a wrapping GM counter with upper bound ``value``."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_inc", allowed_dtypes=_ATOMIC_COUNTER_DTYPES, op=ascscalar.atomic_inc
    )


def atomic_dec(ptr, value):
    """Atomically decrement a wrapping GM counter with upper bound ``value``."""
    return _atomic_binary(
        ptr, value, api_name="scalar.atomic_dec", allowed_dtypes=_ATOMIC_COUNTER_DTYPES, op=ascscalar.atomic_dec
    )


def atomic_cas(ptr, compare, value):
    """Atomically replace a GM scalar when it equals ``compare``; return old."""
    storage_type = _checked_ptr(ptr, _ATOMIC_ADD_DTYPES, api_name="scalar.atomic_cas").dtype
    compare = coerce_scalar_to_storage(compare, storage_type, path="scalar.atomic_cas compare")
    value = coerce_scalar_to_storage(value, storage_type, path="scalar.atomic_cas value")
    return wrap_produced_scalar(
        ascscalar.atomic_cas(storage_type, ptr, compare, value),
        storage_type=storage_type,
    )


__all__ = [
    "data_barrier",
    "RoundingMode",
    "cube_store_bypass",
    "atomic_add",
    "atomic_and",
    "atomic_cas",
    "atomic_dec",
    "atomic_exch",
    "atomic_inc",
    "atomic_max",
    "atomic_min",
    "atomic_or",
    "atomic_sub",
    "atomic_xor",
    "cast",
    "clear_nthbit",
    "clz",
    "ffz",
    "ffs",
    "load_bypass",
    "popc",
    "set_nthbit",
    "sflbits",
    "vec_store_bypass",
    "zero_bits_cnt",
]
