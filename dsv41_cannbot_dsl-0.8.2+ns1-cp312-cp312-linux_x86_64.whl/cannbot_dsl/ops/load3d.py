# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""One dav-3510 img2col instruction, including its per-call configuration."""

from dataclasses import dataclass
import math

from cannbot_dsl.core.diag.diagnostics import (
    CANNBotTypeError, CANNBotValueError, DiagnosticCode,
)

from cannbot_dsl._mlir import ir
from cannbot_dsl._mlir.dialects import cannir
from cannbot_dsl.core.scalar_conversion import _index_value, coerce_scalar_value
from cannbot_dsl.ops._operands import _tensor_operand


@dataclass(frozen=True, kw_only=True)
class Load3DFeatureMap:
    """NC1HWC0 source geometry, in elements; pads name each feature-map edge."""
    height: object
    width: object
    channels: object
    pad_top: object = 0
    pad_bottom: object = 0
    pad_left: object = 0
    pad_right: object = 0


@dataclass(frozen=True, kw_only=True)
class Load3DWindow:
    """Window of the unfolded matrix, before any destination transpose."""
    m_extent: object
    k_extent: object
    m_start: object = 0
    k_start: object = 0


@dataclass(frozen=True, kw_only=True)
class Load3DRepeat:
    """Repeat source advance: stride is in 16 M elements or one C0 K block."""
    count: object = 1
    stride: object = 0
    direction: object = "m"


@dataclass(frozen=True, kw_only=True)
class Load3DDestination:
    """Hardware destination placement, measured in 512-byte fractals."""
    k_stride_fractals: object
    m_start_fractals: object = 0


@dataclass(frozen=True)
class Load3DPadding:
    """A numeric value or the bit pattern of ONE source element."""
    payload: object
    storage_bits: bool

    @classmethod
    def value(cls, value):
        return cls(value, False)

    @classmethod
    def bits(cls, bits):
        return cls(bits, True)


def _selector(value, choices, name):
    if isinstance(value, str):
        if value not in choices:
            raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, f"{name} must be one of {tuple(choices)}")
        value = choices[value]
    if type(value) is bool:
        value = int(value)
    if isinstance(value, ir.Value) and isinstance(value.type, ir.IntegerType) and value.type.width == 1:
        return coerce_scalar_value(value, ir.IntegerType.get_signless(64), source_unsigned=True)
    return _index_value(value, operation=f"load3d {name}")


def _pair(value, name):
    if not isinstance(value, (tuple, list)) or len(value) != 2:
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"load3d {name} requires an (H, W) pair")
    return tuple(_index_value(v, operation=f"load3d {name}") for v in value)


def load3d(dst, src, *, feature, window, filter=(1, 1), stride=(1, 1),
           dilation=(1, 1), transpose=False, config_bank="a",
           repeat=Load3DRepeat(), destination=None, padding=Load3DPadding.value(0)):
    """Unfold an NC1HWC0 L1 feature map into L0A or L0B.

    Geometry uses elements. Repeat and destination fields use the units in
    their descriptors. Runtime integer fields must satisfy the same ranges
    and alignment rules as constants. L0B always transposes the unfolded
    matrix, independently of ``transpose``. ``config_bank`` selects all three
    configuration registers independently of the destination memory space.

    An explicit destination descriptor programs the hardware mapping; the
    caller must supply storage with that mapping and sufficient capacity.
    No storage is allocated and the source is never initialized implicitly.
    """
    for value, cls, name in ((feature, Load3DFeatureMap, "feature"),
                             (window, Load3DWindow, "window"),
                             (repeat, Load3DRepeat, "repeat"),
                             (padding, Load3DPadding, "padding")):
        if not isinstance(value, cls):
            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"load3d {name} requires {cls.__name__}")
    if destination is not None and not isinstance(destination, Load3DDestination):
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "load3d destination requires Load3DDestination or None")
    dst, src = _tensor_operand(dst), _tensor_operand(src)
    integer = lambda v: _index_value(v, operation="load3d geometry")
    parameters = [integer(v) for v in (
        feature.height, feature.width, feature.channels, feature.pad_top,
        feature.pad_bottom, feature.pad_left, feature.pad_right,
        window.m_start, window.k_start, window.m_extent, window.k_extent)]
    parameters += [*_pair(filter, "filter"), *_pair(stride, "stride"), *_pair(dilation, "dilation")]
    parameters += [_selector(transpose, {}, "transpose"),
                   _selector(config_bank, {"a": 0, "b": 1}, "config_bank"),
                   integer(repeat.count), integer(repeat.stride),
                   _selector(repeat.direction, {"m": 0, "k": 1}, "repeat.direction"),
                   integer(0 if destination is None else destination.k_stride_fractals),
                   integer(0 if destination is None else destination.m_start_fractals)]
    payload, bits = padding.payload, padding.storage_bits
    # Numeric zero has the all-zero representation for every supported type.
    if not bits and ((type(payload) is int and payload == 0) or
                     (type(payload) is float and payload == 0 and math.copysign(1, payload) > 0)):
        payload, bits = 0, True
    if bits:
        payload = _index_value(payload, operation="load3d padding bits")
    elif type(payload) is float or (isinstance(payload, ir.Value) and isinstance(payload.type, ir.FloatType)):
        payload = coerce_scalar_value(payload, ir.F32Type.get())
    else:
        payload = _index_value(payload, operation="load3d padding value")
    cannir.Load3DOp(dst, src, payload, parameters,
                    padding_bits=bits, auto_destination=destination is None)


__all__ = ["load3d", "Load3DFeatureMap", "Load3DWindow", "Load3DRepeat",
           "Load3DDestination", "Load3DPadding"]
