# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Tensor-addressed dav-3510 UB block transpose."""

from cannbot_dsl._mlir import ir
from cannbot_dsl._mlir.dialects import cannir
from cannbot_dsl.core.diag.diagnostics import (
    CANNBotTypeError,
    CANNBotValueError,
    DiagnosticCode,
)
from cannbot_dsl.core.scalar_conversion import coerce_scalar_value
from cannbot_dsl.lang.vf import _current_vf_mode
from cannbot_dsl.ops._operands import _tensor_operand


def vnchwconv(dst, src, *, dst_high_half=False, src_high_half=False) -> None:
    """Transpose UB DataBlocks using their Tensor View addresses.

    Both operands have the same 8/16/32-bit dtype and layout (R, 16, B)
    or (16, B) for R=1, where B is 32 bytes in elements. The block axis
    may be nested. R and the two repeat strides come from the Views;
    block origins need not be equally spaced. No storage is allocated.

    The b8 flags select the high/low 16 bytes of each block; the other
    destination half is preserved. Other widths require false flags.
    R=0 performs no access; R=1 emits zero hardware repeat strides.
    Runtime R must be in [0,255]; runtime addresses and strides must meet
    the same alignment, bounds and overlap constraints as constants.
    This is a kernel PIPE_V operation, outside a VF region.
    """
    if _current_vf_mode() is not None:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT, "vnchwconv is a kernel operation and must be outside a VF region"
        )

    def flag(value, name):
        if isinstance(value, bool):
            return coerce_scalar_value(value, ir.IntegerType.get_signless(1))
        from cannbot_dsl.core.ir_transport import unwrap_operand
        try:
            operand = unwrap_operand(value)
        except TypeError as exc:
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE, f"vnchwconv {name} must be a bool or a DSL boolean scalar"
            ) from exc
        if (not isinstance(operand, ir.Value) or not isinstance(operand.type, ir.IntegerType)
                or operand.type.width != 1):
            raise CANNBotTypeError(
                DiagnosticCode.INVALID_TYPE, f"vnchwconv {name} must be a bool or a DSL boolean scalar"
            )
        return operand

    cannir.VnchwconvOp(_tensor_operand(dst), _tensor_operand(src),
                      flag(dst_high_half, "dst_high_half"), flag(src_high_half, "src_high_half"))
