# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Matrix multiplication.

Split out of the former flat ``cannbotdsl/math.py``: matmul is a compute
paradigm of its own (cube unit / L0C, its own precision modes in
``cannbot_dsl.ops.cube``) rather than an elementwise tensor op.
"""

from __future__ import annotations

import cannbot_dsl._mlir.ir as ir
from cannbot_dsl._mlir.dialects import cannir
from cannbot_dsl.core.diag.diagnostics import (
    CANNBotTypeError,
    DiagnosticCode,
)
from cannbot_dsl.core.scalar_conversion import coerce_scalar_value
from cannbot_dsl.core.utils.type_checks import is_exact_instance
from cannbot_dsl.tensor import Tensor


def matmul(
    dst: Tensor,
    lhs: Tensor,
    rhs: Tensor,
    *,
    bias: Tensor | None = None,
    init=True,
    unit_flag: int = 0,
    disable_gemv: bool = True,
    mx_mode: bool = False,
):
    """Write matrix multiplication and return its actual destination View.

    Inputs are explicit Views. The output domain is M by N; K tails do not
    change an accumulator's layout. The destination retains its address map.
    Bind its actual layout explicitly before writing. Pass the returned
    View to subsequent accumulation or copies. Ignoring it discards metadata,
    without changing the write or any existing View.

    ``init`` may be a bool or an i1 SSA value. Accumulation reads and writes
    the explicitly provided destination. Bias must reside in BIAS/BT.
    ``mx_mode=True`` selects MX computation with the explicitly prepared
    paired scale storage. The compiler never infers this mode from prior loads.
    """
    if not is_exact_instance(disable_gemv, bool):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE, f"disable_gemv must be a bool, got {type(disable_gemv).__name__}"
        )
    if not is_exact_instance(mx_mode, bool):
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, f"mx_mode must be a bool, got {type(mx_mode).__name__}")
    if isinstance(init, bool):
        kwargs = {"init": init}
    else:
        # SSA i1 (typically from `Int64(...) == Int64(...)` etc.). Pass via
        # the optional operand so MatMulOp lowering wraps in scf.if.
        kwargs = {"init_value": init}
    from cannbot_dsl.tensor import _require_tensor, _raw
    if bias is not None:
        kwargs["bias"] = _raw(_require_tensor(bias))
    if isinstance(unit_flag, ir.Value):
        kwargs["unit_flag_value"] = coerce_scalar_value(unit_flag, ir.IntegerType.get_signless(32))
    else:
        kwargs["unit_flag"] = int(unit_flag)
    kwargs["disable_gemv"] = disable_gemv
    kwargs["mx_mode"] = mx_mode
    from cannbot_dsl.ops.cube import _managed_matmul_attributes, _record_matmul

    kwargs.update(_managed_matmul_attributes())
    destination = _require_tensor(dst)
    operation = cannir.MatMulOp(
        _raw(destination), _raw(_require_tensor(lhs)), _raw(_require_tensor(rhs)), **kwargs)
    result = Tensor._from_ir(operation.res)
    if hasattr(operation, "operation"):
        operation = operation.operation
    _record_matmul(operation)
    return result
