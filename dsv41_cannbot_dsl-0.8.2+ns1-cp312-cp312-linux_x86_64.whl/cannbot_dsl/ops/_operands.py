# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.

"""Shared validation of Tensor operation operands."""

from cannbot_dsl._mlir.dialects import cannir
from cannbot_dsl.core.diag.diagnostics import CANNBotTypeError, DiagnosticCode
from cannbot_dsl.core.ir_transport import unwrap_operand
from cannbot_dsl.tensor import Tensor


def _tensor_operand(x):
    """Validate and unwrap one selected Tensor memory operand."""
    from cannbot_dsl.ring_buffer import RingBuffer
    if isinstance(x, RingBuffer):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            "Select a Tensor with RingBuffer.next_write() or RingBuffer.next_read() "
            "before passing it to a data operation."
        )
    if not isinstance(x, Tensor):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"tensor operands must be Tensor, got {type(x).__name__}",
        )
    return unwrap_operand(x)


def _operand_memref_type(value):
    """Return the storage type carried by a selected Tensor operand."""
    from cannbot_dsl.tensor import _tensor_memref_type
    if not isinstance(value, Tensor):
        _tensor_operand(value)  # Preserve the public operand diagnostics.
    return _tensor_memref_type(value)


__all__ = []
