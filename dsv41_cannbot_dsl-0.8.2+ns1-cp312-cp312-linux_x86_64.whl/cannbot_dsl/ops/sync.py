# Copyright (c) 2026 Huawei Technologies Co., Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.


from enum import IntEnum as _IntEnum

import cannbot_dsl._mlir.ir as ir
from cannbot_dsl._mlir.dialects import asccube, ascscalar, ascvec, cannir
from cannbot_dsl.core.contracts.elements import wrap_produced_scalar
from cannbot_dsl.core.diag.diagnostics import (
    CANNBotNotImplementedError,
    CANNBotTypeError,
    CANNBotValueError,
    DiagnosticCode,
)
from cannbot_dsl.core.ir_transport import unwrap_operand
from cannbot_dsl.core.scalar_conversion import coerce_scalar_value
from cannbot_dsl.core.utils.type_checks import is_exact_instance
from cannbot_dsl.tensor import Tensor
from cannbot_dsl.types import dtypes


class PIPE(_IntEnum):
    S = 1
    V = 2
    M = 3
    MTE1 = 4
    MTE2 = 5
    MTE3 = 6
    ALL = 10
    FIXPIPE = 11


class CmpOp(_IntEnum):
    EQ = 0
    NE = 1
    GE = 2
    GT = 3
    LE = 4
    LT = 5


class _CoreRole(_IntEnum):
    AIC = 0
    AIV = 1


# Codegen packs flag_id into a 4-bit FFTS config field (`flagId & 0xf` in
# lib/CANNIR/Translate/TranslateToAscendC.cpp), so ids above 15 wrap silently.
MAX_SYNC_BLOCK_FLAG_ID = 15

# Flags per barrier: one for the AIV->AIC funnel, one for the cross-block
# handshake, one for the AIC->AIV release.  The ids need not be adjacent or
# related -- the hardware just shifts each into a 4-bit field -- only distinct,
# because the wait path discards mode.
#
# The cross-block flag is issued twice, once by each core type, and that is not
# a collision: mode 0 means "all cores of the issuing type"
# (pto/npu/a2a3/TPush.hpp gives CUBE_ALL_CORE_SYNC and VEC_ALL_CORE_SYNC the
# same value 0), so the issuing core type partitions the flag.
_GLOBAL_SYNC_ALL_FLAG_IDS = (0, 1, 2)
_GLOBAL_SYNC_ALL_PHASES = len(_GLOBAL_SYNC_ALL_FLAG_IDS)


def _check_flag_id(flag_id, *, api_name):
    """Range-check a constant sync_block flag id.

    Out-of-range ids are truncated silently by codegen and the sync_block ops
    declare no verifier, so this is the only guard.  Dynamic i64 SSA ids cannot
    be checked at trace time and pass through.
    """
    if isinstance(flag_id, int) and not 0 <= flag_id <= MAX_SYNC_BLOCK_FLAG_ID:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT,
            f"{api_name} flag_id must be in [0, {MAX_SYNC_BLOCK_FLAG_ID}] (codegen truncates with & 0xf), got {flag_id}"
        )


def _ensure_i32_attr(val: int) -> ir.IntegerAttr:
    """Helper to convert standard Python ints to MLIR I32 attributes."""
    if isinstance(val, ir.IntegerAttr):
        return val
    return ir.IntegerAttr.get(ir.IntegerType.get_signless(32), int(val))


def _ensure_i64_value(val) -> ir.Value:
    """Convert a Python integer or explicit i64 SSA value to MLIR i64."""
    try:
        return coerce_scalar_value(val, ir.IntegerType.get_signless(64))
    except TypeError as exc:
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            "sync/buffer ID must be an int or i64 MLIR Value "
            f"(or a convertible integer SSA value), got {type(val).__name__}"
        ) from exc


def _wait_point_operands(point, *, api_name):
    if not isinstance(point, ir.Value):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"{api_name} point must be a direct Tensor[...] result, got {type(point).__name__}",
        )

    # Tensor point indexing produces a scalar load SSA value.  Recover its
    # address operands so wait/cache operations use the location rather than the
    # already-loaded scalar.  Unsigned tensor loads add one storage cast.
    value = point
    owner = getattr(value, "owner", None)
    operation = getattr(owner, "operation", owner)
    while getattr(operation, "name", None) == "cannir.scalar_storage_cast":
        value = unwrap_operand(operation.operands[0])
        owner = getattr(value, "owner", None)
        operation = getattr(owner, "operation", owner)

    if getattr(operation, "name", None) != "cannir.tensor_load":
        producer = getattr(operation, "name", type(point).__name__)
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"{api_name} point must be a direct Tensor[...] result; got value produced by {producer}",
        )

    tensor = unwrap_operand(operation.operands[0])
    coord = unwrap_operand(operation.operands[1])
    from cannbot_dsl.core.contracts.elements import dtype_for_storage_mlir_type
    from cannbot_dsl.tensor import MemLoc

    tensor_type = cannir.TensorType(tensor.type)
    pointer_type = cannir.PointerType(tensor_type.pointer)
    if MemLoc(pointer_type.memloc) != MemLoc.GM:
        raise CANNBotNotImplementedError(
            DiagnosticCode.UNSUPPORTED_FEATURE, f"{api_name} supports only GM tensor points"
        )

    storage_type = pointer_type.dtype
    dtype = dtype_for_storage_mlir_type(storage_type)
    if dtype.name not in ("int32", "uint32"):
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE,
            f"{api_name} requires an int32 or uint32 GM tensor point, got dtypes.{dtype.name}",
        )
    return tensor, coord, storage_type


def vec_busy_wait(point, expected=None, *, cmp=CmpOp.NE, pause_nops=50):
    """Busy-wait on the vector (AIV) core or poll a caller-provided check.

    Two calling conventions:
    1. ``vec_busy_wait(check_fn)`` — ``check_fn`` is a callable (e.g. ``@jit``
       method) returning ``Boolean``.  Builds an ``scf.while`` loop that
       repeatedly calls ``check_fn`` until it returns ``True``.  The caller
       manages all UB buffer allocation, event IDs, DMA, and pipeline sync
       inside ``check_fn``.  The loop itself is core-agnostic scaffolding.
    2. ``vec_busy_wait(tensor_point, expected, cmp=CmpOp.NE, pause_nops=50)`` —
       GM polling with ``asc_load_dev``.  Loops while ``*ptr <cmp> expected`` is
       true, where <cmp> names the not-ready (keep-waiting) condition, and
       executes ``pause_nops`` NOP instructions between two polls.  On a MIX
       kernel this form executes only in the AIV clone.
    """
    if callable(point):
        from cannbot_dsl.core.frontend.api import SourceSpan
        from cannbot_dsl.core.frontend.runtime.control_flow import while_region
        from cannbot_dsl.core.frontend.runtime.hooks import RegionInfo

        def _cond():
            return ~point()

        def _body():
            return ()

        while_region(
            (),
            _cond,
            _body,
            RegionInfo(
                id=0,
                kind="while",
                span=SourceSpan("<vec_busy_wait>", 0, 0, 0, 1),
                source="<vec_busy_wait>",
                source_first_line=0,
            ),
        )
        return

    from cannbot_dsl.core.contracts.elements import coerce_scalar_to_storage

    memref, coord, storage_type = _wait_point_operands(point, api_name="vec_busy_wait")
    expected_value = coerce_scalar_to_storage(expected, storage_type, path="vec_busy_wait expected")
    if not is_exact_instance(pause_nops, int) or pause_nops < 0:
        raise CANNBotTypeError(
            DiagnosticCode.INVALID_TYPE, f"vec_busy_wait pause_nops must be a non-negative int, got {pause_nops!r}"
        )
    cmp_val = int(cmp) if isinstance(cmp, CmpOp) else int(CmpOp.NE)
    cannir.VecBusyWaitOp(memref, coord, expected_value, cmp=cmp_val, pause_nops=pause_nops)


# ==============================================================================
# Vector Core Synchronization Operations
# ==============================================================================


def dcci_single(point):
    """Invalidate the data-cache line of one GM scalar location.

    Flushes the cache line containing the location addressed by `point` so the
    next scalar-unit read observes Global Memory directly (manual cache-coherency
    barrier for cross-core communication). Use before polling a flag written by
    another core, or after publishing a scalar-unit store that must become visible
    immediately. This operation cleans and invalidates the entire cache line; it
    does not provide memory ordering or atomicity, and does not make concurrent
    writes to the same cache line safe.

    ``point`` must be a direct ``Tensor[...]`` indexing expression result
    (same calling convention as the tensor form of ``vec_busy_wait``).
    """
    memref, coord, _ = _wait_point_operands(point, api_name="dcci_single")
    cannir.dcci_single(memref, coord)


def dcci_entire_out():
    """Flush all write-out data-cache lines to Global Memory.

    Batch publish barrier after scalar-unit GM stores spanning many cache
    lines.  Complements dcci_single (one precise line) with a whole-region
    flush; stronger than needed for a single flag, cheaper per line for
    large scattered stores.
    """
    cannir.dcci_entire_out()


def dcci_entire_atomic():
    """Flush all atomic-path data-cache lines to Global Memory.

    Publish barrier after atomic read-modify-write ops on GM (counters,
    locks) so other cores observe the effects.  Companion of
    dcci_entire_out for the atomic access path.
    """
    cannir.dcci_entire_atomic()


def dci():
    """Invalidate the entire data cache, discarding dirty lines.

    Stronger than dcci_entire_*: unpublished local modifications are dropped,
    not flushed.  A full data barrier (DSB_ALL) is emitted automatically
    before the invalidation as the hardware contract requires.  Use when
    re-reading GM wholesale after other cores rewrote it and local cached
    writes are known to be disposable.
    """
    cannir.dci()


def vec_get_buf(pipe: PIPE, buf_id, mode: int = 0):
    """
    Apply for a logical buffer within the NPU Vector Core.
    """
    ascvec.get_buf(pipe, _ensure_i64_value(buf_id), _ensure_i32_attr(mode))


def vec_release_buf(pipe: PIPE, buf_id, mode: int = 0):
    """
    Release a logical buffer within the NPU Vector Core.
    """
    ascvec.release_buf(pipe, _ensure_i64_value(buf_id), _ensure_i32_attr(mode))


def vec_sync_intra_arrive(pipe: PIPE, sync_id):
    """
    Issue an intra-block arrive signal within the NPU Vector Core.
    """
    ascvec.sync_intra_arrive(pipe, _ensure_i64_value(sync_id))


def vec_sync_intra_wait(pipe: PIPE, sync_id):
    """
    Wait for an intra-block arrive signal within the NPU Vector Core.
    """
    ascvec.sync_intra_wait(pipe, _ensure_i64_value(sync_id))


def vec_sync_block_arrive(pipe: PIPE, flag_id, mode: int = 2):
    """Issue an all-core arrive signal from the NPU Vector Core."""
    _check_flag_id(flag_id, api_name="vec_sync_block_arrive")
    kwargs = {} if mode == 2 else {"mode": _ensure_i32_attr(mode)}
    ascvec.sync_block_arrive(pipe, _ensure_i64_value(flag_id), **kwargs)


def vec_sync_block_wait(pipe: PIPE, flag_id, mode: int = 2):
    """Wait for an all-core sync signal from the NPU Vector Core.

    ``mode`` does not reach the device: codegen emits ``asc_sync_block_wait``
    without it, so the matching arrive alone selects the participant set.

    It is not inert, though.  ``split-mix-kernel`` reads it to tell an
    all-cores handshake (mode 0, survives on a pure-core kernel) from an
    intra-block one (mode 2, pruned there because its partner core is gone).
    Pass the same mode as the matching arrive, or a mode 0 wait will be
    dropped on a pure-core kernel and the barrier will not hold.
    """
    _check_flag_id(flag_id, api_name="vec_sync_block_wait")
    kwargs = {} if mode == 2 else {"mode": _ensure_i32_attr(mode)}
    ascvec.sync_block_wait(pipe, _ensure_i64_value(flag_id), **kwargs)


def vec_sync_all():
    """Wait for all pending Vector Core pipeline operations."""
    ascvec.sync_all()


def vec_sync_pipe(pipe: PIPE):
    """Order operations on one Vector pipeline, including overlapping writes."""
    ascvec.sync_pipe(pipe)


def vec_sync_notify(src_pipe: PIPE, dst_pipe: PIPE, event_id: int):
    """
    Cross-pipe notify within the NPU Vector Core (asc_sync_notify).

    Issued by the producer pipe to inform the consumer pipe that a hardware
    event_id slot is now armed.
    """
    ascvec.sync_notify(
        _ensure_i32_attr(int(src_pipe)),
        _ensure_i32_attr(int(dst_pipe)),
        _ensure_i32_attr(int(event_id)),
    )


def vec_sync_wait(src_pipe: PIPE, dst_pipe: PIPE, event_id: int):
    """
    Cross-pipe wait within the NPU Vector Core (asc_sync_wait).

    AscendC convention: BOTH notify and wait carry (src_pipe=producer,
    dst_pipe=consumer). The wait blocks the consumer pipe until the
    producer signals — pass the SAME (src, dst) ordering as the matching
    vec_sync_notify; do not flip the args.
    """
    ascvec.sync_wait(
        _ensure_i32_attr(int(src_pipe)),
        _ensure_i32_attr(int(dst_pipe)),
        _ensure_i32_attr(int(event_id)),
    )


# ==============================================================================
# Cube Core Synchronization Operations
# ==============================================================================


def cube_get_buf(pipe: PIPE, buf_id, mode: int = 0):
    """
    Apply for a logical buffer within the NPU Cube Core.
    """
    asccube.get_buf(pipe, _ensure_i64_value(buf_id), _ensure_i32_attr(mode))


def cube_release_buf(pipe: PIPE, buf_id, mode: int = 0):
    """
    Release a logical buffer within the NPU Cube Core.
    """
    asccube.release_buf(pipe, _ensure_i64_value(buf_id), _ensure_i32_attr(mode))


def cube_sync_intra_arrive(pipe: PIPE, sync_id):
    """
    Issue an intra-block arrive signal within the NPU Cube Core.
    """
    asccube.sync_intra_arrive(pipe, _ensure_i64_value(sync_id))


def cube_sync_intra_wait(pipe: PIPE, sync_id):
    """
    Wait for an intra-block arrive signal within the NPU Cube Core.
    """
    asccube.sync_intra_wait(pipe, _ensure_i64_value(sync_id))


def cube_sync_block_arrive(pipe: PIPE, flag_id, mode: int = 2):
    """Issue an all-core arrive signal from the NPU Cube Core."""
    _check_flag_id(flag_id, api_name="cube_sync_block_arrive")
    kwargs = {} if mode == 2 else {"mode": _ensure_i32_attr(mode)}
    asccube.sync_block_arrive(pipe, _ensure_i64_value(flag_id), **kwargs)


def cube_sync_block_wait(pipe: PIPE, flag_id, mode: int = 2):
    """Wait for an all-core sync signal from the NPU Cube Core.

    ``mode`` does not reach the device: codegen emits ``asc_sync_block_wait``
    without it, so the matching arrive alone selects the participant set.

    It is not inert, though.  ``split-mix-kernel`` reads it to tell an
    all-cores handshake (mode 0, survives on a pure-core kernel) from an
    intra-block one (mode 2, pruned there because its partner core is gone).
    Pass the same mode as the matching arrive, or a mode 0 wait will be
    dropped on a pure-core kernel and the barrier will not hold.
    """
    _check_flag_id(flag_id, api_name="cube_sync_block_wait")
    kwargs = {} if mode == 2 else {"mode": _ensure_i32_attr(mode)}
    asccube.sync_block_wait(pipe, _ensure_i64_value(flag_id), **kwargs)


def cube_sync_all():
    """Wait for all pending Cube Core pipeline operations."""
    asccube.sync_all()


def cube_sync_pipe(pipe: PIPE):
    """Wait for all pending operations issued on one Cube pipeline."""
    asccube.sync_pipe(pipe)


def cube_sync_notify(src_pipe: PIPE, dst_pipe: PIPE, event_id: int):
    """
    Cross-pipe notify within the NPU Cube Core (asc_sync_notify).

    The canonical use is to serialize a producer pipe's GM/L1 write against
    a consumer pipe's GM/L1 read on the same memory region — e.g., after a
    FIXPIPE drains L0C → GM, notify MTE2 before re-reading the same GM tile
    via copy_gm2l1. AscendC does NOT auto-serialize across pipes.
    """
    asccube.sync_notify(
        _ensure_i32_attr(int(src_pipe)),
        _ensure_i32_attr(int(dst_pipe)),
        _ensure_i32_attr(int(event_id)),
    )


def cube_sync_wait(src_pipe: PIPE, dst_pipe: PIPE, event_id: int):
    """
    Cross-pipe wait within the NPU Cube Core (asc_sync_wait).

    AscendC convention: BOTH notify and wait carry (src_pipe=producer,
    dst_pipe=consumer). The wait says 'block on the consumer pipe until
    the producer pipe has signalled this event_id'. So callers should pass
    the SAME (src, dst) ordering they used for cube_sync_notify — do not
    flip the args.

    event_id should cycle over a small pool (typically 0-3 for the cube
    core) — reusing the same id sequentially is safe because each
    notify/wait pair drains before the id is reused.
    """
    asccube.sync_wait(
        _ensure_i32_attr(int(src_pipe)),
        _ensure_i32_attr(int(dst_pipe)),
        _ensure_i32_attr(int(event_id)),
    )


# ==============================================================================
# Grid-wide Synchronization
# ==============================================================================


def global_sync_all(*, flag_ids=None):
    """Barrier across every core of the launch.

    Emits the full four-phase sequence.  What survives depends on how the
    kernel classifies, which ``split-mix-kernel`` decides late in the pass
    pipeline from the ops the whole function ended up emitting:

    ======  ==============================  ============================
    phase   handshake                       kept on
    ======  ==============================  ============================
    1       AIV -> AIC, within block (m=2)  mix
    2       all AIC, across blocks   (m=0)  mix, pure-AIC
    3       all AIV, across blocks   (m=0)  mix, pure-AIV
    4       AIC -> AIV, within block (m=2)  mix
    ======  ==============================  ============================

    On a mix kernel all four run.  Phase 2 is the grid barrier; phases 1 and 4
    funnel the vector cores through the AIC of their own block, which is the
    only cross-block path they have.  Phase 3 is a redundant AIV-to-AIV meeting
    point inside that funnel -- every AIV reaches it anyway, so it reorders
    nothing.

    On a pure-core kernel ``split-mix-kernel`` prunes the other core's ops and
    the mode 2 handshakes, whose partner no longer runs, leaving a single
    mode 0 barrier: phase 2 on pure AIC, phase 3 on pure AIV.  That is why this
    function does not take a "which core am I" argument -- at trace time the
    kernel body after this call does not exist yet, so any answer here would be
    a guess about ops not yet emitted.  Emitting the superset and letting the
    pass prune moves the decision to where the answer is known.

    Phases 2 and 3 share a flag id.  mode 0 means "all cores of the issuing
    type" -- ``pto/npu/a2a3/TPush.hpp`` gives ``CUBE_ALL_CORE_SYNC`` and
    ``VEC_ALL_CORE_SYNC`` the same value 0 -- so the issuing core type
    partitions the flag and the two handshakes cannot alias.  The three ids
    that *are* distinct must stay so: codegen drops ``mode`` on the wait path,
    leaving the id as the only thing telling one phase from the next.

    The leading sync_all calls are load-bearing: an FFTS arrive drains only the
    pipe it is issued on, so without them a peer can observe the flag before an
    in-flight write on another pipe.

    Args:
        flag_ids: three distinct ids in [0, 15] -- funnel-in, cross-block,
            funnel-out. Defaults to the fixed triple (0, 1, 2), reused by
            successive completed barriers, including statically unrolled loops.
            Keep these IDs separate from overlapping manual FFTS protocols,
            or supply a different explicit triple for the barrier.

    This barrier establishes completion for the old protocols.
    ``onchip_rewind()`` declares the explicit address/Buffer-ID allocation
    boundary; its default also resets counter ID allocation. Without an
    explicit allocation boundary, IDs continue to be allocated sequentially,
    without automatic lifetime reuse or wraparound. The allocation boundary
    does not insert a barrier and cannot replace this completion relationship.

    Deadlocks if the launch does not fit one resident wave: a mode 0 phase
    makes resident blocks wait for blocks the scheduler cannot start.
    ``block_dim`` must not exceed the device core count for the issuing core
    type.  That cannot be checked here -- this function has no visibility into
    block_dim.
    """
    if flag_ids is None:
        flag_ids = _GLOBAL_SYNC_ALL_FLAG_IDS
    else:
        flag_ids = list(flag_ids)
        if len(flag_ids) != _GLOBAL_SYNC_ALL_PHASES:
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT,
                f"global_sync_all needs {_GLOBAL_SYNC_ALL_PHASES} flag ids (one per phase), got {len(flag_ids)}"
            )
        if len(set(flag_ids)) != len(flag_ids):
            raise CANNBotValueError(
                DiagnosticCode.INVALID_ARGUMENT,
                "global_sync_all flag_ids must be distinct -- the wait path "
                f"ignores mode, so a shared id merges two phases: {flag_ids}"
            )
        for flag_id in flag_ids:
            _check_flag_id(flag_id, api_name="global_sync_all")

    aiv_ready_flag_id, cross_block_flag_id, aic_aiv_ready_flag_id = flag_ids

    # Drain both cores' pipelines before anything is announced externally.
    cube_sync_all()
    vec_sync_all()

    # 1. AIV -> AIC, within block.
    vec_sync_block_arrive(PIPE.MTE3, aiv_ready_flag_id, mode=2)
    cube_sync_block_wait(PIPE.S, aiv_ready_flag_id)

    # 2. All AIC, across blocks -- the grid barrier.
    cube_sync_block_arrive(PIPE.FIXPIPE, cross_block_flag_id, mode=0)
    cube_sync_block_wait(PIPE.S, cross_block_flag_id, mode=0)

    # 3. All AIV, across blocks.  Redundant on a mix kernel -- every AIV is
    # already held by phases 1 and 4 -- and the whole barrier on a pure-AIV
    # kernel, once the pass has pruned the cube side.  Shares phase 2's flag:
    # mode 0 is partitioned by issuing core type.
    vec_sync_block_arrive(PIPE.MTE3, cross_block_flag_id, mode=0)
    vec_sync_block_wait(PIPE.S, cross_block_flag_id, mode=0)

    # 4. AIC -> AIV, within block.
    cube_sync_block_arrive(PIPE.MTE3, aic_aiv_ready_flag_id, mode=2)
    vec_sync_block_wait(PIPE.S, aic_aiv_ready_flag_id)


def onchip_rewind(reset_sync_id=True):
    """Declare an explicit address/Buffer-ID allocation boundary.

    Reset Buffer-ID allocation to the beginning of its hardware namespaces.
    With reset_sync_id=True, also reset counter ID allocation; False preserves
    the counter allocation phase. The reset follows compile-time declaration
    order, including declarations in subsequent mutually exclusive branches.
    IDs are otherwise allocated sequentially,
    without automatic lifetime reuse or wraparound.

    This boundary does not insert a hardware barrier or release live resources.
    Sharing across a reset requires proven runtime exclusivity or completion;
    resources used across it keep their IDs reserved. Address reuse requires
    dead storage.
    This boundary does not reset any RingBuffer's head or tail position.
    """
    if not is_exact_instance(reset_sync_id, bool):
        raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "reset_sync_id must be a static bool")
    cannir.OnChipRewindOp(reset_sync_id=reset_sync_id)


# ==============================================================================
# Cooperative cross-core synchronization using caller-zeroed GM counters.
#
# P/C are contributions per round, not core identities. Each dynamic acquisition
# creates one ticket, which may be ended only once. Callers own role selection,
# round progression, payload completion/cache maintenance and deadlock freedom.
# There are no implicit payload fences or counter initialization operations.
# ==============================================================================


def _outside_vf():
    from cannbot_dsl.lang.vf import _current_vf_mode
    if _current_vf_mode() is not None:
        raise CANNBotValueError(
            DiagnosticCode.INVALID_ARGUMENT, "GroupSync is a scalar-core operation and cannot execute inside VF"
        )


@ir.register_value_caster(cannir.GroupSyncTicketType.get_static_typeid())
class _GroupSyncTicket(ir.Value):
    @property
    def slot(self):
        return wrap_produced_scalar(cannir.GroupSyncTicketSlotOp.build_generic(
            operands=[self], results=[ir.IntegerType.get_signless(64)]).results[0])

    @property
    def round(self):
        return wrap_produced_scalar(cannir.GroupSyncTicketRoundOp.build_generic(
            operands=[self], results=[ir.IntegerType.get_signless(64)]).results[0])


@ir.register_value_caster(cannir.GroupSyncType.get_static_typeid())
class GroupSync(ir.Value):
    """Bind the byte origin of a GM Tensor without touching memory.

    ``depth``, ``producers`` and ``consumers`` are positive compile-time ints.
    Producers use acquire/commit; consumers use wait/release.
    Tensor dtype, shape, capacity and contiguity are not checked. The caller
    provides 128 * depth bytes starting at a 64-byte-aligned Tensor origin.
    Each i64 counter occupies the first 8 bytes of its own 64-byte slot:
    produced[s] at origin + 64*s, consumed[s] at origin + 64*(depth+s).
    The caller must zero the workspace before execution and ensure its lifetime
    and exclusive ownership. Counters must never exceed INT64_MAX. A ticket
    cannot be stored, passed through a standalone ABI, or carried as loop state;
    lexical captures and inline @jit helpers preserve its SSA identity.
    """
    def __init__(self, workspace, *, depth=None, producers=None, consumers=None):
        # The value caster and inline helper transport rebuild an existing SSA
        # handle without rebinding its workspace or specifying its type again.
        if (depth is None and producers is None and consumers is None and
                isinstance(workspace, ir.Value) and isinstance(workspace.type, cannir.GroupSyncType)):
            super().__init__(workspace)
            return
        _outside_vf()
        for name, value in (("depth", depth), ("producers", producers), ("consumers", consumers)):
            if type(value) is not int:
                raise CANNBotTypeError(
                    DiagnosticCode.INVALID_TYPE, f"GroupSync {name} must be a compile-time Python int"
                )
            limit = (2**63 - 1) // 128 if name == "depth" else 2**63 - 1
            if not 1 <= value <= limit:
                raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, f"GroupSync {name} must be in [1, {limit}]")
        if not isinstance(workspace, Tensor):
            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "GroupSync workspace must be a Tensor")
        ty = cannir.GroupSyncType.get(depth, producers, consumers)
        value = cannir.GroupSyncBindOp.build_generic(
            operands=[unwrap_operand(workspace)], results=[ty]).results[0]
        super().__init__(value)

    def acquire(self, q, *, blocking=True):
        """Wait for a reusable slot and return a producer ticket for round q.

        With ``blocking=False``, check once and return ``(ready, ticket)``.
        Only use the ticket and produce/commit when ready is true. A failed
        check changes no counters; retry by calling acquire again.
        """
        return self._acquire(q, producer=True, blocking=blocking)

    def commit(self, ticket):
        """Publish one producer contribution for the acquired ticket."""
        self._end(ticket, producer=True)

    def wait(self, q, *, blocking=True):
        """Wait for a fully produced round and return a consumer ticket.

        With ``blocking=False``, check once and return ``(ready, ticket)``.
        Only use the ticket and consume/release when ready is true. A failed
        check changes no counters; retry by calling wait again.
        """
        return self._acquire(q, producer=False, blocking=blocking)

    def release(self, ticket):
        """Publish one consumer contribution for the ticket returned by wait."""
        self._end(ticket, producer=False)

    def _acquire(self, q, *, producer, blocking):
        _outside_vf()
        if not isinstance(blocking, bool):
            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "GroupSync blocking must be a compile-time Python bool")
        if not (type(q) is int or (isinstance(q, ir.Value) and
                isinstance(q.type, ir.IntegerType) and q.type.width > 1)):
            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "GroupSync round must be an integer scalar")
        if type(q) is int and q < 0:
            raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "GroupSync round must be nonnegative")
        round_value = dtypes.int64(q)
        role = "producer" if producer else "consumer"
        ty = cannir.GroupSyncTicketType.get(self.type, role)
        op = cannir.GroupSyncProducerAcquireOp if producer else cannir.GroupSyncConsumerAcquireOp
        results = [ty] if blocking else [ty, ir.IntegerType.get_signless(1)]
        acquired = op.build_generic(operands=[self, round_value], results=results,
                                    attributes={"blocking": ir.BoolAttr.get(blocking)})
        ticket = acquired.results[0]
        if blocking:
            return ticket
        return wrap_produced_scalar(acquired.results[1]), ticket

    def _end(self, ticket, *, producer):
        _outside_vf()
        if not isinstance(ticket, _GroupSyncTicket):
            raise CANNBotTypeError(DiagnosticCode.INVALID_TYPE, "GroupSync commit/release requires an acquired ticket")
        role = "producer" if producer else "consumer"
        if ticket.type.role != role or ticket.type.sync_type != self.type:
            raise CANNBotValueError(DiagnosticCode.INVALID_ARGUMENT, "ticket role/spec must match commit/release")
        op = cannir.GroupSyncProducerCommitOp if producer else cannir.GroupSyncConsumerReleaseOp
        op.build_generic(operands=[self, ticket], results=[])
